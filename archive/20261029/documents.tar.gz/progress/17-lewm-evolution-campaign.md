# Task 17: discover compact LeWM planning controllers

26 October 2026. Sachin authorized this campaign and a GPU rental in the
[authorization receipt](receipts/17-authorization.json). Implementation and execution
will continue in Codex on the rental because the workstation must shut down.
The scope is a new evolutionary comparison, not a continuation of task 16's queues.

## Objective and evidence

Determine whether evolution discovers a compact planning controller that improves
safe task completion, or reaches comparable performance with less search work, relative
to parameter random search and ordinary learning. Keep the task-16 fixed controller as
a strong reference and retune fixed settings on the new development panel.

Task 16 completed 2,376 valid episodes. Its fixed/adaptive fresh-case scores were
238/240 versus 240/240 in TwoRoom, and 218/240 versus 212/240 in Reacher, with no observed
margin breaches. At Reacher's 1.5 cm clearance the fixed score was 99/120, leaving a
meaningful completion deficit. Task 16 established a configuration lever, not an
adaptive or evolutionary advantage. Tasks 12 and 13 previously found random search
beating or matching NSGA-II. These findings remain in the record.

Read `AGENTS.md`, `firstPrinciples.md`, `progress/receipts/16-lewm-results.md`,
`configs/lewm16/selected-controllers.json`, and the task-16 runtime, planner and tests.
The current explicit authorization permits this LeWM study alongside the broader
ManiGuard research direction. It does not permit any old launch or another task's rental.

## Limits and operating window

- New task-17 rental cap: **$10 cumulative**, including compute, disk, transfer,
  failed setup and cleanup. Task 16's completed allocation is separate.
- One host, up to four GPUs. The rental record fixes its identity, rate and deadline.
- Five hours from rental creation, including setup, implementation, experiments and
  preservation. The remote guard starts closeout 30 minutes before the deadline.
- Protect the last 30 minutes and at least $1 for preservation. Start no batch that
  cannot finish and be preserved inside the remaining allocation.
- Codex uses the user's own login and plan. No separately billed OpenAI API key or
  paid third-party service is authorized by the rental allowance.
- The workstation is not a runtime dependency. Queues, guards, source snapshots and
  private uploads run on the rental. Do not launch another rental from this one.

This is a continuous implementation and research campaign. Repair numerical, renderer,
counter and integration failures. Diagnose an unsuccessful learner before interpreting
it. Use versioned development amendments within scope; freeze the optimizer comparison
before its first training outcome. A positive result is not required.

## Controller class

Use a small linear mode selector, initially six inputs including the bias and six
planning modes, for **36 trainable coefficients** per environment. All three adaptive
optimizers use exactly this representation and decoder. The model, normalization and
safety checker stay frozen. No new learned encoder or progress readout is needed.

Inputs are bias, clipped relative latent-goal-cost improvement, bounded observed
prediction error, previous feasible-candidate fraction, normalized replan index and
requested margin divided by the environment's maximum tested margin. Use only past
and current task-side observations. Freeze clipping, missing-first-step values and
error normalization before comparison. No true goal distance, true position or privileged
candidate endpoint enters the selector. The trusted safety checker retains its declared
state/dynamics access. Requested margin is an input, never an output.

Proposed mode libraries are `(horizon, exploration scale, retention, correlation)`:

| Mode | TwoRoom | Reacher |
| --- | --- | --- |
| 0 | (2, 1, 0, 0) | (3, 1, 0.25, 0.5) |
| 1 | (2, 2, 0.5, 0.5) | (3, 1, 0.5, 0) |
| 2 | (2, 2, 0.5, 0) | (2, 1, 0.25, 0.5) |
| 3 | (3, 1, 0.25, 0.5) | (3, 2, 0.5, 0.5) |
| 4 | (2, 1, 0.25, 0.5) | (2, 2, 0.5, 0) |
| 5 | (3, 2, 0.5, 0.5) | (5, 1, 0, 0) |

This contains every task-16 fixed winner. A bias-only selector can always choose a
constant mode. Expose correlation consistently and recheck retained candidates after
each state transition. A mode switch never changes the five-action executable block,
50-action episode limit, success definition or requested hazard inflation.

Use a softmax distribution for training exploration for all three optimizers and a
frozen deterministic argmax decoder for validation and deployment. Record this
training/deployment difference. Include common constant and margin-routing anchors;
charge every anchor evaluation equally and make their parameters available to all
methods. Seed candidate parameters, mode sampling and planner sampling separately.

## Comparators and training

1. Native and canonical SafeCEM provide contemporary protocol context on a small,
   prespecified panel. They are not the main evolutionary comparator.
2. Replay the task-16 fixed winners as historical-information anchors on new cases.
3. Tune a fresh fixed mode per environment and margin over the same six-mode library.
4. Parameter random search samples selector weights from the same initial distribution
   and support as evolution, with the same shared anchors and selection allowance.
5. Ordinary learning trains the same selector with REINFORCE and a running baseline.
   Keep it simple: no critic network or uncharged replay data. Log reward variance,
   entropy, gradient norms, coefficient changes and actual selected modes.
6. One evolution strategy optimizes those coefficients with antithetic perturbations.
   A practical starting recipe is four perturbation directions, eight candidates per
   generation, three common case/seed evaluations per candidate and eight generations.
   Freeze step size, perturbation scale, bounds, update formula and fitness transform
   after development checks. Do not run an algorithm tournament.

For the matched reference schedule, each optimizer replicate gets 24 common-anchor
episodes, 192 training episodes and 24 deterministic validation episodes. Random search
uses the same eight batches of eight candidates. REINFORCE uses eight batches of 24
episodes; its gradient updates use only those rollouts. No free validation or extra
learning-method hyperparameter search. Freeze the concrete initialization and validation
candidate-selection rule before training, including a fallback for collapsed learners.
Any precomparison debugging/tuning interactions are recorded as development, available
to all methods and separate from the comparison's per-run budget.

The primary training signal is requested-safe completion. Freeze one bounded scalar
utility for all methods, for example `safe_success - 0.1 * J / 50`, assigning J=50 to
unsuccessful or unsafe outcomes. Keep violations separately visible and disqualify any
unsafe finalist before selection. The identical checker enforces the requested margin;
do not use safety penalties to justify relaxing it. Do not reward true goal distance
or a privileged reference objective. Inspect learning diagnostics instead of changing
the reward after comparison outcomes have been read.

## Budgets and fairness

The episode schedule is a workload estimate, not proof of equal interaction cost.
Freeze explicit per-run ceilings for executed actions, predictor steps and checker work,
including candidate rejection, repeated checks, anchor and validation evaluations.
At most 50 actions and ten replans per episode give conservative reservations. Match
the per-replan predictor-work allowance from task 16: 50,000 candidate steps TwoRoom,
15,000 Reacher, plus recorded selected-plan predictions. Retain the same exact checker.

Actual early completion and horizon choices change total costs. Report those actual
counts and learning curves against consumed resources. Claim equality of allowances
only where the scheduler enforces it. For a search-efficiency claim, compare frozen
validation checkpoints at common consumed-resource budgets, charging the validation
itself. If exact resource matching is infeasible, label the comparison by its actual
budget design and do not advertise it as equal simulator interaction work.

Use five independent optimizer seeds per method and environment. These are the units
of optimizer replication; multiple episodes from one trained selector do not replace
them. Keep methods in each case/seed block on the same physical host and GPU where
possible, record placement, and reevaluate competing candidates on common batches.
Never compare an old elite score with a new offspring score from different cases.

## Panels, endpoints and workload

Freeze new development, validation and final panels before training. Generate cases
with task 16's input-valid geometry ranges and new nonoverlapping seeds and IDs. Check
geometry and rendering only; never filter by controller success. Task-16 final cases
are now known evidence and are not task-17 held-out cases. Keep true final case files
outside training loaders and log access. Reacher geometric validity does not prove
feasibility within 50 actions; retain all accepted cases in the denominator.

Primary endpoint: Reacher requested-safe completion at 1.5 cm on fresh cases, comparing
evolution with random search, ordinary learning and the newly tuned fixed controller.
Also report Reacher at 1 cm and TwoRoom at 4 and 6 px. TwoRoom's completion ceiling makes
nondegradation and planning cost useful secondary outcomes. Freeze a concrete practical
effect target before running; retain the task-16 provisional +10 percentage-point target
as context, not a rule for stopping or selecting more favorable cases.

Default final panel: 20 cases per environment, two margins and two fresh planner seeds.
Evaluate all five selected controllers from each of the three adaptive methods. The two
fixed references need one shared final evaluation each, not five duplicate copies.

| Allocation | Default episode allowance |
| --- | ---: |
| Engineering and development diagnostics | 48 |
| Contemporary native/canonical context | 72 |
| Fixed-mode tuning, 6 modes x 2 margins x 2 environments x 6 cases x 2 seeds | 288 |
| Adaptive methods, 3 methods x 5 runs x 2 environments x 240 episodes | 7,200 |
| Selected adaptive controllers on final panel | 2,400 |
| Historical and newly tuned fixed references on final panel | 320 |
| Total | 10,328 |

Do not add these episodes blindly. Measure real throughput, including model loading,
simulation checks, learner updates and preservation, then admit the schedule before
optimizer outcomes. The predeclared compact alternative keeps five optimizer repeats,
uses six training rounds (144 episodes), and the first twelve sealed final cases per
environment: 48 + 72 + 288 + 5,760 + 1,440 + 192 = **7,800** episodes.
If neither fits, freeze a smaller balanced schedule with an explicit loss of scope before
training. Do not silently drop the ordinary learner or spend the final reserve.

Choose each deployed controller solely on its assigned validation allowance. Freeze
all selected parameters and final evaluation code before final outcomes. Do not tune
on the final panel. Analyse safe completion, original-hazard violations, requested-margin
breaches, unfinished episodes, censoring, engagement, failure-capped J and resources.
Use uncertainty over independent optimizer runs and whole case blocks, retaining paired
comparisons. Report per-environment results and all optimizer runs, not only each method's
best run. Small-sample intervals and five runs have limited power; report uncertainty.

## Implementation, preservation and completion

Create fresh `configs/lewm17`, `outputs/lewm17`, task-17 receipts and entry points. Reuse
task-16 code as reviewed source; do not execute its launchers, overwrite its evidence or
regenerate its panels. All task-17 paths must be independent. Preserve the exact source
and manifests before each eligible batch. Validate native identity, constant-mode parity,
checker replay, information isolation, action normalization, and the learner gradient
with a synthetic problem before interpreting real learning output.

The remote repository is a verified working-tree snapshot, including uncommitted source.
It is not a claim that the old git HEAD contains the new campaign. Pin environment/model
identities from task 16. The preparation script creates fresh task-17 checkpoint paths.
The root pyproject/uv lock remains unrelated to this remote environment.

Use the provided private preservation script throughout, and extend its allowlist if
new task-17 evidence paths are added. The destination is the existing private dataset
`Sachioster/maniguard-jar-replication-20261022`, under `17_lewm17_campaign/<instance>/`.
Verify uploaded files by downloading them at the pinned revision and checking hashes.
Preserve code, configs, every attempt, logs, optimizer checkpoints, manifests and final
reports. Exclude secrets, Codex authentication, caches and downloaded frozen model weights;
their pinned public identities are sufficient. The local laptop cannot be the only backup.

Finish with `progress/receipts/17-lewm-evolution-results.md`, machine-readable analysis,
the progress index and one short Odyssey entry. Record scientific shortfalls honestly.
Preserve the final package before requesting self-destruction. The container's own API
token controls only this rental. Record deletion acknowledgement separately from external
absence verification; a dying process cannot claim to have checked later provider state.
The user can verify the final absent status from another device or the Vast console.

Read `progress/17-remote-codex.md` for operational details and
`progress/goal-prompt-17-lewm-evolution.md` for the remote agent's starting instruction.
Published algorithm references: [ES](https://arxiv.org/abs/1703.03864) and
[REINFORCE](https://doi.org/10.1007/BF00992696). These are established methods; no novelty
claim follows simply from applying them here.
