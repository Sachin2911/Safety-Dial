# Task 15 recovery and confirmation handoff

Prepared 26 October 2026. Give this entire prompt to the agent taking over in the
existing Safety-Dial workspace. The latest git commit alone does not contain all
task 15 code, receipts or local evidence.

## Goal and scope

Take over task 15, the phase-gated regrasp adapter for frozen pi0.5 on ManiGuard Jar.
Recover and account for its existing evidence, finish the authorized confirmation
where the cumulative limits permit, produce an honest final result, preserve the
evidence privately, and close the rental. Sachin requested this handoff so another
agent can complete task 15 while the main research discussion focuses on LeWM.

Continue autonomously through ordinary engineering repairs and the authorized rental
workflow. A replacement rental is conditional on the financial and scientific
admission below; this is not a fresh $10 allocation. Do not start LeWM, DSRL, an
evolutionary search, new adapter arms or a broader Jar study. No success outcome is
required: a completed negative comparison is a valid result. If a hard limit prevents
completion, preserve and report the actual shortfall; never bypass it to claim success.

Read [AGENTS.md](../AGENTS.md) and [firstPrinciples.md](../firstPrinciples.md), then:

1. [Task 15 protocol](15-regrasp-dial-plan.md), including the stage D amendment.
2. [Current results](receipts/15-regrasp-results.md).
3. [Provider and local-evidence check](receipts/15-regrasp-handoff-status-20261026.json),
   [posted billing](receipts/15-regrasp-handoff-billing-20261026.json), and
   [private evidence lookup](receipts/15-regrasp-handoff-private-check-20261026.json).
4. [Live v2 source freeze](receipts/15-regrasp-live-v2.json),
   [stage D declaration](receipts/15-regrasp-stage-d.json), and
   [stage D source freeze](receipts/15-regrasp-stage-d-v1.json).
5. [Original rental](rental-regrasp15-20261025.json),
   `outputs/regrasp15/control/finance.json`, and `configs/regrasp15/design.json`.

The root plan and original rental contain stale immediate-action/status text. The
task-specific records and this dated handoff govern recovery; they do not authorize
resuming any other historical task.

## Verified starting state

- At **2026-10-26 07:33:17 UTC (09:33:17 SAST)**, a successful, schema-validated
  Vast `show instances` query contained neither instance **57727030** nor any other
  instance labelled `jar-regrasp15-*`. The original machine ID was 148266. It is absent
  from the account list, not merely known to be stopped. Its exact removal time was
  not established. Do not trust the old rental file's `running` snapshot.
- Posted charges at 07:35 UTC total **$2.555**: $1.595 GPU, $0.805 storage,
  $0.147 download and $0.008 upload. These are provisional, not a certified final
  bill or a fresh spending allowance. The first unsuccessful create was previously
  recorded as absent with zero actual charges.
- Stage 0 is complete. Four stage A engineering episodes and all 80 stage B screen
  episodes are validated locally.
- The local stage C ledger contains **four validated episodes**: jobs 300 through
  303, two native and two `select-0.06`. A fifth start, job 304, native task 6 with
  seed 152000, launched at 05:29:23 UTC and has no locally recorded exit or validation.
  Count that attempted start and recover its trace if possible. Its outcome is unknown.
- There is no local stage C completion marker or stage D ledger. This is a statement
  about the available mirror, not proof that no later work happened remotely.
- A metadata-only check at private dataset revision
  `c68069b2168156f13945e23d8488d7b1d97b073d` found neither
  `receipts/regrasp15/` nor `recordings/regrasp15/`. This does not rule out a newer
  revision, a different prefix or another local copy.
- The saved live-v2 and stage-D source archives match every source hash in their
  respective freezes. Paths and SHA-256 values are in the handoff-status receipt.
  They are under `outputs/regrasp15/source/`, with copies in the remote mirror.

## Recover before renting

Recheck provider status, billing and private evidence. Inspect the local mirror,
other task-15 copies and any preserved completion records. Look for complete C/D
results before scheduling a repeat. Preserve an inventory and immutable copy of the
existing local evidence before operational changes. Record which files are missing
and what is merely unknown; absence of a final backup is not evidence of zero work.

Do not change or aggregate partial confirmation outcomes to choose a new arm, speed
threshold or task panel. The frozen stage B decision already selected `select-0.06`.
The projection condition is separately declared. Original results remain intact.

If a complete original-host confirmation is recovered, validate and analyze it before
considering any further rollout. A provider-absent rental must not be restarted by
blindly running the old launcher.

## Remaining scientific comparison and replacement-host rule

Retain these conditions and endpoints:

- Stage C: native versus `select-0.06`, 48 episodes per arm, tasks 0, 3, 6 and 9,
  seeds 152000 through 152011, with the original deterministic order.
- Stage D: `project-0.10`, 48 episodes on those same tasks and seeds, compared with
  stage C native from the **same physical host and recovery cohort**. Retain the
  declared sequential stage-D schedule and report its timing caveat.
- Keep the frozen policy, K = 32, gate, geometry, thresholds, episode horizon,
  observation/render profile, 20 Hz control, and eight executed actions per chunk.
  Held-out tasks remain untouched. No policy-weight updates occur.
- Report strict safe completion, benchmark success, raw and counted violations,
  unfinished episodes, engagement, grasp, post-gate tips/stalls and adapter activity.
  Keep the declared C and D analyses separate, with their uncertainty and shared
  native comparator explicit. Never pool the screen into confirmation or claim broad
  safety non-inferiority from a small observed violation difference.

If a replacement host is needed, **do not complete only the intervention arm there
and compare it with old-host native episodes**. Prepare a recovery amendment before
any new simulator episode. The preferred recovery is one complete new-host cohort:
48 native, 48 selection and 48 projection episodes, plus required live engineering.
The original four validated C episodes and unfinished fifth attempt remain a separate
historical cohort and are fully charged. Reusing the already frozen task/seed schedule
is a recorded host replication, not a claim that those seeds were never seen.

Use fresh paths such as `outputs/regrasp15r1/`, fresh rental records and new
`15-regrasp-recovery-*` freezes. Bind the physical host, episode identities, analysis
cohort, imported historical costs and cumulative interaction ceilings before launch.
Do not overwrite the old namespace, silently relabel its episodes as new-host work,
or treat old engineering records as live verification on the replacement.

This recovery design must fit the remaining allocation. If it cannot, prepare a
concrete cost/time estimate and the required scope or budget amendment for Sachin
before renting. Do not spend the remainder on an unpaired comparison that cannot
answer the declared question.

## Financial and runtime admission

The existing cumulative limits remain: **$10 total**, $8 active allocation with
shutdown requests from $7.90, $2 reserved for transfer/stopped disk/preservation,
**20 aggregate instance-hours**, and at most $0.65 per hour for a suitable host.
Import all original costs, transfer and elapsed allocation time into the replacement
book. Do not reset them, subtract posted charges from $10 and treat the difference
as entirely usable compute, or grant a fresh 20-hour window.

The local finance book is stale: its original allocation has no verified stop time.
Reconcile it with provider evidence. If exact termination time cannot be recovered,
use a documented conservative bound no later than the verified provider-absence
check. Explain uncertainty and avoid double-counting the same historical charges.

Before creating an instance, admit setup, fresh engineering, all planned confirmation,
replacements, transfer and preservation against both money and remaining aggregate
time. The old host averaged 261 seconds per screening episode, so 144 confirmations
alone would take roughly 10.4 hours at that rate. This is a planning estimate, not a
guarantee on another host. Re-admit using measured engineering timings before C.

Use one RTX 3090 or RTX 4090, NVIDIA driver **580.x**, at least 60 GB RAM,
12 effective CPU cores and 160 GB disk, following the recorded template and pins.
Use one simulator lane and one policy server. Verify local and instance-scoped remote
watchdogs and a deadline based on the remaining allocation. Preserve the 45-minute
episode-admission margin. All setup and failed attempts count.

The stage D amendment raises cumulative simulator starts to 250, policy controls to
500,000 and native queries to 62,000; retain the other original limits, including
120,000 candidate decodes and 20 replacements. Reconcile counters across all hosts
and stages, including historical/model-only work where applicable. Verify actual
counter coverage before admission; a number in a JSON config is not enforcement.

## Engineering details that must be addressed

- **Worktree and freeze differ.** The live-v2 freeze no longer matches three current
  files: `make_regrasp15_freeze.py`, `15-regrasp-dial-plan.md`, and
  `test_regrasp15.py`. The stage-D freeze matches the inspected worktree. Restore
  stage-appropriate sources from verified bundles into an isolated snapshot, or
  record justified operational repairs in a new recovery freeze. Never edit an old
  hash to make a mismatch pass.
- **The old launch script is not a resume command.** It refuses an existing
  `pipeline-started.txt`, starts from stage A, and uses hard-coded namespace and rental
  paths. Managers, guards, launchers, queues, analyzers and preservation also contain
  old-path assumptions. Adapt the recovery wiring explicitly before freezing it.
  Do not remove start/STOP markers to force execution or kill unrelated processes.
- **Completion markers need semantic checks.** `Queue.drain()` can return after
  abandoning a job, and the stage-D launcher currently tests only for a C marker's
  existence. Require the full expected validated job-ID set, no unresolved attempts,
  `finished: true` and an empty `missing_jobs` list before calling a stage complete
  or admitting D against its native control. Preserve any partial result honestly.
- **Start serially.** Warm the simulator before live engineering to avoid the
  extension-cache race observed in task 11. Candidate inference stays in batches of
  at most 16. Verify the 32-candidate request, native RNG isolation, finite actions,
  source/checkpoint identity, and decision replay before confirmation.
- **Use the intended Python environments.** Locally use `.venv/bin/python`, not
  `uv run`. The historical remote evaluator uses the `behavior` conda Python;
  the server uses `third_party/openpi/.venv/bin/python`. Do not sync root legacy
  dependencies into the ManiGuard environment. Run the relevant task-15 tests and
  new recovery tests for cohort integrity, admission and completion checks, plus lint.
- **Analysis and preservation need explicit input roots.** Local data is under
  `outputs/regrasp15/remote/`, while analyzers default to `outputs/regrasp15/`.
  Point them to the validated cohort deliberately. The current preservation helper
  takes a v1 source list and copies the current worktree; repair it to preserve the
  actual executed snapshots, all stage-D/recovery sources and both host histories.
  Do not label a new worktree copy as an old frozen source.

Useful entry points are `manage_regrasp15.py`, `run_regrasp15.py`,
`stage_d_regrasp15.py`, `serve_regrasp15.py`, `probe_regrasp15.py`,
`analyze_regrasp15.py`, `analyze_regrasp15_d.py`, `preserve_regrasp15.py`, and
`make_regrasp15_freeze.py` under `experiments/scripts/`.
The pinned checkpoint is
`IDEAS-Lab-Northwestern/pi05-base-datagen-v1-jar-joint-2cam-lora`, revision
`1d84eda070313a202a595e449fcf41a1a1e8a546`, checkpoint `7400`.
Verify against `outputs/regrasp15/remote/environment/checkpoint-provenance.json`
and the preserved installation records.

## Finish and preserve

Continuously mirror evidence locally. After the admitted queue finishes, reconcile
every planned job and every attempted start against recordings, sidecars, model-query
ledgers and counters. Write final C/D analyses and an actual-versus-planned schedule.
Report failures, missing evidence and limits as well as results.

Verify a complete local inventory, stop compute and verify stop, then upload to the
existing private dataset `Sachioster/maniguard-jar-replication-20261022` using fresh
recovery prefixes. Preserve the original cohort separately. Re-download every
manifested file at a pinned revision and verify hashes. The destruction guard requires
a manifest-backed marker with instance ID, local verification, private verification
and pinned revisions; generate it only from successful checks. Destroy the new disk
after preservation and verify provider absence. Record final posted and conservative
costs, including earlier allocations.

Update `progress/receipts/15-regrasp-results.md` with a dated recovery/final section,
add completion receipts, update the progress and receipt indexes, and add a finished
task entry to `progress/theOdessy.tex`, recompiling and inspecting its PDF. Preserve
the original screen and all earlier freezes. Keep credentials in the ignored `.env`
or account environment; never print them or place them in arguments, archives or
manifests. Do not commit checkpoints, recordings or generated output directories.

Return a concise result: completed denominators by arm and host, safe completion,
violations, unfinished and engagement, the frozen confirmation decisions, total
interactions and costs, preservation revision, and verified rental teardown. If a
limit prevents completion, state precisely what remains and the concrete amendment
needed, with all recoverable evidence already preserved.
