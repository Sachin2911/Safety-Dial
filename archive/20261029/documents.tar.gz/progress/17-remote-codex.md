# Task 17 remote Codex handoff

The rental is instance **57809511**, label `lewm17-1026120444`, with four RTX 3090s,
48 effective CPU cores, 128 GB host RAM and 120 GB disk. Compute plus disk is quoted
at **$1.00933/hour**. The admitted five-hour estimate including transfer allowances
and cleanup is $6.13, below the $10 hard cap. Actual cost is counted from creation.
Read the rental JSON and guard status for authoritative current accounting.

The hard lease deadline is **26 October 2026, 17:04:44 UTC / 19:04:44 SAST**.
Independent closeout starts 30 minutes earlier. The guard is remote and does not
depend on the laptop. Its hard deadline deletes this rental, so results must be
preserved privately before then. A host or provider outage can disrupt a self-hosted
guard; the private checkpoints and provider console remain the recovery paths.

## Connect, install, sign in and start

From the laptop or another device:

```bash
ssh -p 51411 root@61.71.33.195
```

On the rental, create or reattach a persistent terminal:

```bash
tmux new-session -A -s codex17
```

Install Codex using the official Linux installer, then sign in with a device code:

```bash
curl -fsSL https://chatgpt.com/codex/install.sh | sh
export PATH="$HOME/.local/bin:$PATH"
codex --version
codex login --device-auth
```

Open the displayed link on a device with a browser and complete the sign-in. Device
login may need enabling in ChatGPT security settings or workspace permissions. Do not
paste authentication codes or tokens into research logs. No local Codex credentials
were transferred. ChatGPT plan usage is separate from the GPU rental bill.

Then start the campaign agent:

```bash
cd /workspace/Safety-Dial
export HF_HOME=/workspace/Safety-Dial/outputs/lewm17/hf-cache
export MPLCONFIGDIR=/workspace/Safety-Dial/outputs/lewm17/cache/matplotlib
codex --approve-for-me --cd /workspace/Safety-Dial "$(cat progress/goal-prompt-17-lewm-evolution.md)"
```

`--approve-for-me` uses automatic approval review with the workspace-write sandbox;
it is present in the workstation's verified Codex CLI 0.164.0. Check `codex --help`
if the installed release differs. Complete initial sign-in and workspace-trust prompts,
and confirm the agent is working before disconnecting. Automatic review can still reject
an operation; it is not a guarantee of an entirely unattended run. Do not bypass a
rejection by disabling the sandbox. Setup installs the environment first so routine
experiment work remains in the project.

Detach with **Ctrl+B, then D**. This leaves Codex and its child processes running in
tmux on the rental; closing SSH or shutting down the laptop does not stop them.
Reconnect using the same SSH command and `tmux attach -t codex17` while the rental
exists. If Codex itself exits, use `codex resume --last` inside that tmux session.

Official references: [installation](https://learn.chatgpt.com/docs/codex/cli),
[device authentication](https://learn.chatgpt.com/docs/auth).

## Environment and source state

The remote directory contains the current working tree, including uncommitted task-16
and task-17 source. The transferred manifest records source hashes and the workstation
HEAD. The remote `.git` is a new local snapshot baseline, not a rewritten workstation
repository or a push to the origin. Downloaded model weights, local credentials and
old experiment output directories are excluded. Archived source is historical context.

The setup session is `lewm17-setup`. Its log is `outputs/lewm17/logs/setup.log`.
Completion is marked by `outputs/lewm17/environment/ready`; the environment freeze,
GPU inventory, checkpoint identities and tests are beside it. Use `/venv/main/bin/python`,
not `uv run`. New checkpoint paths are under `data/lewm17`. Task-16 configs remain
available for provenance; task-17 environment specs and preserved scalers are copied
into `configs/lewm17` without regenerating or changing their values.

Only `HF_TOKEN` and `HF_NAMESPACE` were copied into the ignored, mode-600 root `.env`
for the authorized private dataset. The provider guard uses the rental's own
`CONTAINER_API_KEY`; no account-wide Vast key is copied. No OpenAI, GitHub or WANDB
credential is transferred. Never print the environment or archive `.env` or `.codex`.

## Guard, worker registration and preservation

Inspect status with:

```bash
/venv/main/bin/python experiments/scripts/control_lewm17.py status
```

All new worker loops must honor `outputs/lewm17/STOP`. Register each experiment process
immediately after starting it, using the exact script argument present in its command:

```bash
/venv/main/bin/python experiments/scripts/control_lewm17.py register \
  --pid WORKER_PID --script experiments/scripts/worker_lewm17.py
```

Replace WORKER_PID with the actual numeric PID. The guard records process start ticks
and exact script identity to avoid signaling a reused or unrelated PID. At closeout it
sets STOP, gives workers 30 seconds to flush, then terminates registered workers and
makes a final private snapshot. The same registration is needed for search/learner
processes; their entry-point filenames must contain `lewm17`.

Make manual checkpoints after every finished batch and before final closeout:

```bash
/venv/main/bin/python experiments/scripts/preserve_lewm17.py
```

The guard also checkpoints periodically. The latest verified revision is in
`outputs/lewm17/control/preservation-latest.json`. Evidence goes to the private dataset
`Sachioster/maniguard-jar-replication-20261022`, under
`17_lewm17_campaign/57809511/<snapshot>`. Every upload is read back at its pinned
revision and hash-checked. The archive includes current source/configs, task-17 results,
optimizer checkpoints, attempt records and progress documents. Check its allowlist if
adding a new output path. A running attempt stays explicitly incomplete in a snapshot.

The guard sets STOP at 4.5 hours or a conservative $8.50 estimate. It destroys the rental
after a verified terminal backup, or at the hard five-hour/$9.50 cutoff using earlier
verified backups if the last upload cannot complete. Do not disable or extend it.

Once all results and the Odyssey are saved and a final manual backup has passed:

```bash
/venv/main/bin/python experiments/scripts/control_lewm17.py finish
```

Then stop writing results. The independent guard takes a terminal snapshot and issues
the self-destruction request. That closes SSH and Codex along with the machine. Final
external absence and posted billing must be verified from the Vast console or another
machine; a local deletion acknowledgement alone is not that external verification.

## Completion distinction

This handoff rents and prepares the host. It does not claim task-17 optimizer code or
experiments are complete. The remote Codex agent implements and executes the campaign
within the existing deadline and cap. The completed task-16 result is unchanged.
