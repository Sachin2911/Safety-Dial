# Task 10 receipt: preservation, teardown and spend (25 October 2026, 19:24 to 19:27 UTC)

## Preservation

- `experiments/scripts/preserve_safecem10.py --upload` staged the final mirror of the primary
  (synced 19:19 UTC, after stage C2 ended at 19:10), the helper's mirrored metadata, every
  `progress/receipts/10-safecem-*` file, the plan, both rental records, the ledger, the relay
  records and `outputs/safecem10/analysis`: 51 files, 188 MB.
- A secret scan of the mirrors and receipts found nothing. The destination is private.
- Uploaded at 19:25:55 UTC and re-downloaded by pinned revision
  `c799121672be8557425f06cc8d538d0f6369f11b`; all 52 files (51 plus the manifest) match by
  size and sha256. Manifest sha256 675fdc51... at
  `outputs/safecem10/hf-stage/receipts/safecem10/sha256-manifest.json`.
- Markers: `10-safecem-preservation.json` (instance 57660116) and
  `10-safecem-preservation-helper.json` (instance 57689039, whose episode results live in the
  primary's attempts and whose own logs, queue and hashes are in
  `recordings/safecem10/helper-run-metadata.tar.gz`).

## Teardown

| instance | role | stopped | destroyed |
|---|---|---|---|
| 57689039 | C2 helper, RTX 3090, New York, $0.29/h | 19:20 UTC, verified | absence verified |
| 57660116 | primary, RTX 3090, Austria, $0.26/h | 19:26 UTC, verified | absence verified |

No task-10 rental, watchdog or relay process remains.

## Spend (ledger `outputs/safecem10/control/finance.json`)

| item | value |
|---|---|
| aggregate instance-hours | 10.71 of the 14-hour cap |
| rental, from ledger rates and verified stop times | $2.92 |
| transfer estimate | $0.16 |
| total spend | about $3.08 of the $10 allocation |

The ledger also carries a $2.00 reserve floor in its total estimate ($4.92). That is held
back by design, not spent.
