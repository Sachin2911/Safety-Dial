# Task 10 receipt: stage A engineering (25 October 2026, 12:20 to 12:23 UTC)

Freeze `progress/receipts/10-safecem-A-freeze.json` (14 jobs). Runner: 3 persistent workers
sharing the RTX 3090. Evidence synced to `outputs/safecem10/remote/attempts/A-*`.
Admission record: `outputs/safecem10/engineering.json` (passed, all five checks).

## Throughput

| quantity | value |
|---|---|
| wall clock for 14 episodes | 105 s |
| median episode (one worker) | 22.2 s, max 23.3 s |
| system seconds per episode (3 workers) | 7.5 s |
| episodes per hour | 478 |
| CEM solve with 3 concurrent workers | about 2.2 s (300 samples x 30 iterations) |
| world-model candidate rollouts per full episode | 90,000 (10 replans x 30 iterations x 300) |

## Unconstrained baseline (lam = 0), seeds 100 to 102

The unconstrained planner ignores the gate, so each seed produces the same trajectory on
every layout; only where the gate sits relative to it changes.

| seed | success | steps | final block error | gate crossing per layout G0 / G40 / G80 / N40 |
|---|---|---|---|---|
| 100 | no | 50 | 7.6 px | pillar / gap / pillar / pillar |
| 101 | yes | 31 | 9.0 px | gap / gap / pillar / pillar |
| 102 | no | 50 | 7.3 px | gap / pillar / pillar / gap |

Mean exposure of the baseline per layout: G0 0.037, G40 0.027, G80 0.072, N40 0.066. Every
layout has at least one baseline episode that enters a true pillar, so the sweep has
something to avoid. Pusher speed along the route: median 18 px per env step. Two of three
baseline episodes end within 10 px of the goal block without reaching the 0.95 coverage
threshold inside 50 steps, so J will often sit at the 50-step charge.

## Safe CEM on G0, seed 100

| dial | success | steps | exposure | crossing | final block error | planner final feasible fraction |
|---|---|---|---|---|---|---|
| d = 0 | yes | 38 | 0.000 | gap | 16.7 px | 0.81 |
| d = 40 | no | 50 | 0.060 (3 states) | none | 60.0 px (block untouched) | 0.56 |

At d = 0 the constraint-priority ranking turns the baseline's pillar entry on this seed into
a clean gap crossing and a success. At d = 40 the inflated pillars close the gap; within the
25-step imagination horizon the planner never found the detour around the right end, hovered
above the wall band, and still touched a true pillar in 3 of 50 states. Both safe episodes
differ from the unconstrained one from the first executed action, as required.

## Decisions taken from stage A

- Stage B frozen with the full 10-seed panel: 4 layouts x (7 pixel dials + p90 = 25 px and
  p95 = 33 px uncertainty dials + lam = 0 and lam = 1 references) = 440 episodes, about
  55 minutes at the measured throughput. The p50 dial (10 px) coincides with a grid dial and
  is dropped by the frozen rule.
- Stage C will be sized after B from the remaining window; at the measured throughput the
  top ladder rung (8 generations x 3 replicates, 3672 episodes, about 7.7 h) fits.
