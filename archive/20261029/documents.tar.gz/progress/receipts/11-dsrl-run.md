# Task 11 run log

Started 25 October 2026. All times UTC. Receipts:
[launch readiness](11-dsrl-launch-readiness.md), [stage-A build](11-dsrl-stage-a-build.md).

## Rental

- 16:02 instance 57688543 (`jar-dsrl11-1025160153`) created on offer 41396007:
  four RTX 4090, 64 cores, 258 GB, driver 580.159.03, Japan, $1.922/h. The local
  financial watchdog started before the create request. Financial stop deadline:
  23:41:58 (nominal 23:46:58 under the $14.90 active-shutdown limit).
- 16:03 to 16:31 the provider reported `loading` (image pull). Image layers
  finished downloading by about 16:17, but no container existed at 16:22 or 16:27
  (`No such container`), and the status message did not change after 16:19.
  Nothing was ever deployed to it.
- 16:31 Sachin said to replace the host now. The script checked the provider row
  (our label, still `loading`) and asked the provider to destroy it. The destroy
  call printed plain text rather than JSON, so the manager's stop command checked
  the provider list instead: 57688543 was absent, and the financial book recorded it
  as destroyed at 16:31:33. The first host is charged 0.49 h at $1.922/h (about
  $0.95). Its rental record is kept as `progress/rental-dsrl11-20261025-57688543.json`.
  The local financial watchdog exited with no active allocation, as designed.
  Instances 57647787, 57660116, 57689039 and 57690181 belong to other tasks and were
  not touched. Instance 57632188 is no longer listed by the provider.
- 16:31 the replacement offer 53206777 ($1.904/h, 57.6 cores) disappeared before the
  create request. The manager refused with nothing reserved.
- Replacement price check (Task 7 timings, 20 minutes allowed for a slow image pull,
  first host charged): $1.816/h projects 6.27 h against 7.37 h allowed (1.10 h
  margin); $2.136/h and $2.164/h left only about 0.2-0.3 h, so I watched the market
  for three minutes rather than take them.
- 16:33 instance 57692161 (`jar-dsrl11-1025163300`) created on offer 53148449:
  four RTX 4090, 48 cores (the frozen minimum), 258 GB, driver 580.159.03, Japan,
  machine 29696, $1.816/h. A fresh local financial watchdog started before the create
  request. Financial stop deadline: 23:58:20 (five minutes before the nominal
  deadline).
- Deploy bundles for the new rental. Bundles are immutable, so new files were made:
  - Setup: `setup-source-57692161.tar.gz`, SHA256 `654ea558...`, 81 files. It is
    the original verified setup archive with only the rental record swapped. Since
    that archive was built, `make_dsrl11_freeze.py` and `test_dsrl11_learner.py`
    have been edited, so a fresh build from the working tree would no longer match
    the setup manifest.
  - Run: `stage-a-source-57692161.tar.gz`, SHA256 `a51fb7f7...`, 98 files, rebuilt
    from the unchanged stage-A freeze.

  Both pass the deploy verification, which reads every hashed file from inside the
  archive. No manifest changed.
- 16:34:34 the host was running (base image cached). SSH opened at 16:35:30.

## Deployment

- 16:35:36-16:36:02 setup deploy: 79 setup-manifest files verified on the host,
  four RTX 4090 on driver 580.159.03 (24,564 MiB each). The remote financial
  watchdog was ready at 16:36:02 with deadline 23:58:20, and preparation started.
- 16:36:23 the first run deploy failed before anything ran on the host. Its rsync of
  the 53.7 MB run bundle hit the deploy step's 180 s limit. The workstation is on
  Wi-Fi with a 515 ms round trip to Japan, and one SSH stream managed about
  37 KiB/s up and 330 KiB/s down. Sixteen parallel SSH streams reached about
  473 KiB/s up, and eight reached about 3 MB/s down.
- 16:41:53-16:43:17 the bundle went up as 16 parallel chunks. It was reassembled on
  the host and checked against the local SHA256 `a51fb7f7...`, with the local
  modification time set. The deploy's own rsync then found the file current.
- 16:43:24-16:43:50 run deploy: 19 changed files installed atomically, 96 frozen
  source and input hashes verified, held preparation files unchanged. Queue session
  `queue11` started, waiting for `ready/learner.json`.
- Local evidence copying: the frozen `sync_dsrl11.py` started at 16:43. Its first
  attempts exceed the manager's 180 s rsync limit on the initial ~100 MB, but rsync
  keeps partial files, so each attempt continues the last. A helper,
  `outputs/dsrl11/control/parallel_mirror.py`, pre-fetches large settled files
  (npz, mp4, msgpack, gz) over eight parallel rsync streams so the frozen sync finds
  them current. It changes no frozen file, and preservation still verifies every
  file against the remote manifest.
- 16:47 Sachin suggested looking for a faster-networked host. The only qualifying
  offer was 48565455 in Taiwan at $2.164/h: the same distance from the workstation,
  and too little budget margin. The frozen financial book also refuses overlapping
  rentals. The Japan host was kept, and parallel streams address the transfer
  speed.

## Second replacement (slow host network)

- 16:36-17:04 host 57692161 prepared about 10x slower than Task 7's host. The Jar
  took 501 s (Task 7: 77 s). The ManiGuard/BEHAVIOR-1K clone and the OpenPI
  environment were unfinished after 28 minutes (Task 7: 173 s and 279 s), and the
  learner environment was still downloading. The host received about 1.75 MB/s
  overall. A direct test fetched the simulator's torch wheel from
  download.pytorch.org at 0.2 MB/s. The simulator install (2,020 s on Task 7's host)
  pulls several GB from PyTorch, NVIDIA and PyPI, so preparation would have run
  hours and the frozen schedule could not have fit the deadline. A1 had not started;
  no learner update, policy query or episode ran on this host.
- 17:07 qualifying offers: 41396007 (Japan, $1.922/h, the first host's machine),
  54503289 (Taiwan, $2.084/h, 112-core AMD EPYC 7663, 1.69 Gbit/s), and 52375914
  (UK, $2.136/h, 80-core Xeon Gold 6133). Taiwan was chosen: a lower rate than the
  UK host, and a newer CPU with more cores.
- 17:08:33 host 57692161 destroyed. The destroy call printed plain text; the
  manager's stop check found the instance absent, and the book recorded it destroyed
  at 17:08:39.9 (0.60 h at $1.816/h, about $1.09). Record kept as
  `progress/rental-dsrl11-20261025-57692161.json`. Its local mirror (setup logs and
  input copies only) was moved to `outputs/dsrl11/remote-57692161` so it cannot mix
  with the next host's evidence.
- 17:09:43 instance 57697202 (`jar-dsrl11-1025170943`) created on offer 54503289:
  four RTX 4090, 112 cores, driver 580.173.02, Taiwan, machine 27299, $2.084/h. A
  fresh local watchdog started before the create request. Financial stop deadline:
  23:15:12.
- Budget position: about $2.04 has gone to the two replaced hosts. With Task 7
  timings (four-lane episode 560 s), measured stage-C admission on this host would
  fall about 12 minutes short. It passes only if bank episodes take about 525 s or
  less. The cap stays at $18. The frozen admission rule decides, and the comparison
  is not shrunk.
- Bundles for 57697202: setup `setup-source-57697202.tar.gz` (SHA256 `e7b8c9fa...`,
  the original setup archive with only the rental record swapped) and run
  `stage-a-source-57697202.tar.gz` (SHA256 `4db7e210...`). Both pass deploy
  verification.
- 17:11:43 the host was running; SSH opened at 17:11:50. A 10 s network test fetched
  from download.pytorch.org at 19.3 MB/s and from PyPI at 91.6 MB/s. Four RTX 4090
  on driver 580.173.02.
- 17:12:34-17:12:55 setup deploy: 79 files verified, GPU check passed, remote
  watchdog ready (deadline 23:15:12), preparation started.
- 17:13:11-17:14:31 run bundle uploaded in 16 parallel chunks, reassembled, SHA256
  `4db7e210...` matched.
- 17:14:36-17:15:07 run deploy: 19 files installed, 96 frozen hashes verified.
  `queue11` started at 17:15:06. The frozen sync and the parallel mirror were
  restarted for this rental.
- Preparation on this host is faster than Task 7's: Jar 50 s (Task 7: 77 s),
  ManiGuard clone 122 s (Task 7: 173 s).

## Workstation work during loading

The stage-A freeze, CPU preflight, input copies, private preservation check and the
analysis, preservation and queue tests were completed while the image loaded (see
the stage-A build receipt). Freeze SHA256 `ecff530a...`; run bundle `4a4e2f22...`.

## Stage A1: critic grid (17:15-17:30)

All eight cell-seed runs ended finite. Admission requires the stage-C pause rule never
to fire: gate quantity outside [-0.30, 1.05] for more than 1% of calibration pairs
at three successive post-update measurements.

| Cell | Updates | Seed 11061 | Seed 11062 |
|---|---|---|---|
| UTD 20, min | 30,000 | paused | paused |
| UTD 20, mean | 30,000 | paused | paused |
| UTD 5, min | 7,500 | paused | paused |
| UTD 5, mean | 7,500 | admitted | admitted |

The frozen preference order selects UTD 5 with mean reduction. What the
measurements show (descriptive, from `a1/*/diagnostic-ledger.jsonl`):

- Min reduction fails low, not high. At update 1,000 the minimum of ten heads
  averaged about -1.89 on recorded pairs, with 100% of pairs below -0.30. It came
  back inside the gate only after about 20,000-25,000 updates (UTD 20, seed 11061:
  outside fraction 0.195 at update 24,500 and 0.008 at update 29,500). The pause had
  already fired on the first post-update measurements. The frozen rule excludes only
  the initialization measurement, so this pessimistic start disqualifies both min
  cells at both UTDs.
- Mean reduction at UTD 20 inflates late. It was inside the gate through update
  19,500, then 77-99.9% of pairs were outside by update 29,500-30,000. At seed
  11062's end, the head mean on recorded pairs was 1.20 (maximum 1.65) against
  returns in [0, 1], with a mean absolute Monte Carlo error of 1.20. Policy entropy
  fell from 21.9 to 12.7-18.8.
- Mean reduction at UTD 5 stays inside the gate, but its policy barely moves: entropy
  21.86 at update 7,500 against 21.85 at update 500, and pre-squash mean norm 0.04.
  Its admission shows calibration over a short diagnostic, not a learned
  improvement.

## Preparation (17:12:55-17:44:58)

Preparation took 32 minutes against Task 7's 41: Jar 50 s, ManiGuard clone 122 s,
OpenPI environment 155 s, benchmark 182 s, simulator install 17:18-17:44.
`environment/source-pins.json` matches every pin: ManiGuard 6bf4c61, behavior-1k
88454bd, OpenPI 215abfb, dsrl_pi0 7f48937, and patched evaluator
`a670d978...8423`. The learner imports JAX 0.5.0 and Flax 0.10.2 on four CUDA
devices. At 17:45-17:46 four policy servers started (about 8.6 GB each), and all
four startup checks completed valid. Each server logged one failed websocket
handshake right after it began listening, consistent with a plain TCP readiness
probe. All four logs show the same single event.

## Stage A2 and numerical admission (17:45-17:46:50)

`stage-a/numerical-summary.json` reports `admit: true`, and
`stage-a/learner-selection.json` selects UTD 5 with mean reduction (the only admitted
A1 cell). A2 passes on all four lanes: valid; same-process native repeat exact;
zero residual reproduces the native draw; historical draws reproduced. Lane 0 found
residual influence present and finite. Query counts: 88 on lane 0 and 24 on each other
lane, all confirmed, none failed. Cross-process comparisons to lane 0 (24 snapshot
cases) are not bitwise identical: maximum absolute differences 0.002-0.003, RMS about
0.0003-0.0004, gripper prefixes equal. They are descriptive only, as frozen. Resource
use after stage A: 150,000 diagnostic updates (the whole grid, under the 180,000
cap), 21 prior engineering updates (CPU preflight), and 172 model-only queries
(cap 1,200).

## Engineering start failure and stop (17:46:51-18:02:43)

- 17:46:51 the queue launched engineering episodes E0-E3 on lanes 0-3 in the same
  second. This was the first simulator start on this host.
- On a cold host, Isaac Sim (Omniverse Kit) cannot resolve two extensions locally
  (`omni.usd.schema.flow-107.0.0`, `omni.flowusd-106.5.2`). It pulls them from
  NVIDIA's registry into one shared folder,
  `third_party/ManiGuard/behavior-1k/OmniGibson/appdata/global/data/exts/v2/`. All
  four processes unpacked them at once.
  - E0 failed with `FileExistsError` on `.../omni.usd.schema.flow-.../usd/schema`.
    Kit exited ("dependency solver failure"), and the evaluator then reported
    `No module named 'omni.kit.usd'` during scene load.
  - E1 failed the same way on `omni.flowusd` and exited 1 at 17:47:09.
  - E2 and E3 got past extension loading. They were in renderer initialization
    when the queue stopped them.
- 17:47:08 the queue recorded E0 invalid ("Evaluator did not exit cleanly"). At
  17:47:09 it closed admission ("Invalid attempt needs diagnosis: E0"). At 17:47:10
  it stopped all 48 recorded worker PIDs (`quiescence.json`) and exited 3. E1-E3
  have no recorded verdict in `queue-state.json` or the ledger, because the queue
  closed before polling them. They are left as recorded.
- Task 7 avoided this by timing, not by design. Its E3 started alone at 08:38:31 and
  pulled the same two extension versions; E0-E2 started six minutes later against
  the filled cache. The extension versions here match Task 7's, so there was no
  registry drift. The Task 11 schedule had no guard against concurrent cold starts.
- No episode reached the policy loop. Journals hold only observer and configuration
  rows (plus `finish` for E0 and E1): 0 policy controls, 0 warm-up controls, and no
  episode model queries.
- Repair assessment. The cause is fixable with one serial simulator warm-up. But
  four frozen starts are spent, and the frozen ledger allows at most one replacement
  per job and two in total (98 starts for 96 jobs). Replacing E0-E3 would have
  needed a recorded amendment (starts 98 to 102, replacements 2 to 6), plus code,
  tests and a re-freeze, because a resumed Task 11 queue cannot change its source
  freeze. That is about 30-40 minutes of idle compute. After that delay, the measured
  stage-C admission could not have fit the $18 allocation (deadline 23:15:12; the
  pilot needs about 4.1 h after a bank ending about 19:40).
- 17:55 Sachin was offered three options: repair and raise the cap to about $22;
  repair at $18 for engineering and bank only; or stop and preserve. Sachin chose
  "Stop now and preserve", then wrote: "Yes please wrap up, destroy the instances and
  write to odessy". No amendment was made, no frozen source changed, and no
  replacement was started.
- 18:01:15 `preserve_dsrl11.py prepare-remote` ran on the host (tool SHA256
  `1f0351aa...`, copied in for closeout; it was not part of the run bundle). It
  verified all 48 worker PIDs gone, backed up the query ledger with the SQLite backup
  API (172 queries, integrity ok), and froze a 438-file, 171,344,752-byte raw
  inventory. Excluded live or mutable files: the query database and its sidecars,
  `network-cost.json` and `logs/remote-watchdog.log`.
- 18:01:47-18:01:57 the frozen sync made its last full pass. The local mirror
  `outputs/dsrl11/remote` then passed `verify_remote`: all 438 files match by size
  and SHA256, with no extra or missing files.
- 18:02:43 compute stop verified (`exited`/`stopped`/`stopped`) and recorded in the
  book. The sync attempt at 18:02:42 failed because the host was stopping; it does
  not affect the verified mirror. The local watchdog, the frozen sync and the
  parallel mirror then exited with no active allocation.

## Final accounting (frozen ledger, `resources.jsonl`)

| Counter | Used | Cap |
|---|---|---|
| Simulator starts | 4 | 98 |
| Replacements | 0 | 2 |
| Policy controls | 0 | 196,000 |
| Warm-up controls | 0 | 980 |
| Model queries (all model-only probes) | 172 | 27,000 (model-only 1,200) |
| Learner updates | 150,021 | 305,000 |
| Diagnostic updates (A1) | 150,000 | 180,000 |
| Engineering updates (CPU preflight) | 21 | 2,000 |
| Learning updates | 0 | 120,000 |

Compute by the financial book (creation to verified stop):

| Instance | Where | Rate | Hours | Estimate |
|---|---|---|---|---|
| 57688543 | Japan | $1.922/h | 0.494 | $0.95 |
| 57692161 | Japan | $1.816/h | 0.594 | $1.08 |
| 57697202 | Taiwan | $2.084/h | 0.883 | $1.84 |
| Total | | | 1.972 | $3.87 |

Storage and transfer are billed separately; the provider's actual charges are
recorded after destruction.

## Closeout (after the verified stage)

- 18:06:03 staged 621 dataset and 21 model files (569 MB, mostly immutable deploy
  bundles and input copies).
- 18:11:52 private verification passed. Dataset revision `b45304f5...` (622 files),
  model repository `Sachioster/safety-dial-dsrl11-20261025` revision `da19ef8d...`
  (21 files), manifest `eb8b1009...`. Every file was downloaded at its pinned
  revision and its SHA256 matched.
- 18:12:12 instance 57697202 destroyed through the preservation guard, with provider
  absence verified. No Task 11 instance remains.
- 18:13 posted provider charges: $3.411 in all (57688543 $0.028, 57692161 $1.147,
  57697202 $2.236). See [11-dsrl-completion/](11-dsrl-completion/README.md).
- After closeout, Sachin was asked whether to resume with a new rental and a
  recorded repair: within $18 (about $11 and 6.0 h left, against about 5.9 h needed
  at about $2.08/h), or with the cap raised to about $21. Sachin chose "Keep Task 11
  closed". No further rental or spending. The four-condition pilot remains unrun.
  This line was added after the closeout upload (revision `7159a3f1...`).
