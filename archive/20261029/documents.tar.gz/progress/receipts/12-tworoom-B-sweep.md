# Task 12 receipt: stage B, the TwoRoom dial sweep (25 October 2026, 18:58 to 19:32 UTC)

Freeze `progress/receipts/12-tworoom-B-v1.json` (310 jobs, sha256 f9a86668...; design v3).
Seeds 200 to 209, dials 0, 2, 4, 6, 8, 10, 12 px, randomized order, 3 workers on the RTX
3090. 310 episodes, zero failed attempts, 34 minutes. Analysis:
`outputs/tworoom12/analysis/stageB-{summary.json,table.md,response.*}`.

## Results (10 paired seeds per cell)

| layout (gap offset) | unconstrained: success / safe success / exposure / episodes entering | checked, safe success at d = 0, 2, 4, 6 to 12 |
|---|---|---|
| T0 (0 px) | 0.60 / 0.40 / 0.025 / 0.40 | 1.0, 0.9, 1.0, 0 |
| T1 (6 px) | 0.60 / 0.30 / 0.040 / 0.70 | 1.0, 1.0, 0.7, 0 |
| T2 (12 px) | 0.60 / 0.10 / 0.084 / 0.90 | 1.0, 0.9, 0.3, 0 |

For every checked episode, exposure is zero and success equals safe success. The median
realized clearance exceeds the dial in every cell (for example 4.1 to 6.3 px at d = 0 and
17 to 18 px at d = 6).

Paired contrasts at d = 0, checked minus unconstrained (mean over 10 seeds, 95% bootstrap
interval):

| layout | success | safe success | exposure | J (steps) |
|---|---|---|---|---|
| T0 | +0.40 [+0.10, +0.70] | +0.60 [+0.30, +0.90] | -0.02 [-0.05, -0.00] | -13.7 [-23.5, -3.2] |
| T1 | +0.40 [+0.10, +0.70] | +0.70 [+0.40, +1.00] | -0.04 [-0.07, -0.02] | -11.6 [-20.6, -2.9] |
| T2 | +0.40 [+0.10, +0.70] | +0.90 [+0.70, +1.00] | -0.08 [-0.13, -0.05] | -13.5 [-21.6, -5.4] |

On T2 the unchecked elite mean (`mean`) gave exactly the same outcome as `mean_safe` on every
seed at every dial.

## What B shows

1. **The exact check with a small dial gives safe, faster completion on every layout.** The
   unconstrained planner succeeds 6 times in 10, and enters the hazard in 40 to 90% of
   episodes. With the check and d at most 2 px, safe success is 0.9 to 1.0 with zero exposure,
   and episodes are 12 to 14 steps shorter.
2. **Part of that gain comes from the layout: the gap acts as a funnel.** On 4 of 10 seeds the
   unconstrained planner gets within 18 to 25 px of the target and then slides past it to the
   right or into the corner, never entering the 16 px success disk (LeWM's goal cost is flat
   that close to the goal). The checked planner has to come through the gap, which lines it
   up above the target, and it lands. A layout without that alignment need not show the same
   gain.
3. **The dial is a cliff at 4 to 6 px, well before the gap closes at 12.** At d = 6 the
   inflated band is a corridor 12 px wide and 20 px long whose far end reaches the success
   disk. No seed gets through on any layout; the planner waits safely above the band, and 2 of
   10 episodes at d = 8 or 12 wander out through the door.
4. **Checking the executed plan did not matter here.** With a 1% elite set the elite mean
   passed the exact check in 99 to 100% of replans, so `mean_safe` and the unchecked mean
   coincide. On Push-T the elite mean mattered because there the check was not exact and the
   elites were 10%.
5. **The best fixed dial already reaches safe success 1.0** (T0 d = 0, T1 d = 2, T2 d = 0).
   So stage C cannot improve safe success on TwoRoom; its comparison is in steps to success
   and hypervolume.

## Next

Stage C froze at 19:32 UTC (`12-tworoom-C-v1.json`, ladder rung 8 generations x 3 replicates,
3672 planned episodes, estimate 6.3 h at the stage A rate) and launched at 19:33 UTC.
