# Task 10 receipt: the SafetyDial-PushT dataset (25 October 2026, 19:45 to 20:16 UTC)

The user asked for a separate Hugging Face dataset just for Push-T, named SafetyDial-PushT,
holding the checkpoints, all the information, results and data, and above all videos of the
different dials working.

## Published

- Private dataset `Sachioster/SafetyDial-PushT`, revision
  `24de3f9f2a273598b7bcd9883d79f6a0c0b06c23`, uploaded 20:16 UTC. All 322 files (321 plus
  `sha256-manifest.json`, sha256 4ce16e95...) were downloaded again at that revision and match
  by size and sha256. The hub parsed the card: license MIT, configs `episodes` and
  `trajectories`. Record: `outputs/safetydial-pusht-upload.json`.
- Contents (351 MB): `videos/` (14 grid videos, 3 GIF previews, 102 single-episode clips,
  manifest with the selection rule of each video), `data/` (episodes.parquet and .csv with one
  row per scored episode, 4,127 rows; trajectories.parquet with 199,011 states; the preserved
  per-episode archives; the C2 and paused C search records; imagination measurements),
  `checkpoints/` (LeWM Push-T weights and config as pinned upstream, the converted
  stable-worldmodel checkpoint, probes v1 and v2 with their reports), `results/` (paper and
  analysis), `protocol/` (design, plan, freezes, receipts, run markers, software versions),
  `code/` (the C2 source tree, the analysis, render and build scripts, per-file hashes of every
  frozen source bundle).

## How it was made

- `experiments/scripts/render_safecem10_videos.py` draws each frame from a saved simulator
  state through the Push-T renderer, with nothing re-simulated. Overlays: true pillars,
  pillars inflated by the dial, the pusher's trail, the goal pose, and a ring for a step inside
  a pillar. For every rendered episode the overlay's count of steps inside a pillar equals the
  scored `hazard_steps`. Videos: per layout (G80 seed 201, G0 seed 205, chosen by a fixed rule)
  a seven-dial sweep for the exact check, the grounded probe and the stage B frozen probe; d =
  10 checked three ways; all ten B2 seeds for no check and for the exact check at d = 0; the
  best C2 front setting on held-out G80 and on fresh G0 seeds.
- `experiments/scripts/build_safetydial_pusht.py` assembles and checks the folder, then with
  `--upload` publishes and verifies it. Build-time checks: the weights match the pinned sha256
  and size; the converted checkpoint records the pinned source hash; both probes match their
  recorded hashes; the raw archives match the preserved archive hashes; saved states are finite
  and as long as recorded; per-step pillar flags sum to `hazard_steps`; the exact check has 0
  violations in 140 episodes and realized clearance at least the dial in every one; a scan of
  every file, archive members included, finds no credential, rental host address or local
  home path. One allowed exception: the frozen `dsrl06_infra.py` names the local vastai binary
  and is kept byte-exact.
- Withheld: rental records and preservation markers (host addresses, local paths), and the
  rental-record members of the source bundles (their hashes stay in
  `code/source-bundles.json`). The full evidence remains in the private preservation repo at
  revision c7991216....

## Corrections made along the way

- `results/safecem10-gate-dial-study.tex` said the planner reaches "the 0.95 coverage
  threshold". The success rule used throughout is the environment's `eval_state`: joint
  distance of pusher and block positions to the goal below 20 px and block angle within pi/9.
  Fixed and recompiled (4 pages, no warnings). Older receipts keep the original wording; the
  dataset card notes it.
- The card's stage B table gives gap-threading counts instead of the paper's "threading stops
  at d", because on G80 5 of 60 episodes at d >= 25 still threaded the real gap under the
  frozen probe (paper: "essentially none").
- The C2 video heading first said the amber box shows the clearance "for the current block";
  it shows d0, the clearance for the first imagined block. Fixed before upload.

## Open

- Visibility is private and the license for the project's own files is MIT, chosen to match
  the upstream checkpoint. Both are the user's call.
