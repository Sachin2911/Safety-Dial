# Task 14 receipt: stage C, searching the planner's settings on Cube (25 to 26 October 2026, 22:41 to 01:04 UTC)

Freeze `progress/receipts/14-cube-C-v1.json` (ladder rung 8 generations x 3 replicates).
Run on instance 57723845 (one RTX 3090): 2872 episodes (2592 search, 280 final), zero failed
attempts, 2 h 23 min. The final fronts had one to four settings, so the run used 800 fewer
episodes than the 3672 planned. The detached finalizer (`experiments/scripts/finalize_cube14.sh`)
synced, stopped the instance, analyzed, preserved the evidence privately
(`Sachioster/maniguard-jar-replication-20261022` at revision `c68069b2168156f13945e23d8488d7b1d97b073d`,
28 files verified; marker `14-cube-preservation.json`) and destroyed the instance at 01:09 UTC
on 26 October. The rental cost about $1.19 over 3.75 h. Analysis:
`outputs/cube14/analysis/stageC-{summary.json,table.md,fronts.*}`; the numbers below come from
`experiments/scripts/summarize_stage_c.py --task cube14`.

NSGA-II, random search and a grid each tuned five settings on layout C1 (moved from C2 before
the freeze, see `14-cube-B-sweep.md`): d0 (0 to 5 cm), d1 (-1 to 1 cm per block), the horizon
(3 to 7 blocks), the elite fraction (0.03 to 0.2) and the tolerated summed penetration (0 to
2 cm). Population 12, 8 generations, 3 seeds per candidate; the objectives were mean exposure
and mean J (steps to success, 50 when the episode does not succeed). Each run's final front
was re-run on fresh seeds 400 to 409 of C1 and on the held-out layout C0, whose gap sits on
the free route. The frozen grid's horizons were 4, 5 and 6.

## Results (mean ± sd over 3 replicates)

| method | search HV | fresh-seed HV | held-out HV | best safe success, fresh | best safe success, held out |
|---|---|---|---|---|---|
| NSGA-II | 13.11 ± 2.69 | 1.20 ± 0.62 | 1.13 ± 0.90 | 0.20 ± 0.00 | 0.20 ± 0.08 |
| random search | 17.44 ± 5.48 | 4.42 ± 3.59 | 12.23 ± 6.39 | 0.27 ± 0.17 | 0.70 ± 0.16 |
| grid search | 9.22 ± 1.29 | 3.53 ± 2.63 | 5.17 ± 3.66 | 0.27 ± 0.19 | 0.43 ± 0.31 |

Best safe success per run (fresh seeds of C1 / held-out C0): NSGA-II 0.2 / 0.1, 0.2 / 0.3,
0.2 / 0.2; random search 0.2 / 0.5, 0.5 / 0.7, 0.1 / 0.9; grid 0.0 / 0.0, 0.4 / 0.7, 0.4 / 0.6.

Replicate pairs (3 x 3): NSGA-II beat random search in 1 of 9 pairs on fresh-seed HV and 0 of
9 on held-out HV (differences of means -3.2 and -11.1). The grid beat NSGA-II in 6 of 9 pairs
on every measure, and random search in 4 of 9 on fresh-seed HV and 2 of 9 on held-out HV.

Final settings (d0 and d1 in cm; safe success on 10 seeds each):

| run | d0 | d1 per block | horizon | elite fraction | tolerance | fresh C1 | held-out C0 |
|---|---|---|---|---|---|---|---|
| random r2 | 0.25 | +0.03 | 3 | 0.12 | 0.69 cm | 0.1 | 0.9 |
| random r1 | 0.35 | -0.12 | 4 | 0.05 | 0.69 cm | 0.5 | 0.7 |
| random r0 | 0.88 | -0.42 | 6 | 0.06 | 0.30 cm | 0.2 | 0.5 |
| grid r1 | 0.70 | -0.75 | 5 | 0.10 | 0 | 0.4 | 0.7 |
| grid r2 (two) | 0 | -0.75, -0.25 | 5 | 0.10 | 0 | 0.4 | 0.6 |
| grid r0 | 0 | +0.25 | 5 | 0.10 | 0 | 0.0 | 0.0 |
| NSGA-II r0 (four copies) | 2.75 | -0.66 | 5 | 0.05 | 1.23 cm | 0.2 | 0.1 |
| NSGA-II r1 (two) | 1.68 to 1.69 | -0.50, -0.52 | 6 | 0.13 | 1.42 to 1.45 cm | 0.1 to 0.2 | 0.0 to 0.3 |
| NSGA-II r2 | 2.01 | -0.88 | 6 | 0.05 | 1.33 cm | 0.2 | 0.2 |

Stage B on the same layouts (seeds 200 to 209, horizon 5): the best fixed dial was d = 0 on
both, with safe success 0.3 (J 45.9 on C1, 46.4 on C0); the planner without the check 0.2.

## What C shows

1. **On the search layout the search did not beat the best fixed dial.** The fronts reached
   safe success 0.0 to 0.5 on fresh seeds of C1 (mean 0.24 over the 9 runs), against 0.3 for
   the check at d = 0 in stage B (other seeds).
2. **On the held-out layout random search's settings did.** On C0, where the gap sits on the
   free route, they reached 0.5, 0.7 and 0.9 (mean 0.70), against 0.3 for the best fixed dial
   and 0.2 without the check; the grid's reached 0.0 to 0.7 (mean 0.43) and NSGA-II's 0.1 to
   0.3 (mean 0.20). The best (random r2) scored 0.9 on C0 but 0.1 on fresh C1 seeds: a good
   setting for the easy layout, not a robust one.
3. **NSGA-II came last, behind even the grid.** Its three fronts converged on large near-term
   clearances (d0 1.7 to 2.8 cm, shrinking by 0.5 to 0.9 cm per block) with large tolerances
   (1.2 to 1.5 cm). These scored well on their 3 search seeds (J 35 to 41) but reached safe
   success 0.0 to 0.3 on the final seeds, which is what stage B predicts for margins of 1 cm
   or more. Safe success was 8.8% across the whole search, so a 3-seed score is very noisy. A
   plausible reading is that NSGA-II's elitist survival kept candidates with lucky scores and
   bred around them (one front is four copies of one setting), while random search kept
   spreading its samples.
4. **The lever on Cube is the clearance, not the horizon.** Search episodes with d0 below
   0.5 cm reached safe success 0.16, against 0.07 for d0 of 2 to 5 cm, while the horizon made
   little difference (0.03 to 0.11). This matches stage B, where any margin of 1 cm or more
   stalled the arm.
5. **Safety mostly held with the approximate check.** 9 of 2872 stage C episodes entered the
   band, for one saved step each. Three came from grid settings with zero margin and zero
   tolerance (the check's own error, as in stage B); the other six tolerated 0.27 to 1.96 cm of
   imagined penetration.

For the GECCO comparison, Cube is a negative result for NSGA-II at this budget: with sparse
successes and 3 seeds per candidate, its selection was misled by noise, random search was the
most reliable method, and only on the held-out layout did any search beat the best fixed dial.
