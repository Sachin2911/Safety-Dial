Task 7 outcome: valid_but_no_observed_gain.

Numerical integration admitted: True; live integration passed: True.

- native: strict safe completion 3/12; raw violations 4/12; counted violations 4/12; unfinished 9/12; engagement 12/12.
- fixed_zero: strict safe completion 0/12; raw violations 3/12; counted violations 3/12; unfinished 12/12; engagement 12/12.
- random: strict safe completion 0/12; raw violations 7/12; counted violations 7/12; unfinished 11/12; engagement 12/12.
- dsrl: strict safe completion 0/12; raw violations 4/12; counted violations 4/12; unfinished 12/12; engagement 10/12.

Frozen screen assessable: True; passed: False.

Screen thresholds are practical, not a significance test or a risk guarantee.
Wilson intervals assume independent episodes; seeds do not reset the simulator explicitly.
Benchmark safe/unsafe classes use counted violation; unscored safety is reported separately.
One learner seed on six development tasks cannot establish generalization or optimizer advantage.
Corrected discounted shaped return equals discounted completion return; intermediate shaping is not an efficacy result.
Actor latent saturation is abs(noise)>=0.99, not an arm-joint saturation measurement.
