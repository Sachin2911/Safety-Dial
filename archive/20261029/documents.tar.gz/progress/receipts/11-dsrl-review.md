# Task 11 pre-implementation review and approved amendment

25 October 2026, before any task-11 freeze, rental, VLA query, simulator start or
learner update. Sachin asked for a review of the plan and pipeline before
implementation. Evidence comes from the task 7 remote-final snapshot
(`outputs/dsrl07/remote-final`), its learner ledger and analysis, the pinned author
source and the pinned ManiGuard/OmniGibson sources. No task-7 artifact was modified.

## Findings that changed the plan

**The planned critic diagnostic could not observe the inflation it targets.** The
task 7 learner ledger logged mean Q of 0.31 to 0.37 for the first 6,000 updates. It
crossed the 1.05 gate near 8,500 updates and reached 3.56 by 15,000 and 37.19 by
90,000. The planned A1 grid stops after 1,250 or 5,000 updates, so mean reduction
would almost certainly pass with zero exceedance and the tie-break would choose
UTD 5 without evidence. Stage C itself runs 1,500 x UTD updates per condition,
7,500 at UTD 5 and 30,000 at UTD 20, longer than any planned A1 run.

**UTD 5 leaves no room for the actor to learn within stage C.** The author's SAC
starts at temperature 1.0 and Adam lowers its logarithm at a nearly constant rate.
Task 7 measured 2.3e-4 to 2.7e-4 per update, independent of reward. Its actor
stayed within one nat of the 32-dimensional maximum entropy (21.9 of 22.2) until
about 19,500 updates; at 7,500 updates the pre-squash mean norm was 0.24 with
standard deviation 0.87 per coordinate. At UTD 5 all four learned conditions would
therefore act like the bounded-random residual. Even at UTD 20, the batch-two actor
(15,000 updates) is near maximum entropy, and only the final, never-deployed actor
has committed. This is a limitation of the planned budget, recorded here before
outcomes; it is not a claim that any setting will improve completion.

## Approved amendment

Sachin approved the following at about 14:50 UTC, before any freeze:

1. Each A1 cell (mean or minimum over the same ten critics, UTD 5 or 20, seeds
   11061 and 11062) follows stage C's exact update schedule on the saved task-7
   tiled-noise replay: reveal 1,500 fitting transitions without updates, perform
   750 x UTD updates, reveal 750 more, then perform 750 x UTD updates. Calibration
   is measured at initialization and every 500 updates, matching the stage-C
   monitor cadence, for recorded and actor-sampled actions on the six calibration
   episodes.
2. A cell is admitted only if all states stay finite and the stage-C pause rule
   (more than 1% of calibration predictions outside [-0.30, 1.05] at three
   successive measurements) never fires, for both seeds and both action sets.
   End-of-run actor entropy and policy spread are reported.
3. Among admitted cells, UTD 20 is preferred over UTD 5 and minimum over mean
   reduction, in that order: (20, min), (20, mean), (5, min), (5, mean). The
   preference rests on the temperature schedule above, never on task-11 outcomes.
   Q and targets are never clipped to pass.
4. Diagnostic update attempts are capped at 180,000 (150,000 for the grid plus one
   30,000-update rerun for a documented repair). The total learner-update cap
   rises from 200,000 to 305,000. Online development updates stay at 120,000 and
   additional engineering updates at 2,000.
5. A1 runs on the authorized rental, in parallel across the four GPUs while the
   simulator environment installs, so it adds little or no critical-path time.

All other plan elements are unchanged, including conditions, seeds, roots, the
residual scale, both reward definitions, the frozen primary condition and final
checkpoint, evaluation thresholds and the $15 cap.

## Findings recorded without a plan change

- **Prior-bank gate risk.** Native task 3 had 6 safe successes in 22 earlier
  episodes (tasks 1, 3 and 7; 27%). Twelve episodes then fail the two-success gate
  with probability about 0.12 at that rate and 0.28 at 20%. A failed gate is
  reported and preserved; no extra sampling or task switch follows.
- **Warm-up has no update credit.** As in task 7 and the author's loop, episodes 4
  to 6 use the initialized actor, so six of nine online episodes per condition are
  effectively random exploration. Retained and reported as a limitation.
- **Reward geometry is benchmark-grounded.** The pinned goal checker
  (`goal_checker.py`, `goal_region.py`, hashes matching the task-6 grasp proof)
  succeeds when the robot grasps the jar (`is_grasping == TRUE`) while the jar's
  world AABB comes within the goal-sphere radius of its centre. ManiGuard defines no
  grasp affordance for the jar. Its own engagement metric `eef2target` measures
  `robot.get_eef_position()` (Franka `eef_link`) to the jar root position, so the
  reach term uses that pair. One new passive recorder field is needed: the jar
  world AABB at every control.
- **Budget.** Current qualifying offers were $1.922/h and $2.138/h at 14:39 UTC.
  Task 7's measured timings imply about 5.1 to 5.4 active hours for the full
  schedule, which fits at about $1.92/h but not at $2.14/h without the
  efficiencies below. The stage-C admission remains binding.
- **Topology.** Task 7's four-lane evaluation episodes took a median 520 s against
  436 s for three-lane training episodes. Four collection lanes in stage C would add
  only about 12% throughput, so the planned three lanes plus one learner GPU remain.

## Efficiencies adopted without a scientific change

- A1 and the A2 decoder checks run during environment installation.
- Each lane starts its next frozen job as soon as it is free and the job's
  dependencies are met. Task 7 lost 6.5% of evaluation lane time to block barriers.
- One seeded condition permutation is reused for warm-up, batch one and batch two,
  so each condition has three collection rounds between batch one and batch two and
  learner updates stay off the collection critical path.
- Evaluation lanes start as soon as the needed actor export exists; native needs
  none.
- The stage-C admission uses four-lane episode durations measured on the prior
  bank, a conservative bound for three-lane collection and the evaluation's own
  topology.
