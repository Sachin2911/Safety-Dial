# Task 9 completion receipts

Task 9 finished on 25 October 2026. All 384 confirmation episodes ran on
instance 57647787 under the recorded fallback, after the added host 57690181 was
stopped before any episode. Both rentals were destroyed after complete private
verification, and provider absence was verified for both.

The posted charge snapshot is $6.615. The conservative estimate rounds up to
$8.55, within the $15 combined cap. Provider charges may receive final
adjustments.

- [../09-unisafe-final-preservation.json](../09-unisafe-final-preservation.json):
  the complete local and private proof and destruction marker for both instances,
  pinned at revision `28c3eda5b8cb875198c224d168a3ebe101716c50`.
- [../09-unisafe-final-archive-audit.json](../09-unisafe-final-archive-audit.json):
  every raw file appears exactly once in the archives.
- [../09-unisafe-C-final-copy.json](../09-unisafe-C-final-copy.json): every
  remote file matched locally before compute stopped.
- [teardown.json](teardown.json): fresh provider absence after both guarded
  destroys. One unrelated instance belonging to other work was left untouched.
- [billing.json](billing.json) and [billing-raw-rows.json](billing-raw-rows.json):
  own-instance charge rows, ledgers and conservative allowances.
- [appendix-upload.json](appendix-upload.json): a pinned completion appendix
  holding these receipts, the final result and run records and the updated log.
  It was published after teardown and verified at its own revision.

The primary evidence snapshot is unchanged. The appendix adds only records
written after teardown. No result was rescored or selected again.
