# Task 10 receipt: stage B2, the gate sweep with the safety check grounded (25 October 2026, 14:20 to 15:18 UTC)

Freeze `progress/receipts/10-safecem-B2-freeze.json` (450 jobs, sha256 1ebbced5...; probe v2
sha256 3da85d40... pinned and verified by every worker). Protocol: the amendment at the end of
`progress/10-safecem-dial-plan.md`, written before any B2 episode. Layouts G0 and G80, the
stage B seeds 200 to 209, so every comparison with stage B is paired by seed. 3 workers, 3424 s
wall clock, zero failed attempts. Analysis: `outputs/safecem10/analysis/stageB2-{summary.json,
table.md,compact.md,response.*,calibration.*}`.

Conditions: `frozen` (stage B: probe v1, unanchored, elite-mean execution), `bestonly` (probe
v1, best checked candidate; G0 only), `fixed` (probe v2, anchored, best candidate), `exact`
(PD-controller path, best candidate), plus the unconstrained planner with best execution and
the grounded probe under the penalty rule. Open dials are d < 30 (the gap is still passable),
closed dials d >= 30.

## Pooled over G0 and G80

| check | dials | episodes | success | safe success | exposure | entering a box | nominal honoured | executed-block error (median px) | path length (median px) |
|---|---|---|---|---|---|---|---|---|---|
| frozen | open | 60 | 0.27 | 0.15 | 0.011 | 0.30 | 0.23 | 32.7 | 1060 |
| frozen | closed | 80 | 0.00 | 0.00 | 0.016 | 0.26 | 0.36 | 95.5 | 1218 |
| bestonly (G0) | open | 30 | 0.10 | 0.10 | 0.006 | 0.20 | 0.30 | 36.3 | 1081 |
| bestonly (G0) | closed | 40 | 0.00 | 0.00 | 0.052 | 0.57 | 0.23 | 87.1 | 1291 |
| fixed | open | 60 | 0.37 | 0.13 | 0.025 | 0.52 | 0.28 | 18.4 | 1047 |
| fixed | closed | 80 | 0.09 | 0.01 | 0.026 | 0.46 | 0.00 | 19.3 | 1126 |
| exact | open | 60 | 0.15 | 0.15 | 0.000 | 0.00 | 1.00 | 0.0 | 1180 |
| exact | closed | 80 | 0.00 | 0.00 | 0.000 | 0.00 | 1.00 | 0.0 | 1381 |

Safe success is success with no saved state inside a true box. The executed-block error is
the distance between the check's predicted pusher position at the end of each executed block
and the saved state there (for stage B, the final-iteration elite stands in for the unchecked
mean it executed). The PD-controller model matched every executed step of every B2 episode to
within 2e-13 px.

## Paired contrasts against the frozen check (mean over 20 layout-seed units, 95% bootstrap interval)

| contrast | success | safe success | exposure |
|---|---|---|---|
| fixed, open dials | +0.10 [-0.05, 0.23] | -0.02 [-0.15, 0.10] | +0.014 [0.008, 0.021] |
| fixed, closed dials | +0.09 [0.03, 0.15] | +0.01 [0.00, 0.04] | +0.010 [-0.003, 0.021] |
| exact, open dials | -0.12 [-0.27, 0.03] | 0.00 [-0.12, 0.12] | -0.011 [-0.015, -0.006] |
| exact, closed dials | 0.00 | 0.00 | -0.016 [-0.026, -0.008] |
| bestonly, open (G0, 10 units) | -0.03 [-0.23, 0.13] | 0.00 [-0.20, 0.17] | -0.002 [-0.012, 0.007] |
| bestonly, closed (G0, 10 units) | 0.00 | 0.00 | +0.025 [0.007, 0.042] |

## What B2 shows

1. **The exact check turns the dial into a guarantee.** Zero exposure in all 140 episodes and
   realized clearance at least the nominal dial in every one of them. On G80, where the gap is
   close to the direct line, it threads at d = 0 and 10 in 20 of 20 episodes and completes 8,
   all safely. On G0, where the safe route needs a larger detour, it threads 8 of 30 open-dial
   episodes and completes 1; the rest hover above the wall on 10 to 20 percent longer paths.
2. **The grounded probe sees the pusher but the planner still cuts corners.** It halves the
   error of the predicted position at the end of each executed block (33 to 18 px with the gap
   open, 95 to 19 px past closure) and completes more often, but most of the extra completions
   cut through a pillar: safe success is unchanged (0.13 against 0.15) while exposure rises.
   Exposure no longer falls to zero at large dials (0.016 to 0.026 at d = 50 and 60, against
   0.000 to 0.002 for the frozen check), and past closure the nominal clearance is never
   honoured.
3. **Grounding changes how the planner fails, not how often it safely succeeds.** With the
   gap open, safe success is 0.15, 0.13 and 0.15 for the frozen, grounded and exact checks.
   Past closure it is zero for all of them: nobody finds the detour.
4. **Executing the best candidate does not help here.** With the frozen probe it leaves
   open-dial behaviour unchanged and raises exposure past closure (+0.025 [0.007, 0.042]); the
   unconstrained planner completes 0.3 with it against 0.5 with the elite mean on both layouts.
   Picking the single best candidate exploits the world model's errors, where averaging the
   elites hedges them. The `fixed` condition and stage C2 include this choice, which was fixed
   before B2 ran; it is a likely contributor to their exposure.
5. **Uncertainty-unit dials with the grounded check** (12, 26 and 32 px, from the v2 anchored
   imagined error) complete 0.1 to 0.5 against 0.0 for stage B's dials, but keep exposure at
   0.013 to 0.048, so the recipe still does not deliver calibrated clearance.

## Reading for the paper

Perception was the first bottleneck and is now fixed. Two planner-level bottlenecks remain:
the world model's imagined motion of the pusher is still about 19 px off per block, and the
myopic goal cost cannot find a detour. With an exact constraint the planner is safe by
construction but stalls when the safe route bends away from the goal; with a learned check it
completes more by trespassing. The headline metric for the honours story should be safe task
completion, which no check improves on its own. Stage C2 tests whether searching the
interface does.
