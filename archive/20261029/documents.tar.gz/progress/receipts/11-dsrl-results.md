# Task 11 results: DSRL improvement phase

25 October 2026. Status: **stopped after stage A**. The first engineering episodes
failed at simulator start-up, and Sachin chose to stop and preserve rather than amend
the replacement limit and raise the cap. The four-condition reward and prior-replay
pilot was never run. Run log: [11-dsrl-run.md](11-dsrl-run.md). Build and freeze:
[11-dsrl-stage-a-build.md](11-dsrl-stage-a-build.md).

## What was built (workstation)

The stage-A freeze (`11-dsrl-stage-a.json`, SHA256 `ecff530a...`) covers:

- Native Gaussian noise plus a bounded latent residual,
  `noise = epsilon + 0.25 * tile(u, 16)` with `u` in [-1, 1]^32. A zero residual
  passes the native draw through bitwise (unit tests plus the pinned real
  `Policy.infer`).
- The denser R1 potential (reach, closed, grasp, lift, goal) with
  `0.25 * (gamma^d Phi' - Phi)` shaping. Verified against the native goal-region
  check, telescoping over partial chunks, and zeroing after violations.
- The calibration gate on the configured reduction of the ten critic heads.
- The four-condition pilot coordinator, with condition-isolated states and RNG.
- 315 workstation tests, ruff check and format clean, and a CPU preflight with the
  real backend (engineering parity 0.0, CPU actor difference 0.0).

## What ran on the rental

### A1: critic diagnostic grid (stage C's schedule; seeds 11061 and 11062)

| Cell | Updates | Result | What the gate saw |
|---|---|---|---|
| UTD 20, min | 30,000 | paused (both seeds) | Min of ten heads about -1.9 at update 1,000 (100% of pairs below -0.30); inside the gate again only after about 25,000 updates |
| UTD 20, mean | 30,000 | paused (both seeds) | Inside until update 19,500, then 77-99.9% of pairs above 1.05; head mean 1.20, maximum 1.65, against returns in [0, 1] |
| UTD 5, min | 7,500 | paused (both seeds) | Same pessimistic start as UTD 20, min |
| UTD 5, mean | 7,500 | **admitted** (both seeds) | Inside throughout, but the policy barely moved (entropy 21.85 to 21.86) |

The frozen preference order selected UTD 5 with mean reduction.

### A2: live decoder checks on the real Jar policy servers

All four lanes passed. Same-process native repeats were exact. The zero residual
reproduced the native draw, historical draws were reproduced, and the residual's
influence was present and finite. Cross-process differences against lane 0 (at most
0.003 absolute, RMS about 0.0004) are descriptive only, as frozen.

### Engineering: no episode ran

At 17:46:51 E0-E3 started together on a cold host. All four tried at once to download
and unpack the same two Isaac Sim extensions into one shared cache. E0 and E1 failed
with `FileExistsError`. The frozen rule then closed admission and stopped all
workers, interrupting E2 and E3 during start-up. Task 7 avoided this only because its
first lane happened to start six minutes before the others. No policy control,
warm-up control or episode model query was used.

## What this does and does not show

- **Shows:** Task 7's critic-inflation diagnosis reproduces under the frozen gate.
  With mean reduction at UTD 20, the reduced estimate climbs well above any
  achievable return late in the schedule (head mean 1.20 on recorded pairs).
- **Shows:** min reduction fails the gate from below at the start. The minimum of ten
  freshly initialized heads is strongly pessimistic, and the frozen rule excuses only
  the initialization measurement. That rejection is about the gate's early
  measurements, not about inflation.
- **Shows:** at UTD 5 with mean reduction the critic stays calibrated for 7,500
  updates, but the actor hardly changes. That admission is evidence of calibration,
  not of learning.
- **Shows:** the zero-residual interface reproduces native decoding on the live GPU
  policy servers, as well as in workstation tests.
- **Does not show anything about safe completion.** No episode ran, so there is no
  evidence on R1 shaping, prior replay, or any of the four pilot conditions. The
  planned primary condition (`r1_prior`) and final checkpoint were never reached or
  evaluated. No larger shaped return or clipped critic value is claimed as progress.
- Held-out tasks were untouched. No episode of any kind ran.

## Accounting

Frozen ledger: 4 starts, 0 replacements, 0 policy controls, 0 warm-up controls, 172
model-only queries, 150,021 learner updates (150,000 diagnostic and 21
engineering-preflight), 0 learning updates.

Compute, by the financial book, came to $3.87 across three hosts. Two of them were
replaced before any experiment ran on them:

- 57688543 stuck pulling its image: $0.95.
- 57692161 downloaded at 1.75 MB/s, and 0.2 MB/s from download.pytorch.org: $1.08.
- 57697202 in Taiwan, where everything above ran: $1.84.

Provider billing, destruction and provider absence are recorded in the closeout
receipt.

## For any later attempt (decisions, not done here)

1. Before the first multi-lane episode, warm the simulator once, serially; for
   example, one headless Kit launch at the end of preparation. Alternatively, stagger
   the first start on each lane. Either change needs a new freeze.
2. Decide whether the gate should also excuse the first few post-update measurements
   for min reduction. As frozen, min reduction cannot pass, whatever its later
   behaviour.
3. Treat the UTD 5 / mean selection as conservative. It was admitted partly because
   its policy did not move in 7,500 updates.
4. Budget from this run's measured timings: Taiwan preparation took 32 minutes. Host
   selection should test real download speed (PyTorch, PyPI, Hugging Face) before
   deployment, because advertised bandwidth was unreliable on both Japan hosts.
