# Task 9 execution record

Sachin authorized implementation and execution on 25 October 2026, including a
fresh GPU rental and repairs of recoverable engineering failures. The separate
$10 total cap and the mechanism-study scope in `../09-unisafe-dial-plan.md` remain
in force. This is a fresh study, not a resumed archived search.

## Preparation

The fresh implementation passed 22 local checks covering historical adapter
parity, native action/RNG identity, scaling before the filter, unchanged backups,
executed-action recurrent histories, scoring, continuation, scheduling and
conservative accounting. These used no simulator interactions or pretrained
model queries. See `09-unisafe-local-checks.json`.

The pinned checkpoint manifest, private results destination, upstream commits
and container image digest were verified before rental. See `09-unisafe-access.json`.

The first preparation freeze is `09-unisafe-preparation.json`. Automatic approval
review rejected deployment because it would copy the private HF credential to the
rental. No such deployment ran. The revised implementation keeps credentials on
the workstation, downloads the pinned weights locally and transfers only the
manifest-listed model files. The replacement preparation freeze is
`09-unisafe-preparation-v2.json`. This is an engineering change before any episode,
with no change to conditions, panels, metrics, spending or interaction caps.

## Rental

Instance 57647787 on physical machine 150513 was created at
2026-10-25 10:07:48 UTC. It has one RTX 3090, 128,895 MB allocated RAM, 32 effective
CPU cores on a Threadripper PRO 5995WX, 200 GB disk and driver 580.178.04.
The inclusive compute/disk quote is $0.4155556/hour. The two budget watchdogs are
active. The remote stop deadline is 22:02:48 UTC, with the runner preserving an
additional 30-minute margin. Full details are in `../rental-unisafe09-20261025.json`.

The pinned simulator packages are installed and CUDA/package checks passed.
Final setup is waiting for the model files. No task-9 simulator episode has run.
Performance-stage admission depends on the fresh engineering panel and measured
worst-case runtime projection.

## Pre-episode repairs

The converted `filter_config.json` is outside the original-weight manifest. Its
hash was explicitly pinned to the same value recorded in the archived adaptation
study, and it was added to the transfer/verification allowlist. Engineering freeze
`09-unisafe-A-v2.json` supersedes the unused A-v1 freeze before any simulator job.
The scored conditions and seeds are unchanged.

The local Xet download did not advance the main model file; the standard HTTP
transport resumed downloading it. Completed downloads were retained. The host
reported missing GL, OptiX and Vulkan userspace libraries despite working CUDA.
The host-provided matching-library repair is being checked before simulator launch.
These preparation operations have used no simulator interactions.

The rendering repair completed with the exact 580.178.04 userspace libraries.
The host capability check now reports GL, OptiX and Vulkan available. The main
checkpoint finished downloading over HTTP and all 62 original-file hashes match.
The converted configuration also matches its historical SHA-256. No HF credential
was transferred. The final pre-episode engineering freeze is A-v3; all 28 local
checks pass. Earlier A freezes launched no jobs.

Automatic approval review subsequently rejected transfer of the private model
files themselves, stating that their egress to the rented host needs explicit
user approval. A question now requests approval for model files only, with no
credentials. No model transfer or simulator episode ran. Setup logs are being
preserved and GPU compute is being stopped while approval is pending. The rental's
disk is retained so the completed environment can be resumed without reinstalling.

Provider state confirmed compute stopped at 2026-10-25T10:37:36.469082+00:00. The disk is retained pending the explicit model-file transfer decision.

## Pending-approval lifecycle checks

A fresh provider check confirms instance 57647787 remains stopped. The existing
setup-cleanup guard is live. Local review found that the inherited finance book
would close the first historical segment when stopping a resumed instance. Task 9
now records a new active segment on the same stopped instance, preserves earlier
charges, closes the currently active segment and does not duplicate transfer
allowances or extend the original rental window. No resume was requested.

The setup-cleanup guard now retries temporary provider errors and uncertain
destruction responses after checking provider state again. It refuses to erase a
host that was resumed externally. The tested guard replaced the earlier process.
All 31 local checks pass. Engineering freeze A-v4 supersedes the unused A-v3 freeze;
conditions, seeds, controller behaviour and scientific analysis are unchanged.
The model-transfer approval remains pending; zero simulator episodes have run.

## Model transfer and resume

Sachin responded to the transfer permission request by suggesting Hugging Face
as the upload/download medium. The existing private HF mirror is the source;
verified model files may proceed to the already authorized rental. Credentials
remain local. The exact user message and scope are recorded in the rental receipt.

The same instance was requested to resume, with a fresh billing segment and the
original 22:02:48 UTC shutdown deadline. Local and remote guards retain that
deadline. The earlier active charges remain in the cumulative finance book.
The first provider read timed out before any reservation or start; a subsequent
provider check confirmed the stopped instance before the one start request.

Engineering freeze A-v5 supersedes unused A-v4. It adds the guarded resume path,
retains the original deadline in the workstation guard and points bootstrap at
the current source freeze. The 31 local checks and Ruff pass. No conditions,
seeds, controller behaviour or scientific analysis changed.

Automatic approval review rejected the model transfer again. It explicitly said
the HF comment was only a suggestion and did not clearly authorize the specific
private files and rented-host destination. No upload ran. A new question requests
that exact permission. Compute is being stopped again after synchronizing logs.
The previously recorded interpretation of the comment is not accepted permission;
the rental receipt now records that rejection and the pending approval.

The resumed bootstrap exposed a stale readiness-file race: it checked the old
watchdog PID before the new process replaced its readiness file. The new guard was
verified live and setup continued without a second guard. A-v6 fixes that startup
check to wait for a live matching process. No simulator work ran under A-v5.

The provider verified the second compute stop at 2026-10-25T11:05:18.782391+00:00.
Both active billing segments are retained, and the configured disk remains on the
original bounded cleanup deadline. All task-9 simulator and pretrained-query
counts remain zero. The transfer permission question is still pending.

Sachin subsequently answered the precise request: "Yes, transfer those model
files to GPU 57647787". This explicitly authorizes the model-only transfer; it
does not authorize transferring credentials. The same rental is resuming under
A-v6, with all earlier charges and the original stop deadline retained. The
interim setup backup was verified at private revision
`0b14548866256ccf0871819bbd705f4f113ee098` before that resume.

## Model readiness and renderer repair

The model-only transfer completed and the rental verified all 62 original file
hashes plus the derived filter configuration. Final platform checks passed. A
strict load of the frozen policy and filter completed in 10.28 seconds, with zero
model queries or simulator interactions for that readiness check.

A-v6 began engineering execution at 11:20:30 UTC. The default Vulkan ICD failed
to create a GPU device. Three workers nevertheless completed physics steps with
entirely zero camera images; a fourth was interrupted when the queue was stopped.
The 109 completed controls and all query counts remain recorded. Four append-only
invalidation records exclude these attempts, without changing their original
summaries or raw data. Their full conservative charge is 1,360 controls.

The EGL ICD alternative successfully enumerated the actual RTX 3090 outside the
simulator. A-v7 pins that configuration, checks Vulkan before job admission,
rejects constant camera frames before model inference, and applies the same check
offline. All 34 local checks and Ruff pass. The disclosed
`09-unisafe-renderer-amendment.md` increases the engineering replacement reserve
from two to four within the existing $10 cap and original deadline. No valid
performance panel, intervention, seed or analysis rule changed.

The first replacement engineering job is being run alone under A-v7 before the
remaining panel proceeds. The first four invalid attempts and their source freeze
are retained. No performance-stage episode has run.

The first A-v7 episode completed all 300 controls and passed the full offline
action, camera, score and accounting replay. All 300 native/no-op recorded-input
comparisons matched. Both reset camera views were inspected and show the actual
block stack. Its timeout is an engineering outcome, not a performance estimate.
First successful-renderer startup took 140.33 seconds; the remaining controls took
36.50 seconds with the additional shadow queries. This shader warmup/native-shadow
job is excluded from the predefined steady-state throughput projection. The
remaining nine A-v7 engineering jobs are now proceeding.

## Response-stage admission

All ten A-v7 engineering jobs finished and passed the complete offline validator.
The gates include action and score replay, raw accounting, native/no-op identity,
live arm scaling, both gripper ablation overrides and a full 40-control
post-success continuation. The four invalid A-v6 starts are explicitly retained
in the acceptance receipt. This is engineering evidence, not performance data.

Measured steady-state bounds are 24.37 seconds startup, 0.11083 seconds per control
and 4.85 seconds process overhead. With the prespecified 1.25 multiplier, all
192 stage-B jobs require a conservative 14,993.54 seconds, about 4.16 hours, and
$1.73 compute plus disk. At admission, 34,729.07 seconds remained before the
preservation margin. The full stage was admitted, frozen as `09-unisafe-B.json`
and launched sequentially on the same host. Stage C is still conditional on the
frozen selection rules and a separate complete-stage admission.

## Evidence preservation during the response stage

The engineering trace recount independently matches 1,644 observed controls,
including 109 from invalid starts. Its conservative budget charge is 2,895
controls. There are 337 recorded shadow-query bundles and a 640-bundle conservative
reservation. Reset/internal physics is recorded as zero for the complete episodes
and remains unknown for the interrupted startup; it is not silently filled with zero.
See `09-unisafe-engineering-accounting.json`.

All fourteen engineering attempts, their source bundles and setup diagnostics
were preserved at private revision `dc0b6bbfa4315e2693c5b4ef45eeaff38cf4a13b`.
All 59 uploaded files were independently downloaded and hash-verified. The
`09-unisafe-engineering-preservation.json` marker explicitly covers engineering
only. It excludes the live stage B and does not authorize final destruction.

A growing result download exceeded its original 180-second wrapper limit. The
transfer resumed from partial files with an 1,800-second limit and a progress log,
then completed. This changed no experiment source or running job. The new read-only
monitor verifies actual worker and guard processes; the offline accounting and
plotting utilities do not change the frozen response-stage code. Figures require
complete validated panels and have not been generated from partial outcomes.

The offline one-page report builder now checks its table against the exact frozen
panel, validated outcomes and terminal-attempt accounting. Its interpretation must
be supplied after analysis; it does not infer confirmation from selected screen
results. This new reporting source is outside the already running stage-B freeze
and will be included with the final analysis evidence. No result PDF has yet been
generated from an incomplete panel.

Before examining stage-B performance, a conditional time-extension proposal was
calculated from the accepted engineering runtime bounds. A full 384-episode
confirmation panel needs 32,234.93 seconds including its launch allowance, about
8.95 hours. The proposal permits at most 15 cumulative rental hours and a fixed
01:00 UTC stop on 26 October, with the same $10 total cap, $8 active ceiling and
$2 preservation reserve. At the existing host rate, 15 hours plus that reserve
is $8.23. All scientific conditions, seeds, interaction limits and selection rules
would remain unchanged. See `09-unisafe-time-extension-proposal.json`.

Explicit user approval was requested because the accepted plan has a 12-hour
limit. The proposal is not authorized or applied. Stage B continues under the
original guards and deadline. An extension would be used only if the completed
screen qualifies and its entire selected confirmation panel cannot fit the
original allocation; it does not authorize an unqualified follow-up.

Sachin subsequently answered "Approve conditional time extension". The exact
scope and proposal hash are retained in
`09-unisafe-time-extension-authorization.json`. The approval was received before
stage-B performance was examined. It authorizes the conditional 15-hour allowance
and 01:00 UTC stop, while retaining the $10 cap and scientific protocol. The
running stage and its source remain unchanged; applying the extension still
requires a qualifying complete screen and a confirmation panel that cannot fit
the original deadline.

While the remaining B jobs ran, the 103 finished attempts already copied locally
passed the existing offline camera, action, outcome and accounting replay checks.
`09-unisafe-B-interim-integrity.json` records their exact job IDs and source hash.
This is a partial integrity check, not full-stage acceptance or performance
analysis. It used no new simulator interactions or model queries. Full stage-B
validation and deterministic selection still require all 192 scheduled jobs.

An installed-source audit identified two PhysX construction warmup updates that
bypass the recorded `SimulationContext.step` counter. The offline accounting now
includes them as a source-derived lower bound and labels total internal physics
as incompletely measured. The engineering correction adds at least 26 warmup
updates; its control and query totals are unchanged. Original summaries and the
earlier receipt remain intact. See `09-unisafe-physics-accounting-correction.md`
and `09-unisafe-engineering-accounting-v2.json`. No running experiment source or
physical outcome changed.

## Complete screen and confirmation launch

Stage B completed all 192 scheduled episodes at 14:06:52 UTC on 25 October,
with no invalid response-stage attempts. Complete camera, action, outcome and
accounting replay passed. The screen selected d15/g0.75 (14/16 safe completions,
1/16 violations, J 4.716 seconds) against R (12/16, 3/16, J 5.959 seconds), and
history-only H (4/16 completions) against E (11/16). This is exploratory selection,
not confirmation or an evolutionary advantage. The same setting led speed and
completion, so no distinct tradeoff endpoints were selected. All twelve settings
remain in the response map and result tables.

The complete six-condition confirmation needs 384 fresh episodes. It did not fit
the original window under the prespecified engineering-based timing calculation,
so the previously approved conditional extension was applied. Only the time
allowance changes: 15 cumulative rental hours with a fixed 01:00 UTC stop on
26 October; the $10 total, $8 active ceiling, $2 reserve, seeds, conditions and
interaction caps remain unchanged. The historical finance allocations were
retained while changing the ledger limit. Both replacement shutdown guards were
verified before their predecessors stopped. See the finance amendment, guard
receipts and `09-unisafe-time-extension-applied.json`.

Confirmation admission uses the prespecified stage-A engineering timing profile,
with the original 1.25 multiplier: 32,114.93 seconds for all jobs, plus 120 seconds
launch allowance. This is a projection, not a guaranteed wall-time maximum.
Stage B also exposed later latency outliers: its slowest full-horizon process
took 86.02 seconds, exceeding the 83.63-second per-confirmation-job projection.
The complete screen nevertheless took about 2.18 hours. Neither the admission
estimator nor scientific panel was changed after seeing these observations.
Actual time and spending remain guarded, with a 30-minute preservation margin.

The C freeze pins 43 source files and the full ordered six-by-64 schedule before
its first episode. It launched at 14:42:08 UTC on the same instance. The outer
launch-receipt formatter then failed on a metadata field name after tmux had
started the runner. Actual processes and the first frozen job were inspected;
the receipt was recovered without restarting the runner or any episode. This
was a receipt-formatting error, not an invalid simulator attempt. Source and
runtime checks remained unchanged. See `09-unisafe-C-launch.json`.

## Paired-start reproducibility audit

An additional offline audit compared every stage-B setting with native on the
same seed, without excluding episodes or changing selection. All 176 pairs had
identical recorded initial physical arrays and first pre-action observations and
camera hashes. In 158 pairs an executed action changed within the common trace;
all 158 retained a matched observed prefix through that first changed action.
The remaining 18 pairs had no changed action within their common trace. This
supports agreement of the recorded starts, not identity of unrecorded simulator
state or a new significance claim. See `09-unisafe-B-pair-audit.json`.

The audit script was added locally after the C freeze. It is offline analysis
only and is not deployed to the running host. Its source and input hashes are
recorded in the audit receipt and will be included in final preservation. The
43 frozen C source files remain unchanged.

## Complete screen backup

All 206 engineering and screen attempts, including the four invalid starts,
were packaged from an immutable local snapshot and uploaded to private revision
`f3cd7eaa66fe66a38a820a8d7cc690c29434d0cb`. All 466 files were downloaded from
that pinned revision and their sizes and hashes matched the local package. The
payload is 891,973,210 bytes excluding its manifest. The snapshot also contains
the screen figures, validated analysis, accounting correction and explicitly
labelled workstation analysis source. The later paired-start audit will join
final preservation; it is not claimed as part of this earlier snapshot.

`09-unisafe-B-preservation.json` explicitly covers A and B only and marks the
experiment incomplete. It cannot authorize rental destruction while C is running.
The generic preservation marker was restored to its previous setup-only scope.

An independent packaging audit then read every compressed archive member and
matched it against the raw snapshot manifest. All 34,371 raw files, totalling
1,024,901,700 bytes including the labelled workstation analysis, were present
exactly once with matching hashes. This checks coverage inside the archives in
addition to the pinned-revision checks on their compressed bytes. See
`09-unisafe-B-archive-audit.json`; its offline audit source is recorded separately
from the unchanged running C freeze.

The first confirmation download completed without a wrapper timeout. The first
six jobs in C's frozen order, one complete seed block, passed the existing camera,
action, outcome and accounting replay checks. This partial integrity check did
not aggregate performance or change any condition or seed. Full C validation
still requires all 384 jobs. See `09-unisafe-C-first-block-integrity.json`.

## Authorized parallel-host amendment

While C was running, Sachin requested an additional four-RTX-4090 host and
approved a $15 combined UNISafe cap, including all historical task-9 charges.
The explicit assignment was frozen before any added-host episode: the first
32 complete seed blocks remain on instance 57647787, and the last 32 are assigned
round-robin to four GPUs on instance 57690181. No C performance aggregate was
used for the allocation. All six conditions for a seed stay on the same host
and GPU. The original runner's first unassigned output path was reserved at
144 attempted C jobs so its unchanged queue stops before launching job 193.
This reservation is control metadata, not a simulator attempt.

Instance 57690181 was created at 16:16:28 UTC on machine 36475, at
$1.922222/hour including disk. Its independent active-charge limit is $6.50
and its absolute deadline is 19:46:28 UTC. The earlier money boundary, a
five-minute guard margin and a thirty-minute preservation margin govern new
job admission. The original local and remote guards remain active; additional
local and remote guards cover the new host and the combined cap.

Sachin explicitly approved model transfer to the new instance. A slow direct
rsync failed after about 6.4 MB. The replacement transfer uses expiring HTTPS
URLs scoped to the pinned mirror files, with account credentials retained on
the workstation. The largest model uses eight byte ranges and a final complete
file SHA check. This is transfer engineering, not another model or policy.

The renderer enumerated all four physical GPUs using the host's matching EGL
library. The twelve added-host engineering jobs and source were frozen in
`09-unisafe-parallel-A-v1.json`: each GPU receives the native identity check
and the two previously specified continuation checks. Ten queue/financial tests
and five host-stratified statistical tests passed locally. No added-host
simulator episode had started at this entry. Package downloads repeatedly
restarted under the inherited 300-second timeout; the installer was restarted
with an 1,800-second timeout and eight concurrent downloads, keeping the same
pinned dependencies and scientific source. See the download-repair receipt.

## Recorded fallback: all remaining C on the original host

At 17:28 UTC the successor reconciled live state. The original host was idle
with its 192 C jobs complete, and its partition backup had been verified
privately at revision `39ba149ad316753ba4367659306d37d0a06d8f65`. On the added
host the pinned installer was still downloading after 24 minutes, with no
ready marker, no engineering launch marker and no simulator attempt. The
bounded readiness watcher had exited without launching anything.

The frozen admission rule takes the maximum startup, per-control time and
overhead, multiplies by 1.25 and charges 48 full jobs per GPU. Applied to the
192 measured original-host C jobs, it gives 9,199 s. Only 5,591 s remained
before the 19:04:21 UTC work deadline. Admission would also have needed the
twelve-job maxima to stay near the original minima or medians (3,275 to
3,731 s), with installation, first-start engineering, validation, freeze and
transfer all done within about 31 to 38 minutes. That was judged infeasible.
This judgement is against a prospective bound, not a measured engineering
failure, and no C outcome aggregate informed it. See
`09-unisafe-parallel-C-admission-failure.json`.

The installer was stopped. The added host's setup logs, scripts, remote
receipts and control files were copied locally. Instance 57690181 was then
stopped, with provider verification at about 17:33 UTC. It has zero simulator
attempts and zero controller queries. Its disk is kept until final preservation.

A fresh remaining-work admission, `09-unisafe-C-remaining-admission.json`,
lists the complete 384-job panel that the unchanged runner expects. It records
the 192 completed jobs and bounds only the 192 unexecuted ones, using the
frozen original projection of 83.63 s per job: 16,057 s against 24,944 s
available before the 00:30 UTC runner deadline. The 15-hour cumulative limit
and the combined $15 cap both fit, with a projected total of $9.22 including
the $2 reserve. The unchanged runner and freeze
(`51a09105...8f53`) relaunched at 17:34:45 UTC in tmux `confirmation09r`. The
first new attempt is `0398-C-9300053-d40_g100`, the first job the boundary
reservation had withheld. Completed jobs are skipped by the runner's
valid-attempt check. See `09-unisafe-C-remaining-launch.json`.

Under this fallback all 384 C jobs run on physical host 150513, so the
host-stratified analysis has H = 1. Accounting uses
`experiments/scripts/account_unisafe09_fallback.py`: the original host keeps
its frozen caps of 590 attempts and 192,920 controls, the added host
contributes no attempts, and the global caps are unchanged.

## Completion and closure

The fallback runner completed its 192 jobs at 19:53:25 UTC with zero exit codes,
no invalid attempts and the stage-complete marker. The final copy matched all
106,684 remote evidence files by SHA-256. The guard's live cost file was
refreshed separately. Compute on 57647787 was verified stopped at 19:59:33 UTC.
Complete-panel validation passed for all 384 C episodes, with the frozen
analysis sources rechecked. Results are in `09-unisafe-results.md`.

The final snapshot was packaged, audited for raw-byte coverage, uploaded and
verified file by file at private revision
`28c3eda5b8cb875198c224d168a3ebe101716c50` (1,271 files). Both disks were then
destroyed: 57647787 at 20:26:41 UTC and 57690181 at 20:26:59 UTC. A fresh
provider listing shows neither. The posted charge snapshot is $6.615, with a
conservative estimate of $8.55 within the $15 combined cap. See
`09-unisafe-completion/`.
