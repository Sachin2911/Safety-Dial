# Task 14 receipt: stage B dial sweep (25 October 2026, 22:22 to 22:34 UTC)

Freeze `progress/receipts/14-cube-B-v1.json` (230 jobs, design v1, 300 samples, top 30),
run on instance 57723845 with 4 workers in 11 minutes (about 1200 episodes/h). Evidence
synced to `outputs/cube14/remote/attempts/B-*`; analysis by
`experiments/scripts/analyze_cube14.py --stage B` in `outputs/cube14/analysis/`.

Scene S15 (dataset rows 1899137 -> 1899162), reach task (pinch point within 0.04 m of the
goal frame's), keep-out band y 0.16 to 0.21 m with an 0.08 m gap. Seeds 200 to 209 shared
across conditions.

| layout (gap offset) | free success / safe success / entries | checked d = 0: success / safe success / entries | checked d = 1 to 4 cm |
|---|---|---|---|
| C0 (on the route) | 0.8 / 0.2 / 7 of 10 | 0.4 / 0.3 / 1 of 10 | 0 success, 0 entries |
| C1 (2 cm off) | 0.8 / 0.2 / 7 of 10 | 0.3 / 0.3 / 0 of 10 | 0 success, 0 entries |
| C2 (4 cm off) | 0.8 / 0.0 / 9 of 10 | 0 / 0 / 0 of 10 | 0 success, 0 entries |

- The free planner reaches the goal in 8 of 10 seeds but cuts through the band in 7 to 9 of
  10 (mean exposure 0.12 to 0.21).
- The check removes almost all entries: one checked episode in 150 (C0, d = 0, one step,
  exposure 0.002) touched the band. The check predicts the pinch point from the commands
  with a fitted gain, so a small miss at d = 0 is possible; no episode with d >= 1 cm
  entered.
- Safe success with the check at d = 0 is 0.3 on C0 and C1 against 0.2 for the free
  planner; on C2 both are 0.
- Any margin stops the planner: from d = 1 cm no checked episode reached the goal on any
  layout. The gripper descends but makes no progress toward the band, and it ends 13 to 21 cm
  from the goal while the world model's goal cost is about as low as at the goal.
- Side diagnoses after B (outside the frozen stages, `outputs/cube14/side-probes/`): 1000
  samples with the top 10 lift C0 at d = 0 to 3/4 but leave d = 1 cm at 1/4; a 0.12 m gap
  (1/4 at d = 2 cm) and a clearance shrinking with depth (1/4) do not remove the stall. The
  latent goal cost is flat over the last 15 to 20 cm, so once the direct plans are ruled out
  nothing pulls the planner on.

Stage C changes its search layout to C1 (holdout C0) because every C2 cell scored 0 safe
success, which would give every method a search hypervolume of 0. Frozen at 22:40 UTC
(`14-cube-C-v1.json`, 8 generations x 3 replicates, 3672 episodes, estimated 3.7 h) and
launched at 22:41 UTC.
