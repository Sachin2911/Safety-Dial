# Task 10 receipt: stage C2, searching the constraint interface on the grounded pipeline (25 October 2026, 15:18 to 19:10 UTC)

Freeze `progress/receipts/10-safecem-C2-freeze.json` (sha256 1a003582...). Ladder rung chosen
at the freeze from the measured 22.6 s per episode per worker: 8 generations, 3 replicates,
3672 planned episodes. 3032 ran, because several final fronts held fewer than the cap of six
candidates. Zero failed attempts. Pipeline, fixed before B2 ran: anchored probe v2 check and
best-candidate execution, i.e. the B2 `fixed` condition. Analysis:
`outputs/safecem10/analysis/stageC2-{summary.json,table.md,fronts.*}`.

## Compute and integrity

- Primary: instance 57660116 (RTX 3090, $0.26/h, 3 workers) ran the generation-synchronous
  runner and 1949 episodes.
- Helper: instance 57689039 (RTX 3090, New York, $0.29/h, from 16:06 UTC) ran 1083 episodes
  fed by `experiments/scripts/relay_safecem10.py`. The relay claims tickets from the back of
  the primary queue and installs finished attempt directories on the primary by atomic rename
  before writing done tickets.
  - Version 3 (from 17:00 UTC) tops up the helper before harvesting and claims at most half
    of a generation's remaining tickets near its end.
  - A session reset killed the relay at 17:15. It was restarted detached at 17:18;
    reconciliation adopted the 11 in-flight tickets, and nothing was lost or duplicated.
- Every one of the helper's 5425 attempt files (1085 attempt directories) is byte-identical
  in the primary mirror (`outputs/safecem10/helper-remote/comparison-with-primary.json`).
- Wall clock 3 h 52 min. At the end of C2 the task-10 book showed 10.6 aggregate rental
  hours of the 14-hour cap and an active spend estimate of $2.89 (plus $0.16 transfer). The
  helper was stopped at 19:21 UTC after its evidence was hashed and mirrored.

## Results (final fronts re-evaluated on ten fresh seeds, 400 to 409)

| method | replicates | search HV | fresh-seed HV (G0) | held-out HV (G80) | best safe success, G0 | best safe success, G80 |
|---|---|---|---|---|---|---|
| NSGA-II | 3 | 14.99 ± 4.91 | 6.23 ± 2.89 | 8.64 ± 2.27 | 0.43 ± 0.21 | 0.27 ± 0.24 |
| random search | 3 | 17.21 ± 1.79 | 9.18 ± 3.47 | 5.32 ± 3.86 | 0.60 ± 0.14 | 0.17 ± 0.17 |
| grid | 3 | 11.01 ± 0.82 | 3.77 ± 0.74 | 7.56 ± 0.38 | 0.33 ± 0.09 | 0.17 ± 0.05 |

Mean ± sd over replicates. Per replicate, best safe success on G0 / G80:
- NSGA-II: 0.7 / 0.1, 0.2 / 0.1, 0.4 / 0.6
- random search: 0.5 / 0.4, 0.5 / 0.0, 0.8 / 0.1
- grid: 0.2 / 0.2, 0.4 / 0.1, 0.4 / 0.2

Pairwise wins across the 9 replicate pairings:
- NSGA-II against random: fresh HV 3/9, held-out HV 7/9.
- Grid against random: fresh HV 0/9, held-out HV 6/9.
- Grid against NSGA-II: fresh HV 3/9, held-out HV 3/9.

Like-for-like baseline: the best single dial on the same pipeline in B2 reached safe success
0.3 on G0 (d = 12) and 0.3 on G80 (d = 32), on the B2 seeds 200 to 209.

## What the fronts contain

- Horizon 3 in every random-search front and in two of three NSGA-II fronts. The 96-point
  grid only offers horizons 4, 5 and 6, which is a structural handicap on fresh seeds.
- Positive feasibility tolerance (1 to 13 px) in every NSGA-II and random front setting.
- Two clearance strategies:
  - small and slowly shrinking, e.g. d0 = 2 px, d1 = -2.9 px per block (NSGA-II run 0:
    0.7 on G0, 0.1 on G80);
  - wide and shrinking fast, e.g. d0 = 38 to 39 px, d1 = -6.5 to -7.7 px per block
    (NSGA-II run 2: 0.4 on G0, 0.6 on G80).

## What C2 shows

1. **Searching the interface beats any single fixed dial on the search layout.** Mean best
   safe success on fresh G0 seeds is 0.43 (NSGA-II), 0.60 (random search) and 0.33 (grid)
   against 0.30 for the best fixed dial; all three random replicates and two of three NSGA-II
   replicates exceed it.
2. **NSGA-II does not beat random search where it searched, but it transfers better.** Fresh
   hypervolume favours random search (9.2 against 6.2, NSGA-II wins 3 of 9 pairings).
   Held-out hypervolume favours NSGA-II (8.6 against 5.3, 7 of 9). With three replicates and
   standard deviations of 2 to 4 hypervolume units, neither difference is conclusive.
3. **The gain does not carry to the held-out layout on average.** Held-out best safe success
   is 0.27, 0.17 and 0.17 against 0.30 for the best fixed dial there. The best single
   held-out result, 0.6, comes from NSGA-II's wide-then-shrinking clearance.
4. **Caveat on selection.** Best-of-front safe success is a maximum over up to six candidates
   on the same ten seeds, just as the fixed-dial baseline is a maximum over eleven dials, so
   both are optimistic by a similar margin. Hypervolume over the whole front is the protocol's
   primary comparison.

## Next

Task 12 found on TwoRoom that CEM under a hard constraint needs a much smaller elite set
(top 10 of 1000) to keep the rare feasible, goal-reaching candidates. C2's elite-fraction gene
spans 0.05 to 0.3 of 300, so it never tested that regime. That is a cheap follow-up for the
B2 observation that the exact-check planner hovers above the wall on G0.
