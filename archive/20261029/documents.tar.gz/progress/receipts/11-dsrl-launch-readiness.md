# Task 11 launch-readiness review

Recorded 25 October 2026, about 16:05 UTC, before any task-11 rental exists.

## Authorization

- The goal authorizes one fresh four-RTX-4090 rental for the DSRL improvement phase.
- At about 15:50 UTC Sachin instructed an immediate rental: "Oh geez you should
  definitely rent something, we have budget. Won't it finish faster then too".
- Asked about the cost of renting before workstation work finished, Sachin chose
  "Rent now, cap $18" at about 15:58 UTC. The total cap rises from $15 to $18.
  Limits: total $18.00, active $15.00, active shutdown $14.90, other reserve
  $3.00, 8 aggregate hours, rate at most $2.20/h. The cap is not raised further.

## Scope admitted now

This launch admits creation, host verification, the remote financial watchdog and
pinned runtime preparation (`11-dsrl-setup.json`). No frozen stage starts until
the stage-A freeze (`11-dsrl-stage-a.json`) exists and is deployed in run mode.
The run deployment refuses to proceed if any preparation input or guard source
differs from the setup authorization.

## Preconditions

- Task 7 closeout is not final. Its receipt (`07-dsrl-completion/README.md`) shows
  compute verified stopped and checkpoint preservation and destruction pending
  under the Task 7 session. Sachin's instruction overrides waiting for it.
  Instance 57632188 (stopped) is not restarted, adopted or touched.
- Other rentals on the account belong to other tasks and are untouched: 57647787
  (Task 9, running) and 57660116 (Task 10, running).
- The task-11 financial book starts fresh; no Task 7 charge or rental is inherited.

## Verified on the workstation

- Protocol tests: 28 passed (schedule, seeds, residual injection, R1 geometry and
  bounds, reward identity with partial chunks, ledger caps and phases, pause rule,
  selection rule).
- Residual server tests: 24 passed, including the real pinned `Policy.infer`
  (OpenPI 215abfb, SHA256 a2ac5236...) where a zero residual reproduces native
  actions and key advancement bitwise for three successive queries.
- Residual validator tests: 27 passed, including R1 against the frozen formula,
  native goal-intersection reproduction from the recorded AABB, every corrupted
  provenance field rejected, and a full 2,000-control actor timeout.
- Static audit (`outputs/dsrl11/stage-a/static-audit.json`): 24 Task 7 episodes,
  return-identity error at most 3.5e-17; author source uses no backup entropy,
  per-transition discounts and mean/min reductions.
- Task 7 forward replay (`outputs/dsrl11/stage-a/task7-forward.json`) reproduces the
  critic inflation: the reduced estimate rises from 0.35 at initialization to 3.76
  after 15,000 updates and 37.19 at 90,000, with 99.6% to 100% of calibration pairs
  outside [-0.30, 1.05], against true returns in [-0.25, 1].

## Pending before the stage-A freeze

Learner orchestration tests, the CPU author-backend integration check, coordinator
tests, the input copies and the stage-A freeze with its receipts. These run while
the rental prepares.

## Price and preliminary full-schedule admission

Qualifying offers at 15:56 UTC: $1.816/h (48 cores, Japan), $1.898/h (112 cores,
258 GB, driver 580.173.02, 1.9 Gbit/s down, Taiwan), $1.922/h and higher. The
112-core offer 48565455 is preferred for four simulator lanes and fast downloads.

Conservative serial projection from Task 7 timings (preparation 2,700 s, numerical
900 s, cold episode 1,500 s, four-lane episode 560 s, three-lane episode 470 s,
0.023 s per update, 900 s restarts, 1,200 s local copy):

| Rate | Workstation wait | Hours | Active cost | Allowed hours | Margin |
|---|---|---|---|---|---|
| $1.898/h | none | 5.93 | $11.26 | 7.85 | 1.92 h |
| $1.898/h | 75 min | 7.18 | $13.63 | 7.85 | 0.67 h |
| $1.816/h | 75 min | 7.18 | $13.04 | 8.00 | 0.82 h |

The measured stage-C admission on the rental remains binding. If it cannot cover
the frozen comparison, the comparison is reported as unaffordable, not shrunk.

Launch decision: admitted for the setup scope above.

## Amendment before deployment (about 16:08 UTC)

Instance 57688543 (`jar-dsrl11-1025160153`, offer 41396007, $1.922/h, 64 cores,
Japan) was created at 16:02 UTC; the 112-core offer had been taken minutes earlier.
Its financial stop deadline is 23:41:58 UTC. Before any deployment, two source
defects were fixed: the coordinator hard-coded the superseded $15 envelope (it now
reads the shared `LIMITS`), and the rental record's `spending_cap_usd` said 15
while its enforced limits already held the $18 envelope. The undeployed setup
authorization and bundle were regenerated from the corrected sources.
