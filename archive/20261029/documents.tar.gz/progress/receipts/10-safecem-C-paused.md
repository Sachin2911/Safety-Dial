# Task 10 receipt: stage C paused for the grounded-check fix (25 October 2026, 13:50 UTC)

Stage C (freeze `progress/receipts/10-safecem-C-freeze.json`, 8 generations x 3 replicates,
3672 episodes planned) started at 13:22 UTC. At about 13:45 the stage B diagnosis showed that
the safety check underneath every candidate misread the pusher out of distribution
(`docs/research/research_notes/SafeCEM task 10 diagnosis and next steps.md`). The user
approved pausing stage C and fixing the check first ("Yes go ahead").

The pause used the runner's own stop path: a `STOP` file at 13:50 UTC made the runner raise
"Preservation margin reached; stop admitted work" and every worker exit after its current
episode. No process was killed mid-episode; the claimed queue was empty afterwards.

What exists: 194 complete episodes, all in generation 0 (grid r0 36, grid r1 36, NSGA-II r0
36, NSGA-II r1 26, random r0 36, random r1 24; replicate 2 not reached), out of the 324 that
generation 0 needs. No generation record has objectives, so no search state exists. Records:
`outputs/safecem10/remote/attempts/C-*` and `outputs/safecem10/remote/stageC/*/gen-00.json`.
The stop file was renamed to `STOP-stageC-paused-20261025T1350Z.txt` before stage B2 started.

Stage C is not resumed. The grounded check changed the planner sources, so the C freeze no
longer verifies against the tree; its exact sources are kept in
`outputs/safecem10/source/bundle-10-safecem-C-freeze.tar.gz`. The search is rerun as stage
C2 on the grounded pipeline (protocol amendment in `progress/10-safecem-dial-plan.md`). The
partial C episodes remain evidence of the frozen pipeline's behaviour on the stage C seeds
and are reported, never pooled with C2.
