# Task 13 receipt: diagnosis and stage A engineering (25 October 2026, 21:57 to 22:16 UTC)

Rental: instance 57723813, one RTX 3090 (Oregon, 24 cores, $0.31/h), created 21:22 UTC;
preparation (model 62adae4b..., dataset e70a080d... 23.75 GB, scalers, EGL render check)
finished 21:53 UTC. Admission record: `outputs/reacher13/engineering.json` (passed, all
four checks). Freeze `progress/receipts/13-reacher-A-v3.json` (11 jobs, design v1).

## Diagnosis (freeze 13-reacher-preparation-v2, no hazard, LeWM's planner 300/30)

`outputs/reacher13/diagnosis/`. Our goal frames match the dataset's to 0 pixels.

| episodes | success |
|---|---|
| 24 dataset pairs 25 steps apart (LeWM's protocol) | 13/24 |
| fixed sweep (0.55, 0.9) -> (-0.55, 0.9), 8 seeds | 6/8 |
| fixed sweep (0.7, 0.9) -> (-0.7, 0.9), 8 seeds | 6/8 |
| fixed sweep (0.85, 0.9) -> (-0.85, 0.9), 8 seeds | 2/8 |
| fixed sweep (1.0, 0.9) -> (-1.0, 0.9), 8 seeds | 0/8 |
| smaller sweeps 0.25 and 0.4, 4 seeds each | 0/8 |

The exact arm model replayed every executed step except the last step of successful
episodes (up to 1.6 cm). The DMC wrapper stops repeating an action once the task
terminates, so that step can be one physics step instead of two; the replay now accepts
either for the final step of a successful episode, and stage A replays to 1.3e-16 m.

## Design v1

Fixed sweep (0.7, 0.9) -> (-0.7, 0.9): the fingertip arcs from (0.088, 0.197) to
(0.209, -0.053) m; free routes cross y = 0.07 m at x = 0.187 to 0.225 m with steps of at
most 0.034 m. Band y 0.05 to 0.09 m across the arena, one 0.05 m gap at x = 0.207 (R0,
on the route, held out), 0.1945 (R1, sweep) and 0.182 (R2, search). Dials 0 to 0.025 m;
the gap closes at 0.025.

## Planner setting

A-v1 crashed at worker start (no MUJOCO_GL for the workers; the runner now passes the
backend preparation verified). A-v2 used task 12's 1000 samples with the top 10: the free
planner failed 6/6 on R0 and R1 (and 3/3 on R2) while the checked planner at d = 0 still
reached the goal on R2. That would cripple the baseline, so the design returned to LeWM's
300/30 in every condition (A-v3); the elite fraction remains a stage-C gene. Superseded
attempts are kept on the rental under `outputs/reacher13/superseded/`.

## Stage A-v3 (6 workers, 32 s for 11 episodes, 1232 episodes/h)

| job | success | steps | exposure | crossing | realized clearance |
|---|---|---|---|---|---|
| free, seed 100 (R0 / R1 / R2) | yes | 20 | 0 / 0 / 0.05 | gap / gap / band | 1.2 / 1.1 / -0.2 cm |
| free, seed 101 | no | 50 | 0 / 0 / 0 | gap | 1.1 / 1.3 / 0.0 cm |
| free, seed 102 | yes | 26 | 0 / 0 / 0.08 | gap / gap / band | 1.0 / 0.0 / -0.5 cm |
| checked d = 0, R2, seed 100 | yes | 36 | 0 | gap | 1.3 cm |
| checked d = 0.01, R2, seed 100 | yes | 49 | 0 | gap | 2.1 cm |

The free planner enters the band on R2 (gap 2.5 cm off its route) on two of three seeds;
on the same seed the checked planner threads the gap at both dials, slower at d = 0.01.
Stage A's checked jobs execute the elite mean (the design default); stage B's checked
condition executes mean_safe.
