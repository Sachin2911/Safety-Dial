# Experiment receipts

Receipts describe what was planned, executed, observed and preserved. Keep their
contents and paths stable. A historical plan or host record is not launch authority.
Use the [progress index](../README.md) to find the next approved work.

The [26 October LeWM dataset consolidation](lewm-datasets-consolidation-20261026.json)
records both private dataset revisions, all attempted episodes and replay media,
and download-and-hash verification of every uploaded file. The associated
[honours manuscript evidence manifest](../../docs/research/honours-gecco/evidence-manifest.json)
maps its claims to the frozen records.
The [plain-language dataset refinement](dataset-clarity-refinement-20261026.json)
records verified documentation-only updates to all four datasets. Experimental
data and replay videos were unchanged; prior pages remain preserved.

| Task | Main records |
| --- | --- |
| 1 | `01-*`, `01b-*`, `01c-*`; [paper evaluation configuration](01-jar-eval.yaml); [excluded instance B](excluded-instance-B/README.md) |
| 2 | [Timelines](02-timelines.md), [pairs](02-pairs.md), [task notes](02-task-notes.md); image sheets are in the private dataset (see [preservation](02-preserve.md)) |
| 3 | [Frozen plan](03-plan.json), [results](03-results.md), [preservation](03-preserve.md) |
| 4 | [Frozen plan](04-tracking-plan.json), [results](04-tracking-results.md), [preservation](04-tracking-preserve.md), [completion](04-tracking-completion.json) |
| 5 | [Executed plan v4](05-adapter-plan-v4.json), [results](05-adapter-results.md), [preservation](05-adapter-preserve.md), [completion verification](05-adapter-completion-verification.json), [billing](05-adapter-billing.json) |
| 6 | [Result](06-dsrl-results.md), [run](06-dsrl-run.md), [executed source v4](06-dsrl-stage-a-v4.json), [decoder audit](06-dsrl-decoder-audit.md), [learner audit](06-dsrl-learner-runtime.md), [independent accounting](06-dsrl-independent-audit.json), [completion](06-dsrl-completion/README.md) |
| 7, experiment complete; preservation closing | [Result](07-dsrl-results.md), [analysis](07-dsrl-analysis.json), [run](07-dsrl-run.md), [final source freeze](07-dsrl-stage-b-v2.json), [critic diagnostic](07-dsrl-critic-diagnostic.json), [reserve handover](07-dsrl-reserve-handover.json) |
| 8 | [Result](08-screen-results.md), [confirmation](08-screen-confirmation-results.json), [final audit](08-screen-audit.json), [protocol](https://github.com/Sachin2911/Safety-Dial/blob/1291199e665ed574050de42a7708c19965ecda35/progress/08-knob-screen.md), [frozen source and schedule](08-screen-plan.json), [run](08-screen-run.md), [completion](08-screen-completion/README.md) |
| 9 | [Result](09-unisafe-results.md), [run](09-unisafe-run.md), [C freeze](09-unisafe-C.json), [validation](09-unisafe-C-combined-validation.json), [analysis](09-unisafe-C-combined-analysis.json), [post hoc contrasts](09-unisafe-C-descriptive-contrasts.json), [accounting](09-unisafe-final-accounting.json), [runtime](09-unisafe-runtime.json), [fallback decision](09-unisafe-parallel-C-admission-failure.json), [remaining admission](09-unisafe-C-remaining-admission.json), [final preservation](09-unisafe-final-preservation.json), [completion](09-unisafe-completion/README.md); historical handover |
| 11, stopped after stage A | [Result](11-dsrl-results.md), [run](11-dsrl-run.md), [launch readiness](11-dsrl-launch-readiness.md), [stage-A build](11-dsrl-stage-a-build.md), [frozen source](11-dsrl-stage-a.json), [setup manifest](11-dsrl-setup.json), [completion](11-dsrl-completion/README.md) |
| 15, recovery handoff prepared | [Result](15-regrasp-results.md), [handoff prompt](../goal-prompt-15-regrasp-handoff.md), [provider and local status](15-regrasp-handoff-status-20261026.json), [posted billing](15-regrasp-handoff-billing-20261026.json), [private evidence lookup](15-regrasp-handoff-private-check-20261026.json), [live source v2](15-regrasp-live-v2.json), [stage D declaration](15-regrasp-stage-d.json), [stage D source](15-regrasp-stage-d-v1.json) |

Task 16 is complete: [results](16-lewm-results.md), [statistics](16-final-statistics.json),
[joint final freeze](16-final-ab-v1.json), [audit](16-final-audit.json),
[selected controllers](16-final-selection.json), [raw preservation](16-preservation-final-raw.json),
[report preservation](16-preservation-final-closeout.json), [destruction](16-rental-destroy.json),
[billing](16-billing-destroyed-final.json) and [closeout verification](16-closeout.json).

Task 17 is complete: [results](17-lewm-evolution-results.md),
[statistics](17-final-statistics.json), [comparison freeze](17-optimizer-comparison.json),
[final audit](17-final-audit.json), [completion audit](17-completion-audit.json),
[local recovery](17-local-recovery.json), and
[external rental absence](17-external-status-20261026.json).
The [campaign](../17-lewm-evolution-campaign.md), authorization and rental records
are historical execution evidence, not permission to resume the completed work.

Task 18 is complete: [plain-language results](18-lewm-results.md),
[independent final audit](18-final-analysis-check.json), [media checks](18-media-validation.json),
[local hash verification](18-final-local-preservation.json),
[private dataset verification](18-datasets-preservation.json),
[rental destruction](18-rental-destroy.json) and [final closeout](18-closeout.json).
The [reset repair](18-reset-repair-admission.json) preserves and charges the original
676 PushT attempts while excluding them from final efficacy estimates. Both valid
cohorts contain 1,352 attempts. The completed protocol and rental records are historical
execution evidence, not permission to resume another campaign.

For task 5, `05-adapter-plan.json`, `05-adapter-plan-v2.json` and
`05-adapter-plan-v3.json` precede the executed v4 plan. Read the three amendment
receipts for the changes. Preserve those versions and their hashes; do not rename,
rewrite or execute them. The failed-provisioning receipts account for the first
task 5 rental separately from its successful replacement.
