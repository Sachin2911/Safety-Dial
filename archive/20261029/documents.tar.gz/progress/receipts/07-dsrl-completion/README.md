# Task 7 completion receipts

Scientific work is complete: all six engineering, 24 training and 48 evaluation
episodes are valid, with a working numerical integration and a negative completion
screen. Native achieved 3/12 strict safe completions and DSRL 0/12, both with 4/12
violations. One learner seed and one development panel do not support a general
claim about DSRL.

**Closeout is still in progress.** Compute is verified stopped. The complete local
raw snapshot and SQLite backup are hash-verified. Private dataset downloads are
being checked at a pinned revision; checkpoint preservation and final destruction
remain pending. Do not treat this folder as a finished preservation certificate
until the final preservation, teardown and upload-verification receipts exist.
Task 7 cleanup belongs to the current agent. Do not restart instance 57632188 or
adopt it for another experiment.

Available evidence:

- [local-copy.json](local-copy.json): full local inventory verification before compute stop.
- [analysis-database.json](analysis-database.json): frozen SQLite backup used for analysis.
- [analysis-check.json](analysis-check.json): outcome and interaction-ledger reconciliation.
- [schedule-and-source.json](schedule-and-source.json): all 78 resolved jobs, final actor versions and frozen source hashes.
- [final-actor.json](final-actor.json): exact final trained-state/export audit without extra model calls.
- [training-signal.json](training-signal.json): reward density across all 24 training recordings.
- [billing-post-stop.json](billing-post-stop.json): provider charge snapshot, subject to later adjustments.
- [cost-bound-preclose.json](cost-bound-preclose.json): conservative pre-destruction bound with a two-hour disk reserve.
- [odyssey.json](odyssey.json): compilation and visual review of the finished-task entry.

The final closure appendix will carry provider absence, billing, the private primary
dataset/model revisions and the final documents. It is separate from the immutable
primary snapshot. Outer verification receipts are produced after verifying the
files they describe; they do not claim to contain themselves recursively.
