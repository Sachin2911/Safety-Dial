# Task 10 receipt: rental, preparation and engineering setup (25 October 2026)

All times UTC. Protocol: `progress/10-safecem-dial-plan.md`. Design: `configs/safecem10/design.json`.

## Freezes

| file | purpose | note |
|---|---|---|
| `10-safecem-preparation-v1-superseded.json` | first preparation freeze (11:45) | superseded before any remote use: `run_safecem10.py` had a key collision in the stage C final record and did not replay the NSGA-II RNG on resume for generation 0 |
| `10-safecem-preparation-v2-superseded.json` | second preparation freeze (11:54) | deployed to the rental at 12:00; setup failed at the import check (`imageio` missing from the pinned requirements) |
| `10-safecem-preparation-v3.json` | preparation freeze actually used (12:04) | adds `imageio==2.37.4` and `imageio-ffmpeg==0.6.0`; preparation completed under it |
| `10-safecem-A-freeze.json` | stage A engineering freeze (12:20) | 14 jobs, same sources as v3 except the admission and freeze scripts (throughput bookkeeping) |

Every freeze records sha256 of 19 source files plus the full job list; the remote verifies
the hashes before any work.

## Rental

- First create attempt (11:46, offer 56596544, Spain) returned an uncertain acknowledgement
  and no instance with the label ever appeared in two authoritative listings a minute apart.
  The reservation was released (`reconcile --release`) and charged nothing. Offer ids churn
  between listings, so the manager now falls back to the best current non-China offer with
  reliability at least 0.99.
- Created 11:57: instance 57660116, label `pusht-safecem10-1025115711`, Austria, one RTX
  3090 (24 GB), 8 cores, 31.5 GB RAM, 80 GB disk, driver 610.57.04, $0.2637/h including
  storage, 726 Mbps down. Allocation deadline 2026-10-26 01:52 (financial deadline minus
  five minutes). Local watchdog pid 785538; remote instance-scoped watchdog started 12:00.
- Record: `progress/rental-safecem10-20261025.json`. Finance: `outputs/safecem10/control/`.

## Preparation (remote, 12:05 to 12:19)

- Packages: torch 2.13.0+cu132 (uv auto backend for the 610 driver), stable-worldmodel
  0.1.1, stable-pretraining 0.1.8, transformers 5.14.1.
- Checkpoint `quentinll/lewm-pusht` at the pinned revision, weights sha256 verified,
  converted with the transformers-v5 key remap to `lewm_object.ckpt`.
- Dataset `pusht_expert_train.h5.zst` at the pinned revision, 13,136,247,974 bytes,
  sha256 verified, decompressed. Scalers (action, proprio, state) fitted on all rows.
- Probe: 100k frames (100 contiguous chunks), 80 epochs. Test split from the same chunks:
  R2 0.9991, RMSE 3.02 px, radial p95 7.5 px (matches the September pilot).
- Imagination calibration: 1500 random dataset snippets, 5 imagined blocks (25 env steps)
  from the real actions.

| depth (blocks) | imagined radial p50 | imagined p95 | probe on real frame p50 | probe on real frame p95 |
|---|---|---|---|---|
| 1 | 8.3 | 34.7 | 4.9 | 31.7 |
| 2 | 9.2 | 35.1 | 4.7 | 29.5 |
| 3 | 9.6 | 35.3 | 4.8 | 27.2 |
| 4 | 10.1 | 35.2 | 4.7 | 24.6 |
| 5 | 10.2 | 32.6 | 4.4 | 22.0 |

Two things worth stating plainly. The held-out probe error (random snippets, almost all
outside the training chunks) has a heavy tail: p95 of 22 to 32 px against 7.5 px on the
chunk-local test split the pilot reported, so the pilot's probe figure was optimistic.
And the imagined-depth error grows only slowly with depth: most of the uncertainty at
depth 5 is probe error, not dynamics error. The dials in uncertainty units for stage B are
the depth-5 quantiles p90 = 25 px and p95 = 33 px (p50 = 10 px coincides with the grid).

## Local checks before renting

- 15 unit tests pass (`experiments/tests/test_safecem10.py`), ruff clean.
- CPU plumbing smoke of the planner with the converted checkpoint, synthetic scalers and a
  random probe: two 6-step episodes, states and metrics consistent, model query counts as
  expected. The synthetic artefacts were deleted afterwards.
- Synthetic-evidence runs of the admission, freeze sizing and analysis scripts.
