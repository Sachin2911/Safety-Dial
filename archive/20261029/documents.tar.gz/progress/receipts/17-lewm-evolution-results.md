# Task 17: LeWM evolutionary-controller comparison

26 October 2026.

All 7,800 admitted episodes completed, including thirty independent optimizer runs and 1,632 final episodes. The frozen criterion for an evolutionary completion advantage was not met. On the primary Reacher 1.5 cm endpoint: Evolution 101/120, Random search 97/120, REINFORCE 99/120, Retuned fixed 20/24.

## Design and execution

The optimizers are established methods: [Salimans et al., ES](https://arxiv.org/abs/1703.03864) and [Williams, REINFORCE](https://doi.org/10.1007/BF00992696). The frozen task-17 recipe specifies this implementation; applying them here is not an algorithmic novelty claim.

The compact alternative was frozen before optimizer outcomes: five independent runs per method and environment, six rounds, and the first twelve fresh final cases per environment. Each run paid for 24 deterministic common-anchor episodes, 144 stochastic training episodes and 24 deterministic validation episodes. The final panel used two requested clearances and two fresh planner seeds. Fixed references were each evaluated once per case/clearance/seed, not copied five times.

The initial p90-per-episode scheduling estimate rejected both proposed workloads. Before training, the scheduler packed individual runs across two lanes per GPU and used the measured all-mode mean with a 50% timing contingency, a further 40% evaluation imbalance allowance, and 30 minutes for startup/reporting. This admitted the predeclared compact workload and rejected the full workload. The initial rejection receipt is retained. No outcomes determined panel size or optimizer settings.

All adaptive methods used the same 36 bounded coefficients, six observation inputs and six planning modes. LeWM's 18,034,478 parameters per environment, scalers, five-action executable block, 50-action limit and exact checker stayed frozen. Clearance was an input, never an output. The task-side selector used no true position, target geometry or candidate endpoint. The exact safety checker retained its declared state and dynamics access. Training used softmax sampling; selection and final deployment used deterministic argmax. The fixed tuning and historical-information anchors are distinct comparators.

Training used requested-safe completion minus 0.1 times failure-capped J/50. Random search re-evaluated its incumbent with seven fresh candidates on every common batch. Evolution used four antithetic Gaussian directions. REINFORCE used only its current 24 trajectories and a running scalar baseline. Every method had the same four-finalist validation allowance and a shared anchor fallback. Unsafe candidates were disqualified before selection. The final parameters were frozen before final case deserialization and evaluation.

Panels were generated from disjoint task-17 RNG streams using task-16 geometry ranges and endpoint validity checks. No case was filtered by success. Final geometry was present only in its sealed file; source integrity checks hashed that file without deserializing it in training. Final access and the complete parameter selection have separate receipts. Geometric validity does not prove 50-action feasibility.

A pre-final seed audit found that the first proposed final planner pair overlapped the last replicate's training seeds. Before any final-case access or evaluation, a [recorded amendment](17-final-planner-seed-amendment.json) replaced it with 179710 and 179711, disjoint from every planned nonfinal planner seed. Panels, counts, selection and inference rules stayed fixed.

## Final outcomes

Counts below retain failures, censored attempts and every accepted case. Movement defines engagement, not progress toward the goal.

| Environment | Clearance | Method | Safe completion | Original violations | Margin breaches | Unfinished | Engaged | Censored | Mean capped J |
| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| tworoom | 4 | Task-16 fixed | 23/24 | 0/24 | 0/24 | 1/24 | 24/24 | 0/24 | 13.17 |
| tworoom | 4 | Retuned fixed | 24/24 | 0/24 | 0/24 | 0/24 | 24/24 | 0/24 | 12.33 |
| tworoom | 4 | Random search | 117/120 | 0/120 | 0/120 | 3/120 | 120/120 | 0/120 | 13.49 |
| tworoom | 4 | REINFORCE | 117/120 | 0/120 | 0/120 | 3/120 | 120/120 | 0/120 | 12.83 |
| tworoom | 4 | Evolution | 118/120 | 0/120 | 0/120 | 2/120 | 120/120 | 0/120 | 12.83 |
| tworoom | 6 | Task-16 fixed | 24/24 | 0/24 | 0/24 | 0/24 | 24/24 | 0/24 | 15.62 |
| tworoom | 6 | Retuned fixed | 24/24 | 0/24 | 0/24 | 0/24 | 24/24 | 0/24 | 15.62 |
| tworoom | 6 | Random search | 119/120 | 0/120 | 0/120 | 1/120 | 120/120 | 0/120 | 15.99 |
| tworoom | 6 | REINFORCE | 120/120 | 0/120 | 0/120 | 0/120 | 120/120 | 0/120 | 14.68 |
| tworoom | 6 | Evolution | 120/120 | 0/120 | 0/120 | 0/120 | 120/120 | 0/120 | 14.93 |
| reacher | 0.01 | Task-16 fixed | 24/24 | 0/24 | 0/24 | 0/24 | 24/24 | 0/24 | 19.17 |
| reacher | 0.01 | Retuned fixed | 24/24 | 0/24 | 0/24 | 0/24 | 24/24 | 0/24 | 22.67 |
| reacher | 0.01 | Random search | 120/120 | 0/120 | 0/120 | 0/120 | 120/120 | 0/120 | 23.18 |
| reacher | 0.01 | REINFORCE | 118/120 | 0/120 | 0/120 | 2/120 | 120/120 | 0/120 | 23.38 |
| reacher | 0.01 | Evolution | 119/120 | 0/120 | 0/120 | 1/120 | 120/120 | 0/120 | 22.29 |
| reacher | 0.015 | Task-16 fixed | 20/24 | 0/24 | 0/24 | 4/24 | 24/24 | 0/24 | 34.67 |
| reacher | 0.015 | Retuned fixed | 20/24 | 0/24 | 0/24 | 4/24 | 24/24 | 0/24 | 33.29 |
| reacher | 0.015 | Random search | 97/120 | 0/120 | 0/120 | 23/120 | 120/120 | 0/120 | 34.11 |
| reacher | 0.015 | REINFORCE | 99/120 | 0/120 | 0/120 | 21/120 | 120/120 | 0/120 | 32.77 |
| reacher | 0.015 | Evolution | 101/120 | 0/120 | 0/120 | 19/120 | 120/120 | 0/120 | 31.98 |

## Contemporary protocol context

This small development panel is descriptive context, separate from the reserved final comparison.

| Environment | Clearance | Context method | Requested-safe | Benchmark-safe | Violations | Margin breaches | Unfinished | Engaged |
| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| tworoom | 4 | native | 1/9 | 5/9 | 4/9 | 8/9 | 0/9 | 9/9 |
| tworoom | 4 | canonical | 6/9 | 6/9 | 0/9 | 0/9 | 3/9 | 9/9 |
| tworoom | 6 | native | 1/9 | 5/9 | 4/9 | 8/9 | 0/9 | 9/9 |
| tworoom | 6 | canonical | 0/9 | 0/9 | 0/9 | 0/9 | 9/9 | 9/9 |
| reacher | 0.01 | native | 2/9 | 7/9 | 0/9 | 6/9 | 2/9 | 9/9 |
| reacher | 0.01 | canonical | 6/9 | 6/9 | 0/9 | 0/9 | 3/9 | 9/9 |
| reacher | 0.015 | native | 0/9 | 7/9 | 0/9 | 9/9 | 2/9 | 9/9 |
| reacher | 0.015 | canonical | 0/9 | 0/9 | 0/9 | 0/9 | 9/9 | 9/9 |

Benchmark-safe completion is also retained separately in the machine-readable statistics. The requested margins are 4 and 6 pixels in TwoRoom, and 1 and 1.5 cm in Reacher. The checker enforced the full requested margin in every checked episode.

## Primary paired comparisons

The practical target was a ten-percentage-point completion gain over each of random search, REINFORCE and the newly tuned fixed reference. The intervals resample whole optimizer runs and whole case blocks independently while retaining paired methods and both planner seeds. The three primary contrasts use 98.33% intervals; other descriptive intervals use 95%.

| Evolution minus | Difference, percentage points | 98.33% interval |
| --- | ---: | --- |
| Random search | 3.3 | [-20.8, 25.8] |
| REINFORCE | 1.7 | [-10.0, 15.0] |
| Retuned fixed | 0.8 | [-20.8, 20.0] |

Five optimizer repeats and twelve case blocks have limited power. A ceiling can make the bootstrap interval degenerate. Zero breaches in n episodes gives an approximate 3/n episode-wise upper bound, not a zero-risk guarantee; repeated cases and trained controllers further limit independence. No transfer, general safety or algorithmic novelty claim follows from this campaign.

## Every optimizer run

Method labels identify the complete selection procedure. When validation selects an anchor or the initial coefficients, the deployed controller was not produced by optimizer updates. The provenance column makes this visible; gains from a shared anchor are not evidence that evolution discovered a better controller.

| Environment | Method | Run | Selected candidate | Final safe completion, low margin | Final safe completion, high margin |
| --- | --- | ---: | --- | ---: | ---: |
| reacher | Evolution | 0 | anchor | 95.8% | 75.0% |
| reacher | Evolution | 1 | penultimate | 100.0% | 79.2% |
| reacher | Evolution | 2 | anchor | 100.0% | 91.7% |
| reacher | Evolution | 3 | anchor | 100.0% | 91.7% |
| reacher | Evolution | 4 | anchor | 100.0% | 83.3% |
| reacher | Random search | 0 | last-round-c7 | 100.0% | 91.7% |
| reacher | Random search | 1 | last-round-c0 | 100.0% | 83.3% |
| reacher | Random search | 2 | last-round-c3 | 100.0% | 83.3% |
| reacher | Random search | 3 | last-round-c6 | 100.0% | 62.5% |
| reacher | Random search | 4 | anchor | 100.0% | 83.3% |
| reacher | REINFORCE | 0 | anchor | 95.8% | 75.0% |
| reacher | REINFORCE | 1 | final | 100.0% | 83.3% |
| reacher | REINFORCE | 2 | final | 95.8% | 79.2% |
| reacher | REINFORCE | 3 | anchor | 100.0% | 91.7% |
| reacher | REINFORCE | 4 | anchor | 100.0% | 83.3% |
| tworoom | Evolution | 0 | anchor | 95.8% | 100.0% |
| tworoom | Evolution | 1 | anchor | 95.8% | 100.0% |
| tworoom | Evolution | 2 | final | 100.0% | 100.0% |
| tworoom | Evolution | 3 | anchor | 100.0% | 100.0% |
| tworoom | Evolution | 4 | anchor | 100.0% | 100.0% |
| tworoom | Random search | 0 | anchor | 95.8% | 100.0% |
| tworoom | Random search | 1 | anchor | 95.8% | 100.0% |
| tworoom | Random search | 2 | last-round-c1 | 100.0% | 100.0% |
| tworoom | Random search | 3 | last-round-c7 | 100.0% | 95.8% |
| tworoom | Random search | 4 | last-round-c0 | 95.8% | 100.0% |
| tworoom | REINFORCE | 0 | anchor | 95.8% | 100.0% |
| tworoom | REINFORCE | 1 | anchor | 95.8% | 100.0% |
| tworoom | REINFORCE | 2 | anchor | 95.8% | 100.0% |
| tworoom | REINFORCE | 3 | anchor | 100.0% | 100.0% |
| tworoom | REINFORCE | 4 | anchor | 100.0% | 100.0% |

Validation selected shared anchors in eight of ten evolution runs and eight of ten REINFORCE runs. Both optimizers changed coefficients in all sixty rounds and exercised all six modes, so the negative result is not explained by an inactive update loop. The gradient and allocation tests passed. The small validation panel, six-round search and train/deploy sampling difference limit what this result says about either optimizer beyond this frozen recipe.

## Learning diagnostics and resources

Round-to-round training utility also changes with the common case batch. These curves describe the search trajectories and do not estimate held-out deployment improvement. Per-episode execution seconds and per-run elapsed wall_seconds, including model startup and result writing, are retained separately from the resource counters in the machine-readable evidence.

The analytical REINFORCE gradient passed a finite-difference expected-reward test, and complete synthetic runs verified all three optimizers' charged allocations. Live diagnostics record reward variance, entropy, coefficient changes, gradient norms and actual selected modes for every round. No reward, step size, panel or stopping rule was changed after optimizer outcomes.

| Method | Completed rounds | Mean reward variance | Mean entropy | Nonzero coefficient updates | Mean gradient norm |
| --- | ---: | ---: | ---: | ---: | ---: |
| Random search | 60 | 0.10554 | 0.000 | 55 | 0.000 |
| REINFORCE | 60 | 0.11647 | 1.577 | 60 | 0.442 |
| Evolution | 60 | 0.12232 | 1.499 | 60 | 1.208 |

REINFORCE and evolution each execute one coefficient-update step per completed round; there are no world-model gradient updates. Random search does not calculate a gradient; its stored zero gradient/entropy diagnostics are placeholders. Selection and round checkpoints retain the actual candidate weights, scores and mode counts.

| Resource, all attempts | Count |
| --- | ---: |
| environment resets | 7,800 |
| goal render frames | 7,800 |
| render frames | 193,870 |
| encoder frames | 82,278 |
| model candidate rollouts | 470,768,966 |
| predictor steps | 1,136,321,665 |
| checker candidate rollouts | 470,941,211 |
| checker physics steps | 3,946,414,366 |
| executed physics steps | 318,709 |
| environment actions | 193,861 |
| analytic path steps | 3,708,000,933 |
| Frozen model batch calls, reconstructed from recorded iterations | 452,516 |

Equal episode counts were not treated as equal simulator interaction work. Each optimizer run had the same enforced action, predictor and checker ceilings, including anchors and validation. Early completion and selected horizons changed actual consumption. The resource vector and learning curves expose those differences. Saved replan records distinguish proposed CEM means and checked selected blocks; state traces record actual commands. Analysis separately reconstructs simulator-bounded controls with the frozen [-1,1] clipping, not joint torques. Validation was not repeated at common consumed-resource checkpoints, so this study does not support an equal-work or search-efficiency claim. Counterfactual Reacher physics and TwoRoom analytic path steps are charged separately from executed actions. Episode reset counts exclude implicit simulator construction/forward operations, which are not controlled physics integrations. Native engineering parity probes had additional counted predictor allowance beyond the base ticket reservation.

Shared verification also performed 14,499,085 synthetic analytic path checks, derived from recorded test-suite executions and fixed solver loop shapes. These used dummy costs: zero live simulator integrations and zero frozen-LeWM model queries. They are separate from the measured episode resource vector above; see the [synthetic test-work receipt](17-synthetic-test-work.json).

## Validation, preservation and rental closeout

All 48 engineering episodes passed native identity, constant-mode parity, rendering and dense checker replay. Seventeen focused implementation tests passed. The final audit independently recomputed dense violations, completion labels, action/physics counts, optimizer resource totals, selection ordering and the complete final job set. No failed rollout starts occurred in the admitted campaign. Historical task-16 files and all other task allocations were left unchanged.

Every completed batch was uploaded to the existing private dataset `Sachioster/maniguard-jar-replication-20261022`, under `17_lewm17_campaign/57809511/`. Each archive was downloaded at its pinned revision and hash-verified. Source archives, all attempts, model identities, panels, optimizer checkpoints, reports and the Odyssey are included. Credentials, caches and downloaded frozen weights are excluded.

The final completion-status receipt records the last observed conservative cost and verified backup. The authorized finish command hands terminal preservation and self-destruction to the independent guard. A finish request or accepted provider deletion request is not external absence verification. Final absence and posted billing must be checked from another device or the Vast console.

Reproduce with `experiments/scripts/analyze_lewm17.py` and `experiments/scripts/report_lewm17.py` using `/venv/main/bin/python` on the restored private snapshot. See [statistics](17-final-statistics.json), [audit](17-final-audit.json), [comparison freeze](17-optimizer-comparison.json), [final freeze](17-final-evaluation.json), and the [campaign](../17-lewm-evolution-campaign.md). Exportable figures are under [safe completion](../../outputs/lewm17/analysis/safe-completion.pdf), [primary contrasts](../../outputs/lewm17/analysis/primary-contrasts.pdf), and [training resources](../../outputs/lewm17/analysis/training-resources.pdf).
