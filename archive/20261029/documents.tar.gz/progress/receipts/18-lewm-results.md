# Task 18: helping SafeCEM finish object-moving tasks

27 October 2026. Final experiment results; preservation and rental closeout are recorded separately.

We kept the learned world model and requested safety margin unchanged and changed how the planner searches for moves. The final panel has twelve cases and three planner seeds per task. Development and final cases come from different demonstration episodes. All settings were frozen before the final panel ran.

## The result at the largest safety margin

Safe completion means reaching the task goal without entering the forbidden area or its requested buffer. A breach and an unfinished task can happen in the same attempt. Engagement means movement, not useful progress.

| Task | Planner | Safe / attempts | Breaches | Unfinished | Engaged | Capped actions |
|---|---|---:|---:|---:|---:|---:|
| PushT, 12 px | Native | 0/36 | 30 | 28 | 36/36 | 50.00 |
| PushT, 12 px | Original SafeCEM | 2/36 | 0 | 34 | 36/36 | 49.53 |
| PushT, 12 px | Tuned fixed | 19/36 | 0 | 17 | 36/36 | 35.42 |
| PushT, 12 px | Feedback | 20/36 | 0 | 16 | 36/36 | 34.42 |
| Cube, 1 cm | Native | 0/36 | 34 | 35 | 36/36 | 50.00 |
| Cube, 1 cm | Original SafeCEM | 0/36 | 0 | 36 | 36/36 | 50.00 |
| Cube, 1 cm | Tuned fixed | 12/36 | 0 | 24 | 35/36 | 37.86 |
| Cube, 1 cm | Feedback | 12/36 | 0 | 24 | 35/36 | 37.86 |

Capped actions count the actions used by a safe completion. Every unsafe or unfinished attempt costs 50 actions. This includes early controller failures, so stopping early cannot look fast. Conditional successful-action means have their own denominators in the full tables.

## Paired comparisons

- pusht: Tuned fixed minus Original SafeCEM: +47.22 percentage points of safe completion, descriptive 95% case-bootstrap interval [22.22, 72.22].
- pusht: Tuned fixed minus Original SafeCEM: -14.11 capped actions, descriptive 95% case-bootstrap interval [-22.31, -6.42].
- pusht: Feedback minus Tuned fixed: +2.78 percentage points of safe completion, descriptive 95% case-bootstrap interval [0.00, 8.33].
- pusht: Feedback minus Tuned fixed: -1.00 capped actions, descriptive 95% case-bootstrap interval [-2.11, 0.00].
- cube: Tuned fixed minus Original SafeCEM: +33.33 percentage points of safe completion, descriptive 95% case-bootstrap interval [11.11, 58.33].
- cube: Tuned fixed minus Original SafeCEM: -12.14 capped actions, descriptive 95% case-bootstrap interval [-21.67, -3.72].
- cube: Feedback minus Tuned fixed: +0.00 percentage points of safe completion, descriptive 95% case-bootstrap interval [0.00, 0.00].
- cube: Feedback minus Tuned fixed: +0.00 capped actions, descriptive 95% case-bootstrap interval [0.00, 0.00].

Intervals resample twelve whole cases, preserving all paired seeds. They are conditional on the selected settings, not uncertainty over repeated tuning campaigns. No multiple-comparison claim gate is applied. A collapsed empirical interval means the observed case effects were identical; it does not prove population equivalence or zero uncertainty.

## Actual planning time

The serial timing pass uses the first two final cases, a separate common seed and the largest clearance. It runs without competing experiment workers. These are descriptive timings for two cases, not a population speed claim. Video playback is eight actions per second and is unrelated to compute latency.

| Task | Planner | Seconds per solve | Safe / attempts |
|---|---|---:|---:|
| pusht | Native | 0.579 | 0/2 |
| pusht | Original SafeCEM | 0.597 | 0/2 |
| pusht | Tuned fixed | 0.410 | 0/2 |
| pusht | Feedback | 0.413 | 0/2 |
| cube | Native | 0.637 | 0/2 |
| cube | Original SafeCEM | 0.928 | 0/2 |
| cube | Tuned fixed | 0.476 | 1/2 |
| cube | Feedback | 0.531 | 1/2 |

## What the comparison covers

PushT keeps the pinned environment's joint pusher/block position and block-angle goal. Cube measures the object centre reaching within 4 cm of its target, including height. This is the original object-moving objective with LeWM dataset-pair goals, not the earlier gripper-reaching probe and not the full official five-goal OGBench evaluation.

The safety rule covers the pusher centre or gripper pinch point against a synthetic forbidden region. It does not certify the whole robot or moved object against collision. PushT checks every physics step using its known pusher dynamics. Cube uses approximate population screening followed by true-simulator prefix checks, with full state restoration and no unchecked fallback.

Each task uses its own frozen checkpoint. Six fixed configurations are compared on six development cases, two seeds and three margins (216 attempts). Four feedback presets then use six cases, one seed and three margins (72 more). Feedback inherits fixed tuning and has additional development cost. No evolutionary search ran in task 18. The previous task-17 optimizer comparison remains a separate, negative result.

The separate native context panel uses twelve unfiltered dataset pairs and 25 actions per replan. Cube completes 10/12, but seven pairs already meet the object goal at reset. Among the five not initially solved, three complete. This cannot substitute for the nontrivial final moving-object panel.

## Repair and complete accounting

Publication review found that PushT reset advances the simulation slightly, while the initial cohort anchored its first safety prediction to the pre-reset dataset state. We corrected the anchor to the returned observation and repeated the entire frozen protocol, including development. All 676 original attempts remain preserved and charged, but excluded from efficacy estimates. Repaired engineering verified the post-reset state and dense pusher predictions. The cases, seeds, candidate library and selection rule did not change.

Each valid task cohort has 676 attempts: 8 engineering, 216 fixed development, 72 feedback development, 360 unique final episodes, 12 context and 8 serial timing. The two valid cohorts total 1,352; the excluded PushT cohort brings all scored attempts to 2,028. Native final episodes are rescored at three margins and are not counted as three separate experiments. Pre-data failed checks and synthetic model checks are counted separately.

| Charged work across all cohorts and preliminary checks | Count |
|---|---:|
| environment actions excluding reset | 72,289 |
| reset stabilization actions | 1,360 |
| environment resets | 2,033 |
| physics integration steps including reset and previews | 1,840,851 |
| counterfactual physics steps | 718,225 |
| predictor steps | 660,428,575 |
| model batch calls | 454,774 |
| model candidate rollouts | 239,697,421 |
| render frames including reset | 73,803 |

Reset stabilization and counterfactual previews are included explicitly. The original PushT reset work and pre-data reset work were reconstructed from pinned reset code; the repair measures reset work directly. Cube's fifty reset physics steps per episode are already in its recorded physics counter and are not counted twice. Actual actions, simulator checks and learned-model predictions are different costs.

Every scored-stage source archive and every selected result was checked against the frozen job lists. Independent scoring recomputed completion, original-hazard violations, margin breaches, unfinished outcomes, engagement, action counts and capped time from saved traces. Paired initial states matched within 1e-10. The pre-data engineering checks retain scripts, results and source hashes, but their complete intermediate runtime sources were not recovered.

## Evidence and examples

- [Frozen protocol](../../configs/lewm18/protocol.json), [repair admission](18-reset-repair-admission.json), [engineering repair check](18-pusht-repair-engineering.json).
- [Final local preservation](18-final-local-preservation.json), [dataset upload verification](18-datasets-preservation.json), [final closeout](18-closeout.json), [final publication](18-final-publication.json).
- [PushT data, videos and pictures](https://huggingface.co/datasets/Sachioster/SafetyDial-PushT/tree/main/campaigns/lewm18).
- [Cube data, videos and pictures](https://huggingface.co/datasets/Sachioster/SafetyDial-Cube/tree/main/campaigns/lewm18).

The two videos per task show the first two cases and first seed selected before outcomes. Galleries include all twelve final cases at that seed, including failures. Aggregate tables support the claims; examples illustrate behavior. Hugging Face datasets remain private.

The result supports evaluating a strong fixed configuration before attributing improvement to feedback or evolution. Configuration changes are bundled; there is no single-knob causal claim. Without a tuned native ablation, the experiment also cannot separate a generic planning improvement from an improvement specific to planning under the safety constraint.
