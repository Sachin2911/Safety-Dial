# Task 14 receipt: diagnosis and stage A engineering (25 October 2026, 21:56 to 22:21 UTC)

Rental: instance 57723845, one RTX 3090 (9 cores, $0.32/h), created 21:22 UTC;
preparation (model b0747c50..., dataset 02a19a67... 46.2 GB packed, 101.9 GB unpacked,
scalers, EGL render check) finished 21:50 UTC. Admission record:
`outputs/cube14/engineering.json` (passed, all four checks). Freeze
`progress/receipts/14-cube-A-v2.json` (11 jobs, design v1).

## Diagnosis (freezes 14-cube-preparation-v2 to v5, no hazard)

`outputs/cube14/diagnosis/`.

- Resetting to a dataset row's qpos/qvel and replaying the dataset's 25 actions reproduces
  the recorded pinch-point and cube paths to at most 0.3 mm (6 pairs).
- Our frames first differed from the dataset's (mean 5.6 to 9.2 of 255): OGBench draws the
  arm translucent in pixel mode by default, the dataset shows it opaque. The env now sets
  `pixel_transparent_arm=False`; the run with the translucent arm was stopped and kept as
  `diagnosis-transparent-arm` on the rental.
- Free planner (LeWM 300/30), the cube rule: random pairs 19/24, mostly pairs whose cube
  never moves (solved at step 1); pairs moving the cube at least 8 cm in the plane 0/24.
  The planner does not complete carries, so the dial study is a reach task: success when
  the pinch point is within 0.04 m (OGBench's cube tolerance) of the goal frame's.
- Reach pairs (cube still, pinch point travels at least 12 cm), 3 cm rule: 10/48.
- Four candidate scenes, 4 cm rule, 8 seeds each:

| scene (dataset rows) | 300/30 | 1000/top-10 |
|---|---|---|
| reach15 (1899137 -> 1899162) | 7/8 | 7/8 |
| reach17 (1248415 -> 1248440) | 7/8 | 3/8 |
| reach04 (1423082 -> 1423107) | 8/8 | 5/8 |
| reach00 (959575 -> 959600) | 6/8 | 8/8 |

- Tracking: the arm covers about 41% of each commanded step in the plane (least squares
  over 3802 steps: gain 0.40 / 0.41 / 0.335 in x / y / z, carry under 0.08). With the
  fitted gain the one-step planar error is median 3.7 mm, p95 11.6 mm, max 27 mm.

## Design v1

Scene S15 (reach15; reach00's route is too short for a band that stays clear of start and
goal under the largest dial). Keep-out band for the pinch point, y 0.16 to 0.21 m, full
height, x 0.2 to 0.65 m; one 0.08 m gap at x = 0.447 (C0, on the free route, held out),
0.467 (C1, sweep), 0.487 (C2, search). Dials 0 to 0.04 m; the gap closes at 0.04. The
check predicts the pinch point from the commands with the fitted gain (interpolating four
points per step), so unlike tasks 10, 12 and 13 it is approximate and the dial is also a
margin for its error. Planner 300/30 in every condition, as in task 13 (A-v1 at
1000/top-10 was stopped after the 300/30 scene results came in; kept under
`outputs/cube14/superseded/`).

## Stage A-v2 (3 workers, 40 s for 11 episodes, 1000 episodes/h)

| job | success | steps | exposure C0 / C1 / C2 | crossing C0 / C1 / C2 |
|---|---|---|---|---|
| free, seed 100 | yes | 32 | 0 / 0 / 0.03 | gap / gap / band |
| free, seed 101 | yes | 33 | 0 / 0.21 / 0.30 | gap / band / band |
| free, seed 102 | yes | 42 | 0.12 / 0.14 / 0.31 | gap / band / band |

| checked job (C2, seed 100) | success | exposure | crossing | closest to goal |
|---|---|---|---|---|
| d = 0 | no | 0 | none | 0.168 m |
| d = 0.02 | no | 0 | none | 0.197 m |

The free planner always reaches the goal but enters the band on 7 of 9 layout-seed cells.
On C2 the checked planner stays safe by never crossing (the near-side stall seen in task
12). The commanded-path model's one-step planar error in these episodes: median 4.3 mm,
max 1.8 cm; the worst 5-step executed block 2.8 cm.
