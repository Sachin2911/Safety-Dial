# Task 11 completion

25 October 2026. Task 11 stopped after stage A, at Sachin's request ("Stop now and
preserve", then "Yes please wrap up, destroy the instances and write to odessy"). Results:
[../11-dsrl-results.md](../11-dsrl-results.md). Run log: [../11-dsrl-run.md](../11-dsrl-run.md).

## Preservation

- 18:01:15 remote freeze by `preserve_dsrl11.py prepare-remote` (tool SHA256
  `1f0351aa...`): 438 raw files, 171,344,752 bytes, with a SQLite backup of the
  query ledger (172 queries, integrity ok). All 48 worker PIDs were verified gone.
- 18:01:57 the local mirror `outputs/dsrl11/remote` matched the freeze exactly by
  size and SHA256.
- 18:06 staged 621 dataset and 21 model files.
- 18:11:52 private upload verified. Every staged file was downloaded at its pinned
  revision and its SHA256 matched:
  - Dataset `Sachioster/maniguard-jar-replication-20261022` at revision
    `b45304f59c4fa397b9e07f4775bbaf87f890233a`: 622 files including the published
    manifest, 284,988,900 bytes, under the fresh `receipts/dsrl11/` and
    `recordings/dsrl11/` prefixes.
  - Model `Sachioster/safety-dial-dsrl11-20261025` (private) at revision
    `da19ef8df3a74411eb11a8c5111173aaa0849b4b`: 21 files, 308,433,762 bytes.
  - Manifest SHA256 `eb8b100968fa251bdccde83655130b98420aafa24c49ed033908ed19befa8d72`.
    Verification marker SHA256 `53fc7418...`. Details are in
    [preservation.json](preservation.json).

The receipts in this folder and the final destroyed rental record were written after
that verified stage. They are kept in the repository and uploaded separately under
`receipts/dsrl11/closeout/`. That upload is dataset revision
`7159a3f1f53a39bd65f53899fc4369d5d6495b38`: 9 files, secret-scanned before upload and
hash-verified after download at that revision. This paragraph was then updated with
the revision, so it is the only text that differs from the uploaded copy.

## Teardown

| Instance | Outcome | Stop | Destroyed |
|---|---|---|---|
| 57688543 | Image never finished loading; nothing deployed | 16:31:33 | 16:31 (absence verified) |
| 57692161 | Slow host network; setup logs only, no experiment | 17:08:39 | 17:08 (absence verified) |
| 57697202 | Stage A ran here; final copy verified | 18:02:43 | 18:12:12 (absence verified) |

After destruction the provider listed none of the three. Instances 57647787,
57660116, 57689039 and 57690181 belong to other tasks and were not touched.
See [teardown.json](teardown.json).

## Billing

Provider-posted charges at 18:13 UTC ([billing.json](billing.json)): $3.411 in all.

- 57688543: $0.028, storage only. No GPU time was billed during image loading.
- 57692161: $1.147.
- 57697202: $2.236, of which $0.456 was 58.4 GB of downloads during preparation.

The financial book's conservative compute estimate was $3.87 over 1.97 aggregate
hours. Both are far below the $18 total cap and the $14.90 active-shutdown limit.
The snapshot may receive final provider adjustments.
