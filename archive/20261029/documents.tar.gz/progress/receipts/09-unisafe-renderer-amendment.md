# Task 9 renderer repair before valid engineering or performance data

25 October 2026. This prospective engineering amendment uses the existing
authorization to fix recoverable engineering problems within the separate $10
allocation. It is recorded before a repaired simulator attempt. The original
A-v6 source freeze, schedules, raw data and earlier protocol remain preserved.

The default Vulkan ICD used the NVIDIA GLX library and could not create a Vulkan
instance. Three engineering processes nevertheless completed physics with both
camera images entirely zero. A fourth process was interrupted during startup
when the queue was stopped. These are infrastructure-invalid starts, regardless
of their original physical outcome labels. No performance-stage episode ran.

The three finished starts recorded 37, 37 and 35 controls, 109 in total, and 545
decimated physics steps. The interrupted start recorded zero completed controls
before startup ended; its unobserved work remains conservatively reserved. The
budget ledger charges all four invalid attempts at 340 controls each, not only
the 109 observed controls. The 37 observed native shadow-query bundles remain
visible, with a conservative 340-bundle reservation for that invalid attempt.

An isolated Vulkan probe succeeded when its ICD used the installed, matching
`libEGL_nvidia.so.580.178.04`. It enumerated the rented RTX 3090 with NVIDIA driver
580.178.04. This did not run the simulator or issue policy queries. NVIDIA documents
the [EGL ICD alternative](https://download.nvidia.com/XFree86/Linux-aarch64/570.86.16/README/installedcomponents.html).
The local host probe, rather than that general documentation, establishes this fix.

The repaired implementation pins this headless ICD, verifies actual Vulkan GPU
enumeration before admitting jobs, and rejects a constant image from either
camera before policy inference. The offline validator applies the same camera
check. Each original attempt receives an append-only invalidation record; original
summaries, action traces, images and logs remain unchanged and are preserved.

The engineering reserve increases from two to four replacements, one per failed
job, to replace these four starts. Maximum attempts increase from 588 to 590,
explicit controls from 192,240 to 192,920, and decimated physics from 961,200 to
964,600. This is a disclosed change to the original engineering allowance, not a
claim that the initial two-start allowance was met. The $10 cap, original rental
deadline, physical host, valid episode counts, panels, seeds, interventions,
outcome definitions, selection rules and confirmation contrasts are unchanged.
No extra valid episode is added to a performance estimate.

The source and complete engineering schedule are frozen again as A-v7 before the
repaired panel. B and C remain conditional on the same engineering, time, money
and selection gates. Unusable camera data cannot support a controller result.
