# Task 10 receipt: stage B gate sweep (25 October 2026, 12:25 to 13:20 UTC)

Freeze `progress/receipts/10-safecem-B-freeze.json`: 440 jobs = 4 layouts x 10 seeds (200 to
209) x (7 pixel dials, the p90 = 25 px and p95 = 33 px imagined-error dials, lam = 0 and
lam = 1 penalty references). 3 workers, 3285 s wall clock, zero failed attempts, 21,986
simulator steps in stages A and B together, 90,000 world-model candidate rollouts per full
episode. Evidence: `outputs/safecem10/remote/attempts/B-*` (result, states, planner history).
Analysis: `outputs/safecem10/analysis/stageB-{summary.json,table.md,response.*,calibration.*}`.

## What the dial does

1. The closure is sharp and sits where the geometry says. On the three 60 px gap layouts the
   planner threads the gap in 60 to 100 percent of episodes at d = 0, 10, 20 and in none at
   d = 25 or above; on the 40 px gap (N40) threading stops at d = 20. The inflated pillars
   leave a 10 px slot at d = 25 and the imagined pusher position is uncertain by about 10 px
   (p50), so the planner finds no feasible route a few pixels before the geometric closure.
2. Nobody detours. Past closure every episode is a "none" crossing: the planner hovers above
   the wall band for the whole 50 steps and the task fails (success 0, J = 50) on all four
   layouts. The 25-step imagination horizon and a goal cost that pulls straight down never
   discover the route around the right end of the wall.
3. Exposure is not monotone in the dial. It is low while the gap is open (0.00 to 0.05),
   peaks just past closure (0.06 to 0.09 at d = 25 to 33, with 60 to 90 percent of episodes
   entering a true pillar; 0.17 on N40 at d = 20) and only falls to zero at d = 50 to 60.
   Hovering at the inflated boundary plus imagination error puts the real pusher inside the
   true pillar. Spearman of exposure against d is between -0.12 and -0.75 per layout; of J
   against d it is +0.98 to +1.00.
4. The uncertainty-unit dials land in the worst zone. p90 = 25 px and p95 = 33 px are the two
   dials with the highest exposure and zero completion on every layout.

## Completion cost

| condition | success (mean over layouts) | J | exposure |
|---|---|---|---|
| unconstrained lam = 0 | 0.50 | 42.5 | 0.015 to 0.036 |
| penalty lam = 1 | 0.10 to 0.40 | 47 to 49 | 0.014 to 0.043 |
| safe d = 0 | 0.10 to 0.40 | 44.7 to 48.4 | 0.009 to 0.035 |
| safe d = 10 | 0.00 to 0.60 | 42.4 to 50 | 0.002 to 0.046 |
| safe d = 20 | 0.00 to 0.30 | 48.3 to 50 | 0.000 to 0.014 (0.168 on N40) |
| safe d >= 25 | 0.00 | 50 | see above |

The constraint costs completion even when the gap is open: the feasibility-first ranking
discards the fastest candidates and the planner reaches the 0.95 coverage threshold less
often within 50 steps. Moderate dials (10 to 20 px) do reduce exposure below the
unconstrained baseline on the 60 px gap layouts (G0: 0.015 to 0.002 or 0.014; G80: 0.036 to
0.009 or 0.002), so there is a usable region, but it is narrow and layout dependent.

## Calibration (nominal against realized clearance)

Realized clearance = the minimum signed distance from the pusher centre to the nearest true
pillar over the episode (negative inside). Median realized clearance is 1 to 15 px for the
open-gap dials, -5 to -18 px for d = 20 to 40 past closure, and 39 to 89 px at d = 50 to 60.
The fraction of episodes whose realized clearance meets the nominal dial ("nominal honoured")
is 0.0 to 0.3 for almost every dial, rising to 0.5 to 0.8 only at d = 60 where the planner
stays far from the wall. The nominal clearance is therefore not a guarantee; it is a knob on
the planner's belief, and the belief is wrong by about the imagined-error quantiles measured
in preparation (p50 10 px, p95 33 px at depth 5).

## Reading for the paper

The dial is a sharp route selector (gap or no gap) with a narrow useful band, not a smooth
safety-for-completion trade-off, and its pixel value is not realized clearance. The honest
"dial for free" claim must be about the route choice and the exposure reduction at 10 to
20 px, with the calibration gap stated. Stage C tests whether searching the richer interface
(clearance schedule, horizon, elite fraction, tolerance) finds settings that complete the
task at low exposure, which no fixed dial here does well.
