# Task 12 receipt: stage A engineering (25 October 2026, 18:56 to 18:57 UTC)

Freeze `progress/receipts/12-tworoom-A-v1.json` (11 jobs, design v3, 21 source files).
Rental: instance 57707282, one RTX 3090 (Spain, $0.24/h), created 18:38 UTC; preparation
(model, dataset 494b1a02..., scalers, replay) finished 18:44 UTC. Runner: 3 workers on the
GPU. Evidence synced to `outputs/tworoom12/remote/attempts/A-*`. Admission record:
`outputs/tworoom12/engineering.json` (passed, all four checks).

## How the design got here

CPU diagnosis before the freeze (details in `progress/12-tworoom-dial-plan.md`): LeWM's
TwoRoom goal cost is informative only within about 30 px of the goal, so the door-crossing
design (v1) and a 50 px design with gaps 13 and 25 px off the route (v2, constrained
planner 0/8) were dropped. Per-iteration CEM traces showed the constrained ranking leaves
the elite set full of far-field candidates; 1000 samples with top 10 fixed that on the
pilot seeds. Pilot seeds 21 to 24 are not used by any stage.

## Throughput

| quantity | value |
|---|---|
| wall clock for 11 episodes | 59 s (68 s including start-up) |
| median episode (one worker) | 12.2 s, max 24.4 s |
| system seconds per episode (3 workers) | 6.2 s |
| episodes per hour | 578 |
| world-model candidate rollouts per full 50-step episode | 100,000 (10 replans x 10 iterations x 1000) |
| GPU utilization during the run | 100% |

## Unconstrained baseline (lam = 0), seeds 100 to 102

The unconstrained planner ignores the band, so each seed gives the same trajectory on every
layout; only where the gap sits relative to it changes.

| seed | success | steps | crossing T0 / T1 / T2 | exposure T0 / T1 / T2 |
|---|---|---|---|---|
| 100 | no (ends 22 px from the target) | 50 | band / band / band | 0.22 / 0.26 / 0.28 |
| 101 | yes | 18 | gap / gap / gap | 0 / 0 / 0 |
| 102 | yes | 23 | gap / gap / band | 0.09 / 0.09 / 0.17 |

Mean baseline exposure: T0 0.10, T1 0.12, T2 0.15. Every layout has baseline episodes
inside a true box, so the sweep has something to avoid. No episode left the right room.

## Safe CEM on T2, seed 100

| dial | success | steps | exposure | crossing | realized clearance | final feasible fraction | elite mean executed |
|---|---|---|---|---|---|---|---|
| d = 0 | yes | 22 | 0 | gap | 4.6 px | 0.89 | 5/5 replans |
| d = 6 | no (ends 41 px away) | 50 | 0 | none | 15.7 px | 0.90 | 10/10 replans |

On the same seed the unconstrained planner failed with exposure 0.28. With d = 0 the
checked planner threads the gap and finishes; with d = 6 (gap narrowed to 12 px and 6 px
further off the route) it stays safe but does not finish.

## Checks

- every episode complete with 1 to 50 saved states;
- the exact check replays every executed step to 4.8e-5 px at worst;
- both safe runs differ from the unconstrained run.

## Next

Stage B froze at 18:58 UTC (`12-tworoom-B-v1.json`, 310 jobs, estimate 32 minutes at the
measured 6.2 s per episode) and launched at 18:58 UTC.
