# Task 9 result: UNISafe block-plucking follow-up

Completed 25 October 2026. The one-page report is
[`results/unisafe-follow-up-results.pdf`](../../results/unisafe-follow-up-results.pdf),
with its LaTeX and input manifest beside it. Figures are in
[`results/unisafe09-figures/`](../../results/unisafe09-figures/).

## Answer

- **Mechanism gain: not supported.** The screen-selected setting, delay 15 with
  translation 0.75, completed 54/64 against 51/64 for R, the earlier
  random-search setting. Every simultaneous paired interval for C, V and J
  includes zero. The screen's lead (14/16 against 12/16) did not confirm. No
  reduction in violation risk is claimed.
- **Ablation: supported.** History-only release completed 31/64 against 50/64
  for sensed delay 15. Completion fell by 29.7 points (simultaneous -52.6 to
  -1.0) and J rose by 4.93 s (2.86 to 6.89), with equal violations (8/64 each).
  Sensing the grasp matters beyond release timing alone.
- **Speed/completion dial: not supported.** The frozen selection had one
  setting as both the speed and the completion endpoint, so no tradeoff could
  be confirmed. Delay 40 was neither faster nor more complete than delay 15.
- **No evolutionary claim.** No optimizer or weight update ran in this study.

## Execution

Engineering stage A, response screen B and the first 192 confirmation jobs
ran on instance 57647787 (one RTX 3090, machine 150513), as recorded in
[`09-unisafe-run.md`](09-unisafe-run.md). An added four-RTX-4090 host,
57690181 on machine 36475, was authorized to run the other 192. Its
installation was still incomplete at handover. Its frozen admission rule gave
9,199 s against 5,591 s available before its work deadline, so it was stopped
before any simulator episode, under the recorded fallback
([decision](09-unisafe-parallel-C-admission-failure.json)). The remaining 192
jobs ran on the original host under the unchanged C freeze `51a09105...8f53`,
admitted by a fresh remaining-work bound
([admission](09-unisafe-C-remaining-admission.json),
[launch](09-unisafe-C-remaining-launch.json)). All 384 C episodes therefore
come from one physical host, and the host-stratified analysis has one stratum
(H = 1), as the plan's amendment specifies for this case.

No C job was duplicated, replaced or discarded. All 384 C attempts are valid,
and every seed block ran entirely on one host and GPU. Every raw trace passed
action and outcome replay
([validation](09-unisafe-C-combined-validation.json)). The analysis is
[`09-unisafe-C-combined-analysis.json`](09-unisafe-C-combined-analysis.json),
computed with the frozen analysis sources, whose hashes were rechecked before
running.

## Confirmation results

Sixty-four seeds per setting. C is safe benchmark completion, V is any
physical failure or boundary exit, and J is mean completion time with 15 s for
each failure or unfinished episode. Sustained means the full success predicate
held with no violation for 40 further controls.

| Setting | Valid | C | Wilson 95% | V | Failure / boundary / timeout | J (s) | Sustained | Post-success violations / predicate losses | Path (cm) | Interventions |
|---|---|---|---|---|---|---|---|---|---|---|
| N: native | 64/64 | 3/64 | 2 to 13% | 9/64 | 8 / 1 / 52 | 14.47 | 0/64 | 3 / 3 | 194 | 61.9 |
| E: delay 15 | 64/64 | 50/64 | 67 to 86% | 8/64 | 7 / 1 / 6 | 5.64 | 22/64 | 8 / 28 | 81 | 8.2 |
| F: delay 40 | 64/64 | 47/64 | 62 to 83% | 9/64 | 8 / 1 / 8 | 6.27 | 25/64 | 7 / 22 | 83 | 9.7 |
| R: earlier random-search setting | 64/64 | 51/64 | 68 to 88% | 9/64 | 8 / 1 / 4 | 5.68 | 29/64 | 7 / 22 | 75 | 6.1 |
| Delay 15, translation 0.75 | 64/64 | 54/64 | 74 to 91% | 4/64 | 3 / 1 / 6 | 4.92 | 44/64 | 6 / 10 | 70 | 6.8 |
| H: history-only delay | 64/64 | 31/64 | 37 to 60% | 8/64 | 6 / 2 / 25 | 10.57 | 18/64 | 2 / 13 | 158 | 9.1 |


Completion by deadline (2, 5, 10, 15 s): native 0, 3, 5, 5%; E 23, 69, 77,
78%; F 23, 64, 70, 73%; R 23, 66, 77, 80%; delay 15 with translation 0.75 28,
75, 83, 84%; history-only 12, 23, 41, 48%. Fewer interventions did not mean
inactivity: the high-completion settings moved the end effector 70 to 83 cm,
while native moved 194 cm and mostly timed out (52/64).

### Primary contrasts

The frozen familywise alpha of .05 covers both contrasts and all three
endpoints (alpha .05/6 per endpoint).

| Primary contrast | C | V | J |
|---|---|---|---|
| Delay 15, translation 0.75 minus R: earlier random-search setting, 95% descriptive | +4.7 pts (-13.9 to 22.6) | -7.8 pts (-22.5 to 8.2) | -0.8 s (-2.1 to 0.5) |
| H: history-only delay minus E: delay 15, 95% descriptive | -29.7 pts (-48.3 to -7.1) | +0.0 pts (-15.2 to 15.2) | +4.9 s (3.3 to 6.4) |
| Delay 15, translation 0.75 minus R: earlier random-search setting, Simultaneous (alpha .05/6 per endpoint) | +4.7 pts (-18.6 to 27.0) | -7.8 pts (-26.3 to 12.3) | -0.8 s (-2.5 to 0.9) |
| H: history-only delay minus E: delay 15, Simultaneous (alpha .05/6 per endpoint) | -29.7 pts (-52.6 to -1.0) | +0.0 pts (-19.1 to 19.1) | +4.9 s (2.9 to 6.9) |

### Post hoc descriptive contrasts

These were chosen after condition aggregates were seen. They answer the plan's
section-1 questions and carry no confirmation weight
([receipt](09-unisafe-C-descriptive-contrasts.json)).

| Post hoc descriptive contrast (unadjusted 95%) | C | V | J | Sustained |
|---|---|---|---|---|
| E: delay 15 minus N: native | +73.4 pts (51.3 to 86.1) | -1.6 pts (-18.6 to 15.8) | -8.8 s (-10.2 to -7.3) | +34.4 pts (14.9 to 49.1) |
| F: delay 40 minus E: delay 15 | -4.7 pts (-18.5 to 9.9) | +1.6 pts (-11.3 to 14.2) | +0.6 s (-0.1 to 1.5) | +4.7 pts (-11.4 to 20.1) |
| Delay 15, translation 0.75 minus E: delay 15 | +6.2 pts (-11.8 to 23.3) | -6.2 pts (-20.5 to 9.1) | -0.7 s (-1.9 to 0.5) | +34.4 pts (13.3 to 50.6) |
| Delay 15, translation 0.75 minus R: earlier random-search setting | +4.7 pts (-13.9 to 22.6) | -7.8 pts (-22.5 to 8.2) | -0.8 s (-2.1 to 0.5) | +23.4 pts (3.0 to 40.6) |
| H: history-only delay minus E: delay 15 | -29.7 pts (-48.3 to -7.1) | +0.0 pts (-15.2 to 15.2) | +4.9 s (3.3 to 6.4) | -6.2 pts (-25.5 to 13.9) |

Grasp-maintenance delay versus native is large (+73 points), as in the
archived study. Translation 0.75 did not resolve a completion gain, but it held
success through the continuation far more often: 44/64 against 22/64 for
delay 15 (+34 points, 13 to 51) and 29/64 for R. It also had fewer
post-success predicate losses (10 against 22 to 28). This is the clearest new
signal, but it is post hoc and unadjusted. It needs its own prespecified test.

## Decision on a later evolutionary dial study

This study does not justify an evolutionary speed/completion dial over this
adapter family. No setting traded speed against completion: E, F, R and the
translation setting cluster at 73 to 84% completion and 4.9 to 6.3 s J. The
fixed improvement over R did not confirm. If the line continues, the
candidate objective is sustained completion under continued control. That
would need a new frozen plan, a fresh seed panel and the full optimizer
comparison (native, tuned fixed setting, random search, ordinary learning)
before any evolutionary claim.

## Accounting

All stages and both rentals, including invalid starts
([accounting](09-unisafe-final-accounting.json), [runtime](09-unisafe-runtime.json)):

- **Attempts:** 590. A had 14, including 4 renderer-invalid starts; B had 192
  and C 384, all valid. The original-host caps were 590 attempts and 192,920
  controls. The added host made 0 attempts.
- **Controls:** 87,177 observed and 88,428 conservatively charged.
- **Physics:** 435,885 known decimated steps (442,140 charged). At least 1,178
  backend warmup updates are counted separately from the source-derived lower
  bound. Recorded context-reset steps were 0. Other backend-internal physics
  was not instrumented and remains unknown, not zero.
- **Controller queries:** 87,177 online and 337 shadow bundles were recorded,
  with 640 offline bundles conservatively charged, for 89,068 charged in total.
  Component counts are in the accounting receipt. There were zero optimizer and
  zero pretrained-weight updates.
- **Runtime:** C worker processes took 16,813 s in total (43.8 s mean, 83.0 s
  max), with a median 20.8 s startup and a median 0.104 s per control. C ran
  14:42 to 17:05 UTC and 17:35 to 19:53 UTC. Active rental time was 9.43 h on
  the original host and 1.28 h on the added host.
- **Money:** see the closure section below. The combined cap was $15,
  including all historical task-9 charges.

## Evidence notes

The final copy matched all 106,684 remote evidence files by SHA-256
([copy receipt](09-unisafe-C-final-copy.json)). The local copy also keeps a
stale `STOP` file. It is byte-identical to `control/STOP-renderer-A-v6.txt`,
the 11:23 UTC A-v6 renderer stop that was removed remotely after diagnosis.
It is also present in both earlier private backups and did not affect C.

The two-host plotting and report helpers gained presentation-only changes: a
single-host title and caption, fixed caption spacing, the actual analysis path
in the report footer, and an optional embedded figure. No count check changed.
`account_unisafe09_fallback.py` replaces the two-host accounting helper for
this fallback, and `describe_unisafe09_contrasts.py` produces the post hoc
contrasts.

## Closure

Both rentals are closed. Compute on the added host 57690181 was verified
stopped at about 17:33 UTC, before any episode. The original host 57647787 was
verified stopped at 19:59 UTC, after the final copy matched every remote file.

The complete snapshot holds all 590 attempts, both hosts' setup, transfer,
repair, control and ledger evidence, source bundles, rental records, final
receipts, figures and this report. It is 1,271 packaged files and 2.80 GB, with
3.23 GB of raw bytes. An audit confirmed every raw file appears exactly once in
the archives ([audit](09-unisafe-final-archive-audit.json)). All 1,271 files
were then re-downloaded from private revision
`28c3eda5b8cb875198c224d168a3ebe101716c50` of
`Sachioster/maniguard-jar-replication-20261022`, and their hashes matched. All
398 earlier attempt archives are byte-identical to the earlier backups. The
complete-experiment marker covering both instances is
[`09-unisafe-final-preservation.json`](09-unisafe-final-preservation.json).

Both disks were then destroyed, and a fresh provider listing verified both
absent. The posted charge snapshot is $6.615: $4.022 for the original host and
$2.593 for the added host. The conservative estimate is $8.55 against the $15
combined cap. It counts all active segments, the full reserved transfer
envelope and four hours of stopped disk per host. Teardown and billing proofs
are in [`09-unisafe-completion/`](09-unisafe-completion/README.md). Posted
charges may still receive provider adjustments.
