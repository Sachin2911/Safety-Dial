# Task 13 receipt: stage B dial sweep (25 October 2026, 22:18 to 22:29 UTC)

Freeze `progress/receipts/13-reacher-B-v1.json` (270 jobs, design v1, 300 samples, top 30),
run on instance 57723813 with 6 workers in 10.5 minutes (about 1540 episodes/h). Evidence
synced to `outputs/reacher13/remote/attempts/B-*`; analysis by
`experiments/scripts/analyze_reacher13.py --stage B` in `outputs/reacher13/analysis/`
(`stageB-summary.json`, `stageB-table.md`, `stageB-response.png`).

Conditions on the fixed sweep (0.7, 0.9) -> (-0.7, 0.9), seeds 200 to 209 shared across
conditions: unconstrained (free); the exact check with mean_safe execution at dials 0 to
2.5 cm on every layout; the exact check executing the unchecked elite mean on R2.

| layout (gap offset) | free success / safe success / entries | best checked dial | its safe success | checked exposure |
|---|---|---|---|---|
| R0 (on the route) | 0.7 / 0.7 / 1 of 10 | 1 cm | 0.8 | 0 |
| R1 (1.25 cm off) | 0.7 / 0.4 / 4 of 10 | 0 | 0.8 | 0 |
| R2 (2.5 cm off) | 0.7 / 0.1 / 8 of 10 | 0.5 cm | 0.5 | 0 |

- No checked episode entered the band: exposure 0 in all 180 checked episodes. The exact
  arm model replays every executed step (stage A), so this is the expected result.
- Seed-paired safe-success differences, checked minus free: R1 d = 0 +0.4 (95% bootstrap
  interval 0.0 to 0.8); R2 d = 0 +0.3 (0.0 to 0.6), d = 0.5 cm +0.4 (0.1 to 0.7); R0 d = 0
  -0.4 (-0.7 to -0.1), d = 1 cm +0.1 (-0.2 to 0.4). The check helps where the free planner
  cuts through the band and can cost success where it would have threaded the gap anyway.
- The dial is a cliff, as on TwoRoom: every layout keeps most of its success up to 1 cm and
  falls to 0 to 0.1 from 1.5 cm, well before the gap closes at 2.5 cm. Beyond the cliff the
  planner never crosses the band and stops 7 to 9 cm away from it.
- On R0 the response is not monotone (0.3, 0.6, 0.8 at 0, 0.5, 1 cm): a small margin kept
  the fingertip off the gap's edges.
- mean_safe executed the elite mean in 93 to 100% of replans; on R2 the elite-mean and
  mean_safe conditions gave identical outcomes on every seed.

Stage C was frozen at 22:32 UTC (`13-reacher-C-v1.json`, 8 generations x 3 replicates,
3672 episodes, estimated 3.0 h) and launched at 22:33 UTC.
