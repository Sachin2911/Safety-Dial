# Task 11 stage-A build and freeze

Recorded 25 October 2026 at about 16:17 UTC.

Freeze: `progress/receipts/11-dsrl-stage-a.json`, SHA256
`ecff530ad6037c68da98b6a908e5b8baab681bb5fdf5a9222dc64fa7ffb1b719`: 83 traced
sources, 13 input files and 21 workstation engineering updates. Run bundle
`outputs/dsrl11/control/stage-a-source.tar.gz`, SHA256
`4a4e2f22cb8da24046e239af0834330a5ddc71299d59de7ab9c3ccd3c7b394b9`, 98 files. The
setup authorization (`11-dsrl-setup.json`, SHA256
`31aca22600fa5bad1f47f1b1e053cd88e3480e2a1fec169d4d9adfbbdc720dd6`) shares all 40
preparation and guard files byte for byte; the run bootstrap refuses any change.

## Source inventory

The inventory is traced from the task-11 entry points through their imports and
quoted repository paths, plus the preparation files proven by the Task 7 bootstrap
(unchanged since its freeze). Tasks 8, 9 and 10 sources are excluded by
construction; the tracer refuses if any leak in. `AGENTS.md` and
`firstPrinciples.md` are shared with other sessions and are hashed as context only.

## Critic inflation diagnosis (workstation)

- Static audit (`outputs/dsrl11/stage-a/static-audit.json`): all 24 Task 7
  training episodes reconstruct from the verified remote-final replay; zero safe
  completions; return-identity error at most 3.5e-17. The pinned author learner
  uses no backup entropy, a per-transition discount, target
  `r + discount * mask * reduce(next_qs)`, soft target updates and supports mean
  and min reductions for both critic targets and the actor.
- Forward replay of Task 7's saved learners (`task7-forward.json`, CPU): the mean
  estimate on its calibration pairs rose from 0.35 at initialization to 3.76
  after 15,000 updates, 7.84, 15.31, 21.19, 28.24 and 37.19 after 90,000. Between
  99.6% and 100% of pairs lie outside [-0.30, 1.05] from the first saved round on,
  while true discounted returns lie in [-0.25, 1]. Policy entropy fell from 21.5
  to -15.9 as temperature decayed. The inflation is present from the first
  training round and grows steadily, not as a late blow-up.

## Gate definition (fixed before any A1 run)

The calibration gate uses the learner's own estimate: its configured reduction of
the ten critic heads, on recorded and on actor-sampled actions, against
[-0.30, 1.05] for more than 1% of pairs at three successive post-update
measurements every 500 updates. The initialization measurement is a descriptive
baseline. Reason: a random ensemble scatters single heads (Task 7 initialization,
26% of heads outside) while its mean lay inside. The CPU preflight also shows the
min of ten random heads lies below -0.30 for every pair at initialization; A1
measures whether it recovers under training.

## Residual interface and R1 geometry

- Residual noise is `epsilon + 0.25 * tile(u, 16)` with `u` in [-1, 1]^32 and
  `epsilon` the exact native draw from the policy's recorded key. The full noise
  is never clipped. A zero residual passes the native draw bitwise, verified
  against the real pinned `Policy.infer`. The GPU decoder check (A2) repeats this
  on the rental.
- R1 uses the pinned ManiGuard 6bf4c61 geometry: reach is the benchmark's
  `eef2target` pair, lift is relative to the initial jar height, and goal is the
  native `object_intersects_goal_region` closest-point distance to the goal-sphere
  centre. The validator recomputes the native intersection from the recorded jar
  AABB at every state and rejects any disagreement. The pinned function converts
  every operand to Python floats, so float64 storage reproduces it exactly.

## Input boundary

- A1 refits the Task 7 final replay, copied from the verified remote-final snapshot
  (`07-dsrl-completion/local-copy.json`, exact inventory verified 12:35 UTC) with
  hashes checked against its checkpoint manifest.
- A2 uses the eight saved decoder views frozen by Task 7 (Task 6 engineering
  observations), hash-checked against the Task 7 freeze. They never enter replay.
- Held-out tasks appear in no job, input or audit. Instance 57632188 is untouched.

## Workstation verification

315 tests passed with no skips (`outputs/dsrl11/stage-a/workstation-verification.json`):
106 new task-11 tests across protocol, server, validator, learner, queue and infra,
plus the 209 Task 6/7 DSRL regressions. Ruff check and format are clean.

The CPU preflight (`outputs/dsrl11/preflight/receipt.json`, JAX 0.5.0 CPU) drove
the pinned author learner through every bridge operation:

- The bridge update equals the direct author update exactly.
- The exported CPU actor equals the live actor exactly.
- All four conditions share one initialization with distinct RNG streams.
- Bank, rounds, credit and real calibration passes stay finite.
- A checkpoint restores bit-identically.
- Training one condition leaves the other three unchanged.
- A1 batches from the Task 7 replay stay finite.

Its 21 gradient updates are engineering charges carried into the frozen accounting.

## Defects found and fixed before the freeze

- The recorder and probe confirmed queries through the Task 6 ledger class, whose
  21,000 ceiling refuses the 27,000-query ledger.
- The coordinator hard-coded the superseded $15 envelope.
- Unsuccessful short fixtures are invalid by the native 2,000-control timeout rule
  (test fixtures corrected; no code change).
- Deployment verified the workstation tree rather than the shipped archive; it now
  verifies the bundle from inside the archive.

## Private preservation access (about 16:20 UTC)

Verified with the write token for account `Sachioster`, read from the ignored root
`.env` and never printed. The dataset
`Sachioster/maniguard-jar-replication-20261022` is private (revision f3cd7eaa66fe at
the check), with no files under `receipts/dsrl11/`, `recordings/dsrl11/` or
`jar/dsrl11_`. The new private model repository
`Sachioster/safety-dial-dsrl11-20261025` was created empty. The plan asks for this
check before rental; it ran after the 16:02 creation but before any deployment
(`outputs/dsrl11/control/preservation-access.json`).
