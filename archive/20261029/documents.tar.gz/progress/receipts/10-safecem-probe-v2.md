# Task 10 receipt: grounded safety check and probe v2 (25 October 2026, 13:53 to 14:19 UTC)

Freezes: `progress/receipts/10-safecem-preparation-v4.json` (first retraining attempt, killed
by the kernel for memory: the script held 30 GB of raw frames) and `...-preparation-v5.json`
(streams frames through the encoder and keeps only embeddings; the smoke run reproduced the
v4 smoke numbers exactly). Script: `experiments/scripts/retrain_probe_safecem10.py`. Outputs:
`outputs/safecem10/remote/{probe-v2.json, imagination-v2.json, probe-v2-eval.npz}`; weights
`outputs/safecem10/remote/probes/probe-v2.pt` (sha256 3da85d40...; pinned into the B2 freeze
and verified by every worker at start).

## Code changes (all unit tested, 23 tests pass)

- `check = exact`: the pusher path at every physics substep through Push-T's PD controller.
  The controller is linear (target = position + 100 x action; 10 semi-implicit Euler substeps
  with k_p 100 and k_v 20 on a kinematic body), so the path is x0 + c v0 + G a, precomputed
  once. Verified at 0.0 px against the simulator from rest and from a moving start, and in
  closed loop: every B2 episode records the per-step gap between saved states and the model,
  and the first episodes show a maximum of 0.0 px.
- Finding on the way: the commanded-target formula in the frozen arena constraint is off by a
  median of 102 px over a 25-step plan (the controller lags its targets; steady travel is about
  40 percent of the commanded offset). The arena constraint is therefore conservative. It is
  left unchanged in every stage so that B2 stays paired with B.
- `check = anchored`: probe readings shifted so the current reading equals the true current
  position; only imagined displacements come from the world model.
- `execute = best`: the planner executes the best checked candidate of the whole CEM solve
  (feasible first, then goal cost; otherwise least violation) instead of the elite mean,
  which the constraint never evaluated. This is iCEM's choice.

## Probe v2

Same architecture as v1 (192 to 256 to 128 to 2). Training data: 48,000 simulator frames
rendered through the planner's own World pipeline (pusher uniform over the arena; block near
the start, along the push, or anywhere; 3,286 of 60,000 candidates dropped because the pusher
overlapped the block), oversampled 4 times, plus 180,000 dataset frames from 900 runs spread
over the whole 2.34 M-frame file. Held out: 4,821 simulator frames, 100 dataset runs (20,000
frames), and 4,000 real closed-loop states from stages A and B (re-rendered from saved
simulator states, never trained on). Wall clock 5.2 minutes on the RTX 3090.

| radial error (px), median / p95 | v1 | v2 |
|---|---|---|
| closed loop, all 4,000 states | 36.5 / 155.0 | 8.2 / 22.7 |
| closed loop, start corner (1,629 states) | 109.7 / 172.8 | 12.8 / 28.1 |
| closed loop, wall band (743 states) | 19.9 / 42.8 | 5.3 / 11.2 |
| closed loop, elsewhere (1,628 states) | 15.4 / 56.3 | 6.6 / 14.9 |
| held-out simulator frames | 39.2 / 170.2 | 9.4 / 40.2 |
| held-out dataset runs | 5.0 / 31.7 | 5.8 / 17.3 |

41 percent of the closed-loop states sit within 80 px of the start corner, where v1 was off
by about 110 px. Probe v2 trades a slightly higher median on dataset frames (5.8 against 5.0
px) for a much lighter tail everywhere.

## Imagined error at depth 5 on the preparation's 1,500 dataset snippets

| variant | p50 | p90 | p95 |
|---|---|---|---|
| v1 raw (reproduces the preparation step exactly) | 10.2 | 25.1 | 32.6 |
| v1 anchored | 12.0 | 32.3 | 43.8 |
| v2 raw | 11.2 | 23.5 | 28.7 |
| v2 anchored (the B2 `fixed` check) | 12.4 | 25.6 | 31.5 |

On in-distribution snippets anchoring costs a little, because the current reading is already
accurate there and the imagined displacement carries its own error. Its benefit is out of
distribution, where the current reading was the dominant error (the stage B diagnosis: p95 of
the executed-block error fell from 153 to 69 px with v1). The pre-registered uncertainty-unit
dials for the `fixed` condition are p50 = 12, p90 = 26 and p95 = 32 px (none within 2 px of a
grid dial).
