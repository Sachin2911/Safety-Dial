# Task 15 results: a regrasp adapter with a safety dial on Jar

Protocol: `progress/15-regrasp-dial-plan.md` (with its amendments section). Freezes:
`15-regrasp-preparation-v1.json`, `15-regrasp-stage0-v1.json`, `15-regrasp-live-v1.json`.
Rental: instance 57727030, one RTX 3090 (Wisconsin, driver 580.173.02), $0.31 per hour,
under the $10 cap. Status: stage 0, stage A and stage B complete; stage C running, stage D declared.

## Stage 0: steerability from stored observations

720 task 7 policy queries inside the closure gate (all 426 whose executed chunk exceeded
0.06 m/s near the jar, plus 294 seeded random others), each decoded with 16 fresh
latents on the stored observation. Evidence: `outputs/regrasp15/stage0/` (summary sha256
`05de31ab…8d4a93`).

**The decode path reproduces the policy.** Replaying each record's stored latent gives
the stored chunk to a median of 0.003 rad (largest element, all 16 steps and 8 dims).
Over the eight executed steps the arm joints agree to a median of 0.0015 rad (99th
percentile 0.009, max 0.026). The few large gaps (up to 0.84) are all in the gripper
channel at unexecuted steps 11 to 15, mid open-close transition: bf16 numerics near a
decision boundary on a different GPU.

**Rescue rates.** Among records whose executed chunk failed the near-jar speed check,
the fraction with at least one passing sample out of 16:

| Limit | Failing records | Rescued | Rescue rate | Mean pass fraction (failing) | Median joint RMS of the closest passing sample |
| --- | --- | --- | --- | --- | --- |
| 0.15 m/s | 170 | 103 | 0.61 | 0.35 | 0.026 rad |
| 0.10 m/s | 254 | 122 | 0.48 | 0.25 | 0.023 rad |
| 0.06 m/s | 426 | 197 | 0.46 | 0.21 | 0.011 rad |

By the frozen rule (rescue at 0.10 m/s below 0.5), live selection uses **K = 32**.

**The split is bimodal.** Of the 254 failing states at 0.10 m/s, 132 had no passing
sample at all, while many of the rest had several (14 had all 16 passing). At about half
of the risky moments, pi0.5's own distribution offers no slow alternative, so selection
can act only at the other half; slowing the native chunk (projection) is not limited
this way. Where a passing sample exists it is close to native (median joint RMS 0.02
rad), so selection is a small nudge, not a different plan. Of the 25 failing records
that preceded a tip within two seconds, 12 were rescued.

These are offline counts on task 7 states; they bound what selection can do but are not
efficacy evidence.

## Live start-up and stage A engineering (pool task 1)

The first pipeline start (live freeze v1) stopped at its startup probe, before any
episode: a single 32-sample candidate batch did not fit the policy server's share of the
GPU. Live freeze v2 decodes candidates in batches of 16 and its probe retries through
the compile. Its probe then showed a 32-candidate request takes 2.9 s, repeats
bit-identically, and leaves the native sampling stream untouched (re-seeded native draws
identical with and without a candidate request in between; consecutive draws differ by
0.17).

| Job | Arm | Wall time | Gated queries | Vetoes | Rescued | Least excess | Projected | Violation step |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | native | 658 s (cold start) | 0 | 0 | 0 | 0 | 0 | none |
| 1 | always-0.10 (select) | 274 s | 14 | 8 | 2 | 6 | 0 | 111 |
| 2 | project-always-0.10 | 255 s | 86 | 13 | 0 | 0 | 13 (mean scale 0.56) | 682 |
| 3 | select-0.10 (closure gate) | 255 s | 0 (lid never closed) | 0 | 0 | 0 | 0 | 477 |

All four recordings validated with every adapter decision replayed exactly from its
journal, and the stage A rules passed (8 candidate requests, 13 projections). The live
base yaw agreed with the per-episode fit to within 4e-7 rad. A rollout takes about 200 s
on this host (about 100 ms per control) plus about 60 s of warm simulator start. Pool-task
outcomes are engineering only; job 3 ran entirely with its gate shut, so its violation is
native behaviour.

## Stage B: dial screen (development tasks 0, 3, 6 and 9; seeds 151000 to 151003)

80 episodes, 16 per arm, all validated with every decision replayed; no incomplete
attempt; mean 261 s per episode. Descriptive only.

| Arm | Strict safe | Success | Raw violations | Gate opened | Post-gate tips | Post-gate stalls | Vetoes | Rescued | Least excess | Projected |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| native | 5/16 | 6 | 6 | 16 | 6 | 5 | 0 | 0 | 0 | 0 |
| project-0.10 | 9/16 | 9 | 2 | 15 | 2 | 4 | 232 | 0 | 0 | 232 |
| select-0.10 | 3/16 | 3 | 6 | 16 | 6 | 7 | 153 | 93 | 60 | 0 |
| select-0.06 | 4/16 | 4 | 5 | 15 | 5 | 6 | 317 | 169 | 148 | 0 |
| always-0.10 | 3/16 | 4 | 5 | 14 | 4 | 7 | 244 | 155 | 89 | 0 |

Strict safe completions by task (0, 3, 6, 9): native 2, 1, 2, 0 of 4 each; project-0.10
3, 3, 2, 1; select-0.10 0, 2, 1, 0; select-0.06 0, 2, 1, 1; always-0.10 1, 1, 1, 0.

- **Slowing the native chunk looked strongest**: projection had fewer post-gate tips than
  native (2 against 6) and more strict safe completions (9 against 5), not worse on any
  task. Vetoed chunks were scaled to a median 0.53 of their speed.
- **Selection did not reduce tips.** About 60% of vetoes were rescued by a passing
  sample, but the rest fell back to the least-excess sample, which still exceeds the
  limit; those are the states where pi0.5's distribution has no slow sample (stage 0's
  bimodal split). Selection therefore cannot enforce the limit at the moments that
  matter, while projection always does. Selection arms traded tips for stalls.
- **The speed limit did not act as a dial for selection**: 0.06 m/s vetoed twice as often
  as 0.10 m/s with similar outcomes.

Frozen stage C rule: select-0.06 (4 strict safe completions against select-0.10's 3; its
5 violations are not three more than native's 6), so stage C compares select-0.06 with
native, 48 episodes each. Stage D (declared before stage C started) adds 48 project-0.10
episodes on the stage C tasks and seeds, compared with stage C's native arm.

## Recovery after the original host disappeared (26 October 2026)

Rules: `progress/15-regrasp-recovery-amendment.md`. Evidence:
`15-regrasp-recovery-evidence-20261026.json`, `15-regrasp-recovery-admission.json`,
`15-regrasp-recovery-readmission.json`, freezes `15-regrasp-recovery-prep-v1.json` and
`15-regrasp-recovery-live-v1.json`.

### What survived from the original host

Instance 57727030 left the provider between about 05:39 UTC (last successful remote query,
six stage C episodes validated) and 05:43 UTC (end of its disk metering). The cause is not
established: both watchdogs only request a stop, no recorded session issued a destroy, and
the workstation itself rebooted at 05:41. No newer copy exists locally or in the private
dataset (revision `c68069b2`, 30,268 files, no task 15 path). The local mirror holds stage 0,
stage A, all 80 stage B episodes and stage C jobs 300 to 303 complete; job 304 (native, task
6, seed 152000: gate opened, post-gate stall, unfinished, no violation) survives only as its
host validation event; job 305's outcome and whether job 306 started are unknown. Stage D
never started. An immutable copy of all 2,884 local files was taken before any recovery step
(`outputs/regrasp15r1/historical/`, archive sha256 `9730c365…`), and the whole original
cohort was preserved privately at revision `bdfc3a44` (3,378 files re-downloaded and
hash-verified; `15-regrasp-historical-preservation.json`).

Original-host stage C, descriptive only and never pooled: native 0/3 strict safe with 1
raw-violation episode (jobs 300, 303, 304), `select-0.06` 0/2 with 2 (jobs 301, 302).

### Cost reconciliation and admission

Posted charges for 57727030 are $2.555 ($1.595 GPU for 7.718 h, $0.805 disk for 7.763 h,
$0.155 transfer) and did not change between 07:35 and 07:55 UTC; the first create attempt
cost nothing. The recovery book closes 57727030 at a conservative 05:45:00 UTC: 7.80
instance-hours and $2.42 charged, leaving 12.20 h and $5.48 of active money under the
unchanged $10 cap. The provider-absence check (07:33:17) is the outer bound: 9.60 h and
$2.98, leaving 10.40 h. Admission simulated the frozen schedule with an episode-time model
fitted on the original host (56.8 s + 0.103 s per control + 2.98 s per candidate request,
residual SD 17 s). On the chosen host at the original speed, all 96 stage C and 46 of 48
stage D episodes were admitted; stage C was admitted in full even under the outer bound.
Faster-CPU hosts on driver 580.x failed the frozen transfer-allowance check and were not
used.

### Replacement host and engineering

Instance 57786177: one RTX 3090 (driver 580.95.05), Xeon W-2133, 12 threads, 125 GB, Quebec,
$0.43 per hour, created 08:17:27 UTC, allocation deadline 20:24:32 UTC. Preparation took 20
minutes. The pinned sources matched, and the patched evaluator hash equals the original
host's. The startup probe decoded 32 candidates in 2.74 s, repeated them bit-identically and
left the native stream untouched (re-seed gap 0, consecutive draws 0.169 apart).

| Job | Arm | Wall time | Gated queries | Vetoes | Rescued | Least excess | Projected | Violation step |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | native | 767 s (cold start) | 0 | 0 | 0 | 0 | 0 | none |
| 1 | always-0.10 (select) | 269 s | 76 | 8 | 3 | 5 | 0 | 605 |
| 2 | project-always-0.10 | 240 s | 94 | 12 | 0 | 0 | 12 (mean scale 0.54) | 750 |
| 3 | select-0.10 (closure gate) | 156 s | 0 (lid never closed) | 0 | 0 | 0 | 0 | 1018 |

All four validated with every decision replayed, and the stage A rules passed (8 candidate
requests, 12 projections). The live base yaw agreed with the per-episode fit to within 2e-7
rad. Job 0 ran alone as the serial cold start. Engineering outcomes never enter efficacy
estimates.

**Re-admission.** The warm engineering episodes ran at 0.93 of the original-host model's
time. Re-simulating the remaining schedule admitted all 96 stage C and all 48 stage D
episodes, with about one hour to spare before the last admissible start. Stage C started at
09:08:56 UTC.
