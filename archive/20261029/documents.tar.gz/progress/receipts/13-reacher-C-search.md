# Task 13 receipt: stage C, searching the planner's settings on Reacher (25 to 26 October 2026, 22:33 to 00:23 UTC)

Freeze `progress/receipts/13-reacher-C-v1.json` (ladder rung 8 generations x 3 replicates).
Run on instance 57723813 (one RTX 3090): 2792 episodes (2592 search, 200 final), zero failed
attempts, 1 h 50 min. Every final front had one or two settings, so the run used 880 fewer
episodes than the 3672 planned. The detached finalizer (`experiments/scripts/finalize_reacher13.sh`)
synced, stopped the instance, analyzed, preserved the evidence privately
(`Sachioster/maniguard-jar-replication-20261022` at revision `5c36bb36d1430a7ae1a5ee0ea81e68fffa169c70`,
26 files verified; marker `13-reacher-preservation.json`) and destroyed the instance at
00:29 UTC on 26 October. The rental cost about $0.95 over 3.1 h. Analysis:
`outputs/reacher13/analysis/stageC-{summary.json,table.md,fronts.*}`; the numbers below come
from `experiments/scripts/summarize_stage_c.py --task reacher13`.

NSGA-II, random search and a grid each tuned five settings on layout R2: d0 (0 to 3 cm), d1
(-0.8 to 0.8 cm per block), the horizon (3 to 7 blocks), the elite fraction (0.03 to 0.2) and
the tolerated summed penetration (0 to 1.5 cm). Population 12, 8 generations, 3 seeds per
candidate; the objectives were mean exposure and mean J (steps to success, 50 when the episode
does not succeed). Each run's final front was re-run on fresh seeds 400 to 409 of R2 and on
the held-out layout R0. The frozen grid's horizons were 4, 5 and 6.

## Results (mean ± sd over 3 replicates)

| method | search HV | fresh-seed HV | held-out HV | best safe success, fresh | best safe success, held out |
|---|---|---|---|---|---|
| NSGA-II | 30.89 ± 3.33 | 17.20 ± 6.49 | 11.67 ± 0.68 | 0.77 ± 0.12 | 0.63 ± 0.05 |
| random search | 30.44 ± 3.36 | 16.20 ± 5.55 | 14.13 ± 4.43 | 0.77 ± 0.12 | 0.70 ± 0.14 |
| grid search | 24.89 ± 3.40 | 12.30 ± 2.20 | 8.70 ± 3.06 | 0.70 ± 0.08 | 0.53 ± 0.12 |

Best safe success per run (fresh seeds of R2 / held-out R0): NSGA-II 0.6 / 0.6, 0.8 / 0.6,
0.9 / 0.7; random search 0.8 / 0.9, 0.9 / 0.6, 0.6 / 0.6; grid 0.6 / 0.5, 0.7 / 0.7, 0.8 / 0.4.

Replicate pairs (3 x 3): NSGA-II beat random search in 5 of 9 pairs on both fresh-seed and
held-out HV (differences of means +1.0 and -2.5; random search's held-out mean is pulled up
by one run at 20.4). The grid beat NSGA-II in 3 of 9 pairs on both HV measures and random
search in 3 and 2 of 9.

Best settings on the final seeds (safe success 0.9, no entries):

| run | d0 | d1 per block | horizon | elite fraction | tolerance | set | mean J |
|---|---|---|---|---|---|---|---|
| NSGA-II r2 | 0.85 cm | -0.71 cm | 3 | 0.13 | 0.60 cm | fresh | 24.9 |
| random r1 | 1.80 cm | -0.66 cm | 3 | 0.07 | 1.16 cm | fresh | 29.1 |
| random r0 | 0.50 cm | +0.28 cm | 3 | 0.10 | 1.09 cm | held out | 29.6 |

Stage B on the same layouts (seeds 200 to 209, horizon 5): on R2 the best fixed dial (0.5 cm)
reached safe success 0.5 (J 43.0), the check at d = 0 0.4 and the planner without the check
0.1; on R0 the best fixed dial (1 cm) reached 0.8 (J 34.1), d = 0 0.3 and no check 0.7.

## What C shows

1. **Searching the settings raised safe success where it searched.** Every run's final front
   reached safe success 0.6 to 0.9 on fresh seeds of R2 (mean 0.74 over the 9 runs), against
   0.5 for the best fixed dial and 0.1 for the planner without the check in stage B (other
   seeds), with steps to success falling from about 43 to 25 to 29 for the best settings.
2. **It did not carry over to the held-out layout on average.** On R0 the fronts reached 0.4
   to 0.9 (mean 0.62), against 0.8 for the best fixed dial and 0.7 for the planner without
   the check in stage B. Task 10 (Push-T) showed the same pattern.
3. **NSGA-II and random search tie; both beat the grid.** The two are within noise on every
   measure (NSGA-II wins 5 of 9 replicate pairs on each hypervolume measure, and both reach
   best safe success 0.77 on fresh seeds). The grid trails on every measure.
4. **The lever is again the horizon.** Every top setting plans 3 blocks ahead. Across the
   whole search, safe success was 0.59 at horizon 3 against 0.32, 0.26, 0.11 and 0.05 at 4
   to 7 (stage B planned 5), and mean J 35.6 against 43.7 to 49.2. NSGA-II spent the most
   search episodes at horizon 3 (204, against 108 for random search); the frozen grid could
   not reach it, which is enough to explain its deficit.
5. **Safety held.** 2 of 2792 stage C episodes entered the band, for one step each, both from
   settings that tolerated more than 1 cm of imagined penetration; no final episode entered.

For the GECCO comparison, Reacher gives no separation between NSGA-II and random search at
this budget, and the searched settings beat the best fixed dial only on the layout they were
searched on.
