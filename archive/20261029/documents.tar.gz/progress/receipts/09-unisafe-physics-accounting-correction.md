# Task 9 physics accounting correction

25 October 2026. This corrects offline accounting while stage B is running. It
changes no controller, simulator setting, episode outcome, seed or budget ceiling.

The worker records `SimulationContext.get_physics_step_count()`. Inspection of
the installed pinned source confirms that this monotonic counter increments in
`SimulationContext.step()` and is not reset by `SimulationContext.reset()`.
Its recorded rollout difference is exactly five steps per control. However, it
does not count every backend initialization update.

The installed `PhysxManager._warmup_and_create_views()` makes two direct
`physx.update_simulation(dt, 0.0)` calls when creating the first simulation view.
Each worker creates one environment in a fresh process. A recorded
`physics_after_construction` value proves that this construction returned, so
the offline ledger separately includes two source-derived warmup updates for
each such attempt. This is a lower bound, not a complete measurement of all
backend-internal updates. Uninstrumented internal work remains unknown.

The original raw summaries and the first engineering accounting receipt are
retained. Their zero reset-counter readouts must not be interpreted as zero total
startup physics. `09-unisafe-engineering-accounting-v2.json` supersedes that
interpretation: 13 completed environment constructions imply at least 26 warmup
updates, in addition to 8,220 recorded decimated physics steps. The interrupted
fourth invalid startup has no completed-construction evidence and is not assigned
an invented warmup count. Control totals remain 1,644 observed and 2,895
conservatively charged. Query counts are unchanged.

Source evidence is pinned in `09-unisafe-physics-counter-source.json` and
`09-unisafe-physx-initialization-source-v2.json`. The latter scopes extraction to
the `PhysxManager` class; its first inspection receipt accidentally selected an
unrelated nested `reset` method for that one excerpt. Both source hashes agree.
The physics backend file hash is
`dc1a3fbabbb54a4a3f7c45bf10e25643a346b06a6d9577e8f974584df9869742`.

The new offline accounting schema distinguishes the recorded counter, the
source-derived warmup lower bound and unmeasured internal totals. The predefined
explicit-control and decimated-physics ceilings remain unchanged. The running
stage-B source is untouched. Its full validation and scientific analysis still
require the complete frozen panel.
