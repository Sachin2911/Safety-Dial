# Task 16: safe progress recovered, adaptive advantage unestablished

26 October 2026. The complete admitted campaign ran on four RTX 3090 GPUs on one host.
The frozen LeWM models were unchanged. All 864 familiar-layout and 960 fresh-case
evaluation episodes completed, alongside 216 mechanism and 312 development episodes.
There were 2,380 attempts in total: 2,376 valid episodes and four retained engineering failures.

Tuning the fixed planner substantially recovered safe completion at the difficult
clearances. On familiar layouts, canonical SafeCEM versus tuned fixed achieved 3/36
versus 34/36 in TwoRoom at 6 px, and 0/36 versus 33/36 in Reacher at 1.5 cm.
On fresh cases, fixed versus adaptive achieved 238/240 versus 240/240 in TwoRoom and
218/240 versus 212/240 in Reacher, pooling the two prespecified margins equally.
All 960 fresh-case episodes respected both the original hazard and requested margin.
The results support a useful planning-configuration lever. They do not establish a
substantial adaptive benefit, an evolutionary advantage, or a safety guarantee.

## Final comparisons

The [joint final freeze](16-final-ab-v1.json) fixed both evaluations before either
ran. A uses three familiar layouts, three margins and twelve new planner seeds per
environment, with four methods. B uses twenty new cases, two margins and six new
planner seeds per environment, with fixed and adaptive methods. Every case/seed block's
methods ran on the same physical GPU and host. New cases were generated before
development outcomes, with no success-based filtering. They are modest changes within
the two environment families, not evidence of transfer to a new task family.

Primary completion requires task success within 50 executed actions and no breach of
the requested inflated-box predicate. Benchmark-safe completion checks the original
hazard. Reacher safety includes every internal repeat integration, unlike the coarser
historical monitor. These are sampled simulation checks. The trusted checker has true
state and dynamics; the task-side adapter has no true target geometry.

### A: familiar layouts

Every entry below has 36 episodes. Native trajectories do not depend on clearance;
they were actually rerun and charged at each margin, but their repeated outcomes are
not independent evidence across margins. All 864 episodes engaged, with no controller
failures or censored episodes. For checked methods, benchmark-safe and requested-safe
completion coincide. Native benchmark-safe completion is 10/36 at each TwoRoom margin
and 15/36 at each Reacher margin. Original-hazard violation and requested-margin breach
are separate columns; unfinished episodes can overlap with violations.

| Environment | Margin | Method | Safe completion | Hazard violation | Margin breach | Unfinished | Mean J |
| --- | --- | --- | --- | --- | --- | --- | --- |
| TwoRoom | 0 px | Native | 10/36 | 26/36 | 26/36 | 6/36 | 27.17 |
| TwoRoom | 0 px | Canonical SafeCEM | 36/36 | 0/36 | 0/36 | 0/36 | 18.61 |
| TwoRoom | 0 px | Tuned fixed | 36/36 | 0/36 | 0/36 | 0/36 | 9.08 |
| TwoRoom | 0 px | Adaptive | 36/36 | 0/36 | 0/36 | 0/36 | 12.22 |
| TwoRoom | 4 px | Native | 3/36 | 26/36 | 33/36 | 6/36 | 27.17 |
| TwoRoom | 4 px | Canonical SafeCEM | 20/36 | 0/36 | 0/36 | 16/36 | 35.61 |
| TwoRoom | 4 px | Tuned fixed | 36/36 | 0/36 | 0/36 | 0/36 | 11.92 |
| TwoRoom | 4 px | Adaptive | 36/36 | 0/36 | 0/36 | 0/36 | 12.58 |
| TwoRoom | 6 px | Native | 1/36 | 26/36 | 35/36 | 6/36 | 27.17 |
| TwoRoom | 6 px | Canonical SafeCEM | 3/36 | 0/36 | 0/36 | 33/36 | 47.89 |
| TwoRoom | 6 px | Tuned fixed | 34/36 | 0/36 | 0/36 | 2/36 | 15.97 |
| TwoRoom | 6 px | Adaptive | 36/36 | 0/36 | 0/36 | 0/36 | 16.64 |
| Reacher | 0 cm | Native | 15/36 | 14/36 | 14/36 | 12/36 | 41.67 |
| Reacher | 0 cm | Canonical SafeCEM | 19/36 | 0/36 | 0/36 | 17/36 | 39.56 |
| Reacher | 0 cm | Tuned fixed | 36/36 | 0/36 | 0/36 | 0/36 | 24.89 |
| Reacher | 0 cm | Adaptive | 36/36 | 0/36 | 0/36 | 0/36 | 25.11 |
| Reacher | 1 cm | Native | 4/36 | 14/36 | 29/36 | 12/36 | 41.67 |
| Reacher | 1 cm | Canonical SafeCEM | 12/36 | 0/36 | 0/36 | 24/36 | 44.17 |
| Reacher | 1 cm | Tuned fixed | 36/36 | 0/36 | 0/36 | 0/36 | 24.72 |
| Reacher | 1 cm | Adaptive | 36/36 | 0/36 | 0/36 | 0/36 | 23.00 |
| Reacher | 1.5 cm | Native | 1/36 | 14/36 | 35/36 | 12/36 | 41.67 |
| Reacher | 1.5 cm | Canonical SafeCEM | 0/36 | 0/36 | 0/36 | 36/36 | 50.00 |
| Reacher | 1.5 cm | Tuned fixed | 33/36 | 0/36 | 0/36 | 3/36 | 32.03 |
| Reacher | 1.5 cm | Adaptive | 29/36 | 0/36 | 0/36 | 7/36 | 35.50 |

J is the task completion action count, assigning 50 to task failures. It is not a
safety-penalized cost: an unsafe native task success can still have a small J.
Completion and safety must therefore be read together.

### B: fresh cases

All rows have zero hazard violations, zero requested-margin breaches, zero controller
failures and full engagement. Benchmark-safe and requested-safe completion coincide.
The pooled result hides the main remaining difficulty: Reacher at 1.5 cm.

| Environment | Margin | Method | Safe completion | Unfinished | Mean J |
| --- | --- | --- | --- | --- | --- |
| TwoRoom | 4 px | Tuned fixed | 120/120 | 0/120 | 11.14 |
| TwoRoom | 4 px | Adaptive | 120/120 | 0/120 | 12.16 |
| TwoRoom | 6 px | Tuned fixed | 118/120 | 2/120 | 14.72 |
| TwoRoom | 6 px | Adaptive | 120/120 | 0/120 | 13.96 |
| Reacher | 1 cm | Tuned fixed | 119/120 | 1/120 | 21.07 |
| Reacher | 1 cm | Adaptive | 120/120 | 0/120 | 19.96 |
| Reacher | 1.5 cm | Tuned fixed | 99/120 | 21/120 | 34.99 |
| Reacher | 1.5 cm | Adaptive | 92/120 | 28/120 | 35.50 |

Paired adaptive-minus-fixed differences in safe completion, in percentage points:

| Environment | Margin | Difference | 95% case-block interval |
| --- | --- | --- | --- |
| TwoRoom | 4 px | +0.00 | [0.00, 0.00] |
| TwoRoom | 6 px | +1.67 | [0.00, 5.00] |
| TwoRoom | Both margins | +0.83 | [0.00, 2.50] |
| Reacher | 1 cm | +0.83 | [0.00, 2.50] |
| Reacher | 1.5 cm | -5.83 | [-19.17, 7.50] |
| Reacher | Both margins | -2.50 | [-9.17, 4.17] |

Intervals use 10,000 percentile bootstrap draws over twenty whole case blocks,
preserving paired seeds and margins, with equal case weights and analysis seed 160026.
They are pointwise and conditional on the selected controllers and fixed planner-seed
panel. There are no repeated independent optimizer runs. The corresponding A intervals
have only three case blocks and limited resolution. A zero-width empirical interval
at a ceiling is not proof of equivalence or a zero population failure rate.
The observed TwoRoom benefit is small; the Reacher strict-margin point estimate is worse
for adaptation, with uncertainty spanning harm and benefit. A large adaptive gain is
not supported on this panel. This is not a general impossibility result for adaptation.

No observed breach in 960 trials is not a zero-risk claim. Under independent identically
distributed episodes the rough rule of three would give 3/960, about 0.31%, but these
episodes share cases, seeds, controllers and host. That calculation is only illustrative,
not a calibrated bound for this clustered evaluation.

## Mechanism comparison and development

Q used nine episodes per environment/margin/condition, without a scientific stopping
gate. Requested-safe completion was:

| Environment | Margin | Native | Canonical | Horizon 3 | Memory + correlation | 2x search | Geometric reference |
| --- | --- | --- | --- | --- | --- | --- | --- |
| TwoRoom | 0 px | 3/9 | 9/9 | 9/9 | 9/9 | 9/9 | 9/9 |
| TwoRoom | 6 px | 1/9 | 0/9 | 6/9 | 8/9 | 0/9 | 9/9 |
| Reacher | 0 cm | 6/9 | 1/9 | 7/9 | 6/9 | 1/9 | 6/9 |
| Reacher | 1.5 cm | 1/9 | 0/9 | 1/9 | 0/9 | 0/9 | 3/9 |

All checked Q conditions had zero observed hazard violations and margin breaches.
Shorter imagination with the matched work allowance, and retained/correlated candidates,
helped TwoRoom much more than simply doubling search. The memory condition changes both
retention and sampling correlation, so it cannot identify retention's isolated effect.
The shorter horizon also allows more samples under the same predictor-work ceiling.
The geometric reference uses privileged goal information; its score is a diagnostic,
not a deployable adapter or proof that every case is feasible.

Development ran D1 (192 episodes), a revised feedback family D2 (48), an exact
fixed-base ablation (12), high-margin selection validation D3a (24), and a prospective
robustness check D3b (36). D2 tested combined prediction-error/stall responses and
smoothed progress; neither was selected. D3b did not trigger further selection.
The selected adapter changed modes in 197/348 final TwoRoom episodes and 347/348 Reacher
episodes. Its lack of a clear advantage is therefore not explained by a universally
inactive feedback rule. Selection details and all alternatives are in the development
receipts and [selected controller file](../../configs/lewm16/selected-controllers.json).

The initial engineering errors were repaired and retained: two Reacher attempts failed
on a negative-stride image array, then two failed because reset replaced the simulator
and detached the physics recorder. The fixes were contiguous images and attaching the
recorder after reset. Twenty-four engineering episodes completed. Live first-block native
action parity was exact in the repaired checks; checker replay passed in both environments.
Four missing physics integrations in the invalid recorder attempts are reconstructed
separately and included in the accounting, without changing original traces.

## Controller and information contract

Each frozen LeWM has 18,034,478 parameters. The selected threshold adapter has ten tunable
parameters and no learned readout. Both environments selected recipe a02: base horizon 3,
exploration scale 1, retention 0.25 and sampling correlation 0.5; prediction-error threshold
0.5, stall threshold 0.02, repair horizon 2, stall horizon 3, stall retention 0.5 and
exploration multiplier 2. It uses frozen latent goal cost, observed relative progress,
prediction error and allowed planner summaries. The requested clearance is never reduced.
No model weights, feature encoders or readouts were trained, and no evolutionary search ran.

Fixed settings were selected separately by environment and requested margin:

| Environment | Margin | Recipe | Horizon | Exploration scale | Retention | Correlation |
| --- | --- | --- | --- | --- | --- | --- |
| TwoRoom | 0 px | f11 | 2 | 1 | 0 | 0 |
| TwoRoom | 4 px | f13 | 2 | 2 | 0.5 | 0.5 |
| TwoRoom | 6 px | f02 | 2 | 2 | 0.5 | 0 |
| Reacher | 0 and 1 cm | f14 | 3 | 1 | 0.25 | 0.5 |
| Reacher | 1.5 cm | f04 | 3 | 1 | 0.5 | 0 |

All checked methods verify candidates and the proposed executable block using the same
checker. A checked candidate may replace an unsafe elite mean; an unchecked least-unsafe
candidate is never used as a fallback. No final episode required controller-failure
termination. Five actions are executed per plan regardless of imagined horizon.
The matched per-replan predictor-work ceilings are 50,000 TwoRoom and 15,000 Reacher
candidate steps, plus the explicitly counted chosen-plan prediction; Q's larger-search
condition alone doubles its candidate-work allowance. Actual episode costs vary with
completion time. Matching this work ceiling does not imply equal simulator or wall cost.

Proposed means and selected checked blocks are retained in replan logs. State traces keep
the actual environment commands. Bounded simulator controls are reconstructed for reporting
using the pinned [-1,1] clipping; Reacher motor gear additionally scales the control, so
these values are not joint torques. Full statistics include path length, command norm,
bounded-control norm, clipping fraction and per-condition computation. Every final episode
exceeded the descriptive engagement threshold (1 px TwoRoom path length or 0.001 m Reacher
path length). Engagement means movement, not task progress; canonical failures can move a lot.

## Resource accounting and validation

The full final schedule was admitted prospectively and completed. The 2,420 planning
allocation was not a requirement to waste unused engineering trials: 28 of 80 engineering
slots were attempted, and twelve unused slots funded the exact-base ablation, producing
2,380 total attempts. There is no final-comparison shortfall. All 2,352 non-engineering
comparisons are complete and valid. The [independent audit](16-final-audit.json) checks
source archives, tickets, manifests, results, action/physics counters, finite outputs,
dense safety labels and checker replay. Ten focused tests passed; new scripts passed Ruff
and compilation. Final runtime code was not changed after the A/B freeze.

| Resource, all attempts | Count |
| --- | --- |
| environment resets | 2,380 |
| goal render frames | 2,380 |
| render frames | 61,390 |
| encoder frames | 25,996 |
| model candidate rollouts | 116,095,892 |
| predictor steps | 375,902,973 |
| checker candidate rollouts | 116,125,967 |
| checker physics steps | 1,240,139,160 |
| executed physics steps | 99,895 |
| environment actions | 61,388 |
| analytic path steps | 1,258,716,983 |
| reconstructed missing executed physics steps | 4 |
| total executed physics steps | 99,899 |

The 61,388 executed environment actions are not the entire interaction bill. Reacher's
counterfactual checker used 1.240 billion physics integrations, and TwoRoom's analytic
checker used 1.259 billion path steps. These are reported separately from 375.9 million
learned predictor steps. Episode reset and goal-render counts include failed attempts;
simulator construction/reset forward operations are not controlled physics integrations.
There were no gradient updates. Per-attempt timings and the complete resource vector are
preserved, including discarded development candidates and failed starts.

## Preservation and financial closeout

The rental was created at 09:48:59 UTC, compute stopped at 11:18:18, and destruction was
confirmed by a complete provider instance list at 11:31:33 on 26 October. The first destroy
command did not complete because the installed CLI required its confirmation flag; a
fresh provider check showed the stopped instance still present. After both preservation
checks, the authorized command was corrected and absence verified by both ID and label.
The task-16 watchdog exited. Task 15's files and rental were not used or changed.

Posted charges at 11:32 UTC total **$1.510**: $1.416 compute, $0.085 storage and $0.009
download. This is a provider snapshot, subject to rounding and later adjustments. The
conservative all-in estimate is **$1.891**, charging full compute plus disk through verified
destruction and retaining the transfer reserve. Both are within the $10 hard cap.
The authorized campaign began at 09:29 UTC; experiments and destruction finished in just
over two hours, with reporting and final preservation following within the five-hour target.
See [stop](16-rental-stop.json), [destruction](16-rental-destroy.json),
[billing](16-billing-destroyed-final.json) and [closeout verification](16-closeout.json).

All 16,915 sealed remote files (282,608,737 bytes) were hash-verified locally. Complete raw
evidence, source archives and controller manifests were uploaded to the existing private
dataset `Sachioster/maniguard-jar-replication-20261022`, prefix
`16_lewm16_campaign/final-raw`, at revision
`cf77289d39b19a21f68dc16c723ee3f55acb1745`. All fifteen uploaded objects were downloaded
at that revision and hash-verified before rental destruction. The
[raw preservation receipt](16-preservation-final-raw.json) fixes the index hash.
The [final closeout snapshot](16-preservation-final-closeout.json) separately preserves
the completed report, figures, Odyssey and teardown evidence.

## What this supports for the thesis and paper

The useful finding is that a strong fixed configuration recovers safe progress under
the same requested constraint and planner-work ceiling. This gives the thesis a clear
mechanism study and a stronger comparator. It prevents attributing configuration gains
to online adaptation or to the method that selected the parameters.

These results do not establish an evolutionary contribution. A future optimizer study
would need matched information and total interaction budgets for tuned fixed control,
parameter random search, ordinary learning and evolution, with replicated searches and
new final cases. That is a separate experiment, not unfinished work in this campaign.
The present B cases have now been evaluated and cannot be reused as untouched selection
evidence. Reacher's stricter-clearance failures remain a concrete research question.

Reproduce the final tables and figures with the venv's Python and
`experiments/scripts/report_lewm16.py` against the restored raw snapshot. The machine-readable
[statistics](16-final-statistics.json) retain per-case rows and contrasts. Local exportable
figures are [completion](../../outputs/lewm16/analysis/safe-completion.pdf),
[paired differences](../../outputs/lewm16/analysis/transfer-difference.pdf) and
[mechanisms](../../outputs/lewm16/analysis/mechanism-comparison.pdf).
