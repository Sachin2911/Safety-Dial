# Task 7 DSRL development result

25 October 2026. Scientific analysis complete; private preservation and rental
closeout pending. The numerical repair succeeded and the full learning comparison
ran. The frozen screen failed. This is a working integration with a negative
development result for this setup, not evidence that latent steering cannot work.

## Frozen comparison

All six engineering, 24 training and 48 evaluation episodes are valid, with no
failed or replaced simulator starts. Evaluation used the final episode-24 actor,
version 6, one learner seed and the six preselected development tasks. No held-out
intervention episodes ran. Arms rotated across GPU lanes on one physical host.

| Arm | Strict safe completion | Benchmark success | Raw / counted violations | Unfinished | Contact | Grasp | Closure observed |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Native | 3/12 | 3/12 | 4/12 / 4/12 | 9/12 | 12/12 | 4/12 | 9/12 |
| Fixed zero | 0/12 | 0/12 | 3/12 / 3/12 | 12/12 | 12/12 | 0/12 | 11/12 |
| Random | 0/12 | 1/12 | 7/12 / 7/12 | 11/12 | 12/12 | 1/12 | 5/12 |
| DSRL | 0/12 | 0/12 | 4/12 / 4/12 | 12/12 | 10/12 | 0/12 | 1/12 |

Strict completion includes the requested closure-before-carry order and no raw
violation. The random arm's benchmark success was unsafe. The screen required at
least two more strict completions than native, gains on two tasks, superiority to
the fixed/random controls, no extra violations and adequate engagement. It failed
completion and relative-engagement criteria. These are practical development
thresholds, not significance tests. Twelve episodes per arm and one learner seed
cannot establish a general failure or an optimizer advantage.

## What worked

The pinned author's SAC and our bridge became exactly equal on the five paired
fixed-batch updates when deterministic GPU operations were enabled before JAX
initialization. Both had been nondeterministic under the original configuration.
Live-batch parity passed. Same-process decoder repeats and explicit native-noise
passthroughs were exact. Cross-process reproducibility remains imperfect and is
reported separately rather than hidden by a relaxed same-process tolerance.

The pipeline collected 6,000 training transitions, completed all 90,000 planned
development updates and exported the actual final trained actor. A separate audit
matched its full published training state and its exported parameters and batch
statistics exactly; parameters are finite and changed during training. All
evaluation jobs used that final actor. This rules out a stale export as the cause
of the observed result.

## What limited learning

Training yielded 0/24 safe completions, 13/24 observed violations, 24/24 unfinished
episodes, 20/24 contact and 1/24 grasp. Four episodes had no safety evaluation
because they did not engage; they are not evidence of safe activity.

The recorded reward was almost absent: 21/24 episodes had all-zero reward.
Only 114/6,000 transitions had nonzero reward, including three positive shaping
events and 111 negative values. No transition had completion reward. The shaped
return identity reconciles with the discounted completion return. Increasing the
potential coefficient alone would not change the exact terminal objective.

Reward starvation is a supported diagnosis, but not an isolated causal finding.
The fixed-zero and random steering controls also grasped less often than native.
At magnitude one the saved-observation probe changed the gripper command on only
one of eight inputs. These observations motivate testing the steering interface
and the reward separately. They do not prove that grasp is uncontrollable.
The post-hoc [critic diagnostic](07-dsrl-critic-diagnostic.json) adds a third
hypothesis. Logged mean Q rose from 0.307 to 37.186 despite no training completion
reward. The pinned caller leaves the critic's entropy backup disabled, so an
entropy term in the target does not explain that rise. The actor still has an
entropy term in its loss. This is consistent with bootstrap overestimation under
the long horizon, mean critic reduction and extensive replay updates; the causal
mechanism is not established. The terminal-zero potential identity bounds the
intended discounted task return between -0.25 and 1, so a prediction around 37 is
miscalibrated for this objective. Exact parity with the author's update establishes
faithful integration, not well-calibrated values for this task and reward.

## Accounting and evidence

The frozen analyzer found no source-versus-ledger mismatch, no valid-episode
accounting deficit and no unresolved invalid jobs. Actual charged interactions:
78 starts, 151,816 policy controls, 780 warm-up controls, 19,213 VLA queries
(18,979 policy, 216 probes, 18 startup), and 90,150 learner updates (90,000
development plus 150 engineering). There were 7,766 actor forward requests.
Internal scene/reset physics is not measured by these control counts.

The final coordinator exited zero. Its predecessor's deliberate minus-nine exit
belongs to the recorded reserve handover, not a failed simulator episode. The
$0.20 internal reserve reallocation changed admission timing but no scientific
field, seed, reward, checkpoint rule or interaction cap. The cumulative $15 cap
includes task 6 and remains in force.

The complete 21,346-file raw inventory, 5,062,035,831 raw bytes, and the consistent
19,213-query SQLite backup were verified locally before provider stop was
confirmed at 12:38:18 UTC. The source backup and frozen evidence remain immutable.
Private copies and final billing will be added in the closeout record.

Primary records: [analysis](07-dsrl-analysis.json), [analysis summary](07-dsrl-analysis.md),
[run record](07-dsrl-run.md), [final stage-B freeze](07-dsrl-stage-b-v2.json),
[reserve handover](07-dsrl-reserve-handover.json), and
[protocol](../07-dsrl-repair.md). All preceding failed numerical checks and source
versions remain recorded. Further improvement experiments require a fresh protocol;
this completed queue is not resumed.
