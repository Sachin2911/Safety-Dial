# Task 12 receipt: stage C, searching the planner's settings on TwoRoom (25 to 26 October 2026, 19:33 to 23:56 UTC)

Freeze `progress/receipts/12-tworoom-C-v1.json` (ladder rung 8 generations x 3 replicates).
Run on instance 57707282 (one RTX 3090): 2892 episodes (2592 search, 300 final), zero failed
attempts, 4 h 23 min. The fronts were small (1 to 4 settings), so the run used 780 fewer
episodes than the 3672 planned. The detached finalizer (`experiments/scripts/finalize_tworoom12.sh`)
synced, stopped the instance, analyzed, preserved the evidence privately
(`Sachioster/maniguard-jar-replication-20261022` at revision `01b2d1ac080e2bceb909497264daa9757c948742`,
24 files verified; marker `12-tworoom-preservation.json`) and destroyed the instance at
00:01 UTC on 26 October. The rental cost about $1.30 over 5.4 h. Analysis:
`outputs/tworoom12/analysis/stageC-{summary.json,table.md,fronts.*}`; the numbers below come
from `experiments/scripts/summarize_stage_c.py --task tworoom12`.

NSGA-II, random search and a grid each tuned five settings on layout T2: d0 (0 to 14 px), d1
(-4 to 4 px per block), the horizon (3 to 7 blocks), the elite fraction (0.005 to 0.05) and
the tolerated summed penetration (0 to 7 px). Population 12, 8 generations, 3 seeds per
candidate; the objectives were mean exposure and mean J (steps to success, 50 when the episode
does not succeed). Each run's final front was re-run on fresh seeds 400 to 409 of T2 and on
the held-out layout T0. The frozen grid's horizons were 4, 5 and 6.

## Results (mean ± sd over 3 replicates)

| method | search HV | fresh-seed HV | held-out HV | best safe success, fresh | best safe success, held out |
|---|---|---|---|---|---|
| NSGA-II | 35.78 ± 1.57 | 32.83 ± 1.80 | 35.57 ± 0.87 | 1.00 ± 0.00 | 1.00 ± 0.00 |
| random search | 37.41 ± 0.11 | 37.00 ± 0.22 | 38.10 ± 0.22 | 1.00 ± 0.00 | 1.00 ± 0.00 |
| grid search | 34.44 ± 0.31 | 31.20 ± 2.26 | 33.27 ± 0.90 | 0.97 ± 0.05 | 1.00 ± 0.00 |

Replicate pairs (3 x 3): random search beat NSGA-II on fresh-seed and held-out HV in 9 of 9
(differences of means 4.2 and 2.5) and the grid in 9 of 9 (5.8 and 4.8). The grid beat NSGA-II
in 2 of 9 on fresh-seed HV and 0 of 9 on held-out HV.

Best settings on the final seeds (all safe success 1.0 with no entries):

| run | d0 | d1 per block | horizon | elite fraction | tolerance | mean J, fresh | mean J, held out |
|---|---|---|---|---|---|---|---|
| random r0 | 1.18 px | -1.43 px | 3 | 0.018 | 2.25 px | 12.7 | 12.0 |
| random r1 | 5.17 px | -1.74 px | 3 | 0.025 | 4.35 px | 13.2 | 12.0 |
| random r2 | 0.89 px | +0.78 px | 3 | 0.013 | 0.82 px | 13.1 | 12.1 |
| NSGA-II r0 | 3.36 px | +0.68 px | 3 | 0.010 | 6.89 px | 15.7 | 13.3 |
| NSGA-II r2 | 2.12 px | -3.85 px | 4 | 0.042 | 2.83 px | 16.1 | 14.6 |
| grid r1, r2 | 2 px | -3 px | 4 | 0.010 | 0 px | 17.2 | 16.1 |
| NSGA-II r1 | 0.18 px | -2.80 px | 5 | 0.036 | 1.56 px | 19.7 | 16.7 |

Stage B on the same layouts (seeds 200 to 209, horizon 5): the best fixed dial (0 px) reached
safe success 1.0 with mean J 21.0 on T2 and 20.8 on T0; the planner without the check 0.1 and
0.4.

## What C shows

1. **Safe success saturates, as stage B predicted.** Every method's best setting reaches safe
   success 1.0 on both final sets (one grid replicate 0.9 on fresh seeds), so the comparison
   is about speed: hypervolume here is close to 50 minus the steps to a safe success.
2. **Random search beat NSGA-II and the grid on every hypervolume measure, in every replicate
   pair.** Its best settings reach the target in 12 to 13 steps on fresh seeds and on the
   held-out layout, against 13 to 20 for NSGA-II's, 16 to 18 for the grid's and about 21 for
   the best fixed dial in stage B (other seeds).
3. **The lever is the horizon, not the dial.** Every top random-search setting plans 3 blocks
   ahead. Over the whole search, mean J was 25.0 at horizon 3 against 34.5 to 41.6 at 4 to 7;
   on fresh seeds the top settings at horizon 4 take 16 to 17 steps and at horizon 5 20 to
   21. The dial settings that reach 1.0 vary widely (d0 0.9 to 5.2 px, d1 -1.7 to +0.8 px
   per block).
4. **NSGA-II found horizon 3 in one replicate of three.** It spent more search episodes on
   horizon 3 than random search did (189 against 132), but two of its fronts
   settled on horizons 4 and 5. Its r0 setting scored search HV 38.0 on 3 seeds and dropped to
   J 15.7 on fresh seeds, so selection on 3 noisy seeds also cost it. The frozen grid could not
   reach horizon 3 at all.
5. **The tolerance gene trades a little safety for flexibility.** 14 of 2892 stage C episodes
   entered the band, each for 1 or 2 steps, all from settings that tolerated 3.2 to 6.7 px of
   imagined penetration; no setting tolerating less than 3.2 px entered.

For the GECCO comparison, TwoRoom is a negative result for evolution at this budget (96
candidates of 3 seeds per run): random search kept a horizon-3 setting at the top of every
replicate, while NSGA-II's small population, selected on 3 noisy seeds, settled on longer
horizons in two of three.
