# Task 15: a regrasp adapter with a safety dial for frozen pi0.5 on Jar

Written 25 October 2026. Status: authorized. Sachin approved the direction ("Yes that
is exactly it, please go ahead"), asked for a separate rented GPU with a **$10 budget**
instead of local inference, and authorized running the later stages after the initial
tests, persisting through recoverable failures until the pipeline works. This task
has its own namespace (`regrasp15`), rental, ledger and receipts. It does not resume
or inherit tasks 6, 7, 8 or 11. Tasks 13 and 14 belong to other sessions.

## Question

Native pi0.5 loses Jar after the lid closes. In 66 recorded native episodes from
tasks 4, 5, 7 and 8, 40 reached a stable closure; afterwards 12 succeeded, 13 tipped
the jar and 15 stalled. Every lever tested so far acted across the whole episode. The
UNISafe study showed that a small adapter acting at a sensed failure moment can change
outcomes, and SafeCEM showed that an explicit check with an adjustable margin gives a
dial. This task tests their combination on ManiGuard:

> Leaving native pi0.5 untouched until the lid is stably closed, does vetoing chunks
> that drive the hand fast near the jar, and running pi0.5's own closest passing
> sample instead, reduce post-closure tips and raise strict safe completion? Does the
> speed limit act as a dial, and does selection among native samples beat simply
> slowing the native chunk?

## Design evidence used before any new episode

All of the following came from preserved recordings, with no simulator or model call
(`experiments/scripts/diagnose_regrasp15.py`, `design_regrasp15.py`; outputs under
`outputs/regrasp15/design/`).

- Post-closure tips (29 across all arms) come from fast pushes with the gripper open:
  in the two seconds before a tip, median peak hand speed 0.25 m/s with sustained
  contact. Successful grasps approach at a median peak of 0.04 m/s.
- Inside the closure gate, a near-jar speed limit of 0.10 m/s would veto 7.7% of native
  chunks but 61.5% of chunks issued within two seconds before a tip; 0.06 m/s vetoes
  14.4% and 73.8%; 0.15 m/s vetoes 4.8% and 41.8%.
- The Franka chain (standard Panda modified DH, 0.107 m flange, 0.105 m eef offset)
  reproduces recorded eef positions to below 0.001 mm once each scene's base pose is
  fitted (`experiments/helpers/regrasp15_kinematics.py`).

These are development data from tasks already run. They fix the check and dial values
below; they are not efficacy evidence.

## Adapter

`experiments/helpers/regrasp15_check.py` holds the frozen logic.

- **Gate.** Opens once the benchmark proposition `jar_closed` has held for 10
  consecutive controls with the jar on its support, upright and not dropped. It closes
  for the rest of the episode at the first lift off the support or any violation. The
  trigger reads the scorer's propositions, which is privileged simulator information;
  this is declared and shared by every adapter arm. The `always` gate (ablation) is open
  from the first control until a violation.
- **Check.** For a chunk's eight executed joint targets, predict the hand path with the
  kinematics above (measured hand position plus base-frame displacement rotated by the
  base yaw). A chunk fails when its predicted hand speed exceeds the limit at any
  executed step whose start or end lies within 0.22 m horizontally of the jar's base
  link. The jar position is read from the simulator (declared, as above).
- **Selection (dial = speed limit).** The native query runs as usual. Inside the gate,
  if the native chunk passes it runs unchanged. Otherwise the server decodes K extra
  pi0.5 samples from fresh, recorded Gaussian noise on the same observation, without
  advancing the native sampling stream. The passing candidate closest to native in
  executed joint space runs; if none passes, the candidate with the smallest excess
  runs. Every executed chunk is therefore a pi0.5 sample.
- **Projection (comparison).** Inside the gate, a failing native chunk is scaled toward
  the current joints until its predicted near speed passes. No candidates are drawn.

## Stages

**Stage 0: steerability from stored observations (model only).** On the rental, decode
K = 16 fresh native-noise samples for task 7 query records inside the closure gate:
all records whose executed chunk exceeded 0.06 m/s plus a seeded random sample of the
others, capped at 720 records. Replay the stored native noise first and report its
difference from the stored chunk. Report each state's fraction of passing samples at
0.15, 0.10 and 0.06 m/s, and the rescue rate: among records whose executed chunk
failed, the fraction with at least one passing sample out of 16. Rule, frozen now:
if the rescue rate at 0.10 m/s is at least 0.5, live selection uses K = 16; otherwise
K = 32. Stage 0 never cancels the live stages, whose question includes projection.

**Stage A: live engineering (pool task 1, seeds 150000 to 150003).** One native episode,
one `select 0.10` episode with the `always` gate (the pool task rarely closes its lid,
so this exercises candidate requests), one `project 0.10` episode with the `always`
gate and one `select 0.10` closure-gated episode. Pass rules: every episode completes
and records; candidate requests return finite (K, 16, 8) chunks; native chunks are
unchanged whenever the gate is shut; selection and projection replay offline from the
journal; recorded checkpoints and sources match the freeze. Engineering outcomes never
enter efficacy estimates.

**Stage B: dial screen (development tasks 0, 3, 6 and 9; seeds 151000 to 151003).**
Five arms, sixteen episodes each, interleaved on one lane in a seeded order:

| Arm | Gate | Mode | Limit |
| --- | --- | --- | --- |
| native | none | native | none |
| select-0.10 | closure | select | 0.10 m/s |
| select-0.06 | closure | select | 0.06 m/s |
| project-0.10 | closure | project | 0.10 m/s |
| always-0.10 | always | select | 0.10 m/s |

Tasks 0, 3, 6 and 9 had the highest native closure rates in earlier development data
(9/10, 7/10, 9/10 and 7/10). Held-out tasks receive no episode.

**Stage C: confirmation (same tasks; seeds 152000 to 152011).** Native against the
stage-B selection arm with the most strict safe completions, ties broken by fewer
violations and then by the 0.10 limit, 48 fresh episodes each. Stage C runs whenever the
budget admits it; stage B only chooses the dial setting. If the selected arm had at least
three more violation episodes than native in stage B, stage C instead compares native
with projection-0.10.

## Outcomes and analysis

For every episode report strict safe completion (benchmark goal held, closure before
leaving the support, no raw violation), benchmark success, raw and counted violations,
unfinished episodes, engagement, grasp, the gate-open step, post-gate tips, stalls, and
adapter activity (vetoes, rescues, least-excess fallbacks, projection scale). The
primary confirmation contrast is strict safe completion, selected arm minus native, with
a one-sided exact Barnard test at alpha 0.05 and the Wilson and bootstrap intervals by
task. Secondary: post-gate tips, post-gate conversion among episodes whose gate opened,
and stalls. Stage B is descriptive. Engagement and inactivity are always reported next
to violations. Nothing pools across testbeds or with earlier tasks' rates.

## Money, host and ceilings

One RTX 3090 or RTX 4090 with driver 580.x (Isaac Sim 4.5 segfaulted on newer drivers),
at least 60 GB RAM, 12 effective cores and 160 GB disk, at most $0.65 per hour including
disk. The baseline of record ran Jar on RTX 3090s, and every comparison here stays on
this one host. The rental is managed by `manage_regrasp15.py` with the local and remote
financial watchdogs. The total cap is **$10**: $8 active with shutdown requests from
$7.90, and $2 reserved for transfer, stopped disk and preservation, with an aggregate
limit of 20 instance hours. No automatic increase.

Hard ceilings including failed attempts: 200 simulator starts (4 engineering, 80
screen, 96 confirmation, 20 replacements), 420,000 policy controls, 60,000 native VLA
queries and 120,000 candidate decodes. One lane: one simulator and one policy server
on the single GPU, sequential episodes, 40 minutes for a cold start and 25 minutes for a
cached episode. A serial warm-up precedes the first episode (task 11's start-up race).

## Amendments before the live freeze

Recorded before any live episode. None changes a dial value, an arm, a task or an
endpoint.

- **Host.** The first create (offer 50878515, one RTX 4090 in South Korea) never produced
  an instance: the create call's acknowledgement was uncertain and no instance with its
  label appeared within ten minutes, so the reservation was released at $0
  (`progress/rental-regrasp15-20261025-absent-1025214924.json`). The rental is instance
  57727030: one RTX 3090 in Wisconsin, driver 580.173.02, 28 cores, 64 GB, $0.31 per hour.
- **Install repair.** The first `behavior_install` attempt finished its conda, torch and
  curobo steps, then lost one Isaac Sim wheel download to a transient network error (the
  upstream installer's curl has no retry). Only the upstream installer was resumed, with
  identical flags and curl retries (`experiments/scripts/resume_behavior_regrasp15.sh`).
- **Gate code.** The `always` gate no longer closes at a lift, matching its definition
  above; the closure gate is unchanged.
- **Execution details made explicit.** Candidate latents are standard normal draws from
  numpy's generator seeded with (15, seed), where the seed is a CRC32 of the episode seed
  and control step, and are recorded in the journal. The live base yaw comes from the
  robot's base orientation and must agree with a fit over the episode's own arm and hand
  positions within 0.01 rad, or the episode fails validation.
- **Stage A pass rules.** Besides per-episode validation, at least one candidate request
  and at least one projection must occur across the four episodes.
- **Stage C choice.** The candidates are the closure-gated selection arms (select-0.10 and
  select-0.06), as the dial setting is what stage B chooses.
- **Candidate decoding (live freeze v2).** The first pipeline start stopped at its
  startup probe, before any episode: one 32-sample batch did not fit the server's share
  of the GPU, and the probe did not survive a reconnect during the compile. Candidates
  are now decoded in batches of at most 16, the size stage 0 ran 720 times, and the
  probe retries until the compile finishes. The candidates' distribution is unchanged.
- **Failures.** A simulator crash or timeout earns one replacement attempt with the same
  seed (at most 20 in total); two consecutive incomplete attempts, or any validation
  failure, halt the queue for diagnosis. Episodes start only while at least 45 minutes
  remain before the allocation deadline.

## Stage D: projection confirmation (added 26 October 2026)

Added with Sachin's approval ("Yes please go ahead") after the stage B screen and declared
in `progress/receipts/15-regrasp-stage-d.json` before the stage C queue started. Stage B
at 77 of 80 episodes had project-0.10 at 9/15 strict safe completions and 1 violation
against native at 5/15 and 6, while the selection arms did not beat native. The frozen
stage C rule still confirms the selection arm; stage D adds 48 project-0.10 episodes on
the stage C tasks and seeds after stage C, compared with stage C's native episodes. Primary
endpoint and test as in stage C; raw-violation episodes are the key secondary. Reported
separately, not pooled with stage B, within the same $10 cap and deadline rule.

## Preservation

Continuous local sync to `outputs/regrasp15/remote/`. After the last episode: quiesce,
inventory, verify a complete local copy, stop compute, upload to the private dataset
`Sachioster/maniguard-jar-replication-20261022` under `receipts/regrasp15/`,
`recordings/regrasp15/` and `jar/regrasp15_*`, verify every file at the pinned revision,
then destroy the disk through the preservation guard. Results go to
`progress/receipts/15-regrasp-results.md` and a finished-task Odyssey entry.
