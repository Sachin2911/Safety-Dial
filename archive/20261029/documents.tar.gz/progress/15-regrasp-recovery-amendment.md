# Task 15 recovery amendment: one complete cohort on a replacement host

Written 26 October 2026, before any recovery simulator episode, under Sachin's goal for
task 15 and the handoff `progress/goal-prompt-15-regrasp-handoff.md`. It changes no arm,
dial value, task, seed, threshold, endpoint or test of `progress/15-regrasp-dial-plan.md`
or the stage D declaration. It adds a host replication of the frozen stage C and stage D
schedule, because the original host disappeared during stage C.

## What happened to the original host

Instance 57727030 (machine 148266, RTX 3090, Xeon E5-2680 v4) ran stage 0, stage A, all
80 stage B episodes and the start of stage C. It left the provider between about 05:39 UTC
(last successful remote query, six stage C episodes validated) and 05:43 UTC (end of the
provider's disk metering); posted charges are $2.555 and stayed unchanged. The cause is not
established. Four stage C episodes (jobs 300 to 303) are complete locally; job 304 has only
its host validation event; job 305 validated on the host with an unknown outcome; job 306
may have started. Stage D never started. Evidence:
`progress/receipts/15-regrasp-recovery-evidence-20261026.json`; immutable local copy:
`outputs/regrasp15r1/historical/` (archive sha256 `9730c365…`).

## Two cohorts, never pooled

- **Historical cohort (original host).** Everything above stays as recorded in
  `outputs/regrasp15/`, is fully charged, and is reported descriptively. Its partial stage C
  is never pooled with the recovery cohort, and its stage B screen keeps its role of having
  chosen the stage C arm (`select-0.06`, frozen decision copied byte for byte to
  `configs/regrasp15r1/historical-stage-c-decision.json`).
- **Recovery cohort r1 (one replacement host).** In `outputs/regrasp15r1/`, sequentially on
  one simulator lane and one policy server:
  1. stage A engineering, jobs 0 to 3 exactly as frozen (pool task 1, seeds 150000 to 150003);
  2. stage C, jobs 300 to 395: native against `select-0.06`, tasks 0, 3, 6, 9, seeds 152000 to
     152011, in the original interleaved order;
  3. stage D, jobs 500 to 547: `project-0.10` on the same tasks and seeds, by seed then task,
     after stage C is complete.

  The task and seed schedule is reused as a recorded host replication; those seeds were run
  on the original host for jobs 300 to 306. Comparisons are within r1 only: the stage C
  primary contrast (r1 `select-0.06` against r1 native) and the stage D contrast (r1
  `project-0.10` against r1 stage C native), each with the declared Barnard test, Wilson and
  task-stratified bootstrap intervals, and the stage D timing caveat (its native comparator
  runs earlier in the same session, not interleaved). Design: `configs/regrasp15r1/recovery.json`.

Everything that defines the intervention is unchanged: frozen pi0.5 checkpoint 7400 at
revision `1d84eda0…`, K = 32 decoded in batches of 16, the closure gate, kinematics and
near-jar geometry, speed limits, 2,000-control horizon, 256 px observations, 20 Hz control
and eight executed actions per chunk. Held-out tasks receive no episode. No weights change.

## Host, start-up and engineering

The rental record (instance and machine) is bound into the live freeze bundle and the queue
refuses any other container. Old engineering records are not reused: the startup probe
re-verifies the 32-candidate request, native RNG isolation and finite outputs, and stage A
re-verifies every adapter decision by journal replay with the original pass rules. The lane
is strictly serial, so the task 11 race (several cold Isaac Sim starts unpacking one cache)
cannot occur; stage A job 0 is the first simulator start and runs alone, as the serial warm-up.

## Money, time and counters

Limits are unchanged and cumulative: $10 total, $8 active with stop requests from $7.90,
$2 reserved, 20 aggregate instance-hours, at most $0.65 per hour. The recovery book
`outputs/regrasp15r1/control/finance.json` imports both earlier allocations. Instance
57727030 is closed at a conservative 05:45:00 UTC, after the 05:42:54 disk-meter end, so
7.80 h and $2.42 are charged against posted $2.40 compute and disk; posted transfer is $0.155.
The provider-absence check at 07:33:17 is the outer bound (9.60 h, $2.98); admission is also
reported against it. Remaining: 12.20 h and $5.48 of active money.

Admission (`progress/receipts/15-regrasp-recovery-admission.json`) simulates the frozen
schedule with the 45-minute episode-admission margin and an allowance of two replacements,
using an episode-time model fitted on the original host. On the chosen host at the original
host's speed, all 96 stage C episodes and 46 of 48 stage D episodes are admitted; a host 10%
faster admits all 148 with about one hour to spare. Under the outer bound, stage C is still
admitted in full. Stage C therefore runs whenever it is re-admitted, and stage D follows its
declaration: episodes start only while 45 minutes remain, and an incomplete stage D is
reported with its actual denominators.

**Re-admission before stage C.** After stage A, a speed factor measured from the new host's
warm engineering episodes re-runs the admission. Stage C starts only when
`outputs/regrasp15r1/admission-c.json` records that all 96 stage C episodes fit with the
margin; otherwise the queue does not start stage C, compute is stopped and the shortfall is
reported.

Cumulative ceilings (stage D amendment): 250 simulator starts, 20 replacements, 500,000
policy controls, 62,000 native queries, 120,000 candidate decodes. The recovery queue
enforces all five against the original host's conservative counters (91 starts, 159,335
controls, 22,469 native queries, 59,328 candidate decodes, including stage 0's model-only
decodes and worst cases for jobs 305 and 306), reserving each start's worst case (2,000
controls, 251 native queries, 8,000 decodes) before admitting it.

## Completion and failures

Failure rules are unchanged: one replacement per crashed or timed-out job, a halt on two
consecutive incomplete attempts or any validation failure. A stage is complete only when
every expected job validated, no start is unresolved, the queue finished and nothing is
missing; stage D needs a complete stage C. A partial stage is preserved and reported as such.

## Recovery changes (operational only)

New files carry the `regrasp15r1` suffix; every earlier frozen source is unchanged. The
changes are the recovery namespace and rental paths, curl retries configured before the
pinned installer, the remote guard's output path, cumulative counter enforcement, semantic
completion checks, the re-admission gate, analysis with explicit input roots and
preservation of the executed source bundles and both host histories. Freezes:
`15-regrasp-recovery-prep-v1.json` (before the create request) and
`15-regrasp-recovery-live-v1.json` (before the first simulator start).

## Preservation

Private dataset `Sachioster/maniguard-jar-replication-20261022`, existing paths untouched:
the historical cohort under `receipts/regrasp15/`, `recordings/regrasp15/` and
`jar/regrasp15_*`; the recovery cohort under `receipts/regrasp15r1/`,
`recordings/regrasp15r1/` and `jar/regrasp15r1_*`. Every file is re-downloaded at the
pinned revision before the disk is destroyed.
