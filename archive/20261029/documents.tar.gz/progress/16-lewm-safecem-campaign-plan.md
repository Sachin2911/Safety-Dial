# Task 16 completed plan: recover progress in LeWM safe planning

**Completed on 26 October 2026.** All admitted final comparisons ran, evidence is
preserved and rental destruction is verified. Start at the
[results](receipts/16-lewm-results.md). The design below is historical execution
evidence and does not authorize another run or spending the unused allocation.

26 October 2026. **Authorized by Sachin's goal prompt at 09:29 UTC.**
The original review draft is retained in the conversation; the exact approval and its
hash are recorded in [the authorization receipt](receipts/16-lewm-authorization.json).

The agreed planning limits are **$10 total, approximately five hours end to end, and up to
four GPUs to shorten independent work**. This draft replaces the earlier suggestion of a
multi-day campaign. Review and explicit launch approval are complete. Task 15 remains a
separate experiment with its own agent, host and budget.

## 1. Decision proposed for review

Run one continuous development campaign around this question:

> Can a compact adapter recover useful progress from a frozen world-model planner while
> maintaining the requested safety constraint?

Use TwoRoom and Reacher together. Begin with quick comparisons that distinguish search
failure from an unhelpful goal objective, allow repairs and substantive method revisions,
then run two larger comparisons. The default workload is **2,420 episodes**, including
864 episodes on familiar layouts and 960 on fresh cases. These are planning allocations,
not a promise of throughput or a requirement to consume every episode.

The execution agent should finish a coherent investigation within the time and money limits.
A recoverable engineering problem calls for repair. An unsuccessful first adapter calls
for inspection and another justified implementation. Neither automatically ends the campaign.
The budget and final evaluation reserve remain real limits.

The desired output is a credible progress-preserving adapter, or a well-supported account
of the remaining bottleneck. A positive result is not required for honest completion.
This campaign establishes a mechanism and a substantial replication. A full evolutionary
optimizer comparison is a subsequent paper experiment, described in Section 13.

## 2. Evidence and questions

The [TwoRoom sweep](receipts/12-tworoom-B-sweep.md) achieved 30/30 safe completions across
three layouts at zero added margin, but 0/30 at a 6 px margin. No episode in either group
entered the hazard. The 24 px passage remains open at 6 px inflation. A saved-trace review
on 26 October found that approximately 89% of candidates in final CEM iterations passed
the check at 6 px, averaged across episodes. Safe candidates therefore remained plentiful.

Among the best candidates in final CEM iterations, the median learned goal cost was about
7.6 at both margins, while the median exact-model endpoint distance was approximately
11 px at margin zero and 45 px at margin six. These are exploratory summaries of correlated
planning records, not independent trials. The saved history contains selected trajectories,
not every candidate trajectory, so it cannot completely distinguish sampling from ranking.

The [Reacher sweep](receipts/13-reacher-B-sweep.md) also lost most completion at larger
margins while its gap remained open. The [Cube reaching study](receipts/14-cube-B-sweep.md)
showed a similar loss of progress, with an approximate safety check. Cube was a reaching
task in the Cube environment, not a demonstrated manipulation result.

Earlier work gives two operational lessons. TwoRoom's
[engineering revisions](receipts/12-tworoom-A-engineering.md) and Reacher's
[environment and planner repairs](receipts/13-reacher-A-engineering.md) changed the validity
and behaviour of the experiment. Their later searches also completed thousands of episodes:
[TwoRoom](receipts/12-tworoom-C-search.md) and
[Reacher](receipts/13-reacher-C-search.md). Those scientific results stand. This campaign
addresses a new mechanism and does not resume their searches.

Four questions guide development:

1. Do safe plans that advance toward the goal enter the candidate population?
2. If they do, does the learned goal objective rank them sensibly?
3. Does execution preserve their useful progress, including when executing an elite mean?
4. Can a small controller respond to these failures better than a strong fixed setting?

## 3. Scope and information contract

Keep the LeWM encoder and predictor frozen. Reuse the pinned model, dataset and software
identities in [TwoRoom's design](../configs/tworoom12/design.json) and
[Reacher's design](../configs/reacher13/design.json) as provenance, not as launch instructions.
Validate those environments in a fresh task-16 namespace. Do not inherit their old seeds,
budgets, queues, tolerance genes or acceptance rules.

TwoRoom is the mechanism test. Reacher tests whether an explanation and adapter survive a
different action interface. Push-T and Cube are follow-ups; their integration cannot consume
this campaign's reserved evaluation time.

Distinguish three information levels:

| Level | Information | Role |
| --- | --- | --- |
| Task-side adapter | Current and goal images, frozen embeddings, past actions, observed prediction error and agreed planner/check summaries | Main controller comparison |
| Trusted safety checker | TwoRoom true position and kinematics; Reacher true joint state and cloned simulator dynamics; declared hazard geometry | Identical safety machinery for all checked methods |
| Geometric progress reference | True target coordinates or joint angles and exact candidate endpoints | Diagnostic reference, reported separately |

The trusted checker is privileged simulator machinery. The main system is therefore a
visual task planner with a privileged safety checker, not an entirely pixel-only safety
system. Giving an adapter true goal distance would move it into the geometric reference
condition. Do not silently give it that information through a progress feature or reward
input at deployment.

An optional small progress readout may use development-only supervision. Its data, label
access, training cost and parameter count must be explicit. Give the same frozen readout
to both the tuned fixed and adaptive comparators. No test frames or labels may train it.

## 4. Safety and outcome contract

The requested clearance is external to the adapter. Hold it fixed for the entire episode
and across the planned horizon. The adapter cannot lower it, introduce positive penetration
tolerance, shorten the scored episode, or change the goal definition to improve completion.

Retain each environment's 50-action episode limit and task-success rule: TwoRoom's 16 px
goal radius and Reacher's joint-angle goal condition. Keep action normalization, action
repeat and the five-action executed block explicit. Horizon adaptation changes imagined
depth, not the number of actions executed before replanning.

Check the actual proposed executable block, including an elite mean, with the same safety
predicate used for candidates. A best candidate is eligible as a fallback only if it passes.
Never execute the least-violating candidate merely because no candidate passed. A zero
command is not assumed safe for a moving torque-controlled arm: check fallback actions.
If no executable safe fallback is available, record a controller failure and unfinished
episode. Record its truncation separately; it is not a successful safe outcome.

Use these endpoints together:

- **Primary: requested-margin safe completion.** The task completes within 50 actions and
  the trajectory respects the requested inflated hazard boxes at every scored sample.
- **Benchmark safe completion:** task completion with no entry into the original hazard.
- Hazard entries, requested-margin breaches, exposure, unfinished episodes and controller
  failures, all with denominators.
- Time and actions to completion, plus failure-capped completion cost; do not average time
  only among successful episodes without also showing failures.
- Engagement: path length or joint motion, executed action magnitude, and progress over time.
- Candidate-model evaluations, predictor steps, checker integrations and wall time.

The margin predicate is the actual inflated-box predicate, not an interchangeable distance
formula near box corners. Preserve unrounded values and specify numerical comparison
tolerances separately from permitted clearance. Numerical tolerances must not become a
learned penetration allowance.

Log the legacy environment-step monitor for comparison with old results. For Reacher also
score every internal physics step of the action repeat and use that denser monitor for
new safety claims. Account for early termination inside a repeated action. Any resulting
protocol difference from task 13 is stated explicitly. These sampled simulation checks do
not establish continuous-time or real-robot safety guarantees.

## 5. Quick comparisons and adapter development

### First comparison: 216 episodes

Use six conditions, two environments, three familiar layouts, two margins and three fresh
planner seeds: `6 x 2 x 3 x 2 x 3 = 216`.

| Condition | Change | Question |
| --- | --- | --- |
| Native | Canonical planner settings, without the hazard constraint | Is the underlying task behaviour reproduced? |
| Canonical SafeCEM | Current exact-check planner and checked execution | Is the progress failure reproduced on this host? |
| Short horizon | Horizon 3 with the standard planning-work allowance | Does shorter imagination improve useful progress? |
| Candidate memory | Rechecked retained candidates and correlated exploration | Is useful candidate support being lost? |
| Larger search | Up to twice the canonical planning-work allowance | Can added search alone recover progress? |
| Geometric progress | Exact task-distance objective under the same safety check | Can the search solve the constrained task with reliable task guidance? |

Use TwoRoom margins 0 and 6 px, and Reacher margins 0 and 1.5 cm. The small seed count is
for locating mechanisms and catching implementation problems. It is not a statistical
pass/fail rule, and a negative cell does not stop the campaign.

Use TwoRoom's existing 1,000 samples/top 10 and Reacher's 300 samples/top 30 for the
canonical/native pair, with ten CEM iterations and horizon five. Thus adding the safety
constraint does not also change the sampling setup. Verify any different released default
separately during engineering and label that comparison with its actual compute.

The geometric reference is a different information condition. If it works while the visual
objective fails, that supports a task-guidance hypothesis; it does not establish a useful
LeWM adapter. If it fails too, inspect task feasibility, action scaling, initialization and
search coverage before blaming the learned representation.

Candidate memory and correlated sampling have prior art in
[iCEM](https://proceedings.mlr.press/v155/pinneri21a.html). Treat them as strong engineering
baselines, not an invention of this campaign. Constraint-aware CEM also predates this work:
[Robust CEM](https://arxiv.org/abs/2010.07968).

### Flexible development allocation: approximately 300 episodes

Use the first comparison's traces to build and revise a compact controller. An initial
implementation should switch among a few planning modes using recent goal-cost change,
observed prediction error, feasible fraction and feasible-cost spread. It can change horizon,
exploration scale and the fraction of retained candidates. Recheck retained candidates
from the new current state rather than trusting their previous feasibility.

Start with a small threshold controller, ideally fewer than 16 tunable parameters. A small
network is allowed if it simplifies implementation, with a proposed maximum of 256
controller parameters. These are complexity limits, not evidence of an advantage.

Tune a strong static comparator over the same available horizon, exploration and retention
choices, explicitly including horizon 3. A fixed setting may be selected per environment
and requested margin. The adaptive controller receives the margin too. This prevents an
artificial win against a deliberately weak fixed baseline.

The initial shared choices are horizons 2, 3 and 5, exploration scales 0.5, 1 and 2 times
the canonical variance, and retained-candidate fractions 0, 0.25 and 0.5. Preserve the
environment's canonical elite fraction initially. If development makes elite fraction a
variable, extend both fixed and adaptive choices together and record the change before
running that comparison. Include the unmodified canonical setting in fixed tuning.

If task guidance is the bottleneck, use a spare GPU to investigate a linear or small progress
readout from frozen embeddings, with at most 2,048 additional trainable parameters. Prefer
existing development trajectories and a bounded frame bank. Split its fitting and validation
data by trajectory, and check predictions on both actual and imagined embeddings. A probe
that predicts real frames well can still fail on imagined states. If this branch is used,
report controller and readout sizes separately and jointly.

Allow at least two substantive revisions when a failure is understood and time permits.
Examples include changing the stall signal, correcting retained-plan initialization, or
replacing an uninformative goal feature. Do not spend the allowance on repeatedly changing
seeds for an unchanged method. Preserve every attempt and count its interactions.

This allocation is flexible: the agent may move development work between environments and
branches using observed evidence. Every new recipe is versioned before its episodes run.
The final evaluation allocation and unseen cases are protected.

### Planning compute is part of the comparison

Use `sum(iteration_sample_count x horizon)` as one predictor-work measure and record actual
model calls too. Match the canonical per-replan predictor-work ceiling for the short-horizon,
memory, fixed and adaptive conditions. Count the mean/fallback verification and checker work.
Changing horizon must not quietly grant more model computation. The explicit larger-search
condition is reported at its higher budget and also placed on a completion-versus-cost plot.

If a change requires more computation to work, retain that result, but describe the gain
at that computation level. Do not attribute it solely to adaptation.

## 6. Two larger experiments

### Larger experiment A: 864 episodes on familiar layouts

Freeze four conditions after development: native, canonical SafeCEM, the selected strong
fixed controller, and the selected adaptive controller. Run both environments on three
familiar layouts, three margins and twelve fresh seeds:
`4 x 2 x 3 x 3 x 12 = 864`.

The proposed margins are TwoRoom 0, 4 and 6 px; Reacher 0, 1 and 1.5 cm. This covers the
working region and the observed completion cliff. Reuse no development planner seed.
The native actions do not depend on the margin; if a native rollout is reused for multiple
margin scores, record that reuse and its single interaction cost. Do not count those scores
as independent episodes. The 864 figure is the conservative workload without that reuse.

This experiment asks whether the selected implementation gives a repeatable improvement,
and whether adaptation adds value beyond the best fixed settings. Familiar layouts provide
replication, not evidence of unseen-task generalization.

### Larger experiment B: 960 episodes on fresh cases

Compare the already selected fixed and adaptive controllers on twenty new cases per
environment, two margins and six fresh seeds:
`2 x 2 x 20 x 2 x 6 = 960`.

Use TwoRoom margins 4 and 6 px; Reacher 1 and 1.5 cm. Vary start-goal pairs and gap placement,
not just planner seeds. Keep the environment family, rendering and task definition fixed.
The twenty cases per environment are generated and sealed before development outcomes are
read. They are not the old T0/R0 layouts, which have already informed this conversation.

Specify the generator before launch. Use modest perturbations around the existing task
families, keep starts and goals outside the inflated hazard, retain the original gap widths,
and reject only input-level geometric invalidity. Pin the accepted IDs and generation seed.
Do not filter cases using native or adapter success. For Reacher, geometric admissibility
does not prove a torque-feasible solution within 50 actions; retain that limitation and all
eligible cases in the denominator. Any subsequent oracle feasibility investigation is
reported separately and cannot retrospectively remove failures.

Proposed generator ranges are TwoRoom start x 150 to 180 px, y 112 to 124 px, goal x 148
to 180 px, y 165 to 181 px, and gap offsets within 12 px of the direct route. Reacher uses
shoulder sweeps from `(h, e)` to `(-h, e)`, with h between 0.6 and 0.8 rad, e between 0.85
and 0.95 rad, and gap centres between 0.182 and 0.207 m. Keep the original hazard bands.
Validate rendering and input geometry without rolling out final cases. The exact generation
seed, deduplication rule and case list belong in the pre-development manifest; do not
change these ranges in response to results on the reserved cases.

Freeze controller code, fitted weights, normalization, selection rule and both evaluation
panels before starting A or B. Do not use A's results to revise the controller before B.
The two queues may run concurrently. Final results become a basis for the next campaign,
not for further tuning on these same cases.

### Workload and throughput alternatives

| Allocation | Default episodes | Maximum executed actions at 50 per episode |
| --- | ---: | ---: |
| Engineering and instrumentation | 80 | 4,000 |
| Quick mechanism comparison | 216 | 10,800 |
| Development and revisions | 300 | 15,000 |
| Larger experiment A | 864 | 43,200 |
| Larger experiment B | 960 | 48,000 |
| Total | 2,420 | 121,000 |

The proposed campaign ceiling is 160,000 executed environment actions, leaving room for
failed starts with actions, repairs and further development. This ceiling is additional to
the dollar and time limits, not permission to spend beyond them. Exact-check simulator
integrations and renderer/model calls have separate counters and prospective work ceilings;
they are not free interactions hidden behind the 160,000 figure.

Before final evaluation, select the full schedule above or a predeclared compact schedule
based on measured runtime and remaining money, without inspecting final outcomes. The
compact schedule uses eight seeds in A (576 episodes) and ten new cases per environment in
B (480 episodes), for 1,652 total planned episodes. It retains both environments, the same
comparators and the same fixed safety requirements.

The default is the full schedule. Spare capacity should first fund repairs and the full
fresh-case panel. Do not add a new environment or optimizer tournament while an essential
comparison is unfinished.

## 7. Four-GPU execution and five-hour schedule

Prefer a single host with four 24 GB RTX 3090/4090-class GPUs, adequate per-worker CPU
capacity, at least 64 GB host RAM and approximately 200 GB usable disk. These are selection
targets; compatibility with the pinned environment and measured throughput decide the offer.
Do not require ManiGuard's historical driver or template for this different workload.

Use independent episode queues. Initially allocate two GPUs to each environment. The old
measured throughput was about 578 episodes/hour on TwoRoom and 1,232 on Reacher, each on
one RTX 3090 with its own worker configuration. Those measurements suggest that three
TwoRoom GPUs and one Reacher GPU may balance the queue better; measure before switching.
Four GPUs will not give linear speedup if CPU rollouts, rendering or storage are saturated.

Assign all methods for a case/seed block to the same physical host and GPU, with randomized
condition order. Record GPU identity and worker configuration. If a host fails, complete
replacement comparison blocks with contemporary controls on its replacement; do not join
an old-host baseline to a new-host intervention. All charges remain cumulative.

| Elapsed time after launch approval | Intended work |
| --- | --- |
| 0:00 to 0:45 | Local implementation, focused checks, manifests and rental admission |
| 0:45 to 1:15 | Remote setup, renderer/model checks, counters and throughput measurement |
| 1:15 to 2:00 | Quick mechanism comparison and immediate repairs |
| 2:00 to 3:15 | Adapter development, fixed tuning and revisions in parallel queues |
| 3:15 to 4:30 | Frozen larger comparisons A and B |
| 4:30 to 5:00 | Final sync, result checks, private preservation and verified teardown |

This is a working schedule, not five independent admission gates. Ready queues should run
while other branches are being repaired. Recalculate completion time as results arrive.
If preparation takes longer, shorten optional development first and select the compact
final schedule prospectively. Do not silently extend the five-hour target or spend the
preservation reserve to keep an exploratory branch alive.

Four GPUs are preferred when an offer fits the cumulative cap and improves predicted finish
time. Two GPUs are an allowed fallback if they fit the same end-to-end deadline and complete
the admitted schedule. If neither option is financially and operationally viable, report
the concrete shortfall before renting.

## 8. Financial admission and reserves

**Hard cumulative cap: $10.** Include all task-16 rentals, failed setup, replacement hosts,
storage, downloads, uploads and closeout. Task 15's funds are separate. Do not borrow from
another task or infer that a larger provider balance raises this cap.

A planning example for four GPUs is an aggregate compute-plus-disk rate no higher than
$1.75/hour, 4.25 billable hours, $1.25 of transfers and a $0.75 closeout reserve:
`1.75 x 4.25 + 1.25 + 0.75 = $9.4375`.
This is an admission ceiling illustration, not a current offer or a promise of availability.
Prefer a cheaper suitable host. If transfers cost more, the affordable hourly rate or rental
duration falls. Check actual offer terms and current account commitments at launch.

[Vast's pricing documentation](https://docs.vast.ai/guides/instances/pricing) states that
prices vary by offer and that compute, storage and transfers contribute to the bill. Storage
continues while a stopped instance exists. Therefore, admission and the watchdog use an
all-in estimate through verified destruction, not just a displayed GPU price.

Protect enough money and time for the selected A/B schedule using measured per-condition
throughput, plus at least $0.75 for preservation and teardown. Initially reserve $3 for A/B
and $1.25 for transfers; replace those estimates with conservative measured forecasts before
allocating more development work. Do not release final-evaluation reserves to speculative
branches without reducing the schedule prospectively and recording the reason.

Run an independent cost/deadline watchdog. Its stop decision includes accrued and estimated
unposted charges, remaining storage, transfer commitments and shutdown latency. Stop new
exploratory jobs when that reserve would be consumed. Preserve continuously so a deadline
does not leave the only copy on the rental. Verify the instance is destroyed and storage
charges are closed out after preservation.

## 9. Repair authority and scientific discipline

After approval of this campaign, the agent may autonomously fix environment setup, EGL or
renderer ownership, worker startup races, numerical errors, logging, action scaling,
checkpoint loading, scheduling and resumability within the agreed limits. It may change
development hypotheses and adapter implementations within the information contract.

Implementation checks remain necessary: reproduce the native action path, verify the exact
checker against actual execution, ensure the goal image and observation transforms match,
and verify that counters include failed and discarded work. A failed check pauses affected
results and triggers repair. Other validated queues can continue. A tiny success-count
threshold is not an engineering requirement.

Keep one immutable record per attempt. Classify invalid engineering output separately from
valid scientific failures. Count resources from both. Repaired versions use new IDs and
source hashes; never overwrite an earlier attempt or relabel its outcome.

Before each batch, freeze its code/configuration, case list, seeds, information level,
resource ceilings and analysis role. Development batches can be revised repeatedly with
new freezes. Final A/B protocols cannot be tuned after their outcomes are seen. If a real
bug invalidates a final batch, preserve it, document the scope and rerun all affected
comparators together if the cap permits. Otherwise report the unfinished validation.

New approval is needed only for a larger financial cap, a substantial extension of the
agreed time/scope, or a change to the protected scientific contract. Routine repairs and
development revisions do not need repeated permission.

## 10. Logging and accounting

Save states, executed actions, termination reasons, both safety monitors and episode costs
for every attempt. At each replan log the requested margin, chosen mode/horizon, feasible
fraction, goal-cost distribution, predicted versus observed progress, selected plan and
the proposed/filtered/executed action provenance.

On a fixed diagnostic subset, also save per-candidate scalar scores and a bounded sample
of trajectories: selected candidates, promising feasible candidates and uniformly sampled
candidates. This addresses the missing information in the old logs without saving every
large tensor for every episode. Freeze that sampling rule; do not save only successes.

Maintain distinct cumulative counters for actual environment actions, underlying executed
physics steps, counterfactual checker physics steps, analytic path evaluations, render/frame
queries, candidate rollouts, predictor steps, fitting updates and elapsed time. Include
readout data collection, sweeps, retries and abandoned configurations. Present the complete
resource vector; do not describe equal episode counts as equal simulator work.

Automate the queue, summaries and preservation. Reuse loaded models and downloaded data
where that is compatible with renderer isolation. Avoid repeated container startup and
copying the same 23.75 GB Reacher dataset to separate hosts. Use checkpoint/data hashes and
private storage; credentials remain in the ignored environment and never enter logs.

## 11. Analysis and selection rules

Use development data to choose one fixed setting per environment/margin and one adaptive
controller per environment. Prefer requested-margin safe completion, then lower failure-capped
completion cost, then lower computation. A few favourable seeds do not justify ignoring
observed margin breaches. Document why each finalist was selected before final evaluation.

For A and B, show every cell's numerator and denominator. Report paired absolute differences
between adaptive and tuned fixed control, along with the canonical and native context in A.
Use uncertainty that respects case and seed pairing. For B, resample case blocks rather than
treating six planner seeds or two margins on one case as unrelated tasks. Report environment
results separately before any explicitly defined average.

The target is a practically useful gain, provisionally at least 10 percentage points in
requested-margin safe completion on the difficult cells, without evidence that it comes
from extra allowed violations or hidden computation. That target guides interpretation,
not stopping or repeated testing until significance appears. Show uncertainty even when
the point estimate meets the target. Zero observed violations does not mean zero risk;
the rough 3/n upper bound assumes independent comparable trials and needs qualification
when episodes share cases.

Interpret the possible results explicitly:

| Result | Supported conclusion |
| --- | --- |
| Strong fixed settings recover progress; adaptation adds little | A useful planning mechanism, with no demonstrated need for a dynamic adapter |
| Adaptive control improves A and B under the matched contract | Evidence for a compact progress-preserving adapter within these environments |
| Only geometric guidance works | Evidence that task guidance is limiting; no pixel-task adapter claim yet |
| More search works only at greater cost | A measured safety/completion/computation tradeoff |
| Gains appear only on familiar layouts | Development or local replication result; transfer remains unestablished |
| Valid implementations remain unsuccessful | A documented limitation, with engineering and scientific failures separated |

These are two task families and one selected development procedure. Multiple planner seeds
do not constitute multiple independent optimizer runs. No result in this campaign alone
establishes an evolutionary optimizer advantage or a general safety theorem.

## 12. Files and completion deliverables

Use the proposed namespace `lewm16`, subject to confirming it is unused before launch:

- `configs/lewm16/`: draft-derived design, panels and stage manifests.
- `experiments/helpers/`: new reusable adapter, instrumentation and accounting helpers.
- `experiments/scripts/`: task-16 runner, worker, analysis, preservation and watchdog entry points.
- `experiments/tests/`: focused tests of action identity, checker replay, fallback validity,
  budget counters and adapter feature isolation.
- `outputs/lewm16/`: ignored attempt data, queue state and analysis artifacts.
- `progress/receipts/16-*`: authorization, admission, freezes, attempts index, final results,
  costs and preservation proof.
- `docs/research/`: the concise research interpretation and recommended next experiment.

Do not modify archived results or another agent's active task. Reuse old helpers only after
checking their assumptions; copy launch orchestration into fresh task-16 paths rather than
running old finalizers. Use the intended environment interpreter explicitly.

Completion means the admitted larger comparisons have valid outputs, or their shortfall is
stated precisely; all attempts and charges are accounted for; selected controllers and
figures are preserved; the rental is cleaned up; and a short results note explains what
changed, what was tested and what remains uncertain. Update the progress index and Odyssey
after execution is finished. This draft itself is not an experiment completion entry.

## 13. Bigger paper experiments after this campaign

The current budget already contains two larger runs. Follow-on campaigns can be larger
again once this run establishes which mechanism deserves investment. Their budgets and
launches require a separate review; none is charged to this $10 allowance.

The first candidate is a fair optimizer comparison over the successful compact adapter:
native, tuned fixed, parameter random search, ordinary learning and evolution. Give the
optimizers the same controller class, permitted inputs, training information and resource
ceilings. Charge common representation fitting and method-specific tuning. Reevaluate
competing evolutionary candidates on common batches rather than comparing stale parent
scores to fresh offspring scores. Select deployed controllers before final testing and
use independent optimizer replications. Choose a single evolutionary method suited to the
established objective rather than running several algorithms with inadequate replication.

The second candidate is transfer to Push-T or the learned-check Cube reaching case, with
checker calibration treated separately from planning progress. A third is a broader study
of completion across requested margins and planning-compute budgets. Their priority follows
the evidence, not a commitment to make evolution win.

This keeps the honours contribution clear: characterize a safety/progress failure, explain
its mechanism and test a compact remedy. The GECCO contribution then asks whether evolution
offers a useful way to discover that remedy compared with credible alternatives. The
[paper framing](paperCombination.pdf) remains the broader context connecting LeWM, UNISafe
and ManiGuard; their outcomes need not be pooled or presented as the same mechanism.

## 14. Review and launch boundary

The review should settle the four-GPU preference and $10/five-hour limits, the two-environment
scope, the full and compact workloads, the fixed-clearance rule and the repair authority.
Exact offers, source hashes, generated case IDs and measured resource ceilings are filled
in during launch preparation. They are required before their dependent jobs, not invented
in this draft.

The approved next action is implementation and financial admission, then rental.
Routine engineering repairs and development revisions remain within the recorded authority.
