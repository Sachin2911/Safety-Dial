# Task 19: an evolved near-jar speed adapter for frozen pi0.5 on Jar

Written 26 October 2026, 22:10 UTC. Status: authorized and running. Sachin set the goal
("run a campaign for an evolutionary adapter result on maniguard ... $10 and 6 hours
starting from now ... go for the low hanging fruit and simplicity"). This task has its
own namespace (`evo19`), hosts, ledger and receipts. It does not resume task 15.

## Why this adapter

Task 15's development screen is the only Jar lever that helped: slowing a native chunk
whose predicted hand speed exceeds 0.10 m/s within 0.22 m of the jar, after the lid
closes, gave 9/16 strict safe completions against native 5/16 (raw violations 2 against
6). Its confirmation never ran (both task 15 hosts disappeared). Selection among pi0.5
samples, global slowing (task 8), retry (task 3) and DSRL (tasks 6, 7, 11) did not help.

A re-analysis of the 80 task 15 stage B recordings (no new episodes) shows every strict
safe completion grasped the jar; every post-gate stall never grasped it; in most stalls
the gripper was never commanded closed while the hand hovered over the lid; tips are
fast pushes into the jar body with the gripper open. Slowing approaches converts tips
into grasps; it cannot fix lid-hovering stalls. Projection therefore stays the mechanism.

## Adapter family and genes

`experiments/helpers/evo19_check.py`: task 15's projection with one added gene. A step
that does not move the hand toward the jar counts at `retreat_weight` times its speed.
With retreat_weight = 1 it is byte-identical to task 15's projection (tested on every
recorded task 15 decision; `experiments/tests/test_evo19.py`).

| Gene | Range | Map |
| --- | --- | --- |
| u0 | [0, 1] | speed limit = exp(ln 0.03 + u0 (ln 0.30 - ln 0.03)) m/s |
| u1 | [0, 1] | near radius = 0.10 + 0.25 u1 m |
| u2 | [0, 1] | retreat weight = u2 |

The box centre (0.095 m/s, 0.225 m, 0.5) is near the task 15 hand setting.

## Search (frozen in `configs/evo19/protocol.json`)

CMA-ES (pycma 4.4.4), x0 at the centre, sigma 0.25, population 8, seed 19, one episode
per candidate on development tasks 0, 3, 6, 9 (fresh seeds 191000 + 10 g + i). Rank score
4 strict safe + 2 no raw violation + 1 grasped. No new generation after 01:00 UTC. The
deliverable is the final distribution mean, never the best observed candidate.

## Confirmation

Tasks 0, 3, 6, 9 by seeds 193000 to 193011 (48 pairs, disjoint from search seeds):
native and the frozen evolved mean. Primary: strict safe completion, evolved minus
native, one-sided Fisher exact test at alpha 0.05, Wilson intervals, task-seed pairing
reported. Native episodes may fill hosts' idle slots during the search. The task 15
hand setting (project-0.10) runs on the same pairs only if both primary arms finish.

## Money, hosts and time

Total $10; the local guard stops every task 19 host at an estimated $9.40, and each host
stops itself at 03:20 UTC. One-GPU RTX 3090 hosts on driver 580.x, one lane each
(h1, h3, h5, h6; h2 was unreachable and destroyed before any setup). No new episode
starts after 02:50 UTC. Outputs mirror to `outputs/evo19/remote/` every five minutes.
