# Project progress

Updated 27 October 2026. One row per task. Each task's evidence lives in
[receipts/](receipts/README.md) under its number prefix. The [Odyssey](theOdessy.pdf)
holds a short narrative entry per finished task, with [LaTeX source](theOdessy.tex).
Research direction and stage boundaries are in [first principles](../firstPrinciples.md).

## Consolidated writing and datasets

Start with the [four-page plain-language guide](paperCombination.pdf): what the
model, planner and adapter do, what worked, and how the three fronts fit together.
The revised [honours manuscript in ACM/GECCO format](../docs/research/honours-gecco/honoursThesis.pdf)
has [editable LaTeX](../docs/research/honours-gecco/honoursThesis.tex),
[review notes](../docs/research/honours-gecco/draft-notes.txt) and a source evidence manifest.
It distinguishes the useful fixed planning lever from the unestablished evolutionary
advantage and treats task 15's final confirmation as unverified.
The fourteen-page draft now includes the SafeCEM algorithm, full four-method dial
comparisons, action-count evidence, and an appendix with pictures and pinned video links.

The private [TwoRoom](https://huggingface.co/datasets/Sachioster/SafetyDial-TwoRoom)
and [Reacher](https://huggingface.co/datasets/Sachioster/SafetyDial-Reacher) datasets
now include all 10,180 task-16/17 attempts, 139 individual recorded-state replay
clips, six comparison videos, figures, controllers and provenance. Every uploaded
file was downloaded at its pinned revision and hash-checked; see the
[consolidation receipt](receipts/lewm-datasets-consolidation-20261026.json).
All four dataset front pages now explain the question, a suggested first video,
its labels and colours, and the findings before linking to the detailed record.
TwoRoom and Reacher also have data-reading guides and simpler campaign pages;
see the [verified documentation update](receipts/dataset-clarity-refinement-20261026.json).
Task 18 adds the corrected PushT and original Cube object-moving comparisons, speed
metrics, videos, pictures and raw attempts to their existing datasets. Start at
[the task-18 result](receipts/18-lewm-results.md).

## Open

- **Task 15, regrasp adapter with a safety dial on Jar: recovery confirmation unverified.**
  The original host left the provider during stage C (about 05:40 UTC on 26 October;
  [recovery evidence](receipts/15-regrasp-recovery-evidence-20261026.json)). Under the
  [recovery amendment](15-regrasp-recovery-amendment.md), one complete new-host cohort
  (stage A engineering, stage C and stage D) was admitted on instance 57786177
  ([rental record](rental-regrasp15r1-20261026.json)) within the same cumulative $10
  cap ([admission](receipts/15-regrasp-recovery-admission.json)). The
  [protocol](15-regrasp-dial-plan.md), [handoff prompt](goal-prompt-15-regrasp-handoff.md),
  [original rental record](rental-regrasp15-20261025.json) and
  [results record](receipts/15-regrasp-results.md) remain evidence. The consolidation
  found no verified final recovery-cohort report locally or in the inspected private
  backup; this entry does not assert a current running rental.
- **Task 7, DSRL follow-up: experiment complete, closeout records pending.** Its
  [protocol](07-dsrl-repair.md), [rental record](rental-dsrl07-20261025.json) and the
  [task 6 plan](06-dsrl-plan.md) it reused stay here until the closeout is written,
  because its frozen source manifests, preservation script and tests read them.

## Latest completed campaigns

- **Task 18, PushT and original Cube expansion: complete.**
  At the largest margins, original SafeCEM versus tuned fixed achieved 2/36 versus
  19/36 safe completions in PushT and 0/36 versus 12/36 in Cube. Feedback achieved
  20/36 and 12/36, with no established additional benefit. No checked final group
  breached its margin. Tuned fixed left 17/36 and 24/36 unfinished, with engagement
  36/36 and 35/36. Every valid result was independently rescored.
  The 1,352 valid attempts and 676 superseded PushT attempts are preserved in the
  existing private PushT and Cube datasets, with four comparison videos and all-case
  galleries. All 662 uploaded files were read back and hash-verified. Both rentals
  were independently confirmed destroyed at 22:43 UTC on 26 October. The conservative
  combined estimate is $2.90 including transfer reserves, below $5; this is not a
  posted invoice. The manuscript, framing guide and Odyssey include the results.
  See [results](receipts/18-lewm-results.md), [analysis audit](receipts/18-final-analysis-check.json),
  [repair](receipts/18-reset-repair-admission.json), [publication](receipts/18-datasets-preservation.json)
  and [closeout](receipts/18-closeout.json). The completed protocol is historical execution
  evidence and does not authorize another run.

- **Task 17, LeWM evolutionary-controller comparison: complete.**
  All 7,800 episodes, 30 optimizer runs and 1,632 final evaluations completed.
  Evolution did not establish a completion advantage over random search, REINFORCE
  or retuned fixed control. Eight of ten evolution runs selected shared preset anchors.
  All final episodes engaged, with zero observed hazard or margin breaches; failures
  were unfinished. The private archive was recovered and verified locally, and provider
  absence was externally verified at 15:15 UTC. Posted billing remains unverified.
  See [results](receipts/17-lewm-evolution-results.md),
  [audit](receipts/17-final-audit.json), [recovery](receipts/17-local-recovery.json),
  [external status](receipts/17-external-status-20261026.json), and the updated
  [combined-paper framing](paperCombination.pdf).

- **Task 16, LeWM and SafeCEM progress-preserving adaptation: complete.**
  All 864 familiar-layout and 960 fresh-case evaluation episodes completed, alongside
  216 mechanism and 312 development episodes. Tuned fixed control recovered safe progress;
  the adaptive advantage was not established. Fresh-case fixed/adaptive safe completion
  was 238/240 versus 240/240 in TwoRoom and 218/240 versus 212/240 in Reacher, with zero
  observed margin breaches in all 960 episodes. All 2,380 attempts are preserved.
  Rental destruction is verified; posted charges are $1.51, with a conservative $1.89
  all-in estimate under the $10 cap. See [results](receipts/16-lewm-results.md),
  [audit](receipts/16-final-audit.json), [selected controllers](receipts/16-final-selection.json)
  and [closeout](receipts/16-closeout.json). The [campaign plan](16-lewm-safecem-campaign-plan.md)
  and [authorization](receipts/16-lewm-authorization.json) are completed execution evidence.

## Tasks

| Task | Finding | Evidence |
| --- | --- | --- |
| 1, Jar replication | 24 safe successes and 43 counted violations in 104 episodes on machine 54514; substantial repeat variance | [Replication and noise floor](../docs/research/research_notes/Jar%20replication%20and%20noise%20floor.md) |
| 2, behavior audit | Contact and continuation distinguish many successes from failures | [Timelines](receipts/02-timelines.md), [pairs](receipts/02-pairs.md) |
| 3, retry controller | Safe success 17/96 native against 16/96 retry; no useful gain | [Results](receipts/03-results.md) |
| 4, native tracking | Safe requested completion 2/12; no general tracking deficit | [Results](receipts/04-tracking-results.md) |
| 5, execution adapter | Safe requested completion 1/12 native, 1/12 fixed, 0/12 adaptive; no useful gain | [Results](receipts/05-adapter-results.md), [executed plan v4](receipts/05-adapter-plan-v4.json) |
| 6, DSRL engineering | Numerical integration gates failed; no learning or efficacy estimate | [Result](receipts/06-dsrl-results.md), [completion](receipts/06-dsrl-completion/README.md) |
| 7, DSRL follow-up | Frozen completion screen failed: native 3/12 strict safe completions against 0/12 DSRL, both 4/12 violations | [Result](receipts/07-dsrl-results.md), [run](receipts/07-dsrl-run.md) |
| 8, execution-knob screen | Target scaling's screening gain did not replicate: 2/12 for both slow and native | [Result](receipts/08-screen-results.md), [completion](receipts/08-screen-completion/README.md) |
| 9, UNISafe mechanism and dial | Gain over random search not confirmed (54/64 against 51/64); grasp-sensing ablation confirmed (history-only lost 29.7 points); no speed/completion dial | [Result](receipts/09-unisafe-results.md), [report](../results/unisafe-follow-up-results.pdf), [completion](receipts/09-unisafe-completion/README.md) |
| 10, SafeCEM dial search | Searching the constraint interface beat the best fixed dial on the search layout, but not on the held-out layout | [Stage C2](receipts/10-safecem-C2-search.md), [preservation](receipts/10-safecem-preservation.md) |
| 11, DSRL improvement | Stopped after stage A: critic inflation reproduced, engineering episodes died in a simulator start-up race; no efficacy estimate | [Result](receipts/11-dsrl-results.md), [completion](receipts/11-dsrl-completion/README.md) |
| 12, TwoRoom planner search | Random search beat NSGA-II and the grid in 9 of 9 replicate pairs; planner horizon was the lever | [Stage C](receipts/12-tworoom-C-search.md) |
| 13, Reacher planner search | NSGA-II and random search tied; both beat the grid; gains did not carry to the held-out layout | [Stage C](receipts/13-reacher-C-search.md) |
| 14, Cube planner search | NSGA-II lost to random search; no search beat the best fixed dial on the search layout | [Stage C](receipts/14-cube-C-search.md) |
| 16, LeWM safe progress | Strong fixed settings recovered safe completion; adaptive benefit not established on 960 fresh-case episodes, all without observed margin breaches | [Results](receipts/16-lewm-results.md), [interpretation](../docs/research/research_notes/LeWM%20safe%20progress%20task%2016.md), [closeout](receipts/16-closeout.json) |
| 17, LeWM optimizer comparison | 7,800 episodes complete; evolutionary advantage unestablished, shared anchors selected in 8/10 evolution runs | [Results](receipts/17-lewm-evolution-results.md), [audit](receipts/17-final-audit.json), [recovery](receipts/17-local-recovery.json) |

| 18, PushT and original Cube | Tuned fixed improves strict-margin safe completion from 2/36 to 19/36 and 0/36 to 12/36; feedback benefit uncertain; no evolutionary search | [Results](receipts/18-lewm-results.md), [closeout](receipts/18-closeout.json) |

Each closed task's preservation receipt names its private dataset and pinned revision.
ManiGuard records use `Sachioster/maniguard-jar-replication-20261022`.
Tasks 10 and 12 to 14 also have packaged datasets
(`Sachioster/SafetyDial-PushT`, `-TwoRoom`, `-Reacher`, `-Cube`) that include their protocols.

## Panels

[panels.json](panels.json) is frozen. Development tasks are 0, 3, 6, 9, 15 and 17.
Pool tasks are for diagnostics. Held-out tasks receive no new episodes before the final
comparison. Baseline and task 2 evidence already include them, so they are not an unseen
dataset.

## Removed on 26 October 2026

Completed task protocols, handovers, agent prompts, the superseded twelve-mechanism
screen and the host rental records for closed tasks were removed. The committed ones are
in git history at `1291199`; links in receipts point there. The task 10 and 12 protocols
are inside their packaged datasets. The task 9 protocol and handover were never committed;
local copies are under `outputs/unisafe09/kept-unique/documents/`. Task 2's image sheets
are in the private dataset (see [02-preserve.md](receipts/02-preserve.md)). A historical
protocol or host record is never launch authority.
