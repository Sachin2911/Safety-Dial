Set a goal to complete the authorized task-17 LeWM evolutionary-controller campaign.

You are running ON the rental in /workspace/Safety-Dial. The laptop may be offline.
Read AGENTS.md, firstPrinciples.md, progress/17-lewm-evolution-campaign.md,
progress/17-remote-codex.md, progress/receipts/17-authorization.json and the task-17
rental record first. These contain the user's current execution authority and limits.

Implement the campaign, repair integration, freeze the new panels and optimizer
comparison, run the admitted balanced workload, analyse it honestly, preserve all
evidence privately, update progress and the Odyssey, and close the rental. A positive
evolutionary result is not required. Do not stop after writing a plan or an initial
negative pilot. Do not repeatedly ask approval for work already within scope.

The cumulative rental cap is $10 and the hard lease deadline is in
progress/rental-lewm17-20261026.json. This rental already exists: DO NOT RENT ANOTHER.
Reserve at least the last 30 minutes and $1 for closeout. Do not extend the deadline,
disable the guard or spend another task's budget. Codex usage is through the user's
login; do not provision or use a separately billed model API.

The provided infrastructure prepares the environment and preserves files. The optimizer
implementation is your remaining work. Check outputs/lewm17/environment/ready and
outputs/lewm17/control/guard-status.json before any experiment. Read setup logs if not
ready. Never run task-16 or archived launch/finalization scripts. Copy or extend reviewed
helpers into task-17 paths, preserving all historical evidence.

Keep LeWM frozen, retain every requested clearance, use no true goal geometry in the
task-side controller, and keep native/fixed/random/ordinary-learning/evolution claims
separate. Compare the same compact controller class with independent optimizer runs.
Count executed actions, counterfactual checker work, model queries and failed starts.
Equal episode counts alone are not equal simulator interaction budgets.

Use the measured timing to freeze full or compact workload before optimizer outcomes.
Repair recoverable engineering failures without changing frozen scientific outcomes.
Register every rollout/training process using the worker registration contract in the
remote guide so the guard can stop it safely. Every loop must honor outputs/lewm17/STOP.

Run experiments/scripts/preserve_lewm17.py after setup, source freezes, each finished
batch and final reporting. It uploads only to the existing private research dataset
and verifies hashes. Do not rely on a sync to the laptop. Never print or archive .env,
CONTAINER_API_KEY, authentication files or Codex session credentials.

At completion, make a final verified snapshot, write a concise completion status, and
use experiments/scripts/control_lewm17.py finish to trigger independent preservation
and self-destruction. Once the guard owns final closeout, do not write more results.
The final provider absence check must be made externally; distinguish an accepted
delete request from that later observation.
