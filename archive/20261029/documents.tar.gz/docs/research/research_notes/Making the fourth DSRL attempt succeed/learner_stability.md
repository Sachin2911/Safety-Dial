# Learner stability for DSRL-style SAC: sparse binary rewards, long horizons, few episodes, pixels

Reading conventions for the report writer. Every "Cited Findings" bullet names its source. I read the papers as full-text PDFs and the code as shallow clones of the official repositories (default branch `main`, cloned 25 Oct 2026). The arXiv version I read is given in brackets wherever numbers could change between versions. Tags: **[Demo]** means an experimental result the authors report. **[Claim]** means the authors' interpretation, hypothesis or advice. **[Theory]** means a proof or derivation. **[Code]** means a default in the official code or launch script. "Inferences" are my reasoning and carry no source of their own. **2026** marks work from 2026.

## Q0 (objective). Which concrete learner changes would have prevented failure mode (a), no learning signal, and failure mode (b), an inflating critic or a calibrated critic with an actor that does not move?

### Takeaway
Failure (a) is a data and horizon problem, and no critic or entropy setting fixes it. Every working few-episode, sparse-reward recipe I found does two things. It puts real successes into the replay buffer, typically 20–50 successful episodes sampled 50/50 with online data. It also shortens the horizon the critic must bridge, through chunked or n-step backups or through critical-phase and reverse curricula.

Failure (b) is what you would expect from three ingredients together:
- an unbounded MSE critic with a non-pessimistic target at UTD 20 and γ≈0.998 per decision. LayerNorm was already on in the DSRL π0 critic.
- a temperature that starts at 1.0 and, under Adam, can fall by only about the learning rate per update in log space.
- per-step actor and temperature updates.

The best-supported fixes are:
- a bounded critic: clip targets to the known return range, or use a sigmoid output with BCE loss, or HL-Gauss.
- a REDQ-style target that takes the min over a random pair of critics.
- UTD of about 4–5, with delayed actor updates.
- a low initial temperature (about 0.01), or a deterministic or fixed-noise actor regularised toward the native noise.
- n-step or chunked backups.

### Cited Findings
- **[Demo]** DSRL's π0 recipe (the one the failed run copied) was shown only on tasks where base π0 already succeeded. On Libero it went from ≈20% to ≈100% after ≈10,000 online samples (3 seeds). Real-world π0-DROID used 80 episodes (~11k steps) and 65 episodes (~10k steps). — [DSRL, arXiv 2506.15799 v2 §5](https://arxiv.org/abs/2506.15799)
- **[Code]/[Demo]** DSRL π0 Libero settings (Table 11) match the user's run:
  - batch 256, hidden 128×3, actor lr 1e-4, critic lr 3e-4
  - γ 0.999, target entropy −d/2, τ 0.005, 64×64 images
  - 20 gradient steps per update, action magnitude 1.0
  - chunk 50 with 20 actions executed per query
  - 10 critics, "Clipped double Q-learning: False"
  — [DSRL v2 Table 11](https://arxiv.org/abs/2506.15799); [dsrl_pi0 launch_train_sim.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/launch_train_sim.py); [run_libero.sh](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/scripts/run_libero.sh)
- **[Code]** The DSRL π0 critic already hard-codes `use_layer_norm=True` — [state_action_value.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/networks/values/state_action_value.py). Its critic update has `backup_entropy=False` by default, and the learner does not override it — [critic_updater.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/agents/pixel_sac/critic_updater.py), [pixel_sac_learner.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/agents/pixel_sac/pixel_sac_learner.py).
- **[Code]** In DSRL π0, every gradient step updates the critic, the actor and the temperature together. Updates run as a burst of `len(traj) × multi_grad_step` steps after each episode — [pixel_sac_learner.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/agents/pixel_sac/pixel_sac_learner.py), [train_utils_sim.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_utils_sim.py). Other learners update the actor and temperature less often:
  - REDQ: once per 20 critic steps — [redq_sac.py](https://github.com/watchernyu/REDQ/blob/main/redq/algos/redq_sac.py)
  - RLPD: once per G critic steps — [sac_learner.py](https://github.com/ikostrikov/rlpd/blob/main/rlpd/agents/sac/sac_learner.py)
  - SERL: critic:actor ratio 4 — [async_drq_sim.py](https://github.com/rail-berkeley/serl/blob/main/examples/async_drq_sim/async_drq_sim.py)
  - HIL-SERL: ratio 2 — [config.py](https://github.com/rail-berkeley/hil-serl/blob/main/examples/experiments/config.py)
  - WSRL: actor delay 4 — [WSRL v3 App.](https://arxiv.org/abs/2412.07762)
- **[Demo]** Few-episode real-robot successes all inject prior successes or lean on a strong base policy:
  - HIL-SERL: RL from scratch got 0% on all tasks; 20–30 demos plus corrections reached 100% in 1–2.5 h — [HIL-SERL, arXiv 2410.21845 v3](https://arxiv.org/abs/2410.21845)
  - PLD: 50 successful base-π0 trajectories per task, Cal-QL critic pre-training, 100 base-policy warm-up episodes — [PLD, arXiv 2511.00091 v1, ICLR 2026](https://arxiv.org/abs/2511.00091)
  - WSRL: 5k warm-up steps (11 min) then 7 min of RL gave 20/20 on Franka peg insertion, versus SERL 0/20 at 50 min — [WSRL v3](https://arxiv.org/abs/2412.07762)
  - ResFiT: 14%→64% after 134 rollouts (~15 min) — [ResFiT, arXiv 2509.19301 v2](https://arxiv.org/abs/2509.19301)
  - **2026** RL Token: VLA warm-up rollouts, chunked actor and critic, BC regulariser toward the VLA's action — [RL Token, arXiv 2604.23073 v2](https://arxiv.org/abs/2604.23073)
- **[Demo]** **2026** In RL Token's ablations, removing the BC regulariser (β=0) "causes the largest single drop in performance". Replacing chunks (C=10) with single-step actions "cannot reliably match the base policy performance" — [RL Token v2 §VI](https://arxiv.org/abs/2604.23073)

### Inferences
Recommended package for attempt 4. Each item names the failure it targets; the best-supported items come first.

1. **Bound the critic (b).** Turn entropy backup off (already the DSRL default). Clip every TD target to the attainable return range:
   - [0, 1] for a 0/1 terminal reward with timeout-as-terminal.
   - [−Φ_max, 1] with potential shaping, since shaped Q = Q − Φ(s).

   Or replace the MSE head with a sigmoid/BCE head (QT-Opt, Q-Transformer), or with HL-Gauss (51–101 bins over the range plus a small margin, σ = 0.75 × bin width). A mean Q of 37 cannot occur under any of these. LayerNorm alone did not stop inflation here, because the run already had it.
2. **Target reduction (b).** Keep 10 LayerNorm critics. Compute the target as the min over a random subset of 2 (REDQ M=2; used by SERL, WSRL, RFCL and ResFiT). Use the mean of all 10 for the actor. This sits between the user's two measured extremes. The expected minimum of N i.i.d. Gaussian estimates is about −0.56σ for N=2 versus about −1.54σ for N=10 (standard order statistics). That matches min-of-10 starting far too pessimistic and mean-of-10 drifting up. RLPD's pixel/sparse alternative (one random critic per target) is less pessimistic again, and only safe together with target clipping.
3. **UTD and update schedule (b).** Use UTD 4–5 at batch 256 (WSRL 4, RL Token 5, ResFiT 4, IBRL 5). Update the actor and temperature once per 2–4 critic steps. With about 6k transitions, UTD 20 drew each transition about 3,800 times on average (90k × 256 / 6k). Rybkin et al. tie this regime to overfitting and plasticity loss.
4. **Shorten the horizon (a, b).** Cut the decisions per episode from about 250 toward about 50. Either execute more of each π0 chunk per noise query (DSRL used 20 of 50 on Libero and 50 of 50 on Aloha) or hold the latent for k queries. Add n-step backups (n≈3) on top. Then pick γ so that 1/(1−γ) is about 1–2× the number of decisions; for 50–100 decisions that is 0.98–0.99 rather than 0.998. Add a time-remaining feature, or bootstrap on timeouts.
5. **Make the actor move only when the critic has something to say (b).**
   - Initial temperature 0.01 (SERL, HIL-SERL and SimbaV2 defaults), temperature lr 3e-4. Compute log-probs before any residual scaling, or shift the target entropy by d·ln(scale).
   - Add an L2 penalty toward zero residual (that is, toward the native noise), with RL Token-style reference dropout.
   - Alternatively, use a TD3-style actor with small fixed noise (RL Token, ResFiT).
   - Without signal, a low temperature alone just lets the actor exploit critic noise. That is what happened at UTD 20, where α fell to 0.002 and entropy to −15.
6. **Inject successes (a).** Before any learning, run native π0 warm-up episodes (WSRL, PLD, RL Token) and keep the successes in a separate buffer sampled 50/50 (RLPD, SERL, PLD). At about 25% native success, about 40 native episodes yield about 10 successes. PLD used 50 successful trajectories and SERL/HIL-SERL used 20–30 demos, so 12 prior episodes (about 3 expected successes) is below every cited working setup. Optionally floor TD targets on successful trajectories with their Monte Carlo return (Q-Transformer, MCAC), or pre-train the critic Cal-QL-style on them (PLD found Cal-QL beat CQL and IQL).
7. **Residual around native noise (a).** Use w = w_native + c·tanh(·) with c≈0.1–0.5 (PLD ξ=0.5 on LIBERO, 0.1 on SimplerEnv). Feed the critic the executed total noise, not the residual alone; Policy Decorator found the sum works best. This keeps early online episodes near the native success rate.
8. **Curriculum (a).** In simulation, start episodes from states taken from successful native rollouts (lid closed, object grasped). Keep start states whose success rate is between 0.1 and 0.9 (Florensa; DemoStart's zero-variance filter). Move start states backwards, then anneal to full episodes, as RFCL's forward stage does, so the final full-episode evaluation does not regress (Nair et al.).
9. **Shaping (a), weakest evidence.** Prefer continuous distance potentials over milestone-only potentials. Set Φ = 0 at every terminal, including timeouts. Make sure the clip bounds include the shaping range.

### Gaps
- I found no published DSRL or noise-space steering result that starts from about 0% base success. All DSRL π0 results start from roughly 20% or higher. Whether any learner change rescues a 0% start, without curricula or prior successes, is untested.
- The ranking of items 1–9 is my synthesis. No single paper ablates all of them together in a few-episode pixel setting.

## Q1. Critic overestimation at high UTD: which reductions do the main methods recommend instead of min-of-all or mean-of-all, and what UTD is typical for pixel-based real-robot RL?

### Takeaway
The field moved from "pessimism via min" to "regularise the network, then use mild or no pessimism". The common choices are REDQ's random 2-of-10 min, RLPD's LayerNorm critics with 2 (state) or 1 (pixels, sparse AntMaze) random critics per target, BRO/OGPO's ensemble mean with heavy regularisation, and normalisation-based critics (CrossQ, SimbaV2, OFN). No major method uses min-of-all-10 or plain mean-of-10 without strong regularisation. Real-robot pixel systems mostly run at moderate UTD: SERL and HIL-SERL are asynchronous with critic:actor ratios of 4 and 2; WSRL 4; RL Token 5; ResFiT 4. DSRL used 20–30.

### Cited Findings
- **REDQ** (ICLR 2021) — [arXiv 2101.05982 v2](https://arxiv.org/abs/2101.05982)
  - **[Demo]** Used "G = 20, N = 10, and M = 2 for all environments", with the target being the min over a random subset of M critics.
  - **[Demo]** Compared with ensemble averaging (AVG) at UTD 20, REDQ "has a very low normalized std of bias for most of training" and "a small and near-constant under-estimation bias", and learns faster.
  - **[Demo]** SAC at UTD 20 has a fluctuating, highly non-uniform bias. Random subset selection gives an extra boost.
  - **[Code]** Defaults: `utd_ratio=20, num_Q=10, num_min=2, q_target_mode='min', policy_update_delay=20` (actor updated once per 20 critic updates), α init 0.2 with automatic tuning — [redq_sac.py](https://github.com/watchernyu/REDQ/blob/main/redq/algos/redq_sac.py)
- **RLPD** (ICML 2023) — [arXiv 2302.02948 v4](https://arxiv.org/abs/2302.02948)
  - **[Code]** Table 1: online/offline batch 128/128, γ 0.99, Adam 3e-4, ensemble E=10, EMA 0.005, UTD 20 (state-based), width 256, initial α 1.0, target entropy −dim(A)/2; pixels: action repeat 2, 64×64, shift 4.
  - **[Code]** Table 2 (target subset and entropy backups):

    | Domain | Target min over 2 (CDQ) | Entropy backups |
    |---|---|---|
    | Locomotion | yes | yes |
    | AntMaze (sparse) | no, 1 random critic | no |
    | Adroit (sparse) | yes | no |
    | DMC pixels | no | no |
  - **[Code]** Pixel config: `num_qs=10, num_min_qs=1, critic_layer_norm=True, backup_entropy=False`, `init_temperature=0.1` — [rlpd_pixels_config.py](https://github.com/ikostrikov/rlpd/blob/main/configs/rlpd_pixels_config.py), [drq_config.py](https://github.com/ikostrikov/rlpd/blob/main/configs/drq_config.py). The actor uses the mean over all 10 critics — [sac_learner.py](https://github.com/ikostrikov/rlpd/blob/main/rlpd/agents/sac/sac_learner.py). The README's pixel command sets no `--utd_ratio`, so it runs at the script default of 1. State commands use 20 — [README](https://github.com/ikostrikov/rlpd/blob/main/README.md).
  - **[Demo]** "In 'AntMaze Large Diverse'... with CDQ, performance deteriorates... subsetting 1 critic is crucial". CDQ is also detrimental on Humanoid Walk Expert. A 2-member ensemble performs worse than 10 members in pixel tasks.
  - **[Demo]** Ensembling was the best critic regulariser. Dropout "does not generalize to challenging sparse reward environments". Weight decay was less performant everywhere.
- **DroQ** (ICLR 2022) — [arXiv 2110.02034 v2](https://arxiv.org/abs/2110.02034)
  - **[Code]** Table 8: 2 Q-functions with dropout 0.01 plus LayerNorm, M=2, UTD 20, batch 256, 2×256 MLP, 5,000 random starting steps. Dropout was retuned per environment in App. I (0.01 Ant, 0.1 Humanoid).
  - **[Demo]** Sample efficiency comparable to REDQ at much lower compute.
- **CrossQ** (ICLR 2024) — [arXiv 1902.05605 v4](https://arxiv.org/abs/1902.05605)
  - **[Code]** Batch Renormalization (momentum 0.99, 1e5 warm-up steps), no target networks, UTD 1, critic width 2048, Adam β1 0.5, policy delay 3, lr 1e-3, 2 critics.
  - **[Demo]** Matches or exceeds REDQ/DroQ sample efficiency at UTD 1.
  - **[Claim]** CrossQ+WN (weight normalisation) "reliably scales with increasing UTD ratios" and removes the need for resets — [arXiv 2502.07523 v2](https://arxiv.org/abs/2502.07523)
- **BRO** (NeurIPS 2024) — [arXiv 2405.16158 v3](https://arxiv.org/abs/2405.16158)
  - **[Code]** Replay ratio 10 (BRO) or 2 (BRO Fast); BroNet critic of about 5M parameters with LayerNorm after each dense layer; AdamW weight decay; full-parameter resets every 250k steps up to 1M plus at 15k and 50k; 100 quantiles; initial α 1.0; batch 128.
  - **[Demo]** Taking the ensemble mean instead of CDQ "in the presence of network regularization unlocks significant performance improvements without value overestimation".
- **Nauman et al. 2024**, over 60 agents on 14 tasks (ICML 2024) — [arXiv 2403.00514 v2](https://arxiv.org/abs/2403.00514)
  - **[Demo]** "layer normalisation is more effective in reducing overestimation than techniques specifically designed for mitigating Q-value overestimation".
  - **[Demo]** Replacing CDQ with network regularisation "leads to significant performance gains". Avoiding critic-regularisation interventions helps "especially if some other type of regularization is used (such as layer norm or full-parameter resets)".
- **SimbaV2** (ICML 2025) — [arXiv 2502.15280 v2](https://arxiv.org/abs/2502.15280)
  - **[Code]** Hyperspherical normalisation; categorical critic (101 atoms, support [−5, 5]) with reward scaling that keeps targets within [Gmin, Gmax]; UTD 2; initial temperature 1e-2.
  - **[Code]** Clipped double Q only on tasks with failure termination.
  - **[Demo]** "SimbaV2 scales smoothly even without reset, where using reset slightly degrades its performance."
- **Hussing et al.** (RLC 2024) — [arXiv 2403.05996 v3](https://arxiv.org/abs/2403.05996)
  - **[Demo]** Under high update ratios, "Overinflated Q-values are found not only on out-of-distribution but also in-distribution data".
  - **[Claim]** They link the divergence to overestimation of unseen actions "propelled by optimizer momentum".
  - **[Demo]** Unit-ball normalisation of the critic's output features (OFN) at UTD 8 matches standard resets at UTD 32 on mean and IQM. With SAC at UTD 32, values "diverge at arbitrary time-points, not only during" early training.
- **Primacy bias** (ICML 2022) — [arXiv 2205.07802 v1](https://arxiv.org/abs/2205.07802)
  - **[Code]** Reset schedules: SAC full networks every 2×10⁵ steps; DrQ the last 3 of 7 layers every 2×10⁵ steps; SPR the final layer every 2×10⁴ steps.
  - **[Demo]** Atari-100k IQM: SPR+resets 0.478 versus SPR 0.380.
- **Scaling studies**
  - **[Demo]** Overfitting rises with UTD; the best batch size falls with UTD as a power law; lower learning rates offset plasticity loss at high UTD; the best batch size and learning rate are nearly uncorrelated once UTD is fixed — [Rybkin et al., arXiv 2502.04327 v2](https://arxiv.org/abs/2502.04327)
  - **[Demo]** "TD-overfitting": smaller models do best with small batches, and "for any fixed model size, increasing the UTD ratio σ reduces the maximally admissible batch" — [Fu et al., arXiv 2508.14881 v2](https://arxiv.org/abs/2508.14881)
  - **[Demo]** MAD-TD stabilises UTD 8 without resets using only 5% model-generated data — [arXiv 2410.08896 v2](https://arxiv.org/abs/2410.08896)
- **Pixels specifically** (ICLR 2024) — [Ma et al., arXiv 2310.07418 v3](https://arxiv.org/abs/2310.07418)
  - **[Demo]** "data augmentation is essential in maintaining plasticity"; the critic's plasticity loss is the bottleneck; a high replay ratio early on is catastrophic.
  - **[Demo]** Adaptive RR starts at 0.5 and switches to 2 when the change in the critic's active-unit fraction drops below 0.001.
- **2026 work**
  - **[Claim]** **2026** Adaptive Ensemble Aggregation builds targets from the ensemble mean plus a learned multiple of pairwise disagreement. It claims REDQ-style subsets "hit an information bottleneck" and that it beats baselines on most tasks. v1 was titled "Directional Ensemble Aggregation for Actor-Critics"; v2 (6 May 2026) is retitled — [arXiv 2507.23501 v2](https://arxiv.org/abs/2507.23501)
  - **[Claim]** **2026** STAC uses a single distributional critic plus dropout as its pessimism — [arXiv 2601.00737 v1](https://arxiv.org/abs/2601.00737)
  - **[Demo]** **2026** OGPO uses a mean-over-critics target but observes Q values "fluctuating widely between over- and under-estimating returns". It reports that over-exploitation "is exacerbated in pixel-based RL" with PaliGemma (π0.5) features, and that higher UTD and pessimistic updates "anecdotally... [do not] suffice". Its fix is two-sided conservative advantages — [OGPO, arXiv 2605.03065 v4](https://arxiv.org/abs/2605.03065)
- **UTD in pixel real-robot RL**
  - **[Code]** SERL:
    - asynchronous learner, critic:actor ratio 4, batch 256, 50/50 demo/online
    - 10 critics with a random-2 min target, LayerNorm, tanh activations, 256×256
    - initial temperature 1e-2, backup off, target entropy −|A|/2, discount 0.96
    - 300 random and start steps, 20 demos
    — [launcher.py](https://github.com/rail-berkeley/serl/blob/main/serl_launcher/serl_launcher/utils/launcher.py), [drq.py](https://github.com/rail-berkeley/serl/blob/main/serl_launcher/serl_launcher/agents/continuous/drq.py), [SERL v4](https://arxiv.org/abs/2401.16013)
  - **[Code]** HIL-SERL:
    - critic:actor ratio 2, batch 256, training starts at 100 steps
    - 2 critics with a min target, LayerNorm in actor and critic
    - initial temperature 1e-2, backup off, γ 0.97
    - 10 Hz, 100-step episodes; total RL transitions were 32k (RAM insertion) and 21k (SSD assembly), the two task tables I read
    — [config.py](https://github.com/rail-berkeley/hil-serl/blob/main/examples/experiments/config.py), [launcher.py](https://github.com/rail-berkeley/hil-serl/blob/main/serl_launcher/serl_launcher/utils/launcher.py), [HIL-SERL v3 Tables 2–3](https://arxiv.org/abs/2410.21845)
  - Neither paper states a fixed UTD — see Gaps.
  - **[Code]/[Claim]** DSRL: "In general we used a UTD of at least 20"; real-world π0 used UTD 30 with 2 critics — [DSRL v2 App. B, Table 11](https://arxiv.org/abs/2506.15799)
  - **[Demo]** UTD in other few-episode systems:
    - WSRL: UTD 4 with 10 critics and a random-2 min — [WSRL v3](https://arxiv.org/abs/2412.07762)
    - **2026** RL Token: "a high update-to-data ratio of 5", 2 critics with a min, 2 critic updates per actor update — [RL Token v2](https://arxiv.org/abs/2604.23073)
    - ResFiT: "UTDs of 4 already capturing most of the benefit", with diminishing returns at 8 or more for 150–250-step tasks — [ResFiT v2](https://arxiv.org/abs/2509.19301)
    - IBRL: state-based UTD 5 with a 5-critic REDQ ensemble; UTD 10 brought no gain — [IBRL v6](https://arxiv.org/abs/2311.02198)
    - Q-chunking: UTD 5 "does not improve the sample efficiency" — [arXiv 2507.07969 v4](https://arxiv.org/abs/2507.07969)

### Inferences
- The user's grid result (mean-of-10 inflates late at UTD 20; min-of-10 is too pessimistic early) reproduces REDQ's AVG-versus-REDQ contrast. The standard compromise is a random 2-of-10 min for targets and the full mean for the actor. Nobody recommends min-over-all-10.
- BRO's and OGPO's use of the mean relies on heavy regularisation (resets, weight decay, BroNet) or, in OGPO, on extra conservative policy extraction. The user's run had neither.
- High γ amplifies any per-backup bias by roughly 1/(1−γ). That is about 625× at 0.9984 per decision, versus 100× at RLPD's γ=0.99. This plausibly explains why LayerNorm plus mean held at UTD 5 but inflated at UTD 20.
- For about 6k transitions and pixels, the evidence favours UTD 4–5 with delayed actor updates over UTD 20. If high UTD is kept, the literature pairs it with resets (BRO, SR-SAC), feature normalisation (OFN, SimbaV2) or model data (MAD-TD). None of these has been validated at a few thousand transitions.

### Gaps
- SERL and HIL-SERL run an asynchronous learner, and neither the papers nor the code fix a UTD number. The effective ratio depends on learner throughput against 10 Hz data collection. I found no reported value.
- The 2026 aggregation methods (AEA, STAC) report state-based MuJoCo/DMC benchmarks only. I found no sparse-reward or pixel evidence for them.

## Q2. Bounded or calibrated critics: classification losses, sigmoid or binary success critics, clipping targets to known return bounds, and Cal-QL-style calibration

### Takeaway
For 0/1 success rewards the return is bounded, and there is direct support for exploiting that:
- QT-Opt and Q-Transformer use sigmoid "success-probability" Q-heads.
- HER clips targets to the attainable range.
- Clipping with valid bounds provably preserves the fixed point.
- HL-Gauss cross-entropy critics beat MSE, including on robot manipulation.

Monte Carlo floors on targets (Q-Transformer, MCAC) and Cal-QL's reference-value floor speed up propagation of rare successes. In stochastic tasks, single-episode MC returns are optimistic.

### Cited Findings
- **Classification critics**
  - **[Demo]** HL-Gauss cross-entropy "outperform[s] MSE" in online and offline RL, with HL-Gauss best. Two-hot "underperforms MSE but is more stable" — [Stop Regressing, arXiv 2403.03950 v1](https://arxiv.org/abs/2403.03950)
  - **[Code]** σ/bin-width 0.75, "which distributes mass to approximately 6 locations". Bins swept over {21, 51, 101, 201}; the best σ was independent of the bin count — [Stop Regressing](https://arxiv.org/abs/2403.03950)
  - **[Demo]** On robot manipulation (Q-Transformer, 60M parameters), HL-Gauss gave "67% higher peak performance over the regression baseline, while being much more sample-efficient" — [Stop Regressing §4.3.3](https://arxiv.org/abs/2403.03950)
  - **[Claim]** Benefits are attributed to robustness to noisy targets and non-stationarity — [Stop Regressing](https://arxiv.org/abs/2403.03950). The method originates in [Imani & White 2018, arXiv 1806.04613](https://arxiv.org/abs/1806.04613).
  - **[Code]** **2026** SERNF uses an HL-Gauss categorical critic with 101 bins and cross-entropy on real-world sparse, manually annotated rewards. Other settings: 2 critics, LayerNorm, chunk length H=10, γ=0.997, 50/50 offline/online mixing, 5,000-update critic warm-up — [SERNF, arXiv 2602.09580 v4](https://arxiv.org/abs/2602.09580)
  - **[Code]** BRC uses categorical cross-entropy value learning for high-capacity multi-task critics — [arXiv 2505.23150 v1](https://arxiv.org/abs/2505.23150)
- **Sigmoid and binary success critics**
  - **[Code]** QT-Opt: reward is 1 at episode end on success and 0 otherwise, with a −0.05 step penalty and a 20-step limit. Its off-policy ablations state γ 0.9 — [QT-Opt, arXiv 1806.10293 v3](https://arxiv.org/abs/1806.10293)
  - **[Demo]** QT-Opt: "We use the cross-entropy function... since total returns are bounded in [0, 1], which we found to be more stable than the standard squared difference". The appendix ablation repeats this.
  - **[Code]** Q-Transformer applies "a sigmoid... interpreting the resulting output... as Q-values... suitable for tasks with sparse per-episode rewards R ∈ [0, 1], since the Q-values may be interpreted as probabilities of task success". Its TD loss is MSE — [Q-Transformer, arXiv 2309.10150 v2](https://arxiv.org/abs/2309.10150)
- **Clipping to known bounds**
  - **[Code]** HER: "we clip the targets used to train the critic to the range of possible values, i.e. [−1/(1−γ), 0]" — [HER, arXiv 1707.01495 v3](https://arxiv.org/abs/1707.01495)
  - **[Theory]/[Demo]** The clipped Bellman operator max(min(BQ, U), L), with valid bounds L ≤ Q* ≤ U, converges to the same Q*. Clipping during training "constrains the Q-values to a tight range much faster than without clipping" in tabular and function-approximation experiments — [Adamczyk et al., RLC 2024, arXiv 2406.18033 v1, Prop. 1](https://arxiv.org/abs/2406.18033)
  - **[Code]** SimbaV2 bounds target returns to [Gmin, Gmax] — [arXiv 2502.15280 v2](https://arxiv.org/abs/2502.15280)
- **Calibration against Monte Carlo returns**
  - **[Code]** Cal-QL calls a Q-function calibrated when E_π[Q] ≥ V^μ for a reference policy μ. It changes CQL's regulariser to max(Q, V^μ) and estimates V^μ by "simply utilizing the return-to-go estimates for tasks that end in a terminal" (a "one-line" change) — [Cal-QL, arXiv 2303.05479 v4](https://arxiv.org/abs/2303.05479)
  - **[Demo]** At high UTD, Cal-QL "also leads these overfitting challenges" and is combined with RLPD's LayerNorm and ensembles — [Cal-QL §7.2](https://arxiv.org/abs/2303.05479)
  - **[Code]** MCAC ("parameter free") initialises replay with demonstrations (e.g., 20) and uses target = max(TD target, MC reward-to-go) — [MCAC, arXiv 2210.07432 v2](https://arxiv.org/abs/2210.07432)
  - **[Theory/Claim]** Q-Transformer uses max(MC, Q), arguing that MC return-to-go lower-bounds Q*, so the fixed point is unchanged. It hypothesises the speed-up comes from giving "useful gradients to Q(s1, a1) at the start of training before the Q-values have propagated" — [Q-Transformer §4.3](https://arxiv.org/abs/2309.10150)
  - **[Demo]** "Removing MC returns or conservatism completely collapse[s] performance" — [Q-Transformer Fig. 6](https://arxiv.org/abs/2309.10150)
  - **[Demo]** **2026** Plotting min, mean and max Q against Monte Carlo returns showed OGPO swinging between over- and under-estimation, while OGPO with conservative advantages converged near y=x — [OGPO v4 Fig. 7](https://arxiv.org/abs/2605.03065)
- **Architectural bounding**
  - **[Theory/Demo]** RLPD argues "LayerNorm bounds the extrapolation" of Q-values beyond the data — [RLPD §4.2](https://arxiv.org/abs/2302.02948)
  - **[Demo]** OFN projects critic features onto the unit ball — [Hussing et al.](https://arxiv.org/abs/2403.05996)

### Inferences
- In the user's setup, entropy backup was off, rewards are 0/1 plus shaping bounded by about 1.25, and timeouts are terminal. Every legitimate Q-value is then inside roughly [−Φ_max, 1]. Hard target clipping is a valid operator (Adamczyk Prop. 1) and would have made Q=37 impossible. It is the cheapest single change against inflation.
- A sigmoid head with BCE (QT-Opt) suits an unshaped 0/1 reward. With potential shaping (shaped Q = Q − Φ(s)), either shift and scale the sigmoid to [−Φ_max, 1] or use HL-Gauss over that support.
- MC floors are lower bounds only in expectation. With noisy outcomes (native success about 25%), max(TD, single-episode MC) is optimistic on lucky successes. A safer option is a fitted V^μ or a per-state average, as Cal-QL does.
- Bounding cannot create signal. A bounded critic under 0/24 successes stays near 0 everywhere, which leads to failure (b)'s second form: a calibrated critic and a stuck actor.

### Gaps
- I found no study of sigmoid/BCE or HL-Gauss critics specifically in actor-critic noise-space steering (DSRL-style). The robot evidence comes from QT-Opt and Q-Transformer (Q-learning with discrete or CEM action selection) and from SERNF (2026; flow actor).
- I found no direct ablation of hard target clipping in high-UTD SAC on manipulation. HER uses it as a default without an ablation; Adamczyk's experiments are not manipulation.

## Q3. Horizon and credit assignment: n-step returns, Q-chunking and action-chunked critics, temporal abstraction, and discount choices for about 250 decisions

### Takeaway
Evidence consistently shows that long decision horizons are a primary failure cause for sparse-reward TD learning. One-step TD accumulates bias over the horizon. Single-step policies fail where chunked ones work, and Q-learning degrades as the time step shrinks. Chunked critics (h≈5–10), n-step returns (n≈3–5) and fewer decisions per episode are the supported fixes. Very long chunks hurt.

### Cited Findings
- **Q-chunking** (Li, Zhou, Levine) — [arXiv 2507.07969 v4, 11 May 2026; I read v4 only](https://arxiv.org/abs/2507.07969); [code](https://github.com/ColinQiyangLi/qc)
  - **[Theory/Claim]** A critic over action chunks gives "unbiased n-step backups (where n matches the length of the chunk)".
  - **[Demo]** Chunk length h=5 by default; h up to 10 helps on cube-triple; h=25 learns faster early but ends lower; "h = 50 fails to achieve any success". 10 critics improve QC and BFN; UTD 5 brought no gain.
  - **[Demo]** On 25 OGBench sparse tasks (offline→online) QC reached 52→86, versus BFN-n 25→50, FQL-n 27→57 and RLPD from scratch 67.
  - **[Code]** Batch 256, γ 0.99, lr 3e-4, τ 5e-3, K=2 critics (10 for RLPD-based variants), UTD 1, width 512 × 4 layers.
- **[Demo]** **2026** RL Token, a VLA with an off-policy actor-critic:
  - It uses chunk C=10 at 50 Hz.
  - Single-step actions "dramatically [increase] the effective horizon... the value function needs to perform credit assignment over a much longer horizon"; the single-step variant "cannot reliably match the base policy performance".
  - The single-step baselines HIL-SERL and PLD "fail to learn effectively" on a task "which spans hundreds of steps with a sparse reward".

  — [RL Token v2](https://arxiv.org/abs/2604.23073)
- **[Demo]** ResFiT reports "the importance of using an n-step larger than 1 for tasks where rewards are sparse... a too large value can affect performance" (n ∈ {1, 3, 5, 9}, horizons of 150–250 steps at 20 Hz). "All of the approaches without action-chunking fail in this sparse" setting — [ResFiT v2](https://arxiv.org/abs/2509.19301)
- **Horizon Reduction** — [Park et al., arXiv 2506.04168 v3](https://arxiv.org/abs/2506.04168)
  - **[Demo]** One-step TD "suffers bias accumulation", with Q errors growing with distance from the episode end.
  - **[Demo]** "increasing the model size or decreasing LR or TUR provides limited or no improvement", whereas "64-step DQN achieves significantly better performance and Q errors".
- **[Demo]/[Theory]** DQN and DDPG "collapse with small time steps", and "Q-learning does not exist in continuous time" — [Tallec et al., ICML 2019, arXiv 1901.09732 v2](https://arxiv.org/abs/1901.09732)
- **[Demo]** Uncorrected n-step returns are "uniquely beneficial" among replay design choices — [Fedus et al., ICML 2020, arXiv 2007.06700](https://arxiv.org/abs/2007.06700)
- **[Demo]/[Claim]** DrQ-v2 adopts 3-step returns (3 and 5 both beat 1-step). It notes that SAC's soft targets make n-step awkward because they need per-step entropies — [DrQ-v2, arXiv 2107.09645 v1](https://arxiv.org/abs/2107.09645)
- **[Demo]** Q-Transformer's n-step variant "reaches similar performance... with 4 times fewer steps" and helps longer-horizon tasks — [Q-Transformer](https://arxiv.org/abs/2309.10150)
- **[Demo]** CQN-AS's critic over action sequences (default length 4) beats baselines on sparse-reward BiGym and RLBench. Longer sequences help until performance "plateaus or decreases" — [CQN-AS, arXiv 2411.12155 v6](https://arxiv.org/abs/2411.12155)
- **[Demo]** DSRL π0 holds one latent noise across the chunk: "we simply sample w_single ∼ π_single and repeat it across the action chunk axis... this makes SAC training more efficient and stable". It executed 20 of 50 actions per query (Libero), 50 (Aloha) and 10 (real robot) — [DSRL v2 App. C](https://arxiv.org/abs/2506.15799)
- **Discounts used in sparse manipulation**
  - **[Code]** QT-Opt γ 0.9 (stated for its off-policy ablations) with at most 20 steps — [QT-Opt](https://arxiv.org/abs/1806.10293)
  - **[Code]** HIL-SERL γ 0.97 with 100-step episodes — [HIL-SERL](https://arxiv.org/abs/2410.21845)
  - **[Code]** SERL default 0.96 — [launcher.py](https://github.com/rail-berkeley/serl/blob/main/serl_launcher/serl_launcher/utils/launcher.py)
  - **[Code]** RFCL γ 0.9 with 100-step episodes — [base_sac_ms2_sample_efficient.yml](https://github.com/StoneT2000/rfcl/blob/main/configs/ms2/base_sac_ms2_sample_efficient.yml)
  - **[Code]** RLPD 0.99; DSRL π0 0.999 (sim) and 0.99 (real); DSRL WidowX 0.97 — [DSRL](https://arxiv.org/abs/2506.15799)
  - **[Code]** **2026** SERNF 0.997 — [SERNF](https://arxiv.org/abs/2602.09580); reverse curriculum generation 0.998 — [Florensa et al.](https://arxiv.org/abs/1707.05300)
- **[Theory/Demo]** On time limits, Pardo et al. distinguish two cases. If the objective is performance within the fixed period, "a notion of the remaining time should be included as part of the agent's input". If time limits are only a training device, bootstrap at the end of partial episodes. Otherwise "state aliasing and invalidation of experience replay" follow — [Pardo et al., ICML 2018, arXiv 1712.00378 v4](https://arxiv.org/abs/1712.00378)

### Inferences
- At γ=0.9984 per decision, 1/(1−γ)≈625, and a terminal success after 250 decisions is worth 0.9984^250≈0.67 at the start. One-step TD must chain about 250 bootstraps; per Park et al., bias accumulates along that chain.
- Cutting decisions to about 50 (execute more of each π0 chunk per noise query, or hold w for k queries) shortens the bootstrap chain about 5×. Adding n=3 shortens it about 15×.
- Q-chunking caps the useful chunk at about 10. RL Token and ResFiT show chunk-free single-step learners fail at hundreds of steps. DSRL itself executed 20–50 low-level actions per noise query.
- The user treats timeout as terminal with no time feature. That aliases states with different remaining time (Pardo). A normalised time-remaining input is the cheap fix if the objective is "succeed within T". Otherwise, bootstrap at timeouts.
- γ for about 50–100 decisions: practitioners with 20–100-step sparse tasks use 0.9–0.99. Choosing γ so that 1/(1−γ) is about 1–2× the decision count balances signal reach against bias amplification. This is a heuristic, not a tested rule.

### Gaps
- I found no controlled study varying decision-horizon length specifically for SAC with sparse terminal rewards in manipulation. The evidence comes from chunk-length ablations (Q-chunking, CQN-AS), single-step versus chunk comparisons (RL Token, ResFiT), offline TD (Park) and time-discretisation theory (Tallec).
- Holding the latent noise across multiple π0 queries is untested beyond holding it within one chunk (DSRL). I found no direct evidence for the multi-query case.

## Q4. Prior and success data: RLPD, WSRL, Cal-QL, IBRL, demo replay; how much success data and what replay ratios; base-policy data labelled with a zero residual versus demonstrations

### Takeaway
A 50/50 offline/online batch (symmetric sampling) is the default and is robust. Working few-episode systems used 20–50 successful episodes; RLPD works with as few as 22 expert trajectories.

Base-policy data is a well-established substitute for demonstrations when the critic sees the executed action:
- WSRL and PLD warm up with base-policy rollouts.
- PLD keeps only base-policy successes.
- ResFiT adds small noise to base actions during warm-up.

If the critic sees only the residual, labelling all prior data "zero residual" removes action contrast. No paper endorses that design.

### Cited Findings
- **RLPD** — [RLPD v4 §4.1, §5](https://arxiv.org/abs/2302.02948)
  - **[Demo]** Symmetric sampling (50% replay / 50% prior) improves sample efficiency, "reduces variance across seeds, and does not work by simply increasing the reward density in a batch".
  - **[Demo]** "Sampling 25% offline can marginally help asymptotic performance in walker2d-medium... [but] comes at the expense of variance and sample efficiency in sparse reward tasks".
  - **[Demo]** With only 22 of 500 Adroit trajectories (expert-only, sparse), "RLPD still exceeds prior work"; removing LayerNorm "results in collapsed performance, with no progress made on any task".
- **WSRL** — [WSRL v3](https://arxiv.org/abs/2412.07762)
  - **[Demo]** No offline data is retained. A 5,000-step warm-up of pre-trained-policy rollouts "recalibrate[s]" the offline Q-function; without warm-up, fine-tuning is slower (warm-up ablated at 1k, 5k and 20k).
  - **[Code]** SAC with 10 Q-functions and a random-2 min, UTD 4, actor delay 4, batch 256, actor lr 1e-4, critic lr 3e-4, temperature lr 1e-4 — [WSRL v3](https://arxiv.org/abs/2412.07762). The SAC config sets target entropy 0, backup off and initial temperature 1.0 — [sac_config.py](https://github.com/zhouzypaul/wsrl/blob/main/experiments/configs/sac_config.py)
  - **[Demo]** On a real Franka peg insertion: 20/20 at 18 min, versus SERL 0/20 at 50 min and the offline Cal-QL policy at 13/20.
- **Cal-QL** — [Cal-QL v4 App. C.2](https://arxiv.org/abs/2303.05479)
  - **[Code]** Fine-tuning mixes offline and online data at a mixing ratio m (for example, 0.25 means 25% offline) and ablates m.
- **IBRL** — [IBRL v6](https://arxiv.org/abs/2311.02198)
  - **[Demo]** The imitation policy proposes actions for both exploration and target bootstrapping.
  - **[Demo]** Real robot, 10–30 demos and 8K–30K steps:

    | Task | IBRL | RLPD | RFT |
    |---|---|---|---|
    | Lift | 100% | 95% | 90% |
    | Drawer, early stop at 10K steps | 100% | 0% | 15% |
    | Hang, 30K steps | 85% | 15% | 35% |
  - **[Code]** Actor dropout 0.5; IBRL and RLPD share a TD3 backbone.
- **PLD** (ICLR 2026) — [PLD v1](https://arxiv.org/abs/2511.00091)
  - **[Code]** The offline buffer is filled with "successful rollouts... from the base policy" (50 successful π0 trajectories per task, called "self-bootstrap data"). Offline and online data are replayed symmetrically, after a 100-episode warm-up "using solely π_b".
  - **[Code]** The residual is scaled to [−ξ, ξ] with ξ=0.5 on LIBERO and 0.1 on SimplerEnv. Other settings: 2 critics with min and LayerNorm, initial temperature 1.0, target entropy −dim/2, critic:actor ratio 2, γ 0.99.
  - **[Demo]** "performance using the Cal-QL pre-trained critic is consistently better and is robust to the conservative coefficients α"; "CQL demonstrates the worst performance with a severe forgetting issue".
  - **[Demo]** ξ too large "can degrade early performance"; too small gives "insufficient exploration and lower asymptotic performance". The final LIBERO success rate was 99%.
- **ResFiT** — [ResFiT v2](https://arxiv.org/abs/2509.19301)
  - **[Code]** Warm-up actions are the base action plus uniform noise ε ~ U(−noise_scale, noise_scale), so the warm-up data is not labelled with a zero residual. Training uses 50/50 demo/online batches, REDQ-style random-subset min, LayerNorm and TD3-style delayed actor updates every 2–8 critic steps.
  - **[Demo]** Real robot: 14%→64% after 134 rollouts; 23%→64% after 343 episodes.
- **Policy Decorator** — [Policy Decorator, arXiv 2412.13630 v1](https://arxiv.org/abs/2412.13630)
  - **[Demo]** For the critic input, "using the sum of both [base and residual actions]" beat concatenation or the residual alone.
  - **[Demo]** Bounded residual α: "too small... final performance may be adversely affected... too large... poor sample efficiency" (good range 0.1–0.5 on PushChair, 0.03–0.1 on StackCube).
  - **[Demo]** Progressive exploration schedule H: "a too-small H can lead to complete failure".
  - **[Demo]** Budgets were large (H from 100K to 3M steps).
- **[Code]** **2026** RL Token pre-fills replay "by rolling out the VLA reference policy for N_warm environment steps". It stores both the executed and the reference chunk, conditions the actor on the reference with 50% reference dropout, and regularises with β‖a−ã‖² — [RL Token v2](https://arxiv.org/abs/2604.23073)
- **[Demo]** **2026** OGPO+ adds behaviour cloning on a success-only buffer, which "biases policy improvement toward replicating only the actions that led to success" — [OGPO v4 §4.2](https://arxiv.org/abs/2605.03065)
- **[Demo]** SERL used 20 demonstrations with 50/50 sampling ("5x fewer demonstrations than BC") — [SERL](https://arxiv.org/abs/2401.16013). HIL-SERL used 20–30 demos; "increased the number of demonstrations... from the usual 20 to 200... without any online corrections... complete failure (0% success) on... car dashboard assembly" — [HIL-SERL](https://arxiv.org/abs/2410.21845)
- **[Theory/Demo]** Theory supporting hybrid offline+online sampling — [Hybrid RL, Song et al., arXiv 2210.06718 v3](https://arxiv.org/abs/2210.06718)

### Inferences
- **Zero-residual labelling.** What matters is the action the critic is conditioned on.
  - Suppose the critic sees the executed total noise w = w_native + c·r, as in Policy Decorator (sum), PLD (ā = a_b + a_δ) or ResFiT. Native episodes are then labelled by their actual random w ~ N(0, I), which gives rich action coverage. This is the setup the literature validates.
  - Suppose instead the critic sees only r. Then every prior transition sits at r=0. The critic learns only "value under native noise" at a single action and must extrapolate its action-slope, which LayerNorm bounds but does not inform. Native noise also becomes unobserved environment randomness that inflates target variance.
  - Recommendation: give the critic the total noise (optionally w_native too), and condition the actor on w_native (RL Token-style reference input with dropout).
- **Amount of data.** The evidence clusters at 20–50 successful episodes (SERL 20, HIL-SERL 20–30, PLD 50, IBRL 10–30, RLPD 22). The planned 12 native prior episodes at about 25% success give about 3 successes, below every cited setup. Within a 60–120 episode budget, roughly 30–40 native warm-up episodes (about 8–10 successes), kept as a success buffer, is the closest feasible match. It is still at the low end.
- **Replay ratio.** 50/50 between the online buffer and the prior or success buffer, per RLPD, SERL and PLD. Per RLPD, do not drop to 25% in sparse tasks.

### Gaps
- No paper tests "base-policy data labelled with zero residual and a residual-only critic". Its failure mode is my inference.
- No paper isolates the minimum number of successful base-policy episodes for VLA steering. PLD uses 50 without an ablation that I found.

## Q5. Entropy and exploration: how initial temperature, target entropy and learning rates affect commitment; settings in SERL, HIL-SERL and DSRL-like setups; fixes for an actor stuck near maximum entropy

### Takeaway
Real-robot pixel stacks (SERL, HIL-SERL, SimbaV2) start the temperature at 0.01, not 1.0, and switch entropy backup off. Several few-episode VLA or residual systems drop learned entropy entirely and use a deterministic or fixed-noise actor (RL Token, ResFiT). RL Token adds a regulariser toward the base action; ResFiT relies on the residual structure alone. With log-temperature under Adam, α can fall by only about the learning rate per update. Starting at 1.0 therefore costs about 15k updates before α≈0.01. A 0.25-scaled residual also makes the default target entropy (−d/2) unreachable if log-probs include the scale.

### Cited Findings
- **[Claim/Code]** SAC's automatic temperature matches an "entropy target in expectation"; the default target is −dim(A) — [SAC v2, arXiv 1812.05905 v2](https://arxiv.org/abs/1812.05905)
- **[Code]** Initial temperatures and target entropies in other pipelines:
  - DrQ: initial temperature 0.1, target −|A| — [DrQ, arXiv 2004.13649 v4](https://arxiv.org/abs/2004.13649)
  - RLPD state: 1.0 and −dim/2 — [RLPD Table 1](https://arxiv.org/abs/2302.02948)
  - RLPD pixels: 0.1 — [drq_config.py](https://github.com/ikostrikov/rlpd/blob/main/configs/drq_config.py)
  - SERL: `temperature_init=1e-2`, target −|A|/2, backup off — [launcher.py](https://github.com/rail-berkeley/serl/blob/main/serl_launcher/serl_launcher/utils/launcher.py), [drq.py](https://github.com/rail-berkeley/serl/blob/main/serl_launcher/serl_launcher/agents/continuous/drq.py)
  - HIL-SERL: `temperature_init=1e-2`, backup off, tanh-squashed Gaussian with std in [1e-5, 5] — [launcher.py](https://github.com/rail-berkeley/hil-serl/blob/main/serl_launcher/serl_launcher/utils/launcher.py)
  - SimbaV2: initial temperature 1e-2 — [arXiv 2502.15280 v2](https://arxiv.org/abs/2502.15280)
  - BRO: 1.0 with temperature lr 3e-4 — [arXiv 2405.16158 v3](https://arxiv.org/abs/2405.16158)
  - WSRL: target 0, initial 1.0, temperature lr 1e-4 — [sac_config.py](https://github.com/zhouzypaul/wsrl/blob/main/experiments/configs/sac_config.py)
  - RFCL: initial 1.0, backup off — [config](https://github.com/StoneT2000/rfcl/blob/main/configs/ms2/base_sac_ms2_sample_efficient.yml)
  - PLD: initial 1.0, target −dim/2 — [PLD](https://arxiv.org/abs/2511.00091)
- **[Code]** DSRL target entropy is 0 for its online Robomimic and Gym experiments (Table 3) and the real-world π0, and −d/2 for Libero and Aloha. The learner default is initial temperature 1.0 with temperature lr 3e-4, and the actor lr is 1e-4 for π0 — [DSRL v2 Tables 3, 11](https://arxiv.org/abs/2506.15799); [pixel_sac_learner.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/agents/pixel_sac/pixel_sac_learner.py)
- **[Code]** DSRL parameterises temperature as `exp(log_temp)` with loss `temperature * (entropy − target)` under Adam — [temperature.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/agents/pixel_sac/temperature.py), [temperature_updater.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/agents/pixel_sac/temperature_updater.py). Adam's steps are "approximately bounded by the stepsize setting α" — [Adam, arXiv 1412.6980 v9 §2.1](https://arxiv.org/abs/1412.6980)
- **[Demo]/[Claim]** DrQ-v2 found that "the automatic entropy adjustment strategy... is inadequate and in some cases leads to a premature entropy collapse". It switched to DDPG with fixed σ=0.2 or a linear schedule of σ from 1.0 to 0.1 over 500k frames — [DrQ-v2](https://arxiv.org/abs/2107.09645)
- **[Code/Demo]** **2026** RL Token uses "a Gaussian policy with a small fixed standard deviation", TD3-style targets, and a BC regulariser β‖a−ã‖² toward the VLA reference with 50% reference dropout. Removing the regulariser was the largest single drop. Without the reference pass-through, learning was slower and showed "early exploration drift" — [RL Token v2](https://arxiv.org/abs/2604.23073)
- **[Code]** ResFiT uses TD3, a deterministic actor with target-policy smoothing — [ResFiT](https://arxiv.org/abs/2509.19301)
- **[Demo]** Nair et al. apply a Q-filtered behaviour-cloning loss only where Q(s, a_demo) > Q(s, π(s)) — [arXiv 1709.10089 v2](https://arxiv.org/abs/1709.10089)
- **[Demo]** **2026** OGPO+ adds success-buffer BC — [OGPO v4](https://arxiv.org/abs/2605.03065)

### Inferences
- **Temperature arithmetic.** log α moves by at most about the learning rate per update. That matches the measured 2.5e-4 per update at lr 3e-4. Going from α=1.0 to 0.01 takes at least ln(100)/3e-4 ≈ 15.4k updates. At UTD 5 that is about 12 episodes of 250 decisions; at UTD 20, about 3. Because DSRL updates temperature every gradient step, UTD 20 also means 20 temperature steps per decision. That explains why α reached 0.002 and entropy −15 in the first run, while UTD 5 barely moved in 7.5k updates.
- **Maximum entropy is not native.** For a tanh-squashed 32-dimensional action on [−1, 1], the maximum entropy is the uniform box: 32·ln 2 ≈ 22.18 nats, matching the "22.2 maximum". So a near-max-entropy noise actor plays uniform noise with std about 0.58, not π0's native N(0, I). The early online episodes therefore did not reproduce native π0 behaviour. A residual around native noise avoids this.
- **The 0.25 residual and the target entropy.** Uniform on [−0.25, 0.25]^32 has entropy 32·ln(0.5) ≈ −22.2 nats. If log-probs include the 0.25 scale, as with DSRL's `action_magnitude` bounds, the auto target −d/2 = −16 is above the attainable maximum. α would then grow without bound and pin the residual at maximum entropy. Fix it by computing entropy on the unscaled tanh output, or by setting H_target = H_target(unscaled) + d·ln(c). This needs checking against the implementation.
- **Recommended settings.**
  - Initial α 0.01, temperature lr 3e-4.
  - Actor and temperature updated once per 2–4 critic steps.
  - Target entropy defined on the unscaled residual (−d/2 or 0).
  - An L2 penalty toward zero residual (β decayed as success data accumulates).

  Alternatively, use a TD3-style actor with a fixed small σ, per RL Token. Lowering α without the regulariser only helps once the critic carries real action-dependent signal.

### Gaps
- I found no paper that sweeps initial temperature or temperature lr in a sparse-reward few-episode setting. The 0.01 choice in SERL, HIL-SERL and SimbaV2 is a default, not an ablated result.
- DSRL's paper gives target entropy but not initial temperature for π0; the 1.0 comes from the code default.

## Q6. Resets and curricula: reverse curricula from demonstration or replay states, Jump-Start RL, and training from intermediate simulator states; reported gains and pitfalls when final evaluation uses full episodes

### Takeaway
Starting episodes from intermediate states taken from successful trajectories is the most reliable known way to create learning signal when full episodes almost never succeed. RFCL solves ManiSkill2 tasks from 1–5 demos where RLPD fails, and JSRL learns with 20 demos where baselines need 100× more. The main pitfall is regression on the true start distribution: Nair's demo-state resets converged to a worse final success rate. Without a forward stage, as in RFCL, or a hand-over schedule, as in JSRL and RL Token, the policy can be good only from late states.

### Cited Findings
- **Reverse curriculum generation** — [Florensa et al., CoRL 2017, arXiv 1707.05300 v3](https://arxiv.org/abs/1707.05300)
  - **[Code]** It assumes the agent can be reset to any state. It trains on "good starts" whose success probability lies in (Rmin, Rmax) = (0.1, 0.9), with γ=0.998.
- **RFCL** (ICLR 2024) — [RFCL, arXiv 2405.03379 v1](https://arxiv.org/abs/2405.03379)
  - **[Demo]** A per-demonstration reverse curriculum from state resets, then a forward curriculum over the true initial states. "RFCL is the only method that can solve every main task from just 5 demonstrations or less".
  - **[Demo]** It solves PegInsertionSide "from just a few demonstrations whereas the strongest baseline [RLPD] fails completely and can only solve PickCube when given 20× the demonstrations".
  - **[Demo]** Steps (×10⁴) to about 100% success from the initial states of 5 demos: per-demo curriculum with dynamic time limit 24.1±5.9; per-demo without it 33.5; global 41.5; uniform demo-state resets (Nair-style) more than 100.
  - **[Demo]** The forward curriculum matters most with very few demos (PickCube with 1 demo, StackCube with ≤5, PegInsertionSide with ≤10).
  - **[Code]** SAC with 10 critics and a random-2 min, LayerNorm critic, γ 0.9, 80 gradient steps per 8 parallel env steps (UTD 10), actor updated every 20 critic steps, initial temperature 1.0, backup off, 100-step episodes, reverse step size 4, per-demo buffer 3, dynamic time limit of 3× the demo horizon — [config](https://github.com/StoneT2000/rfcl/blob/main/configs/ms2/base_sac_ms2_sample_efficient.yml)
- **Jump-Start RL** — [JSRL, ICML 2023, arXiv 2204.02372 v2](https://arxiv.org/abs/2204.02372)
  - **[Theory]** The guide policy rolls in for h steps and h shrinks once performance exceeds a threshold β. It proves polynomial rather than exponential-in-horizon sample complexity for non-optimistic exploration.
  - **[Demo]** Gains are concentrated in the low-data regime:
    - antmaze-umaze-diverse with 10k offline transitions: 72.6 versus 33.1 for IQL.
    - antmaze-medium-play with 100k: 86.7 versus 32.8.
    - door-binary with 100k: 28.5, below IQL's 50.2.
    - Instance Grasping: QT-Opt+JSRL "is able to learn in the smallest-data regime of just 20 demonstrations, 100x less than the standard 2,000".
- **[Demo]** Nair et al. found that resets to demonstration states mean the method "initially learns faster but converges to a worse success rate" (3-block stacking, sparse) — [Nair et al., arXiv 1709.10089 v2](https://arxiv.org/abs/1709.10089)
- **DemoStart** — [DemoStart, arXiv 2409.06613 v2](https://arxiv.org/abs/2409.06613)
  - **[Code]** An auto-curriculum from about 20 simulated demos. Zero-Variance Filtering trains only on task parameters "for which the current policy sometimes succeeds and sometimes fails".
  - **[Demo]** It "requires 100 times fewer demonstrations" than imitation, with more than 98% success in simulation and 97%, 64% and 97% on real transfers.
- **[Demo]** **2026** RL Token first trains RL "in the critical-phase setting only", then advances to the full task with the base model running the non-critical phase. "This two-phase training strategy improves training efficiency while ensuring the RL policy is robust to the initial distributions induced by the base policy" — [RL Token v2 App.](https://arxiv.org/abs/2604.23073)
- **[Code]** PLD's "hybrid rollout" lets the base policy run first and then hands over to the residual (compared with JSRL in its appendix) — [PLD](https://arxiv.org/abs/2511.00091)

### Inferences
- In simulation, the user can reset to states from successful native rollouts, such as lid closed or jar grasped. Filtering start states to success rates in [0.1, 0.9] (Florensa, DemoStart) turns 0/24 into a dense stream of informative 0/1 outcomes.
- A "close the lid, then carry" task suggests a two-stage version: train the carry phase from grasped states first, then the full task. This mirrors RL Token's critical-phase design.
- **Pitfalls for full-episode evaluation:**
  - The start-state distribution shifts. Plan an annealing or forward stage (RFCL), or JSRL-style hand-over, rather than evaluating a late-state specialist from the true start.
  - Episode length must match the remaining horizon (RFCL's dynamic time limit). Otherwise timeouts alias states.
  - Reset states should come from native π0 rollouts rather than scripted poses, so the visual and state distribution matches what the frozen VLA produces.
  - Value estimates learned from late starts must still be bootstrapped from early states, so keep the clipping and n-step changes from Q2–Q3.

### Gaps
- Reported gains (RFCL, JSRL, DemoStart) come from tasks with exact simulator resets and state-based or privileged inputs. I found no reverse-curriculum result with a frozen VLA policy steered in noise space.
- No source quantifies the cost of the forward/annealing stage in episodes for a 60–120 episode budget.

## Q7. Potential-based shaping in long-horizon manipulation: when does it help or hurt sample efficiency, and how do milestone potentials compare with continuous distance-based potentials?

### Takeaway
Potential-based shaping preserves the optimal policy only if terminal potentials are zero, including at timeouts. In tabular theory its effect equals Q-initialisation, so it helps only where the agent actually visits states with changing potential. The best manipulation evidence (DrS) shows that milestone or stage-indicator rewards alone give "limited success" compared with continuous dense rewards. Continuous potentials carry a small, known wrong-sign effect when progress is slow. I found no direct head-to-head comparison of milestone and distance potentials under potential-based shaping in manipulation.

### Cited Findings
- **[Theory]** Potential-based shaping "can formally guarantee policy invariance" — [Müller & Kudenko, arXiv 2502.01307 v1](https://arxiv.org/abs/2502.01307). A learner with shaping makes "the same updates" as one whose Q-values are initialised with the potential — [Wiewiora 2003, JAIR, arXiv 1106.5267](https://arxiv.org/abs/1106.5267)
- **[Theory]** In episodic settings, "the potential function of all terminal states in finite horizon settings has to be zero" — [Grześ, AAMAS 2017](https://www.cs.kent.ac.uk/people/staff/mg483/documents/grzes17goals-in-pbrs.pdf)
- **Müller & Kudenko** — [arXiv 2502.01307 v1](https://arxiv.org/abs/2502.01307)
  - **[Theory]** Effective shaping depends "on the initial Q-values and external rewards". A constant shift of the potential "can be used in sparse-reward settings to improve the sample efficiency", and "scaling the potential function is inherently limited... in terminal MDPs".
  - **[Theory]** Any continuous potential creates some wrong-sign shaping. For positive potentials, a small improvement δ < ((1−γ)/γ)·Φ(s) yields negative shaping reward.
  - **[Demo]** Evidence is on gridworld, CartPole and MountainCar only.
- **DrS** (ICLR 2024) — [DrS, arXiv 2404.16779 v1](https://arxiv.org/abs/2404.16779)
  - **[Demo]** On ManiSkill multi-stage tasks with SAC, the "semi-sparse" stage-indicator reward (R = k at stage k) "yielded limited success within the allocated training budget".
  - **[Demo]** Learned dense rewards matched human-engineered dense rewards on Pick-and-Place and Turn Faucet. Fine-tuning a good policy with semi-sparse rewards showed "significant variance".
  - Caveat: the semi-sparse reward is not potential-based.
- **[Claim/Demo]** HIL-SERL deliberately used sparse binary classifier rewards, stating that shaping was "not feasible" for its tasks, and relied on demos and corrections instead — [HIL-SERL](https://arxiv.org/abs/2410.21845)
- **[Demo]** PLD's reward-bias ablation: "a slight reward bias has little impact, but it could increase convergence speed in 2 out of 8 tasks... A large bias could significantly hinder performance". Main results used no shaping — [PLD App.](https://arxiv.org/abs/2511.00091)
- **[Demo]** QT-Opt found a small per-step penalty "did better than decreasing the discount factor" for faster grasps — [QT-Opt](https://arxiv.org/abs/1806.10293)
- **[Demo]** **2026** Coherent off-policy improvement of large behaviour models reports that sparse-reward actor-critic fine-tuning "unlearn[s] the BC behavior". A dense reward learned by inverse RL maintained or improved π0.5 on all six sparse tasks, reaching ≥90% on five — [arXiv 2606.02194 v1](https://arxiv.org/abs/2606.02194)
- **[Demo]** **2026** VLM-PBRS learns a potential from small-VLM preferences and accelerates learning on Meta-World and Franka Kitchen — [arXiv 2606.27180 v1](https://arxiv.org/abs/2606.27180)
- **[Theory/Demo]** Gupta et al. formalise when shaping provably improves sample complexity — [Unpacking Reward Shaping, NeurIPS 2022, arXiv 2210.09579 v1](https://arxiv.org/abs/2210.09579)

### Inferences
- In the user's run only 114 of 6,000 transitions had nonzero shaping reward. Milestone potentials give signal only after a milestone is reached, so they could not fix failure (a) when the policy rarely got there. That matches DrS's semi-sparse result.
- Continuous potentials (gripper-to-lid distance, lid-closure fraction, grasp-to-goal distance, minus tilt) change every step and give the critic a gradient. The wrong-sign threshold ((1−γ)/γ)·Φ is tiny at γ≈0.998, though it grows if γ is lowered as Q3 suggests.
- Timeout is terminal, so set Φ=0 at every terminal, success or timeout (Grześ). Otherwise the agent is paid γ^T·Φ(s_T) for ending in a high-potential state, for example closing the lid and then idling.
- Shaping changes the Q range (shaped Q = Q − Φ(s)). Any target clipping or bounded head from Q2 must use [−Φ_max, 1].
- Because potential-based shaping is equivalent to Q-initialisation (Wiewiora), much of its benefit in deep RL comes through early TD targets on visited states. It complements success injection and curricula rather than replacing them.

### Gaps
- I found no direct, controlled comparison of milestone (subgoal) potentials versus continuous distance-based potentials under potential-based shaping in long-horizon manipulation. The closest, Okudo & Yamada's subgoal-based shaping ([arXiv 2104.06411](https://arxiv.org/abs/2104.06411)), reports gains over baselines in four-rooms, pinball and picking according to its abstract. I did not verify whether a distance-based potential was among its baselines.
- I found no evidence on shaping in DSRL-style noise-space steering specifically.
