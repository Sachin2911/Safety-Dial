# Evaluation sizing and simulator capabilities for the fourth DSRL attempt

*Conventions.* "Base" means the native strict safe-completion rate of about 25%. "Per arm" means evaluation episodes for one policy. "Computed" means I calculated the number for this note in local Python (SciPy 1.17.1), using either exact enumeration or Monte Carlo simulation; the method is stated beside each number. The scripts are in the session scratchpad and may not persist: `/tmp/claude-1000/-home-sachin-Desktop-Research-Safety-Dial/9018d464-5f42-476f-a07b-0f00850d74e7/scratchpad/power.py` and `/tmp/claude-1000/-home-sachin-Desktop-Research-Safety-Dial/9018d464-5f42-476f-a07b-0f00850d74e7/scratchpad/staged.py`. Source code was read from local checkouts at the exact pinned commits: OmniGibson 3.7.2 at BEHAVIOR-1K `88454bd04f75`, and ManiGuard at `6bf4c61a1f16`. GitHub links below point to those commits. Date: 25 October 2026.

## 1. How many evaluation episodes per arm are needed to detect an improvement over a 25% base?

### Takeaway
With a concurrent base arm, one-sided α = 0.05 and 80% power, Barnard's exact test needs 123 / 46 / 26 / 13 episodes per arm to detect a rise from 25% to 40 / 50 / 60 / 75%. Fisher's exact test needs 132 / 54 / 30 / 15, and a two-sided Barnard test needs 154 / 59 / 31 / 15. Per attempt, only an improvement to about 50% or more can be confirmed: detecting 25%→40% needs about 250 evaluation episodes, roughly 7–9 hours on a four-lane host.

### Cited Findings
- **Per-arm sample sizes at 80% power, base 25%.** Computed for this note. Exact rows give the first n per arm at which exact power reaches the target. Exact power is a full enumeration of the (n+1)² outcome tables, with independent binomial arms. Fisher p-values use the conditional hypergeometric distribution; two-sided uses the minimum-likelihood rule. Barnard p-values are unconditional: pooled score statistic, with the nuisance parameter maximised over a 1,001-point grid. "z" is the closed-form pooled two-proportion formula; "z + cc" adds the Fleiss continuity correction. In almost every cell, exact power stayed at or above target for the next five n. The exceptions were Fisher at one-sided 0.10 for p1 = 0.75, Fisher at 90% power for p1 = 0.60 and 0.75, and Barnard at one-sided 0.10 for p1 = 0.50. Add 1–2 episodes there.

| Test (per arm) | α | p1 = 0.40 | 0.50 | 0.60 | 0.75 |
|---|---|---|---|---|---|
| z, closed form | 0.05 two-sided | 152 | 58 | 31 | 15 |
| z + Fleiss continuity correction | 0.05 two-sided | 165 | 66 | 36 | 19 |
| Fisher exact | 0.05 two-sided | 164 | 64 | 37 | 18 |
| Barnard exact | 0.05 two-sided | 154 | 59 | 31 | 15 |
| z, closed form | 0.05 one-sided | 120 | 46 | 24 | 12 |
| z + continuity correction | 0.05 one-sided | 133 | 54 | 30 | 16 |
| Fisher exact | 0.05 one-sided | 132 | 54 | 30 | 15 |
| Barnard exact | 0.05 one-sided | 123 | 46 | 26 | 13 |
| z, closed form | 0.10 one-sided | 88 | 33 | 18 | 9 |
| Fisher exact | 0.10 one-sided | 100 | 40 | 24 | 11 |
| Barnard exact | 0.10 one-sided | 100 | 37 | 20 | 11 |
| z, 90% power | 0.05 one-sided | 166 | 63 | 33 | 16 |
| Fisher, 90% power | 0.05 one-sided | 178 | 71 | 36 | 18 |
| Barnard, 90% power | 0.05 one-sided | 168 | 65 | 34 | 18 |

- **Formulas used**, for reproducibility (computed):
  - Pooled z: n = [z₁₋α·√(2p̄q̄) + z₁₋β·√(p₀q₀ + p₁q₁)]² / (p₁ − p₀)², where p̄ is the mean of p₀ and p₁.
  - Fleiss correction: n_cc = (n/4)·[1 + √(1 + 4/(n·|p₁ − p₀|))]².
  - Arcsine (Cohen's h): n = 2·[(z₁₋α + z₁₋β)/h]². This gives 152 / 58 / 30 / 15 (two-sided 0.05).
- **Validation of the Barnard code against `scipy.stats.barnard_exact`** (computed). At n = 20, 5/20 against 11/20: mine gives one-sided 0.03049 and scipy 0.03045; two-sided 0.06099 against 0.06090. At n = 30, 7/30 against 15/30: both give 0.01762. For comparison, Fisher's one-sided p-value for the n = 20 table is 0.0527.
- **Power at a fixed n per arm.** Barnard one-sided α = 0.05, with Fisher one-sided in brackets (computed by exact enumeration):

| n per arm | p1 = 0.40 | 0.50 | 0.60 | 0.75 |
|---|---|---|---|---|
| 10 | 0.17 [0.08] | 0.30 [0.18] | 0.46 [0.33] | 0.72 [0.62] |
| 15 | 0.18 [0.12] | 0.38 [0.26] | 0.59 [0.47] | 0.87 [0.80] |
| 20 | 0.21 [0.18] | 0.44 [0.37] | 0.70 [0.61] | 0.95 [0.90] |
| 25 | 0.28 [0.21] | 0.54 [0.48] | 0.78 [0.76] | 0.97 [0.97] |
| 30 | 0.31 [0.25] | 0.62 [0.53] | 0.87 [0.81] | 0.99 [0.98] |
| 40 | 0.39 [0.33] | 0.73 [0.67] | 0.94 [0.91] | 1.00 |
| 50 | 0.48 [0.41] | 0.82 [0.78] | 0.97 [0.96] | 1.00 |
| 60 | 0.54 [0.47] | 0.89 [0.86] | 0.99 [0.99] | 1.00 |
| 80 | 0.64 [0.60] | 0.95 [0.93] | 1.00 | 1.00 |
| 100 | 0.72 [0.69] | 0.98 [0.97] | 1.00 | 1.00 |

- **Smallest detectable target at 80% power** (one-sided 0.05, concurrent control, z approximation; computed). The target p1 is about 0.63 at 20 episodes per arm, 0.56 at 30, 0.52 at 40, 0.49 at 50 and 0.47 at 60.
- **One-arm exact binomial test against a 25% base treated as known** (no concurrent control; one-sided; computed):
  - α = 0.05, 80% power: n = 62, go if ≥ 22 successes (actual α 0.043), for p1 = 0.40; n = 26, ≥ 11 (α 0.040) for 0.50; n = 14, ≥ 7 for 0.60; n = 6, ≥ 4 for 0.75.
  - α = 0.10: n = 46 (≥ 16), 19 (≥ 8), 10 (≥ 5) and 6 (≥ 4).
  - α = 0.05, 90% power: n = 83 (≥ 28), 33 (≥ 13), 17 (≥ 8) and 9 (≥ 5).
- **Precision of a single arm.** Wilson 95% intervals (computed):
  - 5/20 gives 0.112–0.469; 8/30 gives 0.142–0.444; 12/50 gives 0.143–0.374; 25/100 gives 0.175–0.343.
  - 10/20 gives 0.299–0.701; 25/50 gives 0.366–0.634.
- **STEP's rule of thumb.** For p̂ between 0.25 and 0.75 and N ≥ 36, a 95% interval for p is roughly p̂ ± 1/√N. STEP notes that typical papers run "only a small number of trials (e.g., 10–60)" per setting. Telling 59% from 68% "would require Nmax = 500 trials" — [STEP, arXiv 2503.10966 v4](https://arxiv.org/html/2503.10966v4)
- **Kress-Gazit et al.:** "Reducing the number of evaluations makes any conclusions weaker, adding more evaluations makes them stronger". 13/20 against 14/20 is inconclusive under a uniform-prior binomial model — [Kress-Gazit et al., arXiv 2409.09491](https://arxiv.org/html/2409.09491v1)
- **Wall-clock time** (computed). This assumes 7–9 minutes per episode, as in the brief, and lanes running in parallel rounds:

| Episodes | 3 lanes | 4 lanes | 8 lanes |
|---|---|---|---|
| 26 (one-arm 25→50% screen) | 1.1–1.4 h | 0.8–1.1 h | 0.5–0.6 h |
| 92 (46 + 46, Barnard 25→50%) | 3.6–4.7 h | 2.7–3.5 h | 1.4–1.8 h |
| 120 | 4.7–6.0 h | 3.5–4.5 h | 1.8–2.2 h |
| 246 (123 + 123, Barnard 25→40%) | 9.6–12.3 h | 7.2–9.3 h | 3.6–4.7 h |

### Inferences
- **Use Barnard, not Fisher, for binary success comparisons.** At the same α and power, Barnard needs about 5–15% fewer episodes. For 25→50% one-sided, that is 46 against 54 episodes per arm. The continuity-corrected z formula approximates Fisher, not Barnard.
- **A pre-registered one-sided test is defensible.** The question is directional ("does steering beat native?"), and a one-sided test saves about 20% against two-sided. It must be declared before any data are seen.
- **Budget implication.** "Meaningful improvement" should be defined as reaching at least about 50% strict safe completion on the evaluated task mix. That target can be confirmed with 46 + 46 episodes, about 3 hours on a four-lane host, alongside 60–120 training episodes. A rise to 40% cannot be confirmed within one attempt. It would need about 250 evaluation episodes, or a pre-registered pooled analysis across attempts.
- **When a one-arm test against a "known" 25% is acceptable.** It needs only 26 episodes for 25→50%, but it is valid only if the 25% was measured on the same task mix and infrastructure. Because the base rate varies from 0% to 75% across tasks, treat it as a screen (Section 4), not as confirmation.
- **Extra noise beyond the binomial.** "Heavy outcome noise" from simulator nondeterminism is already captured by the binomial variance if episodes are independent. The numbers above become optimistic only when outcomes are overdispersed, for example from host-to-host drift, a task mix that is unbalanced between arms, or variability between training runs.

### Gaps
- Boschloo's test, also an unconditional exact test that is often more powerful than Fisher, was not computed.
- The actual size of the asymptotic z-test at these small sample sizes was not computed.
- I found no data on overdispersion (host or day effects) for this stack, so all numbers assume independent Bernoulli episodes within an arm.
- How many DSRL training episodes are needed to reach a given improvement is a learning question that statistics alone cannot answer, and it was not researched here.

## 2. What do paired or blocked designs and common random numbers gain, and how should simulator nondeterminism and task heterogeneity be handled?

### Takeaway
Pairing episodes by seed (common random numbers) gains nothing when same-seed repeats are no more alike than different seeds. The useful lever is blocking by task: the same task list with the same number of episodes per task in both arms, run interleaved and analysed with a stratified test such as Cochran–Mantel–Haenszel (CMH). In an illustrative task mix ranging from 0% to 70%, blocking cut the variance of the difference by 22% and the required sample from about 45 to about 35 per arm for 25→50%.

### Cited Findings
- **ManiGuard's protocol.** "All policies and seeds share bit-identical initial states, and a seed acts only on the policy's sampler." The per-rollout seed is a CRC-32 hash of the base seed and the scenario name, and the π server re-seeds its JAX PRNG key, so "the π serving stack returns bit-identical action chunks for identical inputs under a fixed key" — [ManiGuard paper, arXiv 2608.17386](https://arxiv.org/pdf/2608.17386)
- **ManiGuard's nondeterminism finding.** "Isaac's ray-traced rendering with temporal accumulation is not bit-reproducible across processes". "In a controlled probe, two identically seeded runs of the same scenario started from a bit-identical simulator state yet received first observations differing in 39% of overview pixels, which contact dynamics amplified into different episode lengths". "Residual nondeterminism of this kind … is folded into the across-seed spread of every reported rate." — [ManiGuard paper](https://arxiv.org/pdf/2608.17386)
- **Isaac Lab on physics determinism.** Given the same hardware and Isaac Sim/PhysX version, "the simulation produces identical results for scenes with rigid bodies and articulations", but "the simulation results can vary across different hardware configurations". "PhysX does not guarantee determinism for any scene with non-rigid bodies, such as cloth or soft bodies". `--deterministic` "configures Torch and rendering only". This is the current Isaac Lab `main` documentation, and its mapping to Isaac Sim 4.5 is not stated — [Isaac Lab reproducibility guide](https://isaac-sim.github.io/IsaacLab/main/source/how-to/reproducibility.html)
- **TRI's large behaviour model (LBM) study.**
  - In simulation, all policies share the same seeds and parameters (paraphrase). The simulation is "deterministic given a random seed", but "the GPU-based policies do not have the same guarantee".
  - Aggregating across tasks slightly violates the i.i.d. assumption, which the authors call "negligible in practice".
  - Tasks were designed to target "policy success rates around 50%" so that comparisons are most informative.
  - Source: [TRI LBM team, arXiv 2507.05331](https://arxiv.org/html/2507.05331v1)
- **Kress-Gazit et al. on A/B testing.** They recommend A/B testing that interleaves rollouts "in a way that is blind to the evaluator", running all policies in one session, and matching initial conditions — [arXiv 2409.09491](https://arxiv.org/html/2409.09491v1)
- **STEP's assumptions.** STEP assumes each trial's initial state is drawn i.i.d. (its Assumption 1) and pairs the two policies' outcomes by trial index. Its multi-task version tests H1 "all tasks have p_s > p_b" with Bonferroni-corrected per-task α = 0.01 — [STEP v4](https://arxiv.org/html/2503.10966v4)
- **Blocking by task: variance decomposition** (computed). The illustrative mix has eight tasks with base rates {0, 0.05, 0.10, 0.15, 0.25, 0.30, 0.45, 0.70} (mean 0.25) and an additive effect of +0.25 (treated mean 0.50).
  - Between-task variance is 0.0475. That is 25% of the base arm's marginal variance (0.1875) and 19% of the treated arm's (0.25).
  - The per-episode variance of the difference is 0.3425 under stratification against 0.4375 unblocked, a ratio of 0.78.
- **Blocking by task: simulated power** (computed). One-sided α = 0.05, 40,000 replicates; the CMH test's type-I error under the null was 0.049–0.050.

| n per arm (per task) | CMH, balanced tasks | pooled z, balanced tasks | pooled z, task drawn at random per episode |
|---|---|---|---|
| 24 (3) | 0.653 | 0.573 | 0.566 |
| 32 (4) | 0.768 | 0.685 | 0.669 |
| 40 (5) | 0.843 | 0.777 | 0.750 |
| 48 (6) | 0.900 | 0.864 | 0.837 |
| 56 (7) | 0.934 | 0.893 | 0.868 |

- **Pairing by seed (McNemar test, Connor-type formula)** (computed).
  - The formula is n = [z₁₋α·√ψ + z₁₋β·√(ψ − δ²)]² / δ², where ψ = p₁₀ + p₀₁, δ = p₁₀ − p₀₁ and p₁₁ = p₀p₁ + ρ·√(p₀q₀p₁q₁).
  - Pairs needed for 25→50% (one-sided 0.05, 80% power): 48 at within-pair outcome correlation ρ = 0; 44 at ρ = 0.1; 35 at ρ = 0.3; 26 at ρ = 0.5.
  - Unpaired Barnard needs 46 per arm.
- **ManiGuard's failure handling.** Non-completed attempts (`crashed`, `monitor_failed`, `load_failed`, `initialization_failed`, `numerical_failed`) carry `null` verdicts. `summary.json` leaves aggregate rates `null` if any attempt failed, and there is no automatic retry — [ManiGuard run_benchmark.md @6bf4c61](https://github.com/NU-IDEAS-Lab/ManiGuard/blob/6bf4c61a1f168cc46e02eb22c41bcb51815e9726/docs/evaluation/run_benchmark.md)

### Inferences
- **Common random numbers.** The brief reports that same-seed repeats agree no better than different seeds, and ManiGuard's probe explains why: the renderer is not reproducible and contact amplifies the difference. The within-pair correlation conditional on task is therefore about 0, and seed-level common random numbers buy nothing (48 pairs against 46 unpaired). Keep matched seeds and frozen snapshots for bookkeeping and traceability, but analyse episodes as independent draws within each task. A quick check is to estimate ρ from existing same-seed pairs before assuming otherwise.
- **Block by task, and by host where possible.** Give both arms the identical task list with equal episodes per task, interleave the arms on every lane (A, B, A, B), and spread both arms over the same hosts. Isaac results "can vary across different hardware". Analyse with CMH or a stratified Mantel–Haenszel risk difference, or a logistic model with task effects, and report per-task rates. In the illustrative mix, about 40 per arm with CMH matched the power of about 48 per arm with a pooled test and random task draws.
- **Task selection.** Tasks at 0% base add no base-arm variance but may dilute the average effect if steering cannot help them. Tasks near 75% leave little headroom. Pre-register the task set, preferring tasks whose native rate is roughly 10–60%; TRI deliberately targeted about 50% for informativeness. Test the pooled average effect. An "every task improves" claim (STEP's multi-task H1) is much more expensive.
- **Crashes.** Pre-register how they are handled. For example, rerun with a fresh seed and report crash counts per arm. Count arm-caused failures, such as NaN actions from steering, as failures for that arm.
- **Scope of a positive result.** One training run per attempt supports a claim about that trained policy, not about the method's reliability. TRI notes its results "do not capture the randomness from the training process".

### Gaps
- The real per-task base-rate distribution and the within-pair correlation ρ for this setup are not in the sources, so the blocking gains above are illustrative.
- I found no source quantifying how PhysX solver warm-start or contact-cache state affects divergence after a restore in Isaac Sim 4.5.

## 3. What do robot-learning evaluation sources recommend (rliable, Kress-Gazit et al., STEP, SPRT and group-sequential designs)?

### Takeaway
The sources agree on four practices:
- Report uncertainty, not point estimates.
- Run blind, interleaved A/B evaluations from matched initial states.
- Use exact or Bayesian methods for binary success.
- Use a pre-specified sequential test (STEP, SPRT or a group-sequential plan) instead of adding trials until the result is significant.

For a two-policy binary comparison at this scale, STEP or an O'Brien–Fleming two-look plan saves about 10–30% of episodes on average without inflating the false-positive rate.

### Cited Findings
- **rliable (Agarwal et al., 2021).** The authors "advocate for reporting interval estimates of aggregate performance". They "propose performance profiles to account for the variability in results" and "more robust and efficient aggregate metrics, such as interquartile mean scores". Evaluation with "a handful of runs" "cannot ignore the uncertainty in results" — [arXiv 2108.13264](https://arxiv.org/abs/2108.13264)
- **Kress-Gazit et al. (2024)**, from [arXiv 2409.09491](https://arxiv.org/html/2409.09491v1):
  - "Providing a point estimate for success and performance metrics can be misleading". Use frequentist interval estimates or a Bayesian Beta posterior with a uniform prior.
  - Worked example: 15/18 against 11/17 gives P(B better) ≈ 0.11.
  - Recommends A/B testing blind to the evaluator, a single session, matched initial conditions, and reporting failure modes.
  - Gives no sample-size formula and does not discuss sequential testing.
- **STEP (Snyder et al., RSS 2025; arXiv v4 of 6 June 2025)**, from [STEP v4 HTML](https://arxiv.org/html/2503.10966v4) and the [abstract page](https://arxiv.org/abs/2503.10966):
  - **Design.** After each trial it decides Accept null, Reject null or Continue, with H0: p1 ≤ p0. Inputs are α*, Nmax, a risk budget f(n) (uniform α*/Nmax in the experiments) and a discretisation M. Decision regions are computed offline by linear programming, so "all the computation can be performed offline".
  - **Behaviour.** It may abstain at Nmax, and "the evaluator may safely append additional trials".
  - **Savings claimed.** "Reduces the number of evaluation trials by up to 32%" against state-of-the-art baselines, and saves "more than 160 simulation rollouts" in a multi-task comparison. Search snippets indicate earlier versions said 40% / 37% and more than 200 rollouts, so cite v4.
  - **Table I trial counts** (SAVI / Lai / STEP / SPRT oracle):

| Setting | SAVI | Lai | STEP | SPRT oracle |
|---|---|---|---|---|
| FoldRedTowel, Nmax = 50 | 20 | 17 | 19 | 17 |
| StackCube, α* = 0.01, Nmax = 500 | 329 | 417 | 225 | 135 |
| Multitask, α = 0.03, Nmax = 1500 | 554 | 578 | 392 | 289 |

  - **Small gaps.** For CarrotOnPlate, "no method reached significance at Nmax = 100".
- **TRI LBM (2025)**, from [arXiv 2507.05331](https://arxiv.org/html/2507.05331v1):
  - 50 real-world and 200 simulation rollouts "per task per policy per condition".
  - Blind, randomised ordering, with bundles matched by initial condition.
  - Bayesian posteriors with a uniform Beta prior, and a sequential paired test with a 5% type-I bound.
  - Bonferroni correction within a test set, with results shown as a compact letter display (CLD).
  - It uses Welch's t-test for task-progress scores, acknowledging that this leaves type-I error "not controlled".
- **One-arm Wald SPRT against a known 25%** (computed by exact dynamic programming, truncated). α = 0.05 and β = 0.20 give bounds A = ln(0.8/0.05) = 2.773 and B = ln(0.2/0.95) = −1.558.
  - For p1 = 0.50, each success adds 0.693 and each failure subtracts 0.405. Four straight successes means go; four straight failures means stop. With Nmax = 40: P(go | 0.25) = 0.050, E[N | 0.25] = 11.3, P(go | 0.50) = 0.823, E[N | 0.50] = 15.0.
  - For p1 = 0.60 (+0.875 / −0.629): P(go | 0.25) = 0.037, E[N] = 6.6; P(go | 0.60) = 0.845, E[N] = 8.8.
  - For p1 = 0.40 (+0.470 / −0.223) with Nmax = 80: α = 0.065, E[N | 0.25] = 28.3; power 0.817, E[N | 0.40] = 37.1. Truncating at Nmax = 40 inflates α to 0.152.
  - Method: Wald's SPRT; the reference link is from memory and was not fetched — [Wald 1945](https://doi.org/10.1214/aoms/1177731118)
- **Group-sequential designs** (computed). Normal approximation, Monte Carlo with 2×10⁶ draws, equally spaced looks, one-sided α = 0.025 (equivalent to two-sided 0.05), 80% power. These factors match the standard published tables (OBF K = 2 → 1.008, Pocock K = 2 → 1.110, Pocock K = 3 → 1.166) as I recall them; the method reference is [Pocock 1977](https://doi.org/10.1093/biomet/64.2.191) (link from memory).

| Design | z boundaries | N_max / N_fixed | E[N \| H0] / N_fixed | E[N \| H1] / N_fixed |
|---|---|---|---|---|
| O'Brien–Fleming (OBF), K = 2 | 2.796, 1.977 | 1.007 | 1.006 | 0.901 |
| OBF, K = 3 | 3.468, 2.452, 2.002 | 1.017 | 1.014 | 0.855 |
| Pocock, K = 2 | 2.178, 2.178 | 1.110 | 1.102 | 0.853 |
| Pocock, K = 3 | 2.289 (all) | 1.166 | 1.155 | 0.819 |
| OBF K = 2 + binding futility (stop if interim z < 0) | 2.794, 1.976 | 1.013 | 0.759 | 0.894 |
| OBF K = 3 + binding futility | 3.435, 2.429, 1.983 | 1.047 | 0.652 | 0.836 |

- **OBF at one-sided α = 0.05, K = 2** (computed): boundaries z₁ = 2.373 and z₂ = 1.678, with N_max/N_fixed = 1.016 and E[N | H1] = 0.877 of the fixed sample.
  - Adding a non-binding futility stop (interim z < 0) gives α = 0.0489, power 0.793, E[N | H0] = 0.757 and E[N | H1] = 0.857.
  - For the Barnard 46-per-arm design, that means at most about 47 per arm, with the interim look at about 24 per arm.

### Inferences
- **Fit of rliable's tools.** rliable's aggregate tools (interquartile mean, performance profiles) target continuous scores over many tasks and runs. With 4–8 tasks of binary outcomes, report per-task Wilson or exact intervals and a stratified pooled estimate. Use rliable-style bootstrap intervals only for cross-task aggregates.
- **Which sequential test.** For two arms, STEP (precomputed offline for, say, α = 0.05 and Nmax = 50 per arm) or an OBF two-look plan are the safe options. A one-arm SPRT against 25% is cheapest (11–15 episodes on average for 25→50%), but it is only valid if 25% is the true base for the task mix, so use it as a screen.
- **No ad-hoc extension.** "Run 20 more and test again" is the p-hacking pattern STEP warns about. Any extension must be part of a pre-specified sequential plan.

### Gaps
- The rliable abstract fetched here does not mention a stratified bootstrap; that recommendation comes from my memory of the paper body and was not verified this session.
- STEP's expected stopping times for this exact setting (25% against 50%, Nmax about 50) would need STEP's own code, which was not run.
- **Conflict on TRI's test:** a search-result description of TRI's dataset says "sequential A/B testing with Barnard's exact test". The fetched paper text names only a cited sequential framework and does not name Barnard's test.
- The original O'Brien–Fleming (1979) and Lan–DeMets (1983) papers were not fetched.

## 4. How should staged go/no-go gates work: futility rules, learning-curve gates and pilot-then-confirm designs?

### Takeaway
A three-gate funnel fits a budget of 60–120 training episodes plus evaluation:
1. A cheap training-window gate that only aborts clearly failing runs.
2. A Simon two-stage screen of the frozen policy against the known 25%: 2/9, then 9/24, which averages 15 episodes when there is no real gain.
3. A concurrent-control, task-blocked confirmation: about 40–46 per arm, one O'Brien–Fleming interim look and a non-binding futility stop at z < 0.

The screen alone cannot confirm anything, because a mis-specified base rate inflates its false-go rate.

### Cited Findings
- **Simon (1989) designs.** Two-stage designs that minimise the expected sample size under the null ("optimal") or the maximum sample size ("minimax"), subject to type-I and type-II error limits — [PubMed 2702835](https://pubmed.ncbi.nlm.nih.gov/2702835/)
  - My implementation reproduces Simon's published p0 = 0.10, p1 = 0.30 designs: optimal 1/10 then 5/29, EN0 = 15.0, PET0 = 0.736; minimax 1/15 then 5/25, EN0 = 19.5 (computed).
- **Simon designs for p0 = 0.25** (computed). Stop after stage 1 if successes ≤ r1 of n1; at the end, go if successes > r of n. EN0 is the expected sample size under the null and PET0 the probability of stopping early under the null.

| p1 | α | Design | Stop if ≤ r1 of n1 | Go if > r of n | EN0 | PET0 | Actual α | Power |
|---|---|---|---|---|---|---|---|---|
| 0.40 | 0.05 | optimal | 5 of 20 | 23 of 71 | 39.5 | 0.617 | 0.049 | 0.802 |
| 0.40 | 0.05 | minimax | 16 of 51 | 20 of 60 | 52.0 | 0.885 | 0.050 | 0.803 |
| 0.50 | 0.05 | optimal = minimax | 2 of 9 | 9 of 24 | 15.0 | 0.601 | 0.048 | 0.805 |
| 0.60 | 0.05 | optimal = minimax | 1 of 5 | 5 of 12 | 7.6 | 0.633 | 0.049 | 0.808 |
| 0.75 | 0.05 | optimal | 1 of 3 | 3 of 7 | 3.6 | 0.844 | 0.047 | 0.821 |
| 0.75 | 0.05 | minimax | 0 of 2 | 3 of 6 | 3.8 | 0.562 | 0.035 | 0.811 |
| 0.40 | 0.10 | optimal | 7 of 25 | 16 of 52 | 32.4 | 0.727 | 0.099 | 0.800 |
| 0.40 | 0.10 | minimax | 13 of 41 | 14 of 44 | 41.4 | 0.878 | 0.099 | 0.801 |
| 0.50 | 0.10 | optimal | 2 of 8 | 7 of 21 | 12.2 | 0.679 | 0.098 | 0.811 |
| 0.50 | 0.10 | minimax | 2 of 9 | 6 of 17 | 12.2 | 0.601 | 0.098 | 0.806 |
| 0.60 | 0.10 | optimal = minimax | 1 of 5 | 4 of 10 | 6.8 | 0.633 | 0.072 | 0.807 |

- **Sensitivity of the 2/9 → 9/24 screen to the true rate** (computed). P(go) by true rate p:
  - p = 0.15: 0.001; p = 0.25: 0.048; p = 0.30: 0.137; p = 0.35: 0.284; p = 0.40: 0.470; p = 0.50: 0.805; p = 0.60: 0.959.
  - Expected episodes at the same rates: 11.1, 15.0, 17.1, 18.9, 20.5, 22.7 and 23.6.
- **Training-window gates.** Probability of at least k successes in the last m training episodes, at true rates 0.25 / 0.40 / 0.50 / 0.60 (computed):
  - m = 10, k = 5: 0.078 / 0.367 / 0.623 / 0.834.
  - m = 20, k = 8: 0.102 / 0.584 / 0.868 / 0.979.
  - m = 20, k = 9: 0.041 / 0.404 / 0.748 / 0.943.
  - m = 30, k = 11: 0.106 / 0.709 / 0.951 / 0.997.
  - m = 30, k = 12: 0.051 / 0.569 / 0.900 / 0.992.
- **Training-window futility.** Probability of at most 4 successes in 20 (computed): 0.830 at p = 0.15; 0.415 at 0.25; 0.051 at 0.40; 0.0059 at 0.50; 0.0003 at 0.60. For at most 3 in 20: 0.648, 0.225, 0.016 and 0.0013 at 0.15, 0.25, 0.40 and 0.50.
- **Interim futility at 50% information** (computed; fixed design with one-sided α = 0.05 and 80% power):
  - Stop if z < 0: P(stop | H0) = 0.500 and P(stop | H1) = 0.039.
  - Stop if z < 0.5: 0.691 and 0.104.
- **Predictive-probability designs (Lee & Liu 2008).** These use the Bayesian predictive probability — the chance of a positive conclusion if the trial runs to its maximum size, given the interim data — for continuous monitoring with early stopping for inefficacy. They report controlled type-I and type-II errors. Source: *Clinical Trials* 5(2):93–106, via [author slides/PDF](https://biostat.app.vumc.org/wiki/pub/Main/MSJournalClub/PredProbDesign.pdf)
- **Bayesian Beta(1,1) illustrations** (computed by Monte Carlo, 10⁶ draws): P(new > base) and the 95% credible interval of the difference.
  - 12/30 against 7/30: 0.913, interval (−0.070, 0.376).
  - 15/30 against 8/30: 0.967, (−0.015, 0.442).
  - 20/40 against 10/40: 0.989, (0.035, 0.432).
  - 10/20 against 5/20: 0.945, (−0.053, 0.492).
- **No silent extension.** STEP stresses that batch tests extended with more trials lead to "inadvertent p-hacking", whereas its sequential design lets trials be appended safely — [STEP v4](https://arxiv.org/html/2503.10966v4)

### Inferences
Proposed staged plan for the fourth attempt. Costs use 7–9 minutes per episode on 4 lanes.
- **Gate 0, infrastructure (no statistics).**
  - Every lane is warm-started serially (Section 7) and runs one smoke episode.
  - The jar snapshot loads, the LTL monitor runs, and no lane crashes. Any crash blocks the stage.
- **Gate 1, learning curve on training episodes.**
  - After at least 40 training episodes, look at the most recent 20 (a 20-episode window is the smallest that separates 25% from 50%).
  - **Abort** if there are ≤ 4 successes: this stops 41% of runs that are still at 25%, and only 0.6% of runs already at 50%.
  - **Flag as promising** if there are ≥ 8: 10% false-promising at 25%, 87% at 50%.
  - With 60–120 training episodes this allows 2–5 non-overlapping windows. A 20-episode window cannot separate 25% from 40%: at k = 8, P = 0.10 against 0.58.
  - Training episodes include exploration and may use a different task mix, so this gate only aborts and never certifies.
- **Gate 2, screen of the frozen policy (Simon 2/9 → 9/24 against 25%).**
  - Run on the same balanced task mix whose native rate is about 25%.
  - It costs about 15 episodes on average if nothing improved (about 0.5 h), and at most 24 (about 0.8 h).
  - If that mix's true base is 35% rather than 25%, the false-go rate rises from 5% to 28%. So the screen decides only whether to spend on Gate 3.
  - Alternative: a one-arm SPRT with p1 = 0.5, which averages 11–15 episodes.
- **Gate 3, confirmation with a concurrent native arm.**
  - Use fresh episodes, block by task (and by host where possible), interleave the arms, and keep the test one-sided at 0.05.
  - Use Barnard at 46 per arm, or about 40 per arm with CMH if the task mix is heterogeneous.
  - Take one interim look at about 24 per arm: stop for efficacy if z ≥ 2.37, and stop for futility if z < 0.
  - Expected cost is about 0.76 of the fixed design if there is no effect and about 0.86 if the effect is real. The maximum is about 94 episodes, roughly 3.5 h on 4 lanes.
  - STEP with α = 0.05 and Nmax ≈ 50 per arm is an equivalent option with more flexible stopping.
- **No reuse of screen data.** Do not reuse Gate 2 episodes in the Gate 3 test unless a combined two-stage analysis is pre-specified; pooling them afterwards inflates α.
- **Across attempts.** If confirmation is underpowered for a smaller but real effect (25%→40%), pre-register a pooled, attempt-stratified analysis across attempts rather than re-testing ad hoc.

### Gaps
- DSRL-specific learning-curve shapes, and whether training-episode success tracks evaluation success, are unknown; this is outside this note's scope.
- Not researched:
  - Pick-the-winner or selection designs (Simon, Wittes and Ellenberg, 1985) for choosing among several steering configurations.
  - Multi-arm multi-stage designs.
  - Exact boundaries for Lee & Liu's predictive-probability design at p0 = 0.25.

## 5. Can full simulation state be saved and restored in OmniGibson 3.7.2, and with what determinism caveats?

### Takeaway
Yes, in-process, through three APIs:
- `og.sim.dump_state()` / `load_state()`, as dicts or a flat tensor via `serialize()`.
- `og.sim.save()` / `restore()`, which write JSON including init info and can recreate scenes.
- `scene.reset()`, which reloads a snapshot cached at initialisation.

The caveats:
- Loading requires a playing simulator, plus one simulator step before spatial predicates are valid.
- Switching scenes in-process is unreliable, which is why ManiGuard uses one process per scenario.
- A restored state does not replay identically, because rendering is nondeterministic.

### Cited Findings
- **`og.sim` state API** — [simulator.py @88454bd](https://github.com/StanfordVL/BEHAVIOR-1K/blob/88454bd04f75dc57c00ab1f1a00bcde1ff505950/OmniGibson/omnigibson/simulator.py)
  - `_dump_state()` returns `{i: scene.dump_state(serialized=False)}` for each scene.
  - `load_state(state, serialized=False)` asserts `self.is_playing()`, because "joint states only get updated when playing".
  - `serialize()` and `deserialize()` concatenate the per-scene tensors.
- **The `load_state` disclaimer**, verbatim: "Currently, omniverse does not support exclusively stepping kinematics, so we cannot update some of our object states relying on updated kinematics until a simulator step is taken! Object states such as OnTop, Inside, etc. relying on relative spatial information will inaccurate until a single sim step is taken." — [simulator.py](https://github.com/StanfordVL/BEHAVIOR-1K/blob/88454bd04f75dc57c00ab1f1a00bcde1ff505950/OmniGibson/omnigibson/simulator.py)
- **`og.sim.save()` and `restore()`** — [simulator.py](https://github.com/StanfordVL/BEHAVIOR-1K/blob/88454bd04f75dc57c00ab1f1a00bcde1ff505950/OmniGibson/omnigibson/simulator.py)
  - `save()` refuses if objects are still initialising ("Please take one additional sim step and then save"), and returns JSON strings or dicts when no paths are given.
  - `restore()` rebuilds scenes from scratch when none are loaded. Otherwise it calls `scene.restore()` per scene.
  - On a scene-count mismatch it logs "Please call og.clear() to relaunch the simulator first".
- **`scene_base.py`** — [scene_base.py @88454bd](https://github.com/StanfordVL/BEHAVIOR-1K/blob/88454bd04f75dc57c00ab1f1a00bcde1ff505950/OmniGibson/omnigibson/scenes/scene_base.py)
  - Scene state is `{"pos", "ori", "registry": self._registry.dump_state(...)}`; the registry holds objects, robots and systems.
  - `save()` writes versions, metadata, state, `init_info` and `objects_info`.
  - `restore()` diffs objects by name, batch-removing or adding them, and syncs systems.
  - `initialize()` caches `self._initial_file = self.save(as_dict=True)`.
  - `reset(hard=...)` either restores that file (hard) or loads only its state (soft, ignoring missing or extra objects), then calls `og.sim.step_physics()`.
- **ManiGuard's process model.** "OmniGibson cannot reliably reload scenes in-process", so the family runner spawns "one OS process per instance". In data collection, "`og.clear()` can't switch tasks in-process". Each scene is built "from the frozen snapshot", and the controller is reloaded "after `env.reset()`" — [ManiGuard run_benchmark.md](https://github.com/NU-IDEAS-Lab/ManiGuard/blob/6bf4c61a1f168cc46e02eb22c41bcb51815e9726/docs/evaluation/run_benchmark.md); [evaluation/index.md](https://github.com/NU-IDEAS-Lab/ManiGuard/blob/6bf4c61a1f168cc46e02eb22c41bcb51815e9726/docs/evaluation/index.md); [data_collection/index.md](https://github.com/NU-IDEAS-Lab/ManiGuard/blob/6bf4c61a1f168cc46e02eb22c41bcb51815e9726/docs/data_collection/index.md)
- **ManiGuard's `REPEAT=N`** duplicates plan lines ("run every instance N times (eval is stochastic)") rather than resetting in-process — [eval_family.sh](https://github.com/NU-IDEAS-Lab/ManiGuard/blob/6bf4c61a1f168cc46e02eb22c41bcb51815e9726/scripts/eval_family.sh)
- **Restored states do not replay.** "The initial state is restored bit-identically", but rendering nondeterminism (39% of pixels differing at the first observation) and contact dynamics produce divergent episodes — [ManiGuard paper](https://arxiv.org/pdf/2608.17386)
- **PhysX scope.** Determinism holds for rigid bodies and articulations on the same hardware, with no guarantee for non-rigid bodies — [Isaac Lab reproducibility guide](https://isaac-sim.github.io/IsaacLab/main/source/how-to/reproducibility.html)

### Inferences
- **Amortise start-up with in-process resets.** For training and screening, run repeated episodes of the same jar task in one process, using `env.reset()` (soft reset to the cached snapshot) followed by a controller reload, as ManiGuard does. Validate it once:
  - Compare `og.sim.dump_state(serialized=True)` after reset with the snapshot's state tensor.
  - Check jar joint states and object poses.
  - Take one step before reading object states.

  ManiGuard's warning concerns switching or reloading scenes, not resetting one scene. Keep ManiGuard-style process-per-scenario runs for the confirmatory stage, so the result is comparable with the published protocol.
- **Branching from mid-episode states.** Saving and restoring mid-episode states, for example just before lid closure or lift, is technically supported. It could concentrate DSRL training on the contact phase where failures arise. Branches share a prefix, so their outcomes are correlated. Evaluation success rates must still come from full episodes starting at the frozen snapshot.
- **No exact replay.** Do not rely on save and restore for bit-exact replay or common random numbers; renderer nondeterminism defeats it.

### Gaps
- I did not read the object-level and prim-level `dump_state` implementations, so I could not confirm whether velocities and controller internal state are included.
- No OmniGibson 3.7.x documentation on determinism was found.
- ManiGuard does not document the concrete failure mode behind "cannot reliably reload scenes in-process".
- PhysX solver-cache and warm-start behaviour after `load_state` was not found in any source.

## 6. Can several environments run per GPU, and what are typical headless throughput and start-up times?

### Takeaway
OmniGibson's `VectorEnvironment` runs N copies of one configuration in one simulator with a single synchronous `og.sim.step()`, but no throughput or memory figures are published for it, and ManiGuard's code does not use it. The better-evidenced lever is two simulator processes per GPU: ManiGuard measured 1.5–1.8× on a latency-bound workload, limited by VRAM (about 4 GB per simulator client, about 13 GB peak with a π0.5 server). Published speeds are 11–24 simulation steps per second with the full feature set on an RTX 3080, and 150–300 s of scene loading per trial on an RTX 4090. Our 7–9 minutes per 2,000-step jar episode works out to about 3.7–4.8 control steps per second.

### Cited Findings
- **`VectorEnvironment(num_envs, config)`** — [vec_env_base.py @88454bd](https://github.com/StanfordVL/BEHAVIOR-1K/blob/88454bd04f75dc57c00ab1f1a00bcde1ff505950/OmniGibson/omnigibson/envs/vec_env_base.py)
  - It builds `og.Environment(configs=copy.deepcopy(config), in_vec_env=True)` per environment, then calls `og.sim.play()` once.
  - `step()` runs each environment's `_pre_step`, then one `og.sim.step()`, then each post-step, and returns Python lists. `reset()` loops over the environments.
- **Scene layout for multiple environments.** Scenes are laid out in a row along x with `scene_margin` gaps, with a z offset during loading — [scene_base.py](https://github.com/StanfordVL/BEHAVIOR-1K/blob/88454bd04f75dc57c00ab1f1a00bcde1ff505950/OmniGibson/omnigibson/scenes/scene_base.py)
- **OmniGibson's vector-environment docs.** "Our simulator now can keep track of multiple environments simultaneously". The config "is copied across all environments". They mention "many vectorized operations" but give no benchmarks — [OmniGibson vector environments](https://behavior.stanford.edu/omnigibson/vector_environments.html)
- **ManiGuard does not use it.** ManiGuard's Python code has no `VectorEnvironment` reference (checked by grep at 6bf4c61). Its `slice_scene_registry_for_worker(registry, num_envs, seed_offset)` shards scenes across workers — [ManiGuard repo @6bf4c61](https://github.com/NU-IDEAS-Lab/ManiGuard/tree/6bf4c61a1f168cc46e02eb22c41bcb51815e9726)
- **Two processes per GPU (ManiGuard data collection):** "On a single GPU two shards still help: the workload is latency / CPU-sync bound (GPU-Util ~100% but power ~35% of TDP, memory bandwidth ~3%), so a second process fills the idle cycles — expect ~1.5–1.8×, with VRAM the limiting constraint (stagger launches)." — [data_collection/index.md](https://github.com/NU-IDEAS-Lab/ManiGuard/blob/6bf4c61a1f168cc46e02eb22c41bcb51815e9726/docs/data_collection/index.md)
- **VRAM (ManiGuard).** "Simulation + the heaviest policy server (π0 / π0.5) peaks at ~13 GB measured". "The simulation client alone needs only ~4 GB". Driver versions newer than 580 "produced repeatable startup segfaults", and 580.x is verified — [installation.md](https://github.com/NU-IDEAS-Lab/ManiGuard/blob/6bf4c61a1f168cc46e02eb22c41bcb51815e9726/docs/getting-started/installation.md)
- **ManiGuard compute and timing.**
  - "The 21,000 simulation rollouts … consumed 1,326 single-GPU hours on RTX 4090 GPUs". That averages 3.79 GPU-minutes per rollout across all families, with horizons of 1,100–5,700 steps and early stopping on success.
  - The rates are 20 Hz action and rendering over 120 Hz physics, and the jar horizon is 2,000 steps.
  - Source: [ManiGuard paper](https://arxiv.org/pdf/2608.17386)
  - New runs default to "five 640×640 DLAA source views"; a `legacy` source profile also exists — [evaluation/index.md](https://github.com/NU-IDEAS-Lab/ManiGuard/blob/6bf4c61a1f168cc46e02eb22c41bcb51815e9726/docs/evaluation/index.md)
- **BEHAVIOR-1K paper, Appendix E.4, Table A.10.** Hardware: i7-10700K and an RTX 3080, single process, idle robot, a 128×128 RGB render each step.
  - Rs_int (81 objects): 24 steps/s with the full feature set; 58 with "− Fluid and Cloth"; 77 with "− Object State Update"; 90 with "− Robot".
  - house_single_floor (621 objects): 11, 26, 55 and 60.
  - The main text says "around 60 fps" for a house scene of about 60 objects with ray tracing, against about 100 fps for iGibson 2.0.
  - Source: [arXiv 2403.09227](https://arxiv.org/html/2403.09227v1)
- **BEHAVIOR Challenge 2025 evaluation**, on an "NVIDIA RTX 4090 (24GB VRAM)": scene load takes "Approximately 150-300 seconds (one-time cost per trial, varies by scene complexity)". The protocol is 50 tasks with the first 10 instances each, one rollout per instance, and a default timeout of "2 * average human task completion time" — [BEHAVIOR Challenge 2025 evaluation](https://behavior.stanford.edu/challenge/archive/2025/evaluation.html)
- **OmniGibson's launch log and defaults.** The launch log prints "This will take 10-30 seconds...". Defaults: `gm.USE_GPU_DYNAMICS = False`, `gm.ENABLE_FLATCACHE = False`, `gm.ENABLE_OBJECT_STATES = True`, `gm.ENABLE_TRANSITION_RULES = True`, `gm.DEFAULT_PHYSICS_FREQ = 120` — [simulator.py](https://github.com/StanfordVL/BEHAVIOR-1K/blob/88454bd04f75dc57c00ab1f1a00bcde1ff505950/OmniGibson/omnigibson/simulator.py); [macros.py](https://github.com/StanfordVL/BEHAVIOR-1K/blob/88454bd04f75dc57c00ab1f1a00bcde1ff505950/OmniGibson/omnigibson/macros.py)
- **NVIDIA forum, Isaac Sim 4.5 on 4×A6000 with one process per GPU:**
  - The third and fourth processes hung after "app ready".
  - Logs showed "Disabling key-value database because another kit process is locking it" and "Waiting for RtPso async group async compilation: 165 seconds so far".
  - A reply recommended containers with one GPU each, or one Kit instance with multiple viewports. No confirmed fix.
  - Source: [NVIDIA forum 331011](https://forums.developer.nvidia.com/t/trouble-running-multiple-isaac-sim-processes/331011)

### Inferences
- **Our own throughput** (derived from the brief). 2,000 control steps in 7–9 minutes is 3.7–4.8 control steps per second, or about 22–29 physics steps per second at 6 substeps per control step. That is about 0.19–0.24× real time for a full-horizon episode, including policy inference and multi-view rendering.
- **Cheapest likely speed-up: two simulators per 4090 sharing one policy server.** About 4 + 4 GB for the simulators plus about 9 GB for the server (13 − 4) is about 17 GB, which is under 24 GB. ManiGuard's 1.5–1.8× was measured without a policy server; evaluation with an inference wait is even more latency-bound, so the gain may hold or grow.
  - This is unverified. Launches must be staggered (Section 7).
  - Watch for the kvdb-lock and RtPso hangs seen on Isaac Sim 4.5.
- **If the pipeline starts a new process per episode**, the 150–300 s scene load could be a large share of the 7–9 minutes. Section 5's in-process reset would then cut wall-clock per episode substantially. This is conditional on how the current lanes are structured.
- **`VectorEnvironment` is a training-only option for a single task.** All copies share one configuration and step in lockstep, so the slowest copy sets the pace and render cost scales with copies × views. It is untested with ManiGuard snapshots, monitors and controllers, so the engineering risk is high for this attempt.
- **Feature trimming has limits.** In Table A.10, removing fluid and cloth plus object-state updates raised simulation speed about 3–5×: 24 to 77 steps/s in Rs_int and 11 to 55 in house_single_floor, if the rows are cumulative. ManiGuard's goal checker and LTL predicates (`jar_closed`, `jar_on_support`, upright) may rely on them, so verify before disabling anything. Both arms must use the same settings.

### Gaps
- No published `VectorEnvironment` throughput or memory figures for OmniGibson 3.x were found.
- No OmniGibson 3.7.x steps-per-second figures on an RTX 4090 were found.
- The NVIDIA GTC 2024 BEHAVIOR slides have figures with and without rendering, but the extraction was garbled, so none are reported here.
- ManiGuard's 1.5–1.8× applies to data collection, not to evaluation with a policy server.
- Cold and warm start-up times for an Isaac Sim 4.5 pip install were not found in NVIDIA documentation; the 4.5 installation pages returned 404.

## 7. Why do concurrent cold starts collide in the Isaac Sim / Kit extension cache, and what fixes work?

### Takeaway
OmniGibson's kit file adds a dependency on `omni.flowusd`, which is not in Isaac Sim's bundled `extscache`. Kit therefore downloads it, along with `omni.usd.schema.flow`, from the online registry on first launch, into a global package cache shared by every lane using the same OmniGibson appdata directory. Simultaneous cold starts race on that download and unpack. The robust fix is to do the first launch once, serially, then either run lanes from that warmed cache under a launch lock or copy it into per-lane `OMNIGIBSON_APPDATA_PATH` directories, and bake it into the host image.

### Cited Findings
- **The dependency.** OmniGibson's `omnigibson_4_5_0.kit` lists `"omni.flowusd" = {}` under `[dependencies]` (added relative to `isaacsim.exp.base.python.kit` per `kit_file_changes.patch`). It configures registries `kit/default` (`…/exts/kit/prod/106/shared`), `kit/sdk` and `kit/community`, and sets `[settings.app.extensions] pathStatCacheEnabled = false` — [omnigibson_4_5_0.kit](https://github.com/StanfordVL/BEHAVIOR-1K/blob/88454bd04f75dc57c00ab1f1a00bcde1ff505950/OmniGibson/omnigibson/omnigibson_4_5_0.kit); [kit_file_changes.patch](https://github.com/StanfordVL/BEHAVIOR-1K/blob/88454bd04f75dc57c00ab1f1a00bcde1ff505950/OmniGibson/omnigibson/kit_file_changes.patch)
- **Air-gapped OmniGibson on Isaac Sim 4.5** (NVIDIA forum):
  - It failed with "[omnigibson_4_5_0-1.5.0] dependency: 'omni.flowusd' = { version='^' } can't be satisfied. Available versions: (none found)" and "Exiting app because of dependency solver failure".
  - The poster found `omni.flowusd` absent from `extscache`.
  - Setting `registryEnabled = false`, `syncRegistry = false` and `registries = []`, plus `--ext-folder`, did not help. The thread was closed without a solution.
  - Source: [NVIDIA forum 365085](https://forums.developer.nvidia.com/t/air-gapped-deployment-app-exits-due-to-dependency-solver-failure-omni-flowusd-despite-disabling-registry-sync-in-offline-l20-cluster/365085)
- **Where OmniGibson points Kit.** `_launch_app()` appends `--portable-root <APPDATA>/local`, `--/app/tokens/omni_global_cache=<APPDATA>/global/cache` and `--/app/tokens/omni_global_data=<APPDATA>/global/data`. It also copies the kit file into Isaac Sim's `EXP_PATH` "on every launch" with `shutil.copyfile`. `og.launch` is `_launch_simulator` — [simulator.py](https://github.com/StanfordVL/BEHAVIOR-1K/blob/88454bd04f75dc57c00ab1f1a00bcde1ff505950/OmniGibson/omnigibson/simulator.py); [__init__.py](https://github.com/StanfordVL/BEHAVIOR-1K/blob/88454bd04f75dc57c00ab1f1a00bcde1ff505950/OmniGibson/omnigibson/__init__.py)
- **OmniGibson's own warning.** `gm.APPDATA_PATH = os.getenv("OMNIGIBSON_APPDATA_PATH", <OmniGibson repo>/appdata)`. The comment reads: "on HPC clusters like SLURM you ideally want to put this in a local path rather than a networked filesystem where read/writes are slow and race conditions can occur." — [macros.py](https://github.com/StanfordVL/BEHAVIOR-1K/blob/88454bd04f75dc57c00ab1f1a00bcde1ff505950/OmniGibson/omnigibson/macros.py)
- **Kit's global package cache.** Its location is `/exts/omni.kit.registry.nucleus/cachePath` plus `cacheVersionSubdir`, "default `${omni_global_data}/exts/v2`". It "is shared by every Omniverse app on the machine" and holds the downloaded packages plus "the registry index and URL caches used for offline startup".
  - Per-app cache (`/app/extensions/registryCache`) entries "are links into the global cache rather than copies" when `cacheCreateLinks` is on, which is the default.
  - The cache cannot be cleaned from a running app; "close every Omniverse app on the machine first".
  - This documentation is for `omni.kit.window.extensions` 1.7.0, a newer Kit than Isaac Sim 4.5's Kit 106 — [Kit Extensions window docs](https://docs.omniverse.nvidia.com/kit/docs/omni.kit.window.extensions/1.7.0/Overview.html)
- **Kit command-line flags:**
  - `--ext-precache-mode`: "Only resolve and download all extensions, exit right after."
  - `--portable-root PATH`: "Enable portable mode and place data/cache/logs folders there."
  - `--ext-folder PATH`: "Add extension folder to look extensions in."
  - `--clear-cache` and `--clear-data`.
  - Source: [Kit SDK overview](https://docs.omniverse.nvidia.com/kit/docs/kit-app-template/latest/docs/kit_sdk_overview.html)
- **Kit 106.3 registry provider.**
  - Registries are "pulled in order" and can be local filesystem paths; the HTTP backend is read-only.
  - An `optional` flag ignores unreachable registries.
  - The override syntax is `kit --/exts/omni.kit.registry.nucleus/registries/0/url=...`.
  - Extensions are stored as zip archives plus an `index.zip`.
  - Source: [omni.kit.registry.nucleus 106.3.0](https://docs.omniverse.nvidia.com/kit/docs/omni.kit.registry.nucleus/106.3.0/Overview.html)
- **Disabling the registry.** The Kit manual lists `/app/extensions/registryEnabled` with default `true` (per a search snippet of a newer, 110.x manual) — [Kit manual 110.1.2](https://docs.omniverse.nvidia.com/kit/docs/kit-manual/110.1.2/index.html)
- **Cache persistence in containers.** Isaac Lab's Docker guide persists Isaac Sim caches as named volumes: `/isaac-sim/kit/cache`, `/root/.cache/ov`, `/root/.cache/nvidia/GLCache` and `/root/.nv/ComputeCache`. These "store frequently re-used resources compiled by Isaac Sim, such as shaders" (per search summary) — [Isaac Lab Docker guide](https://isaac-sim.github.io/IsaacLab/v2.3.1/source/deployment/docker.html)
- **Concurrent launches.** On Isaac Sim 4.5, concurrent processes showed kvdb-lock warnings, 165-second RtPso compilation waits and hangs of the third and fourth processes — [NVIDIA forum 331011](https://forums.developer.nvidia.com/t/trouble-running-multiple-isaac-sim-processes/331011). ManiGuard advises "stagger launches" — [data_collection/index.md](https://github.com/NU-IDEAS-Lab/ManiGuard/blob/6bf4c61a1f168cc46e02eb22c41bcb51815e9726/docs/data_collection/index.md)

### Inferences
Ranked fixes, most robust first:
1. **Serial warm-up per host, once, before any lane starts.**
   - Use the same `OMNIGIBSON_APPDATA_PATH` the lanes will use. Run, for example, `python -c "import omnigibson as og; og.launch()"`, then load one jar snapshot and step it once so the shader and material caches compile.
   - Confirm that `<APPDATA>/global/data/exts/v2` now contains `omni.flowusd` and `omni.usd.schema.flow`.
   - This matches the DSRL-11 lesson ("warm Isaac Sim serially").
2. **A launch lock.** Wrap each lane's start-up in an exclusive `flock` on a file in the appdata directory, held until the simulator reports ready or the first `env.reset()` returns.
   - This serialises only the risky phase: registry sync, extension unpacking, the kit-file copy and shader compilation. Episodes still run in parallel.
   - It also removes the smaller race on `shutil.copyfile` of the kit file into the shared `EXP_PATH`.
3. **Per-lane appdata directories** on local disk via `OMNIGIBSON_APPDATA_PATH`, seeded by `cp -a` from the warmed template. This removes cache sharing entirely.
   - Verify that Kit's per-app-cache links survive the copy, or copy after resolving them.
   - Without a template, each lane would download and compile on its own, which is slower but race-free.
4. **Bake the warmed caches into the host image or a restore tarball.** That means the appdata directory and the GLCache, ComputeCache and `~/.cache/ov` caches. A fresh host then needs no registry access, and part of the 32-minute preparation disappears.
5. **Make `omni.flowusd` resolvable locally.** Place the downloaded extension folders in a directory passed with `--ext-folder`, or into the `extscache` directory already listed in the kit file's `exts.folders`. Only then consider disabling the registry; the forum case shows disabling it alone fails while the extension is missing.
6. **`--ext-precache-mode`** is the Kit-native "download everything and exit" step. It would need a small launcher that reproduces OmniGibson's arguments (experience file, `--portable-root`, global tokens), so it is untested with OmniGibson.
7. **Lane watchdog.** Kill and relaunch any lane not ready within a timeout of several minutes, given the 165-second-plus RtPso waits seen elsewhere. Retry a `FileExistsError` once after a back-off, by which time the competing process has usually finished unpacking. This retry rule is my inference.

### Gaps
- No source documents the exact `FileExistsError` race for `omni.flowusd` / `omni.usd.schema.flow`, or whether Kit 106 unpacks atomically (temporary folder then rename) or takes a lock.
- `--ext-precache-mode` has not been tested with OmniGibson's launch path.
- Whether `registryEnabled = false` under `[settings.exts]` (the maintainer's suggestion) works in Isaac Sim 4.5 was never confirmed in the thread.
- The Kit documentation pages cited are partly for newer Kit versions; equivalent settings in Kit 106.x were assumed, not verified.
- I found no measured cold-start versus warm-start times for Isaac Sim 4.5 pip installs.

## 8. What do the ManiGuard paper and repository say about evaluation seeds, determinism and episode counts?

### Takeaway
ManiGuard evaluates each of 1,000 frozen scenarios once per seed for three policy-sampling seeds (3,000 rollouts per policy), averages rates over seeds, and states that residual renderer nondeterminism cannot be removed. It gives no recommended episode count for comparing methods; per-scenario n is 3, and power comes from the 1,000 scenarios.

### Cited Findings
- **Protocol.** 200 base tasks × 5 conditions = 1,000 frozen scenarios. "Each policy is evaluated once per scenario under three policy-sampling seeds, yielding 3,000 rollouts per policy". "Every reported rate is the mean over the three seeds, each seed being one complete pass over the evaluation set." — [ManiGuard paper](https://arxiv.org/pdf/2608.17386)
- **Seeding and determinism.** The per-rollout seed is a CRC-32 hash of the base seed and the scenario name, so seeding "does not depend on the order in which scenarios are run". There are bit-identical initial states and bit-identical π action chunks under a fixed key, but the renderer "is not bit-reproducible across processes": 39% of pixels differed, and episode lengths diverged — [ManiGuard paper](https://arxiv.org/pdf/2608.17386)
- **Rollout mechanics.**
  - Policies re-infer after 8 executed actions.
  - A rollout ends once the goal predicate holds for 10 consecutive steps, or at the horizon: jar = 2,000 steps, set at "1.5× the longest scripted demonstration".
  - Control is joint-position at 20 Hz over 120 Hz physics, with 256×256 observations.
  - The monitor scores φ every step but never aborts a rollout.
  - Source: [ManiGuard paper](https://arxiv.org/pdf/2608.17386)
  - The jar config comment gives demonstration lengths of "778/902/1308 min/med/max steps" — [jar_transport_joint.yaml](https://github.com/NU-IDEAS-Lab/ManiGuard/blob/6bf4c61a1f168cc46e02eb22c41bcb51815e9726/configs/eval/jar_transport_joint.yaml)
- **Sim-to-real study.** "n = 30 rollouts per cell in each domain" across 12 matched cells — [ManiGuard paper](https://arxiv.org/pdf/2608.17386)
- **Repository practice** — [run_benchmark.md](https://github.com/NU-IDEAS-Lab/ManiGuard/blob/6bf4c61a1f168cc46e02eb22c41bcb51815e9726/docs/evaluation/run_benchmark.md)
  - "`REPEAT=3` alone does not select three distinct seeds"; run seeds 0, 1 and 2 into separate directories.
  - Use `eval_summary.py --expected-seeds 0 1 2` so that "an entirely absent seed run cannot go unnoticed".
  - Plans are saved in `expected_rollouts.json` before any run.
  - Any non-completed attempt makes the aggregate rates `null`.
  - SSR, Pr[success ∧ safe], is "the headline".
- **Silent failure risk.** The benchmark's long-finger gripper bundle is not in the BEHAVIOR dataset. Without it, "OmniGibson loads the stock hand **without any error**", and policies "approach objects but never quite grasp them" — [run_benchmark.md](https://github.com/NU-IDEAS-Lab/ManiGuard/blob/6bf4c61a1f168cc46e02eb22c41bcb51815e9726/docs/evaluation/run_benchmark.md)

### Inferences
- **Per-task rates are noisy.** ManiGuard's per-task outcomes rest on n = 3, and its claims rely on aggregation across many scenarios. Per-task base rates for the jar tasks (0–75%) estimated from small n are similarly imprecise; for example, the Wilson 95% interval for 5/20 is 11–47% (Section 1). Re-measure the native rate on the exact task mix inside the concurrent-control stage.
- **What to adopt from ManiGuard:**
  - Its order-independent CRC-32 seed derivation, for bookkeeping.
  - Saved expected-rollout manifests before running, as pre-registration.
  - The rule that any failed attempt blocks an aggregate until it is resolved.
  - Treat repeats as independent draws, since outcomes do not reproduce.
- **Pre-flight check.** Confirm `franka_panda_longfinger` exists on every fresh host before Gate 0. A missing bundle would silently depress both arms.

### Gaps
- I did not check whether the paper reports across-seed standard deviations or confidence intervals.
- I did not extract the paper's π0.5 jar-family numbers (out of scope).
- ManiGuard gives no guidance on the number of episodes needed to compare two policies on a task subset.
