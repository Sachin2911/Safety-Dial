# Steering and adapting frozen generative robot policies under small budgets

Scope: interfaces that improve a frozen diffusion or flow policy (including VLAs) while keeping its native competence, judged against a frozen pi0.5 on long (about 250-query) episodes with sparse, binary, noisy outcomes and 60 to 120 online episodes per attempt.

Conventions: [real] = real-robot result; [sim] = simulation; **[2026]** = work first posted in 2026; "(claim)" = stated in the abstract or introduction but not checked against a table in the body. Numbers come from the latest arXiv HTML version unless stated, and the version is noted where it matters. Any arithmetic of mine is labelled "my calculation" and appears only under Inferences.

## Q1. V-GPS ("Steering Your Generalists", Nakamoto et al., CoRL 2024): method, critic, sample count K, gains and failure modes

### Takeaway
V-GPS samples K actions from a frozen generalist and executes the one a separately trained critic scores highest. The critic is a language-conditioned Cal-QL Q-function, trained offline on roughly 175K Bridge V2 and Fractal trajectories with a "last 3 steps = success" sparse reward. It used K = 50 with greedy selection on the real robot. On real WidowX it lifted Octo-small-1.5 from 24% to 44% average success. In SIMPLER the gains were small and sometimes negative for stronger policies, and an IQL critic was exploited as K grew. Two later papers report that V-GPS does not help when re-used on other policies: it gave no significant gain on pi0 in simulation (DSRL) and fell below base OpenVLA on out-of-distribution real tasks (RoboMonkey).

### Cited Findings
- **Method.** At each step V-GPS samples K actions from the generalist and picks one by softmax over Q/β, which becomes greedy as β→0. It needs only black-box access to the policy: no fine-tuning and no access to weights. [real+sim] — [V-GPS](https://arxiv.org/abs/2410.13816)
- **Reward labelling.** The last H = 3 transitions of each trajectory are labelled +1 (implemented as shifted rewards 0/−1) and all others 0/−1, following Kumar et al. Discount γ = 0.98. — [V-GPS](https://arxiv.org/abs/2410.13816)
- **Critic choice.** Cal-QL is the main critic because the authors want a "best in support" approximation of the optimal value that is also "robust to noisy actions due to its conservative objective". IQL is shown in an appendix to work as well. — [V-GPS](https://arxiv.org/abs/2410.13816)
- **Critic training details.**
  - Architecture: ResNet-34 image encoder with FiLM conditioning on a frozen MUSE language encoder; the 7-D action is concatenated with the image features and passed through two 256-unit layers.
  - Data: a mix of Bridge V2 (45K trajectories) and Fractal (130K episodes).
  - Settings: batch 512 on a TPU v4-8. Cal-QL used α = 5 for 1M steps; IQL used expectile 0.7 for 200K steps. Augmentation was random crop plus colour jitter, with clipped double-Q.
  - The authors say they "do not assume access to any additional data beyond what the generalist policies were pre-trained on".
  — [V-GPS](https://arxiv.org/abs/2410.13816)
- **K and β.** Real world: K = 50 with greedy selection (β→0). Simulation: they swept K ∈ {10, 50} and β ∈ {0, 0.1, 1.0} and report the best result per policy. — [V-GPS](https://arxiv.org/abs/2410.13816)
- **Real-world result** [real] (WidowX, 6 tasks, 20 trials each): Octo-small-1.5 average 0.24 → 0.44 (reported as +82.8% relative). Examples: green pepper in pot 0.15 → 0.35; mushroom on cloth 0.35 → 0.70. — [V-GPS](https://arxiv.org/abs/2410.13816)
- **SIMPLER result** [sim] (Octo and RT-1-X: 100 trials × 3 seeds; OpenVLA: 50 trials). Overall averages:
  - Octo-small 0.27 → 0.34
  - Octo-base 0.17 → 0.18
  - Octo-small-1.5 0.02 → 0.18
  - RT-1-X 0.12 → 0.14
  - OpenVLA 0.24 → 0.27

  Some tasks got worse, for example Octo-small spoon-on-towel 0.52 → 0.46 and Octo-base pick-can 0.29 → 0.24. — [V-GPS](https://arxiv.org/abs/2410.13816)
- **Critic exploitation as K grows** [sim]. With IQL, the eggplant task scored 0.59 at K = 10, falling to 0.47, 0.42 and 0.35 at K = 30, 50 and 100. Cal-QL was more robust: 0.77, 0.81, 0.84, then 0.63 at K = 100. The base was 0.49. The authors write that "increasing K leads to the exploitation of the value function". — [V-GPS](https://arxiv.org/abs/2410.13816)
- **Dataset-size ablation** [sim, eggplant task, IQL critic]. Base 0.49 → 0.59 with 100% of Bridge, 0.59 with 50%, 0.55 with 10%. — [V-GPS](https://arxiv.org/abs/2410.13816)
- **Both parts are needed.** Random selection among the K samples scored 0.49, the same as the base. A random policy combined with the V-GPS critic scored 0.00. The Cal-QL and IQL actors used on their own scored 0, typically because they never learned to close the gripper. — [V-GPS](https://arxiv.org/abs/2410.13816)
- **Inference overhead** (Octo-small): K = 10 is 1.28× slower, K = 50 is 1.59×, K = 100 is 2.12×. — [V-GPS](https://arxiv.org/abs/2410.13816)
- **Failure modes and limits.** V-GPS fixed imprecise grasping, releasing objects too early and holding them too long. The authors note it has limited ability with unseen language and objects because the critic saw only two embodiments. — [V-GPS](https://arxiv.org/abs/2410.13816)
- **Later independent comparisons.**
  - RoboMonkey found the V-GPS value function is exploited "when sampling more than 8 actions". In its out-of-distribution real WidowX tasks, V-GPS (30%) scored below plain OpenVLA (35%). [real] — [RoboMonkey](https://arxiv.org/abs/2506.17811)
  - DSRL reports that "neither ResiP nor V-GPS are able to significantly improve the performance of π0" on LIBERO and AlohaTransferCube. [sim] — [DSRL](https://arxiv.org/abs/2506.15799)

### Inferences
- V-GPS's data budget is far above ours. Even its 10%-of-Bridge ablation is about 4.5K demonstration trajectories, roughly 20–45× our 100–200 native episodes. Its gains are therefore not evidence that a Q-function trained on about 150 episodes will rank pi0.5 chunks well.
- Its supervision is mostly successful demonstrations labelled by "reached the end". Our native rollouts include real failures, which makes our data closer to the success-versus-failure verifiers in Q2 (DiVeR, FOREWARN's classifier) than to V-GPS's Cal-QL recipe.
- V-GPS selected single 7-D actions at 5 Hz on easy pick-and-place. Our setting is 16×32 chunks, about 250 decisions per episode and contact-critical failures. The two clearest cross-policy re-uses (DSRL on pi0 in simulation, RoboMonkey on OpenVLA out of distribution) showed no gain, so transfer to a strong flow VLA is unproven.

### Gaps
- I found no V-GPS-author result with pi0 or pi0.5, and none with chunked flow VLAs or with tens of episodes of task-specific data.
- arXiv v1 (17 Oct 2024) and v2 (24 Feb 2025) share a title. I did not diff their contents.

## Q2. Related test-time selection: RoboMonkey, learned verifiers and value functions, Hume, FOREWARN, ITPS, DynaGuide and 2024–2026 successors

### Takeaway
Sample-then-select improves a frozen policy only when two conditions hold: the candidates already contain a better behaviour, and the verifier was trained close enough to the deployment distribution to rank them. Reported real-robot gains run from about +10 to +50 points, mostly on short tabletop tasks, and verifiers are exploited as N grows. For flow VLAs the binding constraint is candidate diversity, which is concentrated in a few "decision-critical" states such as pre-grasp and pre-placement.

The closest match to our data and failure pattern is DiVeR **[2026]**. It trained an outcome-labelled verifier on 160 real pi0.5 rollouts (94 successes, 66 failures), weighted training toward pre-grasp and pre-placement states, and raised real Franka success from 58.3% to 71.9% at N = 16.

### Cited Findings

#### RoboMonkey (Kwok et al., arXiv 2506.17811 v2)
- **Verifier.** A VLM-based reward model fine-tuned with LoRA on 20 million synthetic action-preference comparisons generated from Bridge V2 (over 40K trajectories). Preferences are labelled by RMSE to the ground-truth demonstration action, so the verifier is an imitation-quality score rather than an outcome score. Training used 8 H100s. — [RoboMonkey](https://arxiv.org/abs/2506.17811)
- **Deployment.** Sample N̂ actions from OpenVLA at positive temperature. Fit a Gaussian to the translation and rotation components and take a majority vote for the gripper. Sample K̂ candidates from that Gaussian and execute the argmax of the verifier. Real-world settings: 5 initial samples at T = 1.0 and 16 candidates. — [RoboMonkey](https://arxiv.org/abs/2506.17811)
- **Results.**
  - [real] WidowX out of distribution (4 suites × 10 trials): RoboMonkey 60%, OpenVLA 35%, V-GPS 30%.
  - [sim] SIMPLER in distribution: 47.5% average, +9 points over OpenVLA.
  - [sim] LIBERO-Long with a fine-tuned verifier: 49.8% → 56.5% over 500 trials.
  — [RoboMonkey](https://arxiv.org/abs/2506.17811)
- **Data scaling.** SIMPLER success rose from 37.5% to 46.3% as the synthetic dataset grew. Above about 10⁶ comparisons it beat both OpenVLA and V-GPS. — [RoboMonkey](https://arxiv.org/abs/2506.17811)
- **Candidate generation.** At equal compute, Gaussian perturbation gave lower oracle action error than repeated policy sampling. The authors flag that the overhead may make the method "less suitable for tasks requiring high-frequency control". — [RoboMonkey](https://arxiv.org/abs/2506.17811)

#### MG-Select (Jang et al., arXiv 2510.05681; v2 notes "Accepted to ICLR 2026")
- **Method.** Verifier-free best-of-N for autoregressive VLAs. It scores candidates by the KL divergence of their action tokens from a condition-masked reference distribution. It evaluates pi0-FAST, which is not a flow head. — [MG-Select](https://arxiv.org/abs/2510.05681)
- **Results (claim).**
  - [real] +28% in-distribution and +35% out of distribution.
  - [sim] RoboCasa trained on 30 demonstrations: 5.3% → 14.2%.
  — [MG-Select](https://arxiv.org/abs/2510.05681)

#### Hume (Song et al., arXiv 2505.21432 v4)
- **Method.**
  - A value-query head on the VLA backbone is trained offline with Cal-QL on demonstration data, using the V-GPS reward recipe (last 3 transitions = +1).
  - System 2 samples N = 5 candidate chunks (horizon H = 30) at different noise levels at 4 Hz and picks the argmax-Q one.
  - System 1 then finishes denoising the chosen chunk.

  Hume is a separately trained model, not steering of a frozen policy. — [Hume](https://arxiv.org/abs/2505.21432)
- **Ablations** (the fair test of selection is one candidate versus five):
  - Using a single candidate costs −4.8 points on LIBERO, −6.2 on SimplerEnv and −37% in the real world.
  - Fully denoising every candidate (no cascade) "leads to all candidates being sampled from the same distribution", which "reduces the range of candidates" (−2.7 LIBERO, −19% real).
  - Random choice among partially denoised candidates costs −13.7 on LIBERO and −78% in the real world.
  — [Hume](https://arxiv.org/abs/2505.21432)

#### FOREWARN (Wu et al., arXiv 2502.01828 v3)
The arXiv title in v1–v3 is "From Foresight to Forethought: VLM-In-the-Loop Policy Steering via Latent Alignment", not "VLM-Assisted".
- **Setup.**
  - Base: a Diffusion Policy trained on 100 teleoperated demonstrations per task.
  - World model: DreamerV3, trained on 250 real rollouts per task (successes and failures) plus the 100 demonstrations, split 300 for training and 50 for test.
  - Verifier: a Llama-based VLM fine-tuned with LoRA to narrate predicted latent rollouts.
  - Deployment: sample 100 plans, reduce them to K = 6 modes with non-maximum suppression, and pick one with the VLM.
  — [FOREWARN](https://arxiv.org/abs/2502.01828)
- **Results** [real] (20 trials; success requires matching the user's stated preference):

  | | Cup | Bag | Fork |
  |---|---|---|---|
  | Training descriptions: base | 0.30 | 0.20 | 0.10 |
  | Training descriptions: FOREWARN | 0.80 | 0.70 | 0.70 |
  | Novel descriptions: base | 0.50 | 0.40 | 0.30 |
  | Novel descriptions: FOREWARN | 0.80 | 0.70 | 0.60 |

  — [FOREWARN](https://arxiv.org/abs/2502.01828)
- **A simpler baseline matched it in distribution.** A plain outcome classifier on predicted world-model latents ("Classifier-Dyn-Latent") equalled FOREWARN on the training descriptions (0.80/0.70/0.70). It collapsed on novel descriptions (0.00/0.10/0.20). — [FOREWARN](https://arxiv.org/abs/2502.01828)

#### ITPS (Wang et al., ICRA 2025, arXiv 2411.16627 v2)
- **Setting.** Frozen Diffusion Policy or ACT policies, steered at inference by a user's point or sketch. The paper names an "alignment–constraint satisfaction trade-off". — [ITPS](https://arxiv.org/abs/2411.16627)
- **Maze2D** [sim] (DP collision rates): post-hoc ranking 0.01, output perturbation 0.02, guided diffusion 0.06, stochastic sampling 0.01. Stochastic sampling also gave the best alignment. — [ITPS](https://arxiv.org/abs/2411.16627)
- **Block stacking** [sim] (DP; TA = task alignment, CS = constraint satisfaction):

  | Method | TA | CS |
  |---|---|---|
  | Post-hoc ranking | 33% | 100% |
  | Guided diffusion, no guidance in the early steps (β_{i<50} = 0) | 83% | 84% |
  | Guided diffusion, strong guidance throughout (β = 100) | 86% | 15% (71% "aligned failures") |

  Multimodal DP with ranking improved alignment "without significant distribution shift"; unimodal ACT was harder to steer. — [ITPS](https://arxiv.org/abs/2411.16627)

#### DynaGuide (Du & Song, arXiv 2506.13922; v2 "Presented at NeurIPS 2025", v1 "Submitted")
- **Method.** Gradient guidance during denoising from a separately trained latent dynamics model in DinoV2 space. That model was trained on CALVIN play data, or on UMI data for the real robot. — [DynaGuide](https://arxiv.org/abs/2506.13922)
- **Results.**
  - [sim] Target behaviour reached 70% (8.7× the base policy); 5.4× better than goal conditioning on lower-quality objectives; 40% success with only 1% of the target behaviour left in the training data.
  - [real] Cup-colour preference 72.5%; hidden cup found 80% of the time.
  — [DynaGuide](https://arxiv.org/abs/2506.13922)
- **Sampling baseline and guidance strength.** The sampling-based variant (GPC-style best-of-N) "drops to the base policy" on MovableObjects and struggles with underrepresented behaviours. Higher guidance scale "create[s] less smooth or even incoherent trajectories". — [DynaGuide](https://arxiv.org/abs/2506.13922)

#### PA-RL (Mark et al., arXiv 2412.06685 v1)
This is not a frozen-policy method: it distils the optimised actions back into the policy.
- **Action optimisation.** Sample k = 32 actions from the base, keep the top m = 10 by Q, then take 10 gradient-ascent steps on each action (step size 3e-4). The selected actions are then distilled. — [PA-RL](https://arxiv.org/abs/2412.06685)
- **Results** [real]:
  - Diffusion policy: cup to drying rack 55% → 90%; pot to sink 80% → 100%.
  - OpenVLA: 40% → 70% "after 1 hour of zero-shot trials … and 40 minutes of online RL fine-tuning".
  - Overall, 40 minutes to 2 hours "(i.e., 10–70 episodes)" of real interaction.
  - They found it "important to collect 20 warm-up episodes", and observed a performance drop over the first 50 episodes of the cup task.
  — [PA-RL](https://arxiv.org/abs/2412.06685)

#### EXPO (Dong et al., arXiv 2507.07986; v3 of Apr 2026 notes "changed formatting, added code")
- **Method.** The executed action is the argmax-Q among N base samples and their Gaussian "edits". Edits are bounded to [−β, β] with β between 0.05 and 0.7. The base policy is trained with an imitation loss, so it is not frozen. — [EXPO](https://arxiv.org/abs/2507.07986)
- **Selection alone is not enough.** In the ablation, sampling only from the base and taking max-Q made it "often hard to improve pretrained policies online". — [EXPO](https://arxiv.org/abs/2507.07986)

#### Bidirectional Decoding, BID (Liu et al., arXiv 2408.17355 v4)
- **Result** [sim]. Sampling-based chunk selection using backward coherence and forward contrast: +32% relative over vanilla on seven tasks, and +46% combined with EMA. — [BID](https://arxiv.org/abs/2408.17355)
- **Cost on pi0.5.** With batch 16, BID had 2.3× the latency of RTC and underperformed it in simulation. — [RTC](https://arxiv.org/abs/2506.07339)

#### 2026 test-time selection and guidance
- **DiVeR [2026]** (Park et al., arXiv 2610.04933 v1, 4 Oct 2026).
  - *Verifier.* A discriminator trained on trajectory-level success/failure labels, using pi0 or pi0.5 action-expert representations. Each state's weight is its "decision criticality", the dispersion of K = 32 candidates sampled by redrawing the initial noise.
  - *Where criticality sits.* High-criticality states are "sparse and temporally localized" (pre-grasp, pre-placement). In routine states such as free-space motion and post-grasp transport, candidates "remain highly similar". Criticality correlates with a rollout-based oracle at Spearman ρ = 0.493.
  - *Simulation results* [sim]: on LIBERO-Long, +5.9 points (pi0) and +11.6 points (pi0.5) on average over single-sample inference. Random selection among the N candidates gave only marginal gains.
  - *Real results* [real]: Franka FR3, pi0.5 LoRA-tuned on 40 demonstrations per task, N = 16, 24 trials per task. Base 58.3% → uniformly weighted verifier 65.6% → DiVeR 71.9%.
  - *Data.* The real verifier was trained on 94 successful and 66 failed pi0.5 rollouts (12,387 and 12,012 steps). Candidate sampling reuses the VLM computation through KV caching.

  — [DiVeR](https://arxiv.org/abs/2610.04933)
- **Q-VGM [2026]** (arXiv 2606.08015 v5). This fine-tunes the action expert, so it is not frozen. The v1 title was "Q-VGM: Q-Guided Value-Gradient Matching for Flow-Matching VLA Policies" with an off-policy framing; v5 is retitled "…for Offline-to-Online RL…".
  - An IQL chunk critic trained offline on "150 policy rollouts per suite" improved LIBERO few-shot SFT from 84.6% to 90.7% [sim].
  - Offline training improved three real bimanual tasks from 66.7% to 98.3% [real].
  — [Q-VGM](https://arxiv.org/abs/2606.08015)
- **QPILOTS [2026]** (arXiv 2606.14801). Test-time critic-gradient guidance that evaluates the critic on the projected clean action. On frozen pi0.5-LIBERO it "improves over the zero-shot base on every evaluated task and surpasses DSRL on average", with learning curves run to 5×10⁵ steps [sim]. The steering coefficient "requires manual tuning per domain (or per task on LIBERO)". — [QPILOTS](https://arxiv.org/abs/2606.14801)
- **AGF [2026]** (arXiv 2609.34944). Amortises critic guidance into a small network while the VLA and a SARSA-style critic stay frozen. Tested on SmolVLA, pi0.5 and MolmoAct2 across LIBERO, RoboCasa, LIBERO-Pro and a real robot. Claims it is "the most robust method when a single guidance strength is deployed" and 3.6× faster per step than QGF (claim). — [AGF](https://arxiv.org/abs/2609.34944)
- **SDN [2026]** (arXiv 2606.14084). Training-free selection of initial noise using k-NN contrast between the normal view and an object-masked view, plus a smoothness score. Tested on pi0 and GR00T N1.5/N1.6. Claims +8% in simulation and +10% on real robots (claim). — [SDN](https://arxiv.org/abs/2606.14084)
- **VLA-Pilot** (arXiv 2511.14178; v2 Apr 2026).
  - *Method.* An MLLM chain-of-thought verifier scores proposals. Evolutionary search keeps the elite and mutates it by "truncated diffusion-denoising" (partial re-noising).
  - *Setting.* Frozen DiVLA and RDT-1B; no data collection.
  - *Result.* Claims +31% average success across six real tasks (claim).

  — [VLA-Pilot](https://arxiv.org/abs/2511.14178)
- **FASTER [2026]** (arXiv 2604.19730). Learns to filter candidates part-way through denoising. On a pretrained VLA it claims "the same performance while substantially reducing training and inference compute" (claim). — [FASTER](https://arxiv.org/abs/2604.19730)

#### Background: why best-of-N from a behaviour policy is principled
- In IDQL, the IQL critic induces "an implicit actor distribution that can be expressed as a reweighting of the behavior policy". SfBC "uses importance reweighting from a diffusion behavior model". — [IDQL](https://arxiv.org/abs/2304.10573)

#### Version notes (arXiv)
- V-GPS v1 (Oct 2024) and v2 (Feb 2025): same title. — [V-GPS](https://arxiv.org/abs/2410.13816)
- DSRL v1 (18 Jun 2025) and v2 (25 Jun 2025). — [DSRL](https://arxiv.org/abs/2506.15799)
- Hume v1 (May 2025) through v4 (Jul 2025). — [Hume](https://arxiv.org/abs/2505.21432)
- RoboMonkey v1 (Jun 2025) and v2 (Jul 2025). — [RoboMonkey](https://arxiv.org/abs/2506.17811)
- ResiP's v1 title was "…Residual RL for Precise *Visual* Assembly"; v4 (Dec 2024) dropped "Visual". — [ResiP](https://arxiv.org/abs/2407.16677)
- UniSteer v1 was titled "Unified Noise Steering…"; v2 (Jul 2026) prefixes "UniSteer:". — [UniSteer](https://arxiv.org/abs/2605.10821)
- Much Ado About Noising: v1 Dec 2025, v3 Feb 2026. — [Much Ado](https://arxiv.org/abs/2512.01809)
- Golden Ticket: v4 dated 3 Oct 2026. — [Golden Ticket](https://arxiv.org/abs/2603.15757)
- pi_RL: v3 Jan 2026. — [πRL](https://arxiv.org/abs/2510.25889)
- I did not diff the bodies of any of these versions.

### Inferences
- Effect sizes track how weak the base is and how in-distribution the verifier is. The biggest gains (FOREWARN, RoboMonkey out of distribution, V-GPS real) sat on bases at 10–35%, with verifiers trained on hundreds to millions of in-domain samples. On stronger bases (V-GPS SIMPLER on OpenVLA, DiVeR LIBERO pi0) gains were a few points.
- With our native strict success at about 25% (0–75% across tasks), a +10 to +15 point gain is the realistic literature-anchored expectation for an outcome verifier trained on about 150 rollouts.
- Selection preserves base competence by construction, because every executed chunk is a native pi0.5 sample. The risk moves to verifier exploitation (V-GPS K ablation, RoboMonkey's ">8 actions", image-diffusion verifier hacking in Q4). So keep N moderate (8–16) and prefer conservative or ensembled verifiers.
- DiVeR's finding that candidates only diverge at pre-grasp and pre-placement states lines up with our failures concentrating at contact and at grasping after lid closure. This is the strongest literature signal that selection, and steering generally, has authority exactly where our failures are.

### Gaps
- The DiVeR real result is from one lab, four short tabletop tasks and 24 trials per task. It needed action-expert representations recomputed from the policy. Our stored 64×64 images may not be enough to recompute pi0.5 internals offline, so a verifier on (image, state, chunk) would be the fallback. DiVeR lists SVM (Tsao et al., 2026) and TACO as such baselines, but I did not obtain their real-robot numbers.
- I found no test-time selection study on long-horizon tasks with 2,000 control steps per episode, or with safety-violation outcomes such as tipping or lifting while open.
- For the 2026 items marked (claim) I read abstracts and introductions but did not verify tables.

## Q3. Which of these work with offline data only, or with very few online episodes?

### Takeaway
Offline-only methods that need data close to our scale are outcome-verifier selection (DiVeR: about 160 real rollouts) and FOREWARN's classifier variant (about 250 rollouts plus 100 demonstrations per task, with a world model). Training-free selectors (MG-Select, SDN, VLA-Pilot) need no data but bring weaker or less verified gains, and their verifiers are generic.

V-GPS, RoboMonkey and Hume need demonstration corpora of thousands to hundreds of thousands of trajectories.

Methods with tens of online episodes exist:
- DSRL on pi0: 65–80 real episodes.
- PA-RL: 10–70 episodes.
- Golden Ticket search: 50–150 search episodes on hardware.
- BORA: 20 online trajectories per task, but with human corrections.

All of these start from base success of at least 14–20%, on short tasks.

### Cited Findings
- **Offline only, large data.**
  - V-GPS: Bridge + Fractal (~175K trajectories); its 10% ablation still helped. — [V-GPS](https://arxiv.org/abs/2410.13816)
  - RoboMonkey: 20M synthetic comparisons from over 40K trajectories. — [RoboMonkey](https://arxiv.org/abs/2506.17811)
  - Hume: value head trained with Cal-QL on demonstration data, as part of training the whole model. — [Hume](https://arxiv.org/abs/2505.21432)
- **Offline only, moderate data.**
  - DiVeR [2026]: 160 real pi0.5 rollouts with outcomes (94 successes, 66 failures). — [DiVeR](https://arxiv.org/abs/2610.04933)
  - FOREWARN: 250 real rollouts per task plus 100 demonstrations. — [FOREWARN](https://arxiv.org/abs/2502.01828)
  - Q-VGM [2026]: 150 rollouts per LIBERO suite, but it fine-tunes the action expert. — [Q-VGM](https://arxiv.org/abs/2606.08015)
  - DynaGuide: offline play or UMI data for its dynamics model. — [DynaGuide](https://arxiv.org/abs/2506.13922)
- **Training-free.**
  - MG-Select (autoregressive VLAs). — [MG-Select](https://arxiv.org/abs/2510.05681)
  - SDN [2026]. — [SDN](https://arxiv.org/abs/2606.14084)
  - VLA-Pilot (MLLM verifier). — [VLA-Pilot](https://arxiv.org/abs/2511.14178)
  - ITPS (human input). — [ITPS](https://arxiv.org/abs/2411.16627)
- **Few online episodes.**
  - DSRL on pi0 [real]: 80 episodes (~11,000 steps) for the toaster task, 5/20 → 18/20. 65 episodes (~10,000 steps) for spoon-on-plate, 15/20 → 19/20. — [DSRL](https://arxiv.org/abs/2506.15799)
  - DSRL on a single-task diffusion policy [real]: 2/10 → 9/10 in 3,500 steps (~40 episodes), where RLPD stayed at 0/10. — [DSRL](https://arxiv.org/abs/2506.15799)
  - PA-RL on OpenVLA [real]: 40% → 70% after 1 hour of zero-shot trials plus 40 minutes of RL. — [PA-RL](https://arxiv.org/abs/2412.06685)
  - Golden Ticket search [real, diffusion policies]: block pick 80% → 98% with 150 search episodes; piston assembly 60% → 88% with 61; banana pick 50% → 68% with 50. — [Golden Ticket](https://arxiv.org/abs/2603.15757)
  - ResFiT [real]: 14% → 64% with 134 rollouts; 23% → 64% with 343 episodes. — [ResFiT](https://arxiv.org/abs/2509.19301)
  - BORA [2026] [real]: "With only 20 online trajectories per task", 60.8% → 82.5% on standard objects and 52% → 70% on held-out objects. Uses human corrections and an offline-trained critic. — [BORA](https://arxiv.org/abs/2605.30226)
  - UniSteer's DSRL baseline [2026] [real, pi0]: 20% → 50%, 35% → 60%, 15% → 70% and 10% → 40% after 45–100 minutes of on-robot training per task. — [UniSteer](https://arxiv.org/abs/2605.10821)
- **Low initial success is the known weak point.** UniSteer observes that DSRL's improvement is slow under sparse rewards, "especially pronounced when the initial success rate is low: successful trajectories are rarely collected". — [UniSteer](https://arxiv.org/abs/2605.10821)
- **Removing a failure mode by RL on a pi-family model took far more data.** RECAP needed "two iterations (collecting 600 trajectories in each iteration)" to remove one laundry failure mode on π*0.6 (to 97% success), and it fine-tunes the model. — [π*0.6 / RECAP](https://arxiv.org/abs/2511.14759)

### Inferences
- Every few-episode online success in this list had episodes of about 10–150 policy queries and a base success that produced positives in the first batch of rollouts. Our episodes have about 250 queries, and we saw 0/24 successes during DSRL training.
  - My calculation: if the steered policy were as good as native (p ≈ 0.25), P(0/24) = 0.75²⁴ ≈ 0.001. If p ≈ 0.10, P(0/24) ≈ 0.08.
  - So the steered policy was very likely much worse than native, and there was essentially no positive reward for the critic.
- The highest-probability route to a "demonstrable" result is to train the selector or critic offline on the 100–200 recorded native episodes, and then spend the online budget mostly on evaluation, not exploration.

### Gaps
- I found no published method improving a frozen VLA with fewer than about 50 online episodes when the base success during exploration is near zero.

## Q4. Noise-space search and optimisation for diffusion and flow policies: how much does the initial noise change a well-trained policy's actions, and how does that limit steering authority?

### Takeaway
Well-trained diffusion and flow policies are close to deterministic in routine states. Replacing random noise with z = 0, or with the mean over 64 samples, barely changes success on standard benchmarks, and candidates sampled at ambiguous states form single clusters. The noise has leverage mainly at sparse decision-critical states such as pre-grasp.

Even so, a constant noise vector can move a frozen policy's success a long way in either direction.
- Golden Ticket search **[2026]** found tickets ranging from about 5% to nearly 100% success on one task.
- Constant tickets beat Gaussian sampling in 46 of 51 tasks, including pi0 on LIBERO.
- Tiling noise along the horizon made search worse.
- DSRL on pi0's full 1,600-D noise failed, so DSRL itself needed tiling.

Unconstrained latent RL drives the noise to high magnitudes, and that correlates with unstable decoding.

### Cited Findings

#### DSRL (Wagenmaker et al., arXiv 2506.15799 v2) — the method our attempt used
- **pi0 noise parameterisation.** pi0's noise and action space is 50 × 32 = 1,600-D. DSRL trains "a single-step actor … and critic" over 𝓦_single = ℝᵈ (d = 32) and repeats the sampled noise "across the action chunk axis". They write that this "makes SAC training more efficient and stable, while the repeated-noise formulation remains expressive enough to steer π0". This is the same tiled 32-D design our DSRL attempt used. — [DSRL](https://arxiv.org/abs/2506.15799)
- **Hyperparameters for pi0.**

  | | LIBERO [sim] | AlohaTransferCube [sim] | Real |
  |---|---|---|---|
  | Noise action magnitude b_𝓦 | 1.0 | 2.0 | 2.5 |
  | Number of critics | 10 | 10 | 2 |
  | Gradient steps per update | 20 | 20 | 30 |
  | Chunk size / executed | 50 / 20 | 50 / 50 | 10 / 10 |
  | Target entropy | −d/2 | −d/2 | 0 |
  | Clipped double-Q | no | no | no |

  The real-robot noise policy took proprioception, the VLM's last-token hidden feature (2,048-D) and features from a shallow CNN on three cameras. DSRL training ran on an RTX 3070. — [DSRL](https://arxiv.org/abs/2506.15799)
- **Results.**
  - [sim] LIBERO pi0: "≈20% to ≈100% after only ≈10,000 online samples".
  - [real] pi0-DROID (chunk size 10): toaster 5/20 → 18/20 after 80 episodes; spoon 15/20 → 19/20 after 65 episodes.
  - [sim] ResiP and V-GPS did not significantly improve pi0.
  - [sim] DSRL-NA needs about 2× fewer samples than DSRL-SAC on Robomimic Square.
  — [DSRL](https://arxiv.org/abs/2506.15799)
- **Using offline data.** DSRL-NA trains a critic on the original action space ("able to incorporate standard offline data with 𝒜-actions") and distils it into a noise-space critic. Many noise values "may be denoised to the same point" (noise aliasing). — [DSRL](https://arxiv.org/abs/2506.15799)
- **The authors' own limitation.** "A highly concentrated action distribution … might not provide enough 'options' … our approach does not currently offer a clear way to quantify in advance how much improvement is possible". — [DSRL](https://arxiv.org/abs/2506.15799)

#### Golden Ticket search (Patil et al., arXiv 2603.15757 v4, Oct 2026) [2026]
- **Method.** Replace per-query Gaussian sampling with one constant noise vector w ∈ ℝ^{H×d_a} used at every query. Search for it with random search or CEM using Monte Carlo episodic return, and use sequential halving to eliminate poor tickets cheaply. — [Golden Ticket](https://arxiv.org/abs/2603.15757)
- **Prevalence** [sim, mainly]. Tickets beat Gaussian noise in 46 of 51 tasks and at least matched it in 49 (one-sided binomial p ≈ 1.2×10⁻⁹). Examples: robomimic Can 42.8% → 95.0%; LIBERO +13.4, +12.8 and +8 points on Spatial, Goal and Object. — [Golden Ticket](https://arxiv.org/abs/2603.15757)
- **Versus DSRL on pi0.** DSRL "on the full 1600D noise … fails to improve on the base policy" on LIBERO-90 tasks with pi0. Random constant tickets were comparable to DSRL in its tiled space. Over 50% of 200 sampled tickets beat the base on a pi0 LIBERO task, against 2.5% on 28-D Can. The authors attribute DSRL's trouble to critic coverage and overestimation in high-dimensional noise, and note that pi0 "needs 10 critics … and noise space tiling". — [Golden Ticket](https://arxiv.org/abs/2603.15757)
- **Spread and the danger of a bad ticket.** On franka_sim block pick, with 400 tickets × 50 start states, "ticket success rates vary from ≈5% to nearly 100%". On hardware the same search "surfaces a ticket succeeding only 2/50 times". — [Golden Ticket](https://arxiv.org/abs/2603.15757)
- **Search ablations.** "Tiling the noise vector along the horizon leads to worse performance due to a smaller search space". Searching only the gripper-dimension subspace "rises very quickly but plateaus below" full-space search. — [Golden Ticket](https://arxiv.org/abs/2603.15757)
- **Hardware** [real]. Diffusion policies (RGB and point cloud), not VLAs, with binary end-of-episode success. Average gain +31% within about 1 hour of rollouts per task:
  - block pick: 6 tickets × 25 episodes = 150 search episodes
  - piston assembly: 22 tickets over 61 episodes
  - banana pick: 10 tickets × 5 episodes = 50 episodes

  — [Golden Ticket](https://arxiv.org/abs/2603.15757)

#### Evidence that generative policies are near-deterministic in noise
- **Much Ado About Noising** (Pan et al., arXiv 2512.01809 v3, Feb 2026). Comparing z = 0, z ~ N(0, I) and the mean over 64 z [sim]:

  | Task | z = 0 | z ~ N(0, I) | mean of 64 |
  |---|---|---|---|
  | Push-T | 0.97 | 0.97 | 0.95 |
  | Kitchen | 0.99 | 0.99 | 0.97 |
  | Tool-Hang | 0.78 | 0.80 | 0.76 |

  At "symmetry-critical or high-ambiguity states" the action samples formed "single clusters rather than distinct modes". Generative and regression policies "achieve parity across the vast majority" of benchmarks, including pi0 fine-tuned on LIBERO. Gaps appear only on high-precision tasks. The authors attribute the advantage of generative policies to supervised iterative computation plus stochasticity injection, not to multimodality. — [Much Ado](https://arxiv.org/abs/2512.01809)
- **Demystifying Diffusion Policies** (arXiv 2505.05787). In small-data regimes (for example 30 cup-grasping demonstrations), diffusion policies "memorize the training action sequences" and behave like "a lookup table". — [Demystifying](https://arxiv.org/abs/2505.05787)
- **DiVeR [2026].** Candidates drawn with independent initial noise from pi0 or pi0.5 "remain highly similar" in routine states and diverge at decision-critical states. — [DiVeR](https://arxiv.org/abs/2610.04933)
- **Hume.** Fully denoised flow candidates are "sampled from the same distribution", which shrinks the range available to choose from. — [Hume](https://arxiv.org/abs/2505.21432)
- **pi_RL** (arXiv 2510.25889 v3, Jan 2026). Flow VLAs are evaluated with deterministic ODE sampling, and RL had to inject noise (Flow-Noise or Flow-SDE). Lower injected noise "mitigate[s] exploration-induced performance degradation" but "constrain[s] the capacity for RL refinement", and very low noise (a = 0.2) trained unstably. This is full fine-tuning on 8 H100s, with gains of +29.2 points for pi0 and +31.0 for pi0.5. — [πRL](https://arxiv.org/abs/2510.25889)
- **LP-DS [2026].** Under weakly constrained steering, "DSRL predicts high-magnitude latent queries that correlate with unstable decoding and performance degradation" (HalfCheetah, hard clip ‖w‖ ≤ 100). — [LP-DS](https://arxiv.org/abs/2606.01151)
- **DLSRL [2026].** Claims that noise-only steering "fail[s] to modulate intermediate action representations … resulting in performance degradation and inefficiency" and adds hidden-state modulation (claim). — [DLSRL](https://arxiv.org/abs/2609.11270)

#### Inverting actions into noise for flow policies
- **UniSteer [2026].** Inverts the frozen flow decoder by fixed-point iteration of each Euler step, turning action-space corrections into noise targets. The authors report "low inversion error". — [UniSteer](https://arxiv.org/abs/2605.10821)
- **PAINT [2026].** Picks the initial noise by "backward Euler inversion", so that the unmodified flow ODE reproduces the already-executed prefix. Comparable to RTC across 12 simulated and 6 real tasks (claim). — [PAINT](https://arxiv.org/abs/2606.19774)

#### Image-diffusion noise optimisation that carries over
- **Random search over noise and verifier hacking.** Ma et al. found random search over noise against a verifier "highly effective". Past a certain number of search iterations, FID rose and recall fell ("loss of diversity") as search overfit the verifier. — [Ma et al. 2025](https://arxiv.org/abs/2501.09732)
- **Keeping optimised noise in distribution.** ReNO optimises the initial noise for 10–50 steps against reward models. It regularises the noise by maximising the log-likelihood of its norm under a χ^d distribution, following Samuel et al. and D-Flow, so the noise stays in distribution. — [ReNO](https://arxiv.org/abs/2406.04312); [D-Flow](https://arxiv.org/abs/2402.14017)
- **Learned "golden noise".** NPNet maps a random noise to a "golden" noise in one forward pass, evaluated on SDXL, DreamShaper and Hunyuan-DiT. — [Golden Noise](https://arxiv.org/abs/2411.09502)
- **Mutation on the data manifold.** VLA-Pilot mutates elite proposals by partial forward noising followed by truncated denoising, to stay on the data manifold. — [VLA-Pilot](https://arxiv.org/abs/2511.14178)

### Inferences
- **Our "untrained steering broke grasping" result fits the literature.** A fixed zero vector and a random tiled vector are each just one constant ticket, and tickets span about 5% to about 100% success (Golden Ticket). Golden Ticket also shows tiling is a worse search space.
  - Statistically the evidence is weak. My calculation, Fisher two-sided: 4/12 vs 0/12 gives p ≈ 0.09, and 4/12 vs 1/12 gives p ≈ 0.32.
  - The more decisive evidence is 0/24 during training. If the steered policy matched native, that has probability about 0.001.
- **The structure of tiled noise is off-distribution, not its size.** A tiled 32-D Gaussian has the same expected squared norm as i.i.d. 16×32 noise (512). But it is perfectly correlated across the 16 chunk positions, which pi0.5 never saw in training. z = 0 has norm 0, far from the typical radius √512 ≈ 22.6. Image work (ReNO, D-Flow) keeps optimised noise near the typical radius for exactly this reason.
- **Authority is concentrated where we need it.** Because pi0.5 is likely near-deterministic in routine phases and diverse at pre-grasp and contact (DiVeR, Much Ado), noise steering's authority is concentrated at our failure points.
  - A single policy that alters noise at all ~250 queries pays the disruption cost everywhere for leverage it only gets in a few places.
  - This argues for applying steering, whether noise choice or selection, only in the grasp and contact window.
- **A measurement we could run, with no simulation needed.** The recorded native episodes with per-query observations would let us measure pi0.5's candidate dispersion per query, re-sampling noise at stored states (DiVeR-style, K ≈ 16–32). That would quantify steering authority by phase.

### Gaps
- I found no study that quantifies, specifically for pi0.5, how the dispersion of action chunks across noise samples varies by task phase.
- The Golden Ticket VLA evidence is simulation-only; its hardware used diffusion policies.
- I found no paper running CEM or evolution over per-query noise for a VLA with sparse binary outcomes over long episodes. Golden Ticket, with one constant vector per task, is the closest.

## Q5. Residual RL around frozen base policies (Policy Decorator, ResiP, ResFiT, PLD, EXPO, residual policy learning): how is base competence preserved, what budgets and base rates were needed, and has any been applied to pi0, pi0.5 or other VLAs?

### Takeaway
Residual methods protect the base with four mechanisms:
- a zero or near-zero initial residual
- a bounded residual scale, typically 0.03–0.8 in normalised action units
- a progressive exploration schedule, or warm-up with the base alone
- a critic pre-trained conservatively (Cal-QL) on base successes

They work well for precision failures at contact. But their published budgets are millions of simulator steps, or 134–343 real episodes on short tasks with base success of at least 14%. Residual RL on VLAs exists:
- PLD on pi0 (residual on a frozen VLA, then distilled)
- ViTaR on OpenVLA-OFT
- ReCoVLA on pi0.5
- BORA, ForceRFT and HiL-ResRL on other VLAs

DSRL's attempt to apply ResiP to pi0 in simulation did not significantly improve it.

### Cited Findings
- **Residual policy learning** (Silver et al. 2018). "A desirable property of RPL is that it should never make a good initial policy worse", so they initialise the residual "so that f_θ(s) = 0 for all s". — [RPL](https://arxiv.org/abs/1812.06298)
- **Residual RL on a hand-designed controller** (Johannink et al. 2018). RL learns the residual on top of a conventional feedback controller and solved a real block-assembly task with contacts [real]. — [Residual RL](https://arxiv.org/abs/1812.03201)
- **Policy Decorator** (Yuan et al., arXiv 2412.13630 v1).
  - *Design.* SAC residual with a bounded output (tanh × α). A progressive schedule uses the residual with probability ε, rising linearly from 0 to 1 over H steps.
  - *Settings.* H ranged from 30K to 8M steps and α from 0.03 to 0.8 across tasks.
  - *Sensitivity.* Too small an H "can lead to complete failure due to aggressive exploration"; too large an α hurts sample efficiency. α "close to the action scale observed in the demonstration dataset" is the rule of thumb.
  - *Bases and budgets* [sim]: Behaviour Transformer or Diffusion Policy trained on 1,000 ManiSkill or 25 Adroit demonstrations; evaluated every 50K steps; budgets in millions of steps. About 4M steps on Transport versus about 16M for DPPO.
  - *Baselines.* JSRL "only exceeds the base policy's performance on around half of the scenarios".
  — [Policy Decorator](https://arxiv.org/abs/2412.13630)
- **ResiP** (Ankile et al., arXiv 2407.16677 v4).
  - *Design.* A PPO residual applied at every step on top of 8-step chunks from a frozen Diffusion Policy. Orthogonal initialisation "with a small gain factor on the final layer" keeps initial corrections near zero; residual scaling α = 0.1, robust over 0.01–1.0.
  - *Budget.* 1,024 parallel environments, up to 500M environment steps.
  - *Results* [sim]: from 50 demonstrations, one_leg 54% → 98% and round_table 12% → 94%. The real robot was reached by distillation.
  - *Chunk-level residual.* Correcting the whole chunk at once (ResiP-C) learned "significantly slower" and saturated lower.
  — [ResiP](https://arxiv.org/abs/2407.16677)
- **ResFiT** (Ankile et al., arXiv 2509.19301 v2).
  - *Recipe.* Off-policy TD3-style per-step residual on a frozen ACT policy, with n-step returns (n = 3), UTD > 1, and batches sampled 50% from demonstrations. Layer normalisation in the critic "turns out to be crucial". The buffer is warmed up with uniform noise around base actions.
  - *Results* [real, 29-DoF humanoid with two five-fingered hands]:
    - WoollyBallPnP: 14% → 64% after 134 rollouts (about 15 minutes).
    - PackageHandover: 23% → 64% after 343 episodes (about 76 minutes).
    - The base ACT policies were trained on about 1,000 and 900 demonstrations.
  - *Limitation.* It "cannot discover fundamentally different strategies".
  — [ResFiT](https://arxiv.org/abs/2509.19301)
- **PLD** (Xiao et al., arXiv 2511.00091 v1, 30 Oct 2025).
  - *Design.* A frozen VLA (default pi0) with a Gaussian residual scaled to [−ξ, ξ] by a scheduler: ξ = 0.5 suggested for LIBERO, 0.1 for SimplerEnv. Setting ξ too large "can degrade early performance".
  - *Warm-up and critic.* A warm-up phase collects data with the base policy only. The critic is initialised with Cal-QL on 50 successful base trajectories per task; Cal-QL was "consistently better" than IQL, and CQL "demonstrates the worst performance with a severe forgetting issue".
  - *Initial dip.* There is an "initial performance drop" as the residual diverges from the base.
  - *Base-policy probing.* Roll out the base for a random number of steps, then let the residual take over; this widens the starting-state distribution.
  - *Results.* Over 95% on more than 120 LIBERO tasks [sim]. On a real Franka, pi0 was SFT'd on 200 teleop trajectories, and PLD and RLPD both reached 100% "within 2 hours" [real].
  — [PLD](https://arxiv.org/abs/2511.00091)
- **EXPO.** Edits bounded to [−β, β] with β from 0.05 to 0.7. Unlike classic offline-to-online methods it does not show a large initial performance drop, because actions stay "close to actions sampled by the base policy". — [EXPO](https://arxiv.org/abs/2507.07986)
- **Action-space versus noise-space residual [2026].** On Walker2d [sim], LP-DS-A, which applies the residual to the decoded action, "provides only limited improvement and quickly plateaus" below the noise-space residual. — [LP-DS](https://arxiv.org/abs/2606.01151)
- **2026 residuals on frozen VLAs.**
  - *ViTaR* [sim + real]: frozen OpenVLA-OFT, bounded residual selected from a small discrete set and scaled by tactile evidence. 61.3% average on UniVTAC, +30.6 points over the frozen base. — [ViTaR](https://arxiv.org/abs/2608.15816)
  - *ReCoVLA* [sim → real]: frozen VLA plus residual recovery policies trained in simulation with VLM-compiled rewards. 36.7% (fine-tuned pi0.5 baseline) → 66.7% in simulation; 61.7% real zero-shot. — [ReCoVLA](https://arxiv.org/abs/2606.09630)
  - *BORA* [real]: residual over a frozen consistency-policy VLA, guided by an inherited offline critic. 60.8% → 82.5% with 20 online trajectories per task, plus human corrections. — [BORA](https://arxiv.org/abs/2605.30226)
  - *Res-HIL* [real]: frozen imitation policy, not a VLA. Zero-initialising the output layer cut convergence from 16 to 8 minutes. — [Res-HIL](https://arxiv.org/abs/2609.30023)
  - *ForceRFT* [real]: frozen SmolVLA prior. TD bootstrapping is "restricted to autonomous segments, preventing TD credit from crossing human-intervention boundaries". — [ForceRFT](https://arxiv.org/abs/2609.22840)

### Inferences
- The "critic inflated" symptom in our DSRL run matches failure modes the residual literature explicitly guards against: no layer normalisation, no conservative pre-training, and no positives. Remedies with evidence are layer-normalised critics (ResFiT), Cal-QL pre-training on native successes (PLD), and ensembles or clipped double-Q (DSRL used 10 critics in simulation; V-GPS used clipped double-Q).
- At 20 Hz with 2,000 steps per episode, a per-step residual gets many transitions (120 episodes × 2,000 = 240K). But with about 25% sparse terminal successes the credit-assignment horizon is long. Published real-robot residual successes used episodes several times shorter and 134+ episodes, so 60–120 of our episodes is below demonstrated budgets unless the residual is phase-restricted and gets a phase-level reward.
- A residual action targets precision failures, consistent with our failures at contact and grasp, and with ResiP's view that chunked policies act as open-loop "planners". It also gives authority that does not depend on pi0.5's noise diversity. Its downside: in DSRL's pi0 simulation test and in LP-DS's Walker2d test, action residuals underperformed noise steering.

### Gaps
- I found no residual-RL result on pi0.5 that is frozen (not distilled) and trained only on online sparse binary rewards, without human interventions, within 120 episodes.
- PLD's real-robot base success before RL was not stated in the passages I read.

## Q6. Native-preserving steering of the noise itself: residual on fresh Gaussian noise, steering only some chunk positions or dimensions, low-temperature sampling — the trade-off between preserving native behaviour and authority to change outcomes

### Takeaway
The best-supported native-preserving form is a residual added to fresh noise with an explicit trust region: LP-DS **[ICML 2026]**, w = ε + Δ(s, ε) with E‖Δ‖² ≤ δ. At Δ = 0 it recovers the native distribution exactly, and it keeps more action diversity than DSRL-style replacement.

Every family shows the same dial: guidance strength, forward-noise ratio, trust-region size, injected-noise level, guidance clipping. Turning it up buys alignment or reward at the cost of constraint satisfaction, smoothness or base success; ITPS block stacking is the clearest number. Steering only some chunk positions is well supported by inference-time inpainting on pi0.5 (RTC, PAINT). Steering only some dimensions has weak support. I found no study of low-temperature (scaled-noise) sampling for flow VLAs.

### Cited Findings
- **LP-DS [2026]** (Simsir & coauthor, arXiv 2606.01151, "Accepted as a regular paper at ICML 2026").
  - *Form.* w = ε + Δ_θ(s, ε), and "when Δ_θ(s, ε) = 0, the policy recovers the original behavior cloning distribution exactly".
  - *Trust region.* E‖Δ‖² ≤ δ is enforced by a Lagrange multiplier; KL is approximated by ½E‖Δ‖², following Eyring et al. Trust-region targets δ ∈ {0.01, 0.05, 0.1} are shown.
  - *Claims.* "Mitigates mode collapse relative to prior-replacing noise-space steering"; return gains "up to 25%" over baselines [sim].
  - *pi0.* A frozen pi0 on LIBERO-90 improved "substantially", with numbers only in a figure [sim].
  - *Real Franka.* Steering was trained in simulation and deployed on hardware. The rows I read show per-position success going 1/5→4/5, 3/5→5/5, 4/5→4/5 and 3/5→5/5 [real].
  — [LP-DS](https://arxiv.org/abs/2606.01151)
- **DSRL bounds its noise action with tanh** at magnitude 1.0–2.5 (see Q4). That bounds the replaced noise, not its distance from fresh Gaussian noise. — [DSRL](https://arxiv.org/abs/2506.15799)
- **Partial noising as an authority dial** (To the Noise and Back, Yoneda et al., arXiv 2302.12244). The forward-diffusion ratio γ = k_sw/K "regulates the balance between the fidelity and the conformity" of actions. When γ is too high "the copilot ignores the pilot's actions". The ratio also gives "a formal bound on the extent to which the copilot's action deviates". — [To the Noise and Back](https://arxiv.org/abs/2302.12244)
- **ITPS block stacking** quantifies the dial: from ranking to strong guidance, task alignment rises 33% → 86% while constraint satisfaction falls 100% → 15%. Guidance withheld in the early denoising steps reached 83% alignment with 84% constraint satisfaction. — [ITPS](https://arxiv.org/abs/2411.16627)
- **Guidance strength in DynaGuide.** Higher guidance scale produces "less smooth or even incoherent trajectories". — [DynaGuide](https://arxiv.org/abs/2506.13922)
- **Chunk positions: RTC** (Black et al., NeurIPS 2025, arXiv 2506.07339 v2). "Freezing" the actions guaranteed to execute and inpainting the rest on pi0.5 (H = 50, Δt = 20 ms, n = 5 denoising steps), with training-free ΠGDM guidance. Without guidance-weight clipping β "the algorithm became unstable with the small number of denoising steps"; there was no gain beyond β = 5 [real + sim]. — [RTC](https://arxiv.org/abs/2506.07339)
- **Chunk positions: PAINT [2026]** gets prefix consistency from initial-noise selection alone (backward Euler inversion) (claim). — [PAINT](https://arxiv.org/abs/2606.19774)
- **Dimensions: Golden Ticket.** Searching only the gripper-dimension subspace of the noise "rises very quickly but plateaus below" full-space search, and horizon tiling is worse. — [Golden Ticket](https://arxiv.org/abs/2603.15757)
- **Injected noise level: pi_RL.** Lower noise preserves rollout performance but limits RL refinement; minimal noise was unstable. — [πRL](https://arxiv.org/abs/2510.25889)
- **Mean action instead of a sample: Much Ado.** Using the mean action (the extreme low-temperature case) barely changed success on Push-T, Kitchen and Tool-Hang. — [Much Ado](https://arxiv.org/abs/2512.01809)
- **Norm regularisation from image work.** ReNO keeps optimised noise near the typical χ^d radius. — [ReNO](https://arxiv.org/abs/2406.04312)

### Inferences
- Our unexecuted follow-up (ε + 0.25·tile(u) with a native prior bank) is close to LP-DS. Two literature-backed adjustments:
  - Replace the fixed 0.25 with a trust-region constraint, adapted by a dual variable, on ‖Δ‖² summed over the chunk. Note ‖0.25·tile(u)‖² = 0.0625 × 16 × ‖u‖² = ‖u‖², so a unit-Gaussian u already gives a perturbation with the same expected squared norm as a 32-D Gaussian.
  - Consider an untiled or partially tiled Δ, since Golden Ticket found tiling shrinks the useful search space.
- Restricting the residual to the grasp and contact queries, and leaving free-space queries native, preserves native competence where it is already good, and still acts where DiVeR-style evidence says candidates differ.
- A native prior bank could be built by inverting recorded native actions into noise (UniSteer and PAINT fixed-point or backward-Euler inversion), or simply by storing the noise used at record time. That would give native noises with known outcomes for warm-starting a noise critic, as in DSRL-NA's use of action-space data.

### Gaps
- I found no paper measuring the native-preservation versus authority curve on pi0.5 specifically.
- I found no study steering a subset of action dimensions for VLAs, beyond Golden Ticket's gripper-subspace ablation.
- I found no study of temperature-scaled initial noise (ε·τ, τ < 1) for flow VLAs.

## Q7. Phase-targeted or gated intervention: acting only in specific phases, gating between base and learned policies, JSRL guide policies, takeover or intervention policies, shared autonomy, failure-predictor-triggered recovery

### Takeaway
Evidence that phase restriction and gating help comes from three directions:
- *Theory.* JSRL: exponential to polynomial sample complexity in horizon, given a guide policy that covers good states.
- *Empirics on frozen VLAs **[2026]**.* ViTaR's contact-gated, single-chunk, bounded residual added +30.6 points over a frozen VLA, trained from 100 branch rollouts per task. DiVeR showed that weighting learning toward decision-critical states beats uniform weighting.
- *Safety.* Recovery RL's safety critic gates a recovery policy, and needs offline violation data.

Learned gates trained from small correction datasets matched human gating (TRANSIC: 17–100 corrected trajectories per task). Runtime failure predictors calibrate on successful rollouts alone. I found no paper that closes the loop from a failure predictor to a learned recovery policy on a VLA and reports success gains, except stage-gated recovery trained in simulation (ReCoVLA).

### Cited Findings
- **JSRL** (Uchendu et al., ICML 2023, arXiv 2204.02372).
  - *Mechanism.* The guide policy acts for the first h steps and the exploration policy afterwards, π_{1:h} = π^g and π_{h+1:H} = π^e. A curriculum shrinks h as π^e improves.
  - *Theory.* "Non-optimism-based exploration … suffer[s] from a sample complexity that is exponential in horizon". With a guide policy that covers good states, JSRL attains polynomial sample complexity.
  - *Empirics* [sim]: "significantly outperform … particularly in the small-data regime".
  — [JSRL](https://arxiv.org/abs/2204.02372)
- **PLD's base-policy probing.** Base roll-in for a random number of steps, then the residual takes over. — [PLD](https://arxiv.org/abs/2511.00091)
- **Policy Decorator's schedule.** The ε-greedy mixing schedule between base and residual. — [Policy Decorator](https://arxiv.org/abs/2412.13630)
- **TRANSIC** (Jiang et al., CoRL 2024, arXiv 2405.10315 v3).
  - *Data.* A residual learned from human online corrections: 20, 100, 90 and 17 corrected trajectories for four tasks.
  - *Gate.* "Learning a gating function to control whether to apply residual actions" improves performance; the learned gate "only incurs negligible performance drops compared to human gating".
  - *Without a residual.* Fine-tuning the base directly on the corrections "leads to large motions and even model collapse".
  - *Result* [real]: 77% average across five sim-to-real pairs with exaggerated gaps.
  — [TRANSIC](https://arxiv.org/abs/2405.10315)
- **ViTaR [2026]** (arXiv 2608.15816 v1).
  - *Action choice.* Each decision either keeps the frozen action (ΔA = 0) or picks one of a few structured 7-D residual directions, scaled by a learned gain. The design "preserv[es] pretrained capabilities by construction".
  - *Training data.* "Short-horizon branch rollouts restored to common decision points": 100 rollouts per task = 5 branches × 20 restored decision groups, giving 160 preference pairs.
  - *Intervention size.* Each residual branch modifies one action chunk, then resumes the reference policy for up to 30 chunks.
  - *Result.* 61.3% on UniVTAC, +30.6 points over frozen OpenVLA-OFT [sim], with physical-robot validation.
  — [ViTaR](https://arxiv.org/abs/2608.15816)
- **DiVeR [2026].** Decision-critical states are "sparse and temporally localized" (pre-grasp, pre-placement). Criticality-weighted training gave +6.3 points over a uniformly trained verifier on the real robot. — [DiVeR](https://arxiv.org/abs/2610.04933)
- **EQRL [2026]** (arXiv 2606.14375). A frozen VLA with a latent-schedule adaptor and a learned residual. A "state difficulty signal from critic ensemble disagreement" directs compute "toward difficult states". Tested on LIBERO, ALOHA and real robots (claim). — [EQRL](https://arxiv.org/abs/2606.14375)
- **ReCoVLA [2026].** A VLM picks a recovery stage and a reward mask, for example placing rewards are "inactive until the object is grasped". It trains residual recovery policies on a frozen VLA in simulation. — [ReCoVLA](https://arxiv.org/abs/2606.09630)
- **Recovery RL** (Thananjeyan et al., RA-L/ICRA 2021).
  - *Mechanism.* A safety critic Q_risk is learned from offline data that includes constraint violations. The agent switches to a recovery policy whenever Q_risk(s, a) > ε_risk.
  - *Ablation.* "Offline pretraining of π_rec and Q̂_risk is critical", while removing online updates hurts less.
  - *Results.* Better task-success-to-violation ratios in simulation, and on a physical dVRK.
  — [Recovery RL](https://arxiv.org/abs/2010.15920)
- **Learning from interventions and takeovers.**
  - Sirius "labels a fixed-length window of autonomous transitions preceding each intervention as suboptimal and assigns these samples zero weight", as described by Res-HIL. — [Res-HIL](https://arxiv.org/abs/2609.30023)
  - RLIF uses "user intervention signals themselves as rewards". — [RLIF](https://arxiv.org/abs/2311.12996)
  - HIL-SERL reached "near-perfect success rates … with only 1 to 2.5 hours of training time in the real world", with human interventions and no frozen base. — [HIL-SERL](https://arxiv.org/abs/2410.21845)
  - ThriftyDAgger does "budget-aware novelty and risk gating" for human queries. — [ThriftyDAgger](https://arxiv.org/abs/2109.08273)
- **Shared autonomy.** Partial forward diffusion of the user's action, then denoising, with the γ dial between fidelity and conformity. — [To the Noise and Back](https://arxiv.org/abs/2302.12244)
- **Runtime failure predictors** (all detection-only in what I read):
  - FIPER: scores "calibrated using a small set of successful rollouts via conformal prediction". — [FIPER](https://arxiv.org/abs/2510.09459)
  - FAIL-Detect: failure detection "without failure data". — [FAIL-Detect](https://arxiv.org/abs/2503.08558)
  - Sentinel: temporal-consistency plus VLM monitors for diffusion policies. — [Sentinel](https://arxiv.org/abs/2410.04640)
  - SAFE: VLA failure detection from internal features of OpenVLA, pi0 and pi0-FAST. — [SAFE](https://arxiv.org/abs/2506.09937)
- **Why contact phases fail.** The FACT study (CoRL 2026 spotlight) splits contact-rich VLA failures into "precision failures" (small, accurate corrective actions) and "force failures". Its fixes are training-time: more low-noise sampling and force conditioning. They reach 66% against 41% for the best prior method over about 2,500 real rollouts. Not applicable to a frozen policy, but diagnostic. — [FACT](https://arxiv.org/abs/2608.01402)

### Inferences
- **Gating shortens the horizon the learner must assign credit over.** Restricting the learned component to the roughly 10–40 queries around lid-closure, grasp and lift, out of about 250, shortens that horizon by an order of magnitude. That is the regime JSRL's bound rewards.
- **Gating also preserves native behaviour elsewhere by construction.** It reduces the risk of breaking competence we already have, as happened when tiled noise was applied at every query.
- **Our simulator allows ViTaR-style branching.** If Isaac Sim / OmniGibson states can be saved and restored at a grasp decision point, ViTaR-style branch rollouts become possible: short continuations from the same state under alternative chunks or noises. That turns one long episode into many short, nearly paired comparisons at the critical phase, and is the most sample-efficient credit assignment in this literature.
- **A phase-level outcome helps.** For example, "grasped and lifted closed jar without tipping within N steps", as an intermediate binary label. It gives dense-enough positives at the phase (ReCoVLA's stage-gated rewards are the closest precedent). Final strict safe completion stays the evaluation metric.

### Gaps
- I found no study on a pi-family VLA that combines a learned gate (when to steer) with noise or selection steering and reports sample-efficiency curves at under 100 episodes.
- Whether OmniGibson state restore is exact enough for branch rollouts is outside the literature.

## Q8. Synthesis: given our failure pattern, which interface gives the best chance of a demonstrable gain within about 60 to 120 episodes, and why?

### Takeaway
The best bet is **phase-gated test-time selection with an outcome-trained verifier**:
- At grasp and contact queries only, sample N ≈ 8–16 native pi0.5 chunks by redrawing ε and execute the one a verifier ranks highest.
- Train the verifier offline on the 100–200 recorded native episodes (DiVeR-style success/failure discrimination, weighted toward the grasp window).
- Leave all other queries native.
- Spend the 60–120 online episodes on paired evaluation rather than exploration.

Why it ranks first:
- It cannot leave the native action distribution, so it preserves competence by construction.
- It needs no online positives.
- Its closest analogue (DiVeR, real pi0.5) gained +13.6 points from 160 rollouts.

Second choices:
- Phase-gated Golden-Ticket-style noise search, with full untiled noise and sequential halving: 50–150 hardware search episodes in the literature.
- An LP-DS-style trust-region residual on fresh noise, restricted to the grasp window, warm-started from native data and given a phase-level reward.

Ranked lower:
- Residual action RL: needs more episodes than we have at our horizon.
- Full noise replacement (our DSRL setup): the literature itself shows it failing on pi0's full noise space, needing tiling and 10 critics, stalling at low initial success, and drifting to high-magnitude latents.

A hard constraint applies to every option: at 25% base success, 60 or 120 unpaired episodes can only detect large gains (Inferences below).

### Cited Findings

#### Interface comparison table

| Interface | Data and online budget in the literature | How native competence is preserved | Evidence quality | Sources |
|---|---|---|---|---|
| **Full noise replacement (DSRL)** | 65–80 real episodes on pi0-DROID (chunk 10) at base 25–75%; ~10K samples in sim; fails on full 1,600-D pi0 noise; needs tiling and 10 critics; slow when initial success is low | Only via tanh bound b_𝓦 = 1.0–2.5 on the replacement noise | Real + sim, multiple labs; a 2026 independent comparison shows weakness on VLAs | [DSRL](https://arxiv.org/abs/2506.15799); [Golden Ticket](https://arxiv.org/abs/2603.15757); [UniSteer](https://arxiv.org/abs/2605.10821); [LP-DS](https://arxiv.org/abs/2606.01151) |
| **Residual on fresh noise (LP-DS)** | Sim benchmarks plus pi0 on LIBERO; real Franka via sim-trained steering; online budgets in sim units | Δ = 0 recovers the base; Lagrangian trust region E‖Δ‖² ≤ δ; keeps action entropy | One paper (ICML 2026); VLA result sim-only | [LP-DS](https://arxiv.org/abs/2606.01151) |
| **Constant-noise search (Golden Ticket)** | 50–150 search episodes on hardware (diffusion policies); pi0 in sim | None by default (a ticket can be catastrophic, 2/50); held-out validation needed | 51 tasks; real only for diffusion policies | [Golden Ticket](https://arxiv.org/abs/2603.15757) |
| **Residual action (ResFiT / PLD / Policy Decorator)** | 134–343 real episodes (ResFiT, base 14–23%); 2 h (PLD, pi0); millions of sim steps (Policy Decorator, ResiP 500M) | Zero or small init, bounded α or ξ, progressive ε schedule, base-only warm-up, Cal-QL critic pre-training | Strong in sim; real on short tasks; PLD on pi0 | [ResFiT](https://arxiv.org/abs/2509.19301); [PLD](https://arxiv.org/abs/2511.00091); [Policy Decorator](https://arxiv.org/abs/2412.13630); [ResiP](https://arxiv.org/abs/2407.16677) |
| **Test-time selection with learned verifier or critic** | Offline only: 160 real rollouts (DiVeR) up to 175K demos (V-GPS); online episodes only for evaluation | Executes only native samples; risk is verifier exploitation at large N | Real: DiVeR (pi0.5), V-GPS (Octo), RoboMonkey (OpenVLA), FOREWARN (DP); mixed results on strong bases | [DiVeR](https://arxiv.org/abs/2610.04933); [V-GPS](https://arxiv.org/abs/2410.13816); [RoboMonkey](https://arxiv.org/abs/2506.17811); [FOREWARN](https://arxiv.org/abs/2502.01828) |
| **Phase-gated steering** | ViTaR: 100 branch rollouts per task; TRANSIC: 17–100 corrected trajectories; Recovery RL: offline violation data | Base action kept outside the gate (ΔA = 0 option; learned gate) | ViTaR sim + real (2026); TRANSIC real; JSRL theory + sim | [ViTaR](https://arxiv.org/abs/2608.15816); [TRANSIC](https://arxiv.org/abs/2405.10315); [JSRL](https://arxiv.org/abs/2204.02372); [Recovery RL](https://arxiv.org/abs/2010.15920) |

#### Evidence directly bearing on our failure pattern
- **Steering authority is located where our failures are.** Decision-critical states, where noise-sampled candidates differ, are at pre-grasp and pre-placement; routine states give near-identical candidates. — [DiVeR](https://arxiv.org/abs/2610.04933)
- **Constant noise vectors vary from about 5% to nearly 100% success, and tiling is a worse search space.** So "untrained steering broke grasping" is an expected outcome for an arbitrary fixed tiled vector. — [Golden Ticket](https://arxiv.org/abs/2603.15757)
- **DSRL-type learning stalls when early successes are rare.** — [UniSteer](https://arxiv.org/abs/2605.10821)
- **Unconstrained latent steering drifts to high-magnitude latents that destabilise decoding.** — [LP-DS](https://arxiv.org/abs/2606.01151)
- **Contact-phase failures of VLAs are largely precision failures,** small corrective actions the base cannot produce. That favours a small, bounded residual or targeted selection at contact. — [FACT](https://arxiv.org/abs/2608.01402); [ResiP](https://arxiv.org/abs/2407.16677)
- **Overhead and practical details of selection.** Candidate sampling for pi0/pi0.5 can reuse the VLM prefix through KV caching. V-GPS reports a 1.28× slowdown at K = 10 and 1.59× at K = 50 (Octo). — [DiVeR](https://arxiv.org/abs/2610.04933); [V-GPS](https://arxiv.org/abs/2410.13816)
- **Ways to keep candidate search cheap and on-manifold.** Sequential halving eliminates poor noise candidates cheaply; partial re-noising mutation keeps proposals on the data manifold. — [Golden Ticket](https://arxiv.org/abs/2603.15757); [VLA-Pilot](https://arxiv.org/abs/2511.14178)

### Inferences
- **Statistical feasibility comes first.** My calculation: two-proportion test, α = 0.05 two-sided, power 0.8, base 25%.
  - Episodes per arm needed: about 152 to detect +15 points (25% → 40%), about 58 for +25 points, about 30 for +35 points.
  - With 60 episodes split 30/30, the minimum detectable effect is about 25% → 60%. With 120 split 60/60, about 25% → 50%.
  - Literature-anchored effects for our best candidates are +10 to +30 points. So a "demonstrable" gain needs one or more of: (a) an interface that uses no online episodes for training, so all of them go to evaluation (favours offline-trained selection); (b) paired evaluation on matched seeds and initial states with a McNemar test; (c) a phase-level endpoint (grasp-and-lift success after lid closure, about 4/12 natively) as the pre-registered primary outcome, with strict safe completion secondary; (d) restricting evaluation to tasks with mid-range base rates (25–60%), where gains are both possible and measurable.
- **Ranking and reasons.**
  1. **Phase-gated selection with an offline outcome verifier.**
     - Preserves native competence by construction.
     - Its data need (about 150 labelled rollouts) matches what we already have, and the closest analogue is real pi0.5.
     - It needs no online positives.
     - It aims at the decision-critical grasp states where candidates differ.
     - Risks: too little candidate diversity at our grasp states (measure first; see Q4), verifier overfitting with about 150 episodes (use a small model on compact features, ensembles, moderate N, and validate on held-out native episodes), and recomputing pi0.5 internals from stored 64×64 images may be impossible (use image + state + chunk features instead).
  2. **Phase-gated constant-noise or CEM search over full, untiled 16×32 noise, used only in the grasp window.**
     - Derivative-free, so it avoids the critic inflation we hit.
     - Hardware budgets of 50–150 episodes match ours.
     - Risks: noisy per-candidate estimates at a 25% base; winner's curse; catastrophic tickets. Mitigations are sequential halving, branch evaluation from restored grasp states if the simulator allows it, and held-out confirmation.
  3. **LP-DS-style residual noise.** w = ε + Δ, zero-initialised Δ, dual-adapted trust region on ‖Δ‖², active only in the grasp window, warm-started with DSRL-NA-style action-space critics from native data, plus a phase-level reward. It is the right direction for a fourth DSRL attempt, but it is still RL and needs positives within the budget.
  4. **Residual action.** Best matched to precision failures. But real budgets were 134–343 episodes on much shorter tasks, so success within 60–120 of our episodes is unlikely unless gated to the grasp phase and given branch or phase rewards.
  5. **Full noise replacement.** Every independent 2025–2026 comparison and our own data argue against it on a pi-family VLA.
- **The critic does not need to be thrown away.** If a critic is learned for options 3 or 4, the same model can serve as the verifier for option 1, so the first experiment should be the offline-only selection test.

### Gaps
- No paper tests any of these interfaces on BEHAVIOR-1K/OmniGibson tasks, on 2,000-step episodes, or with a safety-violation outcome alongside success.
- The 2026 papers (DiVeR, Golden Ticket, LP-DS, UniSteer, ViTaR, BORA, Res-HIL, QPILOTS, AGF, SDN, EQRL, ReCoVLA) are recent preprints. Only LP-DS (ICML 2026) and FACT (CoRL 2026 spotlight) carry venue acceptance in their arXiv comments. None has independent replication.
- How diverse pi0.5's candidates are at our grasp states is unknown, and it determines whether options 1–3 have any authority. It is measurable offline from the recorded native episodes if the stored observations can be fed back to the policy.
