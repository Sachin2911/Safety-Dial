# DSRL (Wagenmaker et al., arXiv 2506.15799): method, configuration, evidence and budgets, follow-ups to Oct 2026, and why our pi0.5 Jar attempt failed

**Sources.** I read the following in full:
- the TeX source of both arXiv versions;
- the CoRL 2025 camera-ready;
- both official repositories (code, configs, run scripts) and every issue in each;
- a third-party pi0 DSRL-NA port;
- the full text of about 30 citing papers.

**Conventions.**
- "≈ (fig.)" marks my reading of a plotted curve, not a reported number.
- "[brief]" marks facts about our setup taken from the assignment brief. These are internal, not public.
- Papers dated 2026 are marked "(2026)" with their arXiv month.

## 1. How DSRL works and exactly how it was configured (paper versions and official code)

### Takeaway
DSRL freezes a DDIM or flow policy and runs off-policy RL over its initial noise.

For pi0, the released code works as follows:
- **Noise action:** one 32-dim vector (pi0's padded action width), tanh-bounded to ±action_magnitude and copied to every step of the chunk.
- **Reward:** −1 per policy query, 0 at success.
- **Discount:** applied per query as γ^query_freq.
- **Critic backup:** no entropy term.

The three pi0 runs differ substantially:

| Run | Magnitude | Critics |
|---|---|---|
| LIBERO | 1.0 | mean of 10 |
| ALOHA | 2.0 | mean of 10 |
| Real | 2.5 | min of 2 |

The code also departs from the paper in several places.

### Cited Findings

#### Versions and venue
- arXiv v1 is dated 18 Jun 2025 and v2 25 Jun 2025. Diffing the TeX sources (figures excluded), the only change is the author name "Abishek" → "Abhishek". Both versions use the CoRL 2025 style in `[preprint]` mode. — [arXiv abs](https://arxiv.org/abs/2506.15799); [e-print v1](https://arxiv.org/e-print/2506.15799v1); [e-print v2](https://arxiv.org/e-print/2506.15799v2)
- On arXiv the "Limitations" section is toggled out of the main body (toggle `arxiv2`) and printed in the appendix after "Contributions". The CoRL camera-ready puts it in the main body. — [e-print v2](https://arxiv.org/e-print/2506.15799v2); [PMLR PDF](https://raw.githubusercontent.com/mlresearch/v305/main/assets/wagenmaker25a/wagenmaker25a.pdf)
- The conference version is CoRL 2025, PMLR 305:258–282, and it rearranges the content:
  - the single-task Franka experiment moves to Appendix A;
  - offline-to-online and "Understanding Diffusion Steering" move to Appendix B;
  - the hyperparameter tables are unchanged.

  — [PMLR](https://proceedings.mlr.press/v305/wagenmaker25a.html)
- Every version says LIBERO improves "from ≈20% to ≈100% after only ≈10,000 online samples". An author confirmed on GitHub: "it should be 100,000 samples, not 10,000. That was a typo, and we'll make sure to fix it in the camera-ready version". The camera-ready still says 10,000. — [arXiv TeX](https://arxiv.org/e-print/2506.15799v2); [PMLR PDF](https://raw.githubusercontent.com/mlresearch/v305/main/assets/wagenmaker25a/wagenmaker25a.pdf); [dsrl_pi0 issue #1](https://github.com/nakamotoo/dsrl_pi0/issues/1)

#### Core formulation
- For DDIM or flow policies, π_dp^W(s,w) deterministically maps noise w ∈ R^d to actions.
  - The latent-action MDP M^W has P^W(·|s,w) = P(·|s, π_dp^W(s,w)) and r^W(s,w) = r(s, π_dp^W(s,w)).
  - Any RL algorithm can run on M^W with forward-only, black-box access to the policy.

  — [arXiv html v2](https://arxiv.org/html/2506.15799v2)
- There are two variants:
  - DSRL-SAC: SAC directly on M^W.
  - DSRL-NA: noise aliasing (Section 3).

  The README states that a diffusion policy "must be sampled from with DDIM sampling". — [arXiv html v2](https://arxiv.org/html/2506.15799v2); [ajwagen/dsrl README](https://github.com/ajwagen/dsrl)

#### Noise space for pi0: shape, tiling, which dimensions
- **What the paper says.** pi0 "uses an action chunk size of 50 and each action is 32-dimensional, resulting in a total action space dimension of 1,600". DSRL instead samples "w_single" and repeats it "across the action chunk axis". In the paper's words: "We find that this makes SAC training more efficient and stable, while the repeated-noise formulation remains expressive enough to steer π0 to produce effective actions." No ablation is given. — [arXiv TeX, appendix](https://arxiv.org/e-print/2506.15799v2); quoted in [issue #6](https://github.com/nakamotoo/dsrl_pi0/issues/6)
- **The code's action space** is `Box(low=-1, high=1, shape=(1, 32,))`, commented "32 is the noise action space of pi 0". — [train_sim.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_sim.py)
- **Tiling in the code.** `noise = np.repeat(actions_noise[-1:, :], 50 - actions_noise.shape[0], axis=0)` is concatenated into a (1, 50, 32) tensor. The real-robot code tiles to 10, matching pi0-DROID's chunk.
  - Because the code repeats only the *last* row, a k-row noise output can drive the first k steps. BEE ran DSRL this way with k = 10 ("chunk-10 configuration", Section 6).

  — [train_utils_sim.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_utils_sim.py); [train_utils_real.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_utils_real.py); [BEE](https://arxiv.org/abs/2609.27450)
- **Real vs padding dimensions.** Only some of the 32 dims are real actions. For π0.5, LIBERO actions are 7-D, padded with 0 to 32-D, and DROID actions are 8-D, padded with −1. FRS (2026, with the DSRL authors Wagenmaker and Levine among its authors) therefore replaces the padding-dimension noise with i.i.d. N(0,I). They say this "does not affect performance" and gives noise policies "a smaller output space". — [FRS appendix D.3](https://arxiv.org/abs/2606.13675)
- **openpi fork.** It adds an externally supplied `noise` argument to `Pi0.sample_actions` (10 Euler flow steps), plus `get_prefix_rep`, which returns the VLM hidden states. — [nakamotoo/openpi commit a6d2400](https://github.com/nakamotoo/openpi/commit/a6d2400d2534ce32e7bdf8747709b97aaef8ec04)
- **Warm-up vs evaluation noise differ.**
  - Warm-up data (before the first update) is collected with one Gaussian (1, 1, 32) vector, tiled to 50 steps.
  - The step-0 "base policy" evaluation uses i.i.d. `jax.random.normal(rng, (1, 50, 32))`.

  So the plotted base rate reflects native noise, but the first training data comes from tiled noise. — [train_utils_sim.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_utils_sim.py)

#### Action magnitude
- **Rationale.** If π_dp was trained with standard-Gaussian noise, only noise "reasonably likely under a standard Gaussian" is in-distribution, so W is restricted to [−b_W, b_W]^d. b_W in [1, 3] "generally worked well for online RL and [0.5, 1.5] for offline RL". — [arXiv html v2](https://arxiv.org/html/2506.15799v2)
- **Values used:**
  - pi0: LIBERO 1.0, ALOHA 2.0, real 2.5.
  - Robomimic: Lift, Can and Square 1.5; Transport 1.
  - Gym: Hopper 1.5, Walker 2.5, HalfCheetah 1.5.
  - WidowX: 2, 2 and 1.5.
  - OGBench offline: 0.5–1.5 per task.

  — [arXiv TeX appendix](https://arxiv.org/e-print/2506.15799v2); [run_libero.sh](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/scripts/run_libero.sh); [run_aloha.sh](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/scripts/run_aloha.sh); [run_real.sh](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/scripts/run_real.sh); [cfg/](https://github.com/ajwagen/dsrl/tree/main/cfg)
- **Actor parameterization.** The actor is a tanh-squashed diagonal Gaussian scaled to [−b, b]. Mean and log-std heads are initialized at scale 1e-2, and log-std is clipped to [−20, 2]. — [learned_std_normal_policy.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/networks/learned_std_normal_policy.py); [pixel_sac_learner.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/agents/pixel_sac/pixel_sac_learner.py)
- **README guidance:** "Typically setting `action_magnitude` around 1.5 and `utd` around 20 performs effectively, but for best performance these should be tuned on new environments." — [ajwagen/dsrl README](https://github.com/ajwagen/dsrl)

#### SAC settings in the official pi0 code
| Setting | LIBERO (code) | ALOHA (code) | Real Franka-DROID (code) | Paper pi0 table |
|---|---|---|---|---|
| Critics, reduction | 10, mean | 10, mean | 2, **min** | 10 / 10 / 2; "Clipped double Q-learning: False" for all |
| UTD | 20 gradient steps per stored transition (= per decision) | 20 | 30 | 20 / 20 / 30 |
| Discount | 0.999 per control step, stored as 0.999^20 per transition | 0.999^50 | 0.99^10 | 0.999 / 0.999 / 0.99 (per-query exponent not mentioned) |
| Target entropy | 'auto' = −32/2 = −16 | **0.0** | 0.0 | −d/2 / **−d/2** / 0 |
| Initial temperature; how it is learned | 1.0; `log_temp` trained with Adam at 3e-4 | same | same | not stated |
| Entropy in critic backup | no (`backup_entropy=False`) | no | no | not stated |
| Learning rates (actor / critic / temperature) | 1e-4 / 3e-4 / 3e-4 | same | same | actor 1e-4, critic 3e-4 |
| Batch, τ | 256, 0.005 | 256, 0.005 | 256, 0.005 | same |
| MLP | 128×3 + LayerNorm | 128×3 | 1024×3 | 128 / 128 / 1024, 3 layers |
| Encoder | 4 conv (32 ch, 3×3, strides 2,1,1,1) → Dense 50 + LayerNorm + tanh; actor and critic initialize separate encoder copies | same | strides 3,2,2,2; 3 cameras | "four convolutional layers" |
| Inputs | 64×64 agentview + 8-D state | 64×64 top camera + 14-D | three 128×128 cameras + joints/gripper + pi0 VLM 2,048-D feature | 64 / 64 / 128 |
| Augmentation | random crop (pad 4, edge) + color jitter | same | same | not stated |

Sources: [launch_train_sim.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/launch_train_sim.py); [launch_train_real.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/launch_train_real.py); [pixel_sac_learner.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/agents/pixel_sac/pixel_sac_learner.py); [temperature.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/agents/pixel_sac/temperature.py); [critic_updater.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/agents/pixel_sac/critic_updater.py); [actor_updater.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/agents/pixel_sac/actor_updater.py); [networks.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/networks/encoders/networks.py); [augmentations.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/data/augmentations.py); [train_utils_real.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_utils_real.py); [arXiv html v2](https://arxiv.org/html/2506.15799v2)

The update rules are:
- critic target: `rewards + discount * masks * next_q`, where next_q is the min or mean over target critics;
- actor loss: `(α·log π − Q_reduced).mean()`;
- temperature loss: `temperature * (entropy − target_entropy)`.

— [critic_updater.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/agents/pixel_sac/critic_updater.py); [actor_updater.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/agents/pixel_sac/actor_updater.py); [temperature_updater.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/jaxrl2/agents/pixel_sac/temperature_updater.py)

#### Query frequency, decisions per episode, reward, episode length, warm-up, step counting
- **LIBERO-90 task 57** ("pick up the cream cheese and put it in the tray"):
  - at most 400 control steps and query_freq 20, so at most 20 decisions per episode;
  - success means the final reward equals 1;
  - the checkpoint is `pi0_libero`, "fine-tuned for 30k steps on the Libero-{Spatial, Object, Goal, 10} suites, containing a total of 1,693 demonstrations on 40 tasks", so the target task is unseen.

  — [train_sim.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_sim.py); [arXiv TeX appendix](https://arxiv.org/e-print/2506.15799v2)
- **ALOHA TransferCube:**
  - at most 400 steps and query_freq 50, so at most 8 decisions;
  - success means reward 4;
  - `pi0_aloha_sim` was "fine-tuned for 20k steps using 50 demonstrations on the same task".

  — [train_sim.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_sim.py); [arXiv TeX appendix](https://arxiv.org/e-print/2506.15799v2)
- **Real Franka:**
  - 15 Hz, at most 200 steps, query_freq 10, so at most 20 decisions;
  - a human types 1 or 0 for success, and 'q' stops the loop;
  - the gripper is binarized and actions are clipped to [−1, 1].

  — [train_utils_real.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_utils_real.py)
- **Reward.** The paper says the agent "receives –1 at every time step until it succeeds, at which point it receives 0". The code applies this per decision:
  - success: rewards `[-1,…,-1, 0]`, with mask 0 on the last transition;
  - failure: all −1 with mask 1, so timeouts are bootstrapped.

  — [arXiv html v2](https://arxiv.org/html/2506.15799v2); [train_utils_sim.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_utils_sim.py)
- **Update schedule.**
  - Each trajectory triggers `len(traj["rewards"]) * multi_grad_step` gradient steps, i.e. the UTD is per decision.
  - Updates start only once the buffer holds more than `start_online_updates` transitions: 500 for LIBERO, 1,000 for ALOHA.
  - The real robot starts after one trajectory, with 5,000 gradient steps at the first update.
  - The online buffer holds max_steps // UTD transitions (25,000 for LIBERO).

  — [train_utils_sim.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_utils_sim.py); [run_libero.sh](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/scripts/run_libero.sh); [run_aloha.sh](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/scripts/run_aloha.sh); [train_utils_real.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_utils_real.py)
- **Step counting.** The loop counter `i`, which is used for `max_steps` and as the W&B `step=`, counts *gradient steps*. Environment control steps are logged separately as `env_steps`. — [train_utils_sim.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_utils_sim.py)
- **Real-robot observation.** The paper uses "the final token's last hidden feature from π0's VLM backbone (a 2,048-dimensional vector)" plus proprioception and a shallow CNN over the left, right and wrist cameras. DSRL trained on an RTX 3070 (8 GB), with pi0 on a remote server. — [arXiv TeX appendix](https://arxiv.org/e-print/2506.15799v2)

#### Run scripts (argument lines verbatim; env exports omitted)
LIBERO ([run_libero.sh](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/scripts/run_libero.sh); the script also runs `pip install mujoco==3.3.1`):
```
python3 examples/launch_train_sim.py --algorithm pixel_sac --env libero --prefix dsrl_pi0_libero \
--wandb_project ${proj_name} --batch_size 256 --discount 0.999 --seed 0 --max_steps 500000 \
--eval_interval 10000 --log_interval 500 --eval_episodes 10 --multi_grad_step 20 \
--start_online_updates 500 --resize_image 64 --action_magnitude 1.0 --query_freq 20 --hidden_dims 128
```
ALOHA ([run_aloha.sh](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/scripts/run_aloha.sh); `mujoco==2.3.7`):
```
python3 examples/launch_train_sim.py --algorithm pixel_sac --env aloha_cube --prefix dsrl_pi0_aloha \
--wandb_project ${proj_name} --batch_size 256 --discount 0.999 --seed 0 --max_steps 3000000 \
--eval_interval 10000 --log_interval 500 --eval_episodes 10 --multi_grad_step 20 \
--start_online_updates 1000 --resize_image 64 --action_magnitude 2.0 --query_freq 50 --hidden_dims 128 \
--target_entropy 0.0
```
Real ([run_real.sh](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/scripts/run_real.sh)):
```
python3 examples/launch_train_real.py --algorithm pixel_sac --env franka_droid --prefix dsrl_pi0_real \
--wandb_project ${proj_name} --batch_size 256 --discount 0.99 --seed 0 --max_steps 500000 \
--eval_interval 2000 --log_interval 100 --multi_grad_step 30 --resize_image 128 --action_magnitude 2.5 \
--query_freq 10 --hidden_dims 1024 --num_qs 2
```

**Robomimic and Gym configs** (DSRL-NA, except Transport which uses DSRL-SAC). Common settings:
- `n_critics: 2`, `critic_backup_combine_type: min`, `target_ent: 0.0`, `ent_coef: auto`;
- LayerNorm, batch 256, actor lr 3e-4, τ 0.005;
- 4 training environments; 200 evaluation episodes per evaluation point.

— [cfg/robomimic](https://github.com/ajwagen/dsrl/tree/main/cfg/robomimic); [cfg/gym](https://github.com/ajwagen/dsrl/tree/main/cfg/gym); [train_dsrl.py](https://github.com/ajwagen/dsrl/blob/main/train_dsrl.py)

| Task | utd | γ | hidden | b_W | init_rollout_steps (×4 envs) | Paper "Initial steps" | DDIM inference steps |
|---|---|---|---|---|---|---|---|
| Lift | 30 | 0.99 | 2048 | 1.5 | 1501 | 24,000 | 8 |
| Can | 20 | 0.99 | 2048 | 1.5 | 1501 | 24,000 | 8 |
| Square | 20 | 0.999 | 2048 | 1.5 | 2001 | 32,000 | 8 |
| Transport (SAC) | 20 | 0.99 | 128 | 1 | 20001 | 320,000 | 100 |
| Hopper / Walker / HalfCheetah | 20 (train_freq 2) | 0.99 | 128 / 2048 / 1024 | 1.5 / 2.5 / 1.5 | 2001 | 32,000 | 5 |

In the Robomimic and Gym code, DSRL-SAC uses a full per-step noise action space: `action_dim*action_horizon` dims bounded by `action_magnitude`, with no tiling. Warm-up rollouts use i.i.d. `torch.randn` noise, clipped to the magnitude for SAC only. — [env_utils.py](https://github.com/ajwagen/dsrl/blob/main/env_utils.py); [utils.py](https://github.com/ajwagen/dsrl/blob/main/utils.py)

#### Code vs paper discrepancies
- **ALOHA target entropy:** 0.0 in the script, −d/2 in the paper. — [run_aloha.sh](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/scripts/run_aloha.sh); [arXiv TeX](https://arxiv.org/e-print/2506.15799v2)
- **Real-robot critic:** the code takes the min over 2 critics, but the paper's table says "Clipped double Q-learning: False". — [launch_train_real.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/launch_train_real.py)
- **Hopper hidden size:** 2048 in the paper, `layer_size: 128` in the config. — [dsrl_hopper.yaml](https://github.com/ajwagen/dsrl/blob/main/cfg/gym/dsrl_hopper.yaml)
- **Transport warm-up:** the paper says 320,000 initial steps. The config's 20,001 chunk-steps × 4 envs × 8-step chunks is about 640k control steps (my arithmetic). The other tasks match: 1,501 × 4 × 4 ≈ 24,000 and 2,001 × 4 × 4 ≈ 32,000.
- **Real-robot VLM feature:**
  - The code takes `img_rep_pi0[:, -1, :]` but declares a state dimension of `8 + 2024`, which conflicts with the 2,048-D feature.
  - Issue #11 (open, no author reply) argues that because language is padded to 200 tokens, the last prefix token is padding and its feature is likely uninformative.

  — [train_real.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_real.py); [train_utils_real.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_utils_real.py); [issue #11](https://github.com/nakamotoo/dsrl_pi0/issues/11)
- **Entropy in the critic backup:** absent in the pi0 code; present in the SB3 DSRL-NA code (`next_q_values - ent_coef * next_log_prob`). An open issue asks why, and also why the real robot uses target entropy 0. — [dsrl.py](https://github.com/ajwagen/stable-baselines3-dsrl/blob/master/stable_baselines3/dsrl/dsrl.py); [issue #14](https://github.com/nakamotoo/dsrl_pi0/issues/14)

### Inferences
- **Per-decision discount and effective horizon 1/(1−γ):**

  | Run | γ per decision | Effective horizon | Decisions per episode |
  |---|---|---|---|
  | LIBERO | 0.999^20 = 0.980 | ≈ 50 | ≤ 20 |
  | ALOHA | 0.999^50 = 0.951 | ≈ 20 | ≤ 8 |
  | Real | 0.99^10 = 0.904 | ≈ 10 | ≤ 20 |

  In every published pi0 run, the effective horizon is at most a few times the number of decisions per episode.
- **The −1 reward anchors the critic.** With −1 per decision, Q for a failing policy sits near −1/(1−γ_dec): about −50 (LIBERO), −20 (ALOHA) or −10 (real). Value gaps between noise actions are O(1–50). Every transition also carries a dense −1 that pins down the critic.
- **The untrained actor emits weak noise.** Because of the 1e-2 head initialization, the untrained actor outputs about b·tanh(z) with z ~ N(0,1). Numerically E[tanh²(z)] = 0.394:
  - at b = 1, RMS ≈ 0.63 per dim (32-dim norm ≈ 3.55, vs ≈ 5.66 for N(0, I₃₂));
  - at b = 1.5, variance ≈ 0.89, roughly matching N(0,1).

  This may be why "≈1.5" is the README default; the authors never state this rationale.
- **The temperature can only fall slowly.** `log_temp` is trained by Adam at 3e-4, so it moves by at most about 3e-4 per update. Starting from α₀ = 1:
  - after 7,500 updates, α ≥ ≈ e^(−2.25) ≈ 0.1;
  - after 19,500 updates, α ≥ ≈ 0.003.
- **Episode counts depend on the x-axis.** Paper curves are labelled "Timesteps", and it is unclear whether that means gradient steps (the W&B step) or control steps.
  - LIBERO: the two readings nearly coincide, because UTD 20 per decision equals 20 control steps per decision.
  - ALOHA: they differ by 2.5× (20 gradient steps vs 50 control steps per decision).

### Gaps
- The paper does not justify, ablate or quantify:
  - applying the discount per query;
  - mean vs min critic reduction;
  - the real-robot target entropy of 0.
- I could not inspect the public W&B logs (wandb.ai/mitsuhiko/DSRL_pi0_public, a JS app), so the x-axis unit is unresolved.
- No GPU type or wall-clock is reported for the pi0 simulation runs.
- I found no public peer reviews.

## 2. Where DSRL succeeded, and with what budgets

### Takeaway
Every published DSRL success shares the same profile:
- a single task;
- a base policy with non-trivial native success (≈10–75%);
- short episodes (≤ 20 decisions for pi0).

Budgets were large in simulation:
- pi0-LIBERO: ≈70–100k steps, ≥ 250 episodes;
- pi0-ALOHA: ≈0.45–1.5M steps;
- Robomimic and Gym: millions of steps.

Real-robot wins took 40–150 episodes, with human-labelled rewards and resets. Most curves dip below the base before they improve.

### Cited Findings
| Experiment (sim/real) | Variant | Base | Result | Budget | Eval | Source |
|---|---|---|---|---|---|---|
| Robomimic Lift (sim) | NA | ≈0.75 | dips to ≈0.67 at ≈60k; ≈0.97 by ≈0.25M; ≈1.0 by ≈0.5M (fig.) | 5 seeds; 24k initial steps | 200 eps per point | [arXiv TeX](https://arxiv.org/e-print/2506.15799v2) |
| Robomimic Can (sim) | NA | ≈0.45 | dips to ≈0.3; ≈0.97 by ≈1M (fig.) | 24k initial | 200 | same |
| Robomimic Square (sim) | NA | ≈0.45 | dips to ≈0.33; ≈0.97 by ≈2–3M (fig.) | 32k initial | 200 | same |
| Robomimic Transport (sim) | SAC | ≈0.2 | ≈0.7–0.75 at ≈10–15M (fig.) | 320k initial | 200 | same |
| Gym Hopper (sim) | NA | ≈1.5k return | ≈3k by ≈0.7M (fig.) | x-axis to 5M | 200 | same |
| Gym Walker2D (sim) | NA | ≈2.3k (start of other methods) | DSRL's first point ≈0.9k, ≈3.8k by ≈0.4M, ≈4.2k at 3M (fig.) | x-axis to 3M | 200 | same |
| Gym HalfCheetah (sim) | NA | ≈4.1k | ≈5k by ≈4–5M (fig.) | x-axis to 5M | 200 | same |
| Online claim | — | — | "at least a 5-10× improvement in efficiency" over DPPO, IDQL, DQL, DIPO, QSM | — | — | [arXiv TeX](https://arxiv.org/e-print/2506.15799v2) |
| OGBench offline, 10 tasks (sim) | NA | BC(π_dp) 0–3% | cube-double 53; scene 88; puzzle-4x4 37; antmaze-large 40; humanoidmaze-medium 34; humanoidmaze-large 10; puzzle-3x3 0; antmaze-giant 0 | flow policy 1M steps | 4 seeds, ± 1 sd | [arXiv TeX](https://arxiv.org/e-print/2506.15799v2) |
| Robomimic Can and Square offline→online (sim) | NA | — | sample efficiency improved "by a factor of approximately 2×"; "standard offline-to-online RL approaches are not able to learn at all on these tasks" | — | — | [arXiv TeX](https://arxiv.org/e-print/2506.15799v2) |
| Franka cube→bowl; single-task CNN diffusion policy trained on a narrow, self-collected expert dataset (real) | SAC | 2/10 | 9/10 (RLPD 0/10; RLPD + interventions 0/10) | "3500 online steps (approximately 40 episodes)" | 10 | [arXiv TeX](https://arxiv.org/e-print/2506.15799v2) |
| WidowX, Bridge-V2 multi-task DiT; mushroom / drawer / stacking (real) | SAC | ≈0.1 / ≈0.6 / ≈0.45 | ≈1.0 / ≈0.9–1.0 / ≈0.8–0.9; first points dip to ≈0.2 (drawer) and 0.0 (stacking) (fig.) | "100-150 episodes" after 20 base rollouts; γ 0.97, b_W 2 / 2 / 1.5, UTD 30 / 20 / 20, hidden 1024 / 2048 / 1024 | 20 / 10 / 10 | [arXiv TeX](https://arxiv.org/e-print/2506.15799v2) |
| pi0 LIBERO-90 #57 (sim) | SAC, tiled | dashed base ≈0.19; DSRL's first point ≈0.13 | ≈0.8 at ≈40k; 1.0 at ≈70k; fluctuates ≈0.77–1.0 to 350k (fig.) | "≈10,000 online samples" (author: 100,000) | 10 eps per point, 3 seeds | [arXiv TeX](https://arxiv.org/e-print/2506.15799v2); [issue #1](https://github.com/nakamotoo/dsrl_pi0/issues/1) |
| pi0 ALOHA TransferCube (sim) | SAC, tiled | ≈0.65 | starts ≈0.57; collapses to ≈0.03 near 0.1M; first ≈0.9 at ≈0.45M; fluctuates ≈0.65–0.93 to ≈1.3M; then ≈0.9–1.0 by 1.5M (fig.) | script max_steps 3M gradient steps | 10, 3 seeds | [arXiv TeX](https://arxiv.org/e-print/2506.15799v2) |
| pi0-DROID "turn on the toaster" (real) | SAC, tiled | 5/20 | 18/20 | 80 episodes (≈11,000 steps) | 20 | [arXiv html v2](https://arxiv.org/html/2506.15799v2) |
| pi0-DROID "put the spoon on the plate" (real) | SAC, tiled | 15/20 | 19/20 | 65 episodes (≈10,000 steps) | 20 | [arXiv html v2](https://arxiv.org/html/2506.15799v2) |

- **pi0 baselines (fig.):** ResiP and V-GPS stay at ≈0.25–0.45 on LIBERO and ≈0.6–0.8 on ALOHA. — [arXiv TeX](https://arxiv.org/e-print/2506.15799v2)
- **Hardware:**
  - Robomimic/Gym and the offline experiments: "run on an NVIDIA A5000 GPU";
  - WidowX: an RTX 4090;
  - real pi0: an RTX 3070.

  No wall-clock is reported. — [arXiv TeX appendix](https://arxiv.org/e-print/2506.15799v2)
- **Third-party reproductions:**
  - One user reproduced Can only "after training for 100 hours on our server". `n_envs=50` "works much better". — [dsrl issue #2](https://github.com/ajwagen/dsrl/issues/2)
  - Transport (both SAC and NA) was not reproduced after "four days on a RTX 5090". — [dsrl issue #5](https://github.com/ajwagen/dsrl/issues/5)
- **Wall-clock vs CEM:** to run 1M environment steps on Robomimic Lift and 2M on Can, "plain CEM is about 15–20× faster than DSRL". — [Golden Ticket](https://arxiv.org/abs/2603.15757)

### Inferences
- **Episode counts implied by the budgets:**
  - LIBERO: ≈100k steps at ≤ 400 per episode is ≥ 250 episodes, under either x-axis reading.
  - ALOHA, to 1.5M: ≥ 3,750 episodes if the axis is control steps; ≈ 75k decisions (≥ 9,375 episodes) if it is gradient steps.
  - Real pi0: ≈140–155 control steps per episode.
  - WidowX: ≈30–70.
- **Warm-up alone exceeds our whole training budget in episodes:**
  - LIBERO: > 500 transitions at ≤ 20 decisions per episode, so ≥ 25 episodes;
  - ALOHA: > 1,000 transitions at ≤ 8 per episode, so ≥ 125 episodes.
- **Every positive result has this profile:** a single task, native base success ≥ ≈10%, and ≤ 20 decisions per episode (≤ 400 control steps for pi0 simulation).
- **Early dips below the base are the norm.** They appear in:
  - Lift, Can and Square;
  - ALOHA, to ≈3%;
  - WidowX drawer and stacking;
  - all four data-quality splits (Section 4).

  A 24-episode run would plausibly end inside this dip.

### Gaps
- Curve values are my readings of the figures.
- Per-seed variance and wall-clock are not reported for any pi0 run.

## 3. DSRL-NA (noise aliasing) and the offline and offline-to-online variants

### Takeaway
DSRL-NA works in three steps:
1. It learns an action-space critic Q^A by TD on ordinary (s,a,r,s′) data, taking the next action as the base policy's denoising of the actor's noise.
2. It distills Q^A into a noise critic Q^W, using fresh N(0,I) noise.
3. It trains the actor on Q^W.

Because of this, it can use demonstrations and native-noise rollouts that have no noise labels. The cost is many more base-policy forward passes, which is why pi0 used DSRL-SAC.

Reported gains:
- about 2× over SAC on Square;
- strong offline results;
- about 2× faster offline-to-online.

One third party found that the gain over SAC mostly disappears once a termination bug is fixed.

### Cited Findings
- **Algorithm 1:**
  1. Q^A is trained with min E[(Q^A(s,a) − r − γ Q̄^A(s′,a′))²], where a′ = π_dp^W(s′, π^W(s′)).
  2. Q^W is distilled with min E_{w~N(0,I)}[(Q^W(s,w) − Q^A(s, π_dp^W(s,w)))²].
  3. The actor is trained with max E[Q^W(s, π^W(s))].

  The replay buffer can be initialized with offline data. — [arXiv html v2](https://arxiv.org/html/2506.15799v2)
- **Implicit offline conservatism:** "by construction π_dp^W will only output in-distribution actions"; Q^A is queried only on dataset actions and π_dp outputs. — [arXiv TeX method](https://arxiv.org/e-print/2506.15799v2)
- **SB3 implementation:**
  - the Q^A target denoises the actor's next noise and subtracts the entropy term;
  - Q^W is distilled on `th.randn` noise passed through the base policy, with 10 noise-critic steps per update in the configs (the SB3 default is 1);
  - warm-up rollouts store real actions for NA and noise for SAC;
  - an offline `.npz` of real-action transitions can be preloaded via `load_offline_data`.

  — [dsrl.py](https://github.com/ajwagen/stable-baselines3-dsrl/blob/master/stable_baselines3/dsrl/dsrl.py); [utils.py](https://github.com/ajwagen/dsrl/blob/main/utils.py); [train_dsrl.py](https://github.com/ajwagen/dsrl/blob/main/train_dsrl.py)
- **Online gain over SAC:**
  - NA needs about 2× fewer samples than SAC on Square. On Can the trend is "somewhat less pronounced".
  - The best SAC settings matched NA's except for "a hidden size of 128".

  — [arXiv TeX appendix](https://arxiv.org/e-print/2506.15799v2)
- **README:** "In general `DSRL-NA` is more sample efficient and should be preferred to `DSRL-SAC`, however `DSRL-SAC` is somewhat more computationally efficient." — [ajwagen/dsrl README](https://github.com/ajwagen/dsrl)
- **Offline (OGBench) settings:**
  - FQL flow policy trained for 1M steps;
  - 10 critics with mean aggregation (the baselines used 2);
  - GELU; 4 layers × 512; 10 flow steps; lr 3e-4; batch 256;
  - per-task b_W 0.5–1.5 and γ 0.99–0.995, with b_W tuned as the "degree of conservatism".

  — [arXiv TeX appendix](https://arxiv.org/e-print/2506.15799v2)
- **Why pi0 used SAC:** an author confirmed "we use the DSRL-SAC variant for the pi0 experiments". A user noted that NA needs π0 inference both for every next action and for every distillation sample, which "takes much longer time". — [issue #2](https://github.com/nakamotoo/dsrl_pi0/issues/2); [issue #8](https://github.com/nakamotoo/dsrl_pi0/issues/8)
- **Third-party pi0 DSRL-NA port (arayabrain; announced 16 Mar 2026, 2026).**
  - Engineering:
    - KV cache saved during rollouts and reused in training;
    - batched VLA inference, sharded across GPUs;
    - "around 2.4 - 2.7 iterations/second" on 4 A100s at batch 128;
    - the first ≤ 3,000 updates take about 20 minutes.
  - ALOHA script:
    - action magnitude 0.75; 125 initial trajectories; 10 critics; target entropy 0; `backup_entropy=0`; γ 0.999; hidden 128; max_steps 1M; online buffer 150k;
    - per update: 15 action-critic, 5 noise-critic and 5 noise-actor steps (script comment: "UTD = action_critic_steps + noise_critic_steps" = 20);
    - `grl_noise_sample=1`, defined as "For noise critic distillation, sample half the noise from the noise actor".
  - The authors say pi0.5 is supported and was used in "a lot of in-house experiments", but publish no numbers and have not deployed on a real robot.
  - A collaborator found that 5 flow steps showed no degradation; with the KV cache, 10 → 5 flow steps was 1.75× faster.

  — [issue #8](https://github.com/nakamotoo/dsrl_pi0/issues/8); [run_aloha_sim_na.sh](https://github.com/arayabrain/dsrl_pi0_na/blob/main/examples/scripts/run_aloha_sim_na.sh); [launch_train_aloha_sim_na.py](https://github.com/arayabrain/dsrl_pi0_na/blob/main/examples/launch_train_aloha_sim_na.py)
- **Bugs reported in the SB3/Robomimic code** (third-party, 2026):
  - DSRL-SAC warm-up actions are "denoised twice";
  - the timestep count is off by the chunk factor;
  - DSRL-NA "doesn't consider `action_magnitude`. As a consequence it's as if you always set `action_magnitude` equal to 1";
  - the chunk wrapper returns `truncated=False`, so episodes run to a fixed length and false truncations are bootstrapped. After fixing this, "there is little gain for DSRL NA over DSRL SAC".

  — [dsrl issue #6](https://github.com/ajwagen/dsrl/issues/6)
- **NA-style successors:**
  - **GR-RL (Dec 2025):**
    - an offline TD3+BC critic serves as a task-progress model;
    - a distributional noise critic is distilled with a cross-entropy loss on ε ~ N(0,1) with probability 0.5, else on the noise predictor's output;
    - it collected "673 trajectories generated by the offline model" to align the critic.

    — [GR-RL](https://arxiv.org/abs/2512.01801)
  - **RLMM-Flow (2026):** "we warm up an action-space critic before jointly training the latent critic and latent actor". — [RLMM-Flow](https://arxiv.org/abs/2607.26460)
  - **HAF (2026):** maps demonstrated trajectories "back to their initial flow noise through numerical reverse integration", keeps "the first 8 temporal DCT coefficients", and trains a regularized SAC offline-to-online. — [HAF](https://arxiv.org/abs/2608.16837)

### Inferences
- NA, flow inversion (Section 6d) or success-weighted regression are the DSRL-family routes that can learn from our native i.i.d.-noise rollouts, where our ≈25% successes live [brief]. Plain DSRL-SAC cannot use them, because those rollouts carry no tiled-noise labels.
- On pi0.5, NA's bottleneck is VLA forward passes per update. At ≈2.5 updates/s on 4 A100s, it would compete with our 3–4 RTX 4090 lanes, which are also running simulation [brief].

### Gaps
- No published DSRL-NA numbers exist on pi0.5. Its advantage on VLAs is unmeasured, and contested even in simulation (dsrl issue #6).

## 4. Ablations, authority of the noise space, stated limitations, and low-base and long-horizon behaviour

### Takeaway
What the paper ablates and what it does not:
- **Ablated:** NA vs SAC, base-policy width, data quality, BC epochs, and train/inference denoising steps.
- **Not ablated:** action magnitude, noise dimensionality, and repeated vs per-step noise. Tiling is supported only by assertion.

The paper's own limitations concede that DSRL can only exploit behaviour the base already explores. Later 2026 work, including two papers co-authored by DSRL authors, shows plain DSRL failing on long-horizon tasks and on tasks the base rarely or never solves.

### Cited Findings
- **Paper ablations** (Robomimic Can unless noted):
  - Width: all base-policy widths were steerable.
  - Data quality: dashed base rates are Better ≈0.72, All ≈0.65, Okay ≈0.52, Worse ≈0.27 (fig.).
    - *All four* DSRL curves dip sharply at the first evaluation after training starts: to ≈0.1–0.2, and "Worse" to ≈0.01 (fig.).
    - Worse recovers more slowly, reaching ≈0.9 by ≈0.5M (fig.).
    - The text says DSRL works "as long as π_dp still exhibits some task-solving behavior".
  - Epochs: training for 3,000, 6,000 or 9,000 epochs "has almost no effect on the performance of DSRL".
  - Denoising steps: "neither the number of train steps or inference steps has virtually any impact".
  - NA beats SAC: ≈2× on Square, "somewhat less pronounced" on Can.

  — [arXiv TeX](https://arxiv.org/e-print/2506.15799v2)
- **Stated best practices:**
  - large networks ("layer size up to 2048");
  - LayerNorm;
  - high UTD;
  - bounded action magnitude.

  — [arXiv TeX appendix](https://arxiv.org/e-print/2506.15799v2)
- **Limitations (verbatim):** "the exploration capabilities of DSRL are inherently determined by the underlying diffusion policy … we do not have a guarantee that all diffusion policies are steerable, nor that all such policies provide adequate exploration. A highly concentrated action distribution (e.g., a policy trained on very narrow data) might not provide enough 'options' for our method to select from, limiting its ability to improve, and our approach does not currently offer a clear way to quantify in advance how much improvement is possible with a given diffusion policy." DSRL also "requires reward signals, online rollouts … and resets". — [arXiv TeX appendix](https://arxiv.org/e-print/2506.15799v2); [PMLR PDF](https://raw.githubusercontent.com/mlresearch/v305/main/assets/wagenmaker25a/wagenmaker25a.pdf)
- **On difficulty:** both pi0 tasks are "extremely challenging for RL agents due to their complex nature---including high control frequency, long horizons, large observation and action spaces, and sparse rewards". Both cap at 400 control steps. — [arXiv TeX](https://arxiv.org/e-print/2506.15799v2); [train_sim.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_sim.py)
- **Open question the authors pose:** "Can we make any claims about the expressivity of the noise-space optimization we employ or the structure of the diffusion policy's noise space and ease of learning a policy over it?" — [arXiv TeX main.tex](https://arxiv.org/e-print/2506.15799v2)
- **Noise dimension and tiling (third party):**
  - **Golden Ticket (2026, Mar):**
    - On pi0 LIBERO, "DSRL on the full 1600D noise (dashed) fails to improve on the base policy".
    - DSRL "tiles the noise space, which departs from the i.i.d. pretraining noise and removes all temporal variation within the chunk".
    - In Golden Ticket's own search, "searching a tiled space leads to worse performance due to a constrained search space".

    — [Golden Ticket](https://arxiv.org/abs/2603.15757)
  - **PSS (2026, Sep):**
    - High-dimensional noise has "strongly anisotropic effects on decoded actions".
    - SAC over k = 8 leading response directions (out of D = 28 on Robomimic) "converges faster and exhibits more stable late-training behavior than full-latent control".
    - Leading directions beat "random and least-responsive subspaces of equal dimension".

    — [PSS](https://arxiv.org/abs/2609.33765)
- **Noise authority (third party):**
  - Golden Ticket improved "46 out of 51 tasks", with gains of "up to 79% for simulated tasks", using a single constant noise vector. — [Golden Ticket](https://arxiv.org/abs/2603.15757)
  - With π0.5-LIBERO, selecting noise to control chunk-boundary artifacts raised success "from 0.033 to 0.717" in one selected context (2026). — [Chunk-boundary](https://arxiv.org/abs/2603.11642)
- **Limited to the base's support:**
  - **SARL** (2026, Jun; Wagenmaker and Levine co-authors): "DSRL can filter to find good actions from the base policy's distribution, but cannot synthesize fundamentally new ones". DSRL and residual RL "are unable to learn at all on several tasks" (π0.5, LIBERO-10 and WidowX). — [SARL](https://arxiv.org/abs/2606.31958)
  - **MiDAS** (2026): at a critical LIBERO-Long state, "actions from Filtered BC and DSRL remain concentrated near samples from π_base and fail". — [MiDAS](https://arxiv.org/abs/2608.11363)
  - **OGPO** (2026; Nakamoto co-author):
    - Steering "relies on sufficient base policy action coverage, leading to suboptimal performance when the base policy's performance is poor".
    - It struggles on "high-precision tasks such as the Adroit task suite".
    - "In some tasks, DSRL performance crashes despite heavy tuning". The authors attribute some of this to running DSRL on a flow-based policy.

    — [OGPO](https://arxiv.org/abs/2605.03065)
  - **TMRL** (2026): DSRL reaches ≈90% in pointmaze-giant but "near-0 success rates on the higher-dimensional task cube-single". On LIBERO-90 it "overfits to picking up the same object each time". — [TMRL](https://arxiv.org/abs/2605.12236)
  - **LP-DS** (ICML 2026): "DSRL collapses immediately to a single mode". It "predicts high-magnitude latent queries that correlate with unstable decoding and performance degradation". — [LP-DS](https://arxiv.org/abs/2606.01151)
  - **RFS** (2026): DSRL was the *strongest* baseline (0.74 grasp, 0.70 pick-and-place, 0.64 packing, 0.43 push-to-grasp), "but only 0.15 on stacking and 0.26 on pouring". — [RFS](https://arxiv.org/abs/2602.01789)
- **Low base success:**
  - **FRS** (2026, Jun; Tang, Chen, Wagenmaker, Finn, Levine): on "10 LIBERO-90 tasks that the base VLA get close to 0% average success rate on", "Naive DSRL struggles to learn – only reaching a final success rate of around 30%".
    - For these tasks, DSRL dropped tanh and added "0.1 KL relative to the standard normal". In their words: "We find that without this change, overall DSRL performance is very low."
    - Prefilling with one FRS success made it work.

    — [FRS](https://arxiv.org/abs/2606.13675)
  - **PostBC** (Dec 2025; Wagenmaker co-author): running DSRL on LIBERO-90 Kitchen Scene 2, "PostBc pretraining leads to significant gains … enabling efficient RL finetuning in settings where both standard Bc pretraining and σ-Bc pretraining fail". — [PostBC](https://arxiv.org/abs/2512.16911)
- **Critic stability at high UTD:**
  - **Symmetry-aware steering:** high UTD "presented as a best practice for DSRL" is "prone to Q-value divergence". Standard DSRL "frequently (3 out of 5 seeds) suffered from performance collapse attributed to significant Q-value divergence" (also in Lift). — [Symmetry-aware steering](https://arxiv.org/abs/2512.11345); background: [Hussing et al.](https://arxiv.org/abs/2403.05996)
  - **NSL** (2026, Oct): "Without a noise limit, the actor's Gaussian means drift farther from initialization … while the upper tail of critic targets remains above the return bound." — [NSL](https://arxiv.org/abs/2610.13943)
- **Checkpoint responsiveness:**
  - AWLS (CoRL 2026) proposes "a rollout-free decoder-sensitivity criterion for selecting pretrained checkpoints that remain responsive to latent-noise perturbations". — [AWLS](https://arxiv.org/abs/2610.27736)
  - "Breaking Lock-In" (2026, Apr) reports that after low-data SFT, VLAs become "overly specialized to the post-training data". Here "steerability" means responding to new *instructions*, not noise. — [Breaking Lock-In](https://arxiv.org/abs/2604.23121)

### Inferences
- Noise has real authority over execution details such as grasp approach, chunk boundaries and mode choice. That authority is bounded by what the frozen policy can emit, and it plausibly shrinks under narrow SFT.
- For a conjunctive safe-completion goal that the policy reaches about 25% of the time [brief], the authority is probably sufficient in principle. In practice, the steering parameterization must not first destroy those successes.
- I found no failure cases reported in the DSRL paper itself.

### Gaps
- There is no controlled, author-run ablation on any VLA of:
  - tiling vs per-step noise;
  - magnitude;
  - noise dimensionality.
- The third-party evidence is spread across preprints and issues and is mostly single-task.

## 5. GitHub issues, discussions and third-party reproductions

### Takeaway
The trackers document our failure pattern almost exactly. Several users report that copying one noise vector across the chunk breaks briefly fine-tuned pi0 or pi0.5 checkpoints and joint-space setups: motions are erratic, and the initial successes needed by the sparse reward disappear.

Workarounds offered:
- train the checkpoint longer (≈30k steps);
- use full or partial per-step noise;
- shuffle the tiled noise.

There is a counterpoint: one user found pi0.5 with tiling "fine" on LIBERO. A real-world run from a 40%-success base was unstable.

### Cited Findings
- **[Issue #1](https://github.com/nakamotoo/dsrl_pi0/issues/1):** "based on the W&B logs, the success rate seems to reach 100% around 50k steps and stabilizes closer to 100k steps". A second user saw stabilization at about 50k. The author confirmed the typo.
- **[Issue #6](https://github.com/nakamotoo/dsrl_pi0/issues/6):**
  - alexander-cobot: "The robot was behaving erratically with the original paper's formulation - my guess is because the noise didn't look 'noisy' enough". He settled on repeating the vector and then applying a fixed-seed shuffle.
    - Later he clarified that this was for selecting a behaviour in an unseen environment, not for improving a target-task policy.
  - yachenkang: interpolate-and-shuffle improved exploration, but "the SAC policy fails to learn useful information".
- **[Issue #9 (pi0.5)](https://github.com/nakamotoo/dsrl_pi0/issues/9):**
  - omarrayyann (DROID, joint position): "performance degrades significantly when the noise remains consistent across chunks". It "worked fine … when i optimized the whole noise space", but with repetition it "behaved very weirdly, not getting a single success for the sparse reward to work".
  - kcyoung98 (pi0.5, joint-space mobile ALOHA) saw the same failure. The interpolate-and-shuffle trick from #6 fixed it.
  - jesbu1 (pi0.5 fork [dsrl_openpi](https://github.com/jesbu1/dsrl_openpi)), tested in LIBERO: "Seems to work fine for me".
  - shivakanthsujit (internal 10-task set, ≈450 demos, fine-tuned from pi05_base):
    - "When we took the 5k ckpt, we couldn't use repeated noise. But the 30k ckpt was fine."
    - Repeated noise "reduces the initial policy performance, but is still able to improve".
    - The full 32×25 noise "was really difficult for the DSRL policy to optimize".
  - Another suggestion: predict 3 noises and tile each 5 times.
- **[Issue #12](https://github.com/nakamotoo/dsrl_pi0/issues/12)** (real Franka; pi0 after SFT on 20 SpaceMouse trajectories):
  - "it is impossible to collect successful data under repeated noise. In contrast, under non-repeated, fully random Gaussian noise, the success rate is actually quite high."
  - The user's diagnosis: "if the number of training epochs for pi0 model sft is too small, it will lead to a very low success rate when using repeated noise … making it difficult to obtain a successful init trajectory before the first update."
  - Another user: "severe changes between different action chunks which make the deployment very dangerous".
  - Unresolved.
- **[Issue #15](https://github.com/nakamotoo/dsrl_pi0/issues/15):** after task fine-tuning, "the policy with repeated noise does not work at all. The robot's behavior looks pretty weird (it stretches and never tries to complete the task...)".
- **[Issue #13](https://github.com/nakamotoo/dsrl_pi0/issues/13):** severe jumps between chunks on a humanoid persisted even at action magnitude 0.005. The cause was "using different action_horizon between training and deploying".
- **[Issue #10](https://github.com/nakamotoo/dsrl_pi0/issues/10):** a real pi0 with ≈40% base success, trained with the paper's real-world hyperparameters, did not maximize sparse rewards. Adjusting the entropy coefficient and MLP width, or removing the VLM feature, did not stabilize training. Another user: action magnitude "is playing a very important role".
- **[Issue #4](https://github.com/nakamotoo/dsrl_pi0/issues/4):** a simulated-WidowX pi0 at ≈30% base gives results "really different to the results in the paper". No reply.
- **[Issue #3](https://github.com/nakamotoo/dsrl_pi0/issues/3):** strange arm motions with the pinned openpi submodule; fixed by jax 0.5.3.
- **[Issue #11](https://github.com/nakamotoo/dsrl_pi0/issues/11):** the last-token VLM feature is likely padding. Sending the full hidden state and KV cache over the websocket took "a second or more" per query; indexing server-side cut it to ≈50 ms.
- **[Issue #14](https://github.com/nakamotoo/dsrl_pi0/issues/14):** backup entropy is False in the pi0 code and True in the simulation code. The target entropy is 0 for real vs −d/2 elsewhere. Unanswered.
- **ajwagen/dsrl issues:**
  - [#2](https://github.com/ajwagen/dsrl/issues/2): Can reproduced after 100 h; `n_envs=50` much better.
  - [#3](https://github.com/ajwagen/dsrl/issues/3): asks for the single-task real diffusion-policy code; replication failed on a custom image-conditioned task with two different base policies. Unanswered.
  - [#5](https://github.com/ajwagen/dsrl/issues/5): Transport not reproduced.
  - [#6](https://github.com/ajwagen/dsrl/issues/6): bugs (Section 3).
  - [#7](https://github.com/ajwagen/dsrl/issues/7): the data-quality ablation needs the authors' data files.
- **RLinf DSRL example:** pi0 on LIBERO-Spatial with 10 Q-heads, γ 0.999, target entropy −16, initial α 1.0, 16 training environments, at most 240 steps. No results are reported. — [RLinf DSRL docs](https://rlinf.readthedocs.io/en/latest/rst_source/examples/embodied/dsrl.html)

### Inferences
- These reports describe the same mechanism as our result that untrained steering hurt grasping: native 4/12, but 0–1/12 under fixed-zero or random tiled noise [brief].
- Tiled noise is out of distribution for some flow heads, especially pi0.5 and briefly fine-tuned checkpoints. The steered policy then starts below base; with a sparse reward and a small budget, it may never collect the first success.
- The jesbu1 and 30k-checkpoint counterpoints suggest this depends on the checkpoint, not on DSRL as such.

### Gaps
- The authors have not replied on pi0.5, tiling failures or real-world instability. All remedies are anecdotal.

## 6. Follow-up work, mid-2025 to 25 Oct 2026

### Takeaway
DSRL is heavily cited: 224 citing papers. In 2026 it serves mostly as a pi0.5 baseline. At VLA-realistic budgets, and with low base success or long horizons, it usually stays near the base:

| Paper | DSRL result | Comparison |
|---|---|---|
| BEE | 38.8 → 42.1% | — |
| EXPO-FT | 19/30 | SFT 18.8/30 |
| MiDAS | at BC level | — |
| UniSteer | 55% | UniSteer 90% |

Noise-space variants that work change the recipe in one or more of these ways:
- bound or regularize the noise toward N(0,I);
- tile only the real action dimensions, or use low-dimensional bases;
- seed with successes or human corrections (via flow inversion);
- use grounded or pessimistic critics;
- replace SAC with success-weighted regression.

### Cited Findings
- Semantic Scholar lists 224 citing papers as of 25 Oct 2026. — [S2 API](https://api.semanticscholar.org/graph/v1/paper/arXiv:2506.15799/citations)

#### 6a. DSRL on pi0.5 and other flow VLAs (results and budgets)
- **NSL (2026, Oct): π0.5 and SmolVLA on LIBERO-10, RoboTwin, and four real tasks.** — [NSL](https://arxiv.org/abs/2610.13943)
  - Base policies: 10,000-step SFT checkpoints on one demo per task ("One") or 379 demos ("Full").
  - Execution: predict 50 actions, execute 10; at most 520 steps per episode.
  - Budget: 4,000 trajectories per epoch (50 resets × 8 rollouts × 10 tasks), with curves over 60 epochs.
  - Peak results: π0.5-Full 99.8%; π0.5-One 40.4 → 71.2%.
  - Averages under the same collection schedule: NSL-SAC 83.5%, RLT 81.0%, action-space AWR 79.4%.
  - SAC recipe:
    - α₀ 0.006; target entropy 0.5 per noise dimension;
    - twin critics with a Monte-Carlo auxiliary loss (weight 0.5);
    - minibatch 2,048; actor lr 1e-5, critic lr 2e-5; γ 0.99 per chunk;
    - replay sampled 50% from successes;
    - bounded noise.
  - Real robot: NSL-AWR goes 37.5 → 71.3% average with 1.53 min of training per task.
  - NSL-SAC on the real robot: "noise distributions far from standard Gaussian can be tolerated in simulation but are associated with unsafe motions and safety interventions, such as emergency stops, on real robots". It also produced "unintended table contact". Actor proposals had "higher predicted Q values and greater critic disagreement than replay noise".
- **BEE (2026, Sep): frozen π0.5-SFT on three real tasks plus LIBERO-Pro.** — [BEE](https://arxiv.org/abs/2609.27450)
  - Budget: about 20 pre-collected correction episodes plus an online budget of 70 episodes per real task and 25 for the simulated bowl task. "DSRL maintains no demonstration buffer and receives them as additional online interaction."
  - Evaluation: 3 rounds × 20 trials.
  - DSRL results: phone 93.3, snack 13.3, cloth 31.7, bowl 30.0; average 42.1 vs base 38.8. RLT 57.5, BEE 91.2.
  - DSRL setup: "noise is sampled for the first 10 steps of a chunk, the last noise vector is repeated to fill the 50-step VLA chunk".
- **MiDAS (2026, Aug; v3 21 Oct): π0.5 with one-demo BC on LIBERO-Long.** — [MiDAS](https://arxiv.org/abs/2608.11363)
  - Three tasks, BC vs DSRL vs MiDAS: 12.7 vs 12.0 vs 99.3; 4.0 vs 3.3 vs 82.7; 13.3 vs 12.7 vs 93.3. DSRL stays at BC level.
  - DSRL settings: batch 64, γ 0.999, UTD 20, chunk 10, noise magnitude 1.0, updates from step 500, 128×3 MLPs.
  - MiDAS on a real YAM bimanual robot improved after "approximately six hours".
- **UniSteer (2026, May): a π0-architecture flow policy warmed up with 30 demos, 30 Hz, four real tasks.** — [UniSteer](https://arxiv.org/abs/2605.10821)
  - Average: base 20%, DSRL 55%, DAgger 60%, UniSteer 90%, within 66 min on average.
  - DSRL "repeatedly approaches the spoon from above". Slowness "is especially pronounced when the initial success rate is low: successful trajectories are rarely collected".
- **EXPO-FT (2026, May): four real tasks, out of 30 trials.** — [EXPO-FT](https://arxiv.org/abs/2605.25477)
  - Averages: SFT 18.8, HG-DAgger 20.5, DSRL on frozen π0.5 19, HIL-SERL 5.5, EXPO-FT 30. EXPO-FT reached 30/30 with an average of 19.1 min of online data.
  - DSRL settings:
    - hidden 256×3; γ 0.99; batch 64; UTD 10;
    - initial temperature 0.1; "no entropy term in the backup";
    - REDQ-style critic (10 networks, 2 for the target);
    - ResNet (3,4,6,3) image encoder.
- **FRS (2026, Jun): π0.5-LIBERO.** — [FRS](https://arxiv.org/abs/2606.13675)
  - Noise layout: the noise policies "predict a single 7D vector", "repeat it along the chunk dimension to the chunk horizon (10 …), then pad all actions to be 32D with i.i.d. N(0,I) noise".
  - DSRL + FRS (Table 1):
    - tanh clip 5.0 (none, plus KL 0.1, on hard tasks);
    - entropy term off; initial std 0.01;
    - batch 16; 10 critics with mean reduction;
    - UTD 20, or 10 on hard tasks; 200k–250k steps;
    - γ 0.999; updates start after 1,000; 84-px images.
- **SARL (2026, Jun): π0.5 on LIBERO-10 (600-step horizon, step size 10) and WidowX.** — [SARL](https://arxiv.org/abs/2606.31958)
  - DSRL baseline: discount 1 − 1/H; 25 simulated warm-up episodes "via uniformly sampling" the noise range; UTD 20 in simulation and 10 on the real robot.
  - It fails on several tasks.
- **GR-RL (Dec 2025): GR-3 VLA threading a real shoelace.** — [GR-RL](https://arxiv.org/abs/2512.01801)
  - Recipe: penalize the noise predictor "when its output diverges from the original normal distribution beyond a certain threshold β"; distributional noise critic.
  - Results: filtered BC with symmetry augmentation reaches 72.7%; online steering reaches 83.3%.
  - "The non-distributional critic suffers from severe over-estimation, especially in earlier parts of trajectories where the reward supervision signal is weak."
- **RL Token (2026, Apr; Physical Intelligence):** "DSRL leads to high success but significantly lags behind in throughput." — [RLT](https://arxiv.org/abs/2604.23073)
- **Golden Ticket (2026, Mar): search for a constant noise vector.** — [Golden Ticket](https://arxiv.org/abs/2603.15757)
  - Real block pick: 80 → 98% on 50 held-out episodes, using "150 search episodes (≈30 min)".
  - Real tasks: up to +28% "within 60 search episodes".
  - GR00T N1.5 on 7 SimplerEnv tasks: +20% average.
  - Sample efficiency: "comparable sample efficiency to that of DSRL".

#### 6b. Changes to the noise space
- **Low-dimensional or structured noise:**
  - PSS (2026, Sep): with a frozen, closed-source 3B flow VLA on a humanoid, "success is observed in 2/10 trials for the frozen VLA policy and 6/10 after SAC+PSS adaptation" (exploratory). — [PSS](https://arxiv.org/abs/2609.33765)
  - HAF (2026, Aug): first 8 DCT coefficients. — [HAF](https://arxiv.org/abs/2608.16837)
  - RLMM-Flow (2026, Jul): "coarse-to-fine latent steering that progressively expands control from a horizon-shared latent representation to a full-dimensional residual representation". — [RLMM-Flow](https://arxiv.org/abs/2607.26460)
- **Constrained or residual noise:**
  - LP-DS (ICML 2026): a "Lagrangian trust-region objective … constraining deviation from the latent prior". Return gains up to 25%. Also tested with a π0 backbone and a physical Franka. — [LP-DS](https://arxiv.org/abs/2606.01151)
  - AWLS (CoRL 2026): offline, advantage-weighted latent steering. — [AWLS](https://arxiv.org/abs/2610.27736)
- **Beyond the initial noise:**
  - DLSRL (2026, Sep) injects adapter features into intermediate action-token hidden states. — [DLSRL](https://arxiv.org/abs/2609.11270)
  - RFS (2026, Feb) combines residual actions with latent-noise steering. — [RFS](https://arxiv.org/abs/2602.01789)
  - ZPRL (2026, May): "+33.7%" average real success over imitation base policies on four tasks. — [ZPRL](https://arxiv.org/abs/2605.19919)
- **Source priors (not RL):**
  - WarmPrior "reshapes the exploration distribution in prior-space reinforcement learning". — [WarmPrior](https://arxiv.org/abs/2605.13959)
  - LeaP: a learnable source prior. — [LeaP](https://arxiv.org/abs/2606.17408)
  - PAINT: initial-noise selection for asynchronous chunking. — [PAINT](https://arxiv.org/abs/2606.19774)
  - "The Gaussian Is Enough" finds non-Gaussian priors do not help fine-tuning of LBM 1.0, π0.5 and GR00T N1.5. — [Gaussian Is Enough](https://arxiv.org/abs/2609.27070)

#### 6c. Safety-constrained steering
- INSPO (2026, Sep): inference-time noise-space trajectory optimization under constraints, on Push-T, Can and LIBERO-Spatial (including VLAs). It "improves task success and constraint satisfaction over best-of-N sampling and action projection". — [INSPO](https://arxiv.org/abs/2609.21220)
- SCORE (2026, Jun): leaves the base policy untouched. Across eight real dexterous tasks it raises average success "from 37.8% to 89.9%, compared to 59.5% for the best baseline". — [SCORE](https://arxiv.org/abs/2606.27475)
- NSL's real-robot safety finding is in 6a, and GR-RL's noise-norm penalty is also in 6a. — [NSL](https://arxiv.org/abs/2610.13943); [GR-RL](https://arxiv.org/abs/2512.01801)

#### 6d. Offline-to-online and human-guided steering via flow inversion
- FRS turns reference actions into noise to prefill DSRL. — [FRS](https://arxiv.org/abs/2606.13675)
- UniSteer and FlowDAgger map human corrections to the noise "that would have produced it under the frozen base policy". — [UniSteer](https://arxiv.org/abs/2605.10821); [FlowDAgger](https://arxiv.org/abs/2607.08877)
- HAF inverts demonstrations. — [HAF](https://arxiv.org/abs/2608.16837)
- Dual-Actor reaches 100% on three real tasks "within 101 minutes". — [Dual-Actor](https://arxiv.org/abs/2509.13774)
- Offline latent steering: LPS (RSS 2026) and ReFORM (ICLR 2026). — [LPS](https://arxiv.org/abs/2603.05296); [ReFORM](https://arxiv.org/abs/2602.05051)

#### 6e. Multi-task and continual steering
- NSL trains "one shared, task-conditioned noise actor across all ten tasks". — [NSL](https://arxiv.org/abs/2610.13943)
- D2R (2026, Oct): on CALVIN it improves eight tasks in sequence entirely in imagination, from 63.7% to 74.8%, while LoRA fine-tuning drops to 11.7%. With π0 plus a world model, it learns unseen LIBERO-90 tasks in the environment. — [D2R](https://arxiv.org/abs/2610.13816)

#### 6f. Non-steering alternatives that beat DSRL on VLAs at small budgets
- RLT, EXPO-FT, MiDAS, and DICE-RL (residual off-policy RL). — [RLT](https://arxiv.org/abs/2604.23073); [EXPO-FT](https://arxiv.org/abs/2605.25477); [MiDAS](https://arxiv.org/abs/2608.11363); [DICE-RL](https://arxiv.org/abs/2603.10263)
- PARTS (2026, Sep) applies residual RL only at bottleneck subtasks, with local success rewards. It goes 32 → 61% on a bimanual YAM and 50 → 95% on a Franka "using tens of minutes of real-world RL rollouts per task". — [PARTS](https://arxiv.org/abs/2609.21788)
- Full flow-VLA RL on π0 and π0.5 with large simulation budgets: πRL (Flow-Noise and Flow-SDE). — [πRL](https://arxiv.org/abs/2510.25889)

### Inferences
- Each pi0.5 noise-steering success used at least one of the following:
  - a large simulation budget (NSL);
  - prefilled successes or human corrections (FRS, UniSteer, FlowDAgger, BEE-style data);
  - success-weighted regression (NSL-AWR);
  - noise constraints (bound, KL, norm penalty, trust region);
  - real-dimension-only tiling with i.i.d. padding (FRS).
- Plain DSRL-SAC with full-width tiling, a learned CNN, and 60–120 episodes from a low base matches the BEE, EXPO-FT and MiDAS regimes, where DSRL ends near the base.

### Gaps
- The D2R full text was not available.
- SARL's per-task DSRL curves exist only as figures.
- No follow-up reports episodes of minutes each, so none is comparable to our 7–9 min per episode [brief].
- I found no paper that combines noise-space RL with explicit constraint costs (CMDP or Lagrangian violation budgets) on a VLA.

## 7. Comparison with our setup, and ranked explanations of our failure

### Takeaway
Our run differs from every published DSRL success on the two axes the method depends on:
- it had **no successes under the steering-noise distribution**;
- its decision horizon and discount are **5–60× longer**.

The observed sequence matches the failure chain documented in the trackers and follow-ups:
1. Tiled noise breaks the base policy.
2. Warm-up and early training collect no successes.
3. An unanchored critic inflates.
4. The entropy term swamps a tiny reward signal.

### Cited Findings
| Dimension | pi0 LIBERO (published) | pi0 ALOHA | pi0 real | pi0.5 follow-ups | Ours [brief] |
|---|---|---|---|---|---|
| Base on target | ≈20% ([arXiv](https://arxiv.org/html/2506.15799v2)) | ≈65% | 25% and 75% | NSL-One 40%; BEE 0–90%; MiDAS 4–13%; FRS hard tasks ≈0% ([NSL](https://arxiv.org/abs/2610.13943), [BEE](https://arxiv.org/abs/2609.27450), [MiDAS](https://arxiv.org/abs/2608.11363), [FRS](https://arxiv.org/abs/2606.13675)) | ≈25% strict native (0–75% by task); 0/24 under steering |
| Control steps / decisions per episode | 400 / ≤ 20 ([train_sim.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_sim.py)) | 400 / ≤ 8 | 200 / ≤ 20 ([train_utils_real.py](https://github.com/nakamotoo/dsrl_pi0/blob/main/examples/train_utils_real.py)) | 520 / ≤ 52 (NSL); 600 / 60 (SARL) | 2,000 / ≈250 |
| Chunk / executed | 50 / 20 | 50 / 50 | 10 / 10 | 50 / 10 | 16 / 8 |
| Noise | 32-D tiled ×50 | same | 32-D tiled ×10 | NSL 32-D repeated; FRS 7-D tiled + i.i.d. padding; BEE per-step for the executed 10 | 32-D tiled ×16 |
| Magnitude | 1.0 | 2.0 | 2.5 | FRS 5.0, or unbounded + KL; NSL real 5·tanh | 1.0 |
| Reward | −1 per decision, 0 at success | same | same, human-labelled | sparse success (all) | terminal 0/1 + 0.25 shaping |
| γ per decision | 0.980 | 0.951 | 0.904 | NSL 0.99 per chunk; SARL 1 − 1/H | 0.9984 |
| Critics | 10, mean | 10, mean | 2, min | NSL twin + MC loss; EXPO-FT REDQ; FRS 10 mean | 10, mean |
| Entropy | target −16, α₀ 1, none in backup | target 0 | target 0 | FRS off; NSL α₀ 0.006; EXPO-FT α₀ 0.1 | auto (target −16) |
| Actor/critic input | 64² + 8-D | 64² + 14-D | 3×128² + VLM 2,048-D | EXPO-FT ResNet; FRS 84² | 64² + 8-D |
| Warm-up | > 500 transitions (≥ 25 eps), tiled noise | > 1,000 (≥ 125 eps) | 1 ep + 5k updates | FRS 1,000 frames + prefilled successes; SARL 25 eps | not stated in brief |
| Budget to result | ≈70–100k steps (≥ 250 eps) | ≈0.45–1.5M steps | 65–80 eps | NSL ≈240k trajectories; BEE ≈90 eps (+3.3 pts); EXPO-FT (≈ SFT) | 24 training eps + 12 eval |

### Inferences
**Ranked causes, most to least plausible:**

1. **The steering parameterization removed the successes DSRL needs.**
   - Native grasp was 4/12 vs 0/12 under tiled noise (one-sided Fisher p ≈ 0.047). Under a 25% native rate, 0/24 has probability 0.75²⁴ ≈ 0.001.
   - Six independent users (issues #6, #8/#9, #12, #15) and Golden Ticket's analysis describe the same breakage.
   - The DSRL authors' own 2026 π0.5 implementation (FRS) tiles only the 7 real action dims and fills the padding with i.i.d. N(0,I).
   - DSRL can only reweight behaviour the base still produces (its own limitations; SARL, MiDAS, OGPO). With zero positives there is nothing to learn.
   - The counterpoints (pi0.5 tiling "fine" in LIBERO; 30k-step checkpoints) make this checkpoint-dependent, so it is testable before RL.
2. **Too few outcomes for a sparse reward.**
   - In transitions, our budget (24 × 250 ≈ 6,000 decisions) resembles LIBERO's ≈100k/20 = 5,000.
   - In outcomes, it is 10–150× smaller: 24 episodes vs ≥ 250 to ≥ 3,750.
   - Published real-robot wins needed 40–80 episodes from 20–75% bases.
   - At ≈90 episodes on π0.5-SFT, DSRL gained +3.3 points (BEE), and DSRL matched SFT in EXPO-FT.
3. **Horizon and discount mismatch.**
   - At γ_dec = 0.9984 the effective horizon is ≈625 decisions, vs 10–50 in every published run. Any per-backup overestimation b compounds to roughly b/(1−γ) ≈ 625b.
   - An optimistic bias of only ≈0.06 per backup would explain Q rising to 37 when returns are bounded in [−0.25, 1] [brief].
   - Divergence at high UTD is documented for DSRL (symmetry-aware steering; NSL).
   - Even official-style 0.999 per control step would give 0.992 per decision (≈125 decisions).
4. **Reward scale vs SAC temperature.**
   - The official −1-per-decision reward gives Q gaps of O(10–50). Our 0/1 terminal reward with shaping gives gaps below 1, so α·log π dominates the actor loss.
   - α itself is slow to fall: Adam on `log_temp` at lr 3e-4 bounds α to ≳ e^(−3e-4·N), i.e. ≈0.1 after 7,500 updates. This matches "entropy stayed near maximum; the actor barely moved" at UTD 5 [brief].
   - Follow-ups that work on π0.5 set α₀ to 0.006 (NSL) or 0.1 (EXPO-FT), or remove the entropy term (FRS).
5. **An ungrounded critic.**
   - With 21/24 all-zero episodes [brief], mean-of-10 has no pessimism and nothing anchoring it.
   - Timeouts are bootstrapped (mask = 1 in the official code), and there is no per-step −1.
   - Documented fixes:
     - Monte-Carlo-return regression, success-oversampled replay, and noise bounds (NSL);
     - distributional critics (GR-RL);
     - REDQ (EXPO-FT) or min-of-10 (SARL).
6. **Representation.**
   - A from-scratch 64×64 CNN learns from ≈6k transitions on a 2,000-step task.
   - The original real-robot runs added a VLM feature, though possibly a padding token (issue #11). EXPO-FT's DSRL baseline used a ResNet.
7. **Checkpoint steerability.**
   - Briefly fine-tuned checkpoints break under tiling (issues #9 and #12).
   - Low-data SFT narrows VLAs (lock-in), and BC pretraining choice decides whether DSRL works (PostBC).
   - AWLS offers a sensitivity criterion to screen checkpoints.
8. **Task definition and statistics compound everything.**
   - The strict safety conjunction (≈40% violations, mostly tipping [brief]) lowers base success and penalizes exploratory noise.
   - Base rates that vary by task (0–75%) dilute the signal.
   - 12-episode evaluations cannot separate 0/12 from 3/12 (one-sided Fisher p ≈ 0.11; SE ≈ 12.5 points at p = 0.25).

**DSRL choices we likely misapplied or took out of context:**
- **Noise layout:** tiling all 32 padded dims, where FRS tiles only the real dims and pads with N(0,I).
- **Magnitude:** 1.0, copied from pi0-LIBERO. ALOHA used 2.0, real 2.5, the README suggests 1.5, and FRS uses 5.0 (or unbounded with KL) on hard tasks.
- **Reward:** a terminal 0/1 reward with shaping instead of −1 per decision, which changes both the Q scale and the critic's anchor. Potential-based shaping is policy-invariant only if it uses the same per-decision γ as the critic; this should be checked.
- **Discount:** γ = 0.9998 per control step, vs 0.999 (simulation) or 0.99 (real).
- **Entropy:** target −16 with α₀ = 1 under a sub-unit reward.
- **Critic:** mean-of-10 at UTD 20, a setting validated only with short horizons and a dense −1 anchor.
- **Warm-up:** tiled-noise warm-up, which discards the native successes.

**Implications for attempt 4 (all inferences):**
- Before any RL, measure success under the exact steering-noise layout and require it to roughly match native success. Candidate layouts:
  - per-step or k-row noise;
  - 7-D (real-dim) tiling with i.i.d. padding;
  - a PSS or DCT basis.
- Seed learning from native successes, using DSRL-NA's action critic, flow inversion into noise labels, or success-weighted regression (NSL-AWR).
- Rescale the reward or remove the entropy term.
- Shorten the effective horizon: a lower per-decision γ, or phase/subtask rewards (as in PARTS).
- Use a grounded or pessimistic critic (MC regression, REDQ or min, or distributional) with bounded noise.
- Treat a Golden Ticket search (≤ 60–150 episodes) as the strongest cheap baseline at our budget.

### Gaps
- The brief does not state several things that could reorder causes 5–8:
  - our warm-up procedure;
  - the shaping γ;
  - the SFT step count of our checkpoint;
  - whether one actor spans all Jar tasks.
- No published DSRL result covers episodes of ≈2,000 control steps or ≈250 decisions, so the horizon argument is an extrapolation.
