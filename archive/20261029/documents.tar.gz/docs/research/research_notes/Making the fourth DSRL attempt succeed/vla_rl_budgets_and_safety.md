# RL for VLA and flow/diffusion robot policies (pi0 / pi0.5 focus): budgets, success conditions, and safety-constrained variants

Scope note for the report writer. Research date: 25 October 2026. Items marked **[2026]** are 2026 papers or 2026 revisions. "Sim" means simulation and "real" means a physical robot. All numbers come from the primary source linked on the same line, unless the line says the source is a search snippet. Lines starting "Inference:" are my own reasoning, not source claims. Several 2026 papers are very recent (some posted in September–October 2026) and are unreviewed preprints.

## Q1. Method by method: starting success, budget, reward, gains, and behaviour on near-zero-success tasks

### Takeaway
The large reported gains (+20 to +90 points) fall into two groups.
- **Simulation methods** (πRL, SimpleVLA-RL, RLinf-VLA, RIPT) run tens of thousands to hundreds of thousands of episodes on 4–32 datacenter GPUs, with 64–320 parallel environments and binary success rewards.
- **Small-budget methods** (DSRL, ConRFT, PA-RL, HIL-SERL, UniSteer, PARTS, Real-Time EXPO-FT, RLT, GR-RL) use tens to roughly 1,000 episodes, but almost all of them work on short real-robot tasks or task phases. They also add demonstrations, human corrections or human/classifier success labels, and a policy that already succeeds 10–55% of the time.

No method in this set reports progress from a true 0% start using outcome-only reward.

### Cited Findings

#### πRL (Flow-Noise and Flow-SDE PPO for pi0/pi0.5; RLinf team; sim, plus one sim-to-real demo) — fetched v3 dated 29 Jan 2026 [2026 revision]
- Few-shot SFT → RL on LIBERO, average success:
  - pi0: 57.6 → 96.1 (Flow-SDE) / 97.6 (Flow-Noise).
  - pi0.5: 77.1 → 97.9 / 98.3.
  - Lowest-start suites: pi0.5 LIBERO-Long 43.9 → 93.0 / 94.0; pi0 Goal 49.8 → 96.2 / 98.2.
  - Full-data SFT references: pi0 94.2, pi0.5 96.9.
  - [πRL](https://arxiv.org/html/2510.25889)
- ManiSkill in-distribution: pi0 38.4 → 78.8 / 77.8; pi0.5 40.1 → 90.9 / 89.7. Out-of-distribution: pi0.5 26.4 → 49.3 / 53.4. [πRL](https://arxiv.org/html/2510.25889)
- MetaWorld MT50: pi0 50.8 → 78.1 / 85.8; pi0.5 43.8 → 70.7 / 66.1. [πRL](https://arxiv.org/html/2510.25889)
- CALVIN D, Len-5 success: pi0.5 61.3 → 87.0 / 84.5; pi0 57.5 → 61.7 / 59.9. [πRL](https://arxiv.org/html/2510.25889)
- SIMPLER, Flow-Noise: pi0 67.2 → 86.7; pi0.5 59.2 → 79.1. [πRL](https://arxiv.org/html/2510.25889)
- Reward:
  - Binary success on LIBERO and MetaWorld.
  - Sparse 1.0 per completed subtask on CALVIN.
  - Shaped on ManiSkill: 1.0 for placement plus 0.1 for gripper–object attachment.
  - [πRL](https://arxiv.org/html/2510.25889)
- Algorithm:
  - PPO with GAE (γ 0.99, λ 0.95, clip 0.2).
  - The VLM is frozen; only the roughly 300M action expert is trained.
  - The critic sits on the VLM output for pi0.5 and on the action expert for pi0.
  - GRPO trails PPO on LIBERO: pi0 90.0 vs 96.0; pi0.5 91.5 vs 97.9.
  - [πRL](https://arxiv.org/html/2510.25889)
- Budget:
  - LIBERO: 500 training epochs, global batch 2,048, 64 parallel environments, 8 rollout epochs, 240–480 "interaction steps".
  - ManiSkill: 150 RL train steps, 320 parallel environments, batch 5,120.
  - SIMPLER: 40–130 RL train steps, 256 parallel environments.
  - Hardware: 8× H100 80GB. GPU-hours and wall-clock time are not reported.
  - [πRL](https://arxiv.org/html/2510.25889)
- Few-shot SFT used 58 trajectories for pi0 (208 for Long) and 40 for pi0.5. The appendix says at least 40 demonstrations are needed. The text also says pi0.5 used "only a single trajectory" in one place, which conflicts with this. [πRL](https://arxiv.org/html/2510.25889)
- Sim-to-real: 20 demonstrations plus 100 RL iterations in simulation gave 40% real success. The SFT-only policies failed on the real robot. [πRL](https://arxiv.org/html/2510.25889)
- Fragilities the paper reports:
  - Noise level 0.2 was unstable (high clip fraction).
  - One denoising step caused a sharp drop.
  - Larger action chunks lowered the RL ceiling.
  - On pi0.5 LIBERO-Long the KL rose steadily, and a cosine scheduler was needed.
  - ManiSkill evaluation dipped early, which the authors blame on an inaccurate critic during warm-up.
  - There was no out-of-distribution gain on MetaWorld.
  - The authors cite low sample efficiency as the reason they "rely on sim-to-real deployment".
  - [πRL](https://arxiv.org/html/2510.25889)

#### SimpleVLA-RL (OpenVLA-OFT, GRPO-style; sim plus sim-to-real) — arXiv v1 11 Sep 2025; ICLR 2026 camera-ready [2026 version]
- LIBERO with full SFT: 91.0 → 99.1 average. With one-trajectory SFT: 48.9 → 96.9; LIBERO-Long 17.3 → 91.7. [SimpleVLA-RL](https://arxiv.org/html/2509.09674)
- RoboTwin 1.0 (4 tasks): 39.8 → 70.4. RoboTwin 2.0 (12 tasks): 38.3 → 68.8. Real robot via sim-to-real (4 tasks, 50 trials each): 17.5 → 38.5. [SimpleVLA-RL](https://arxiv.org/html/2509.09674)
- Reward and settings:
  - Binary trajectory-level reward, no process reward, KL term removed.
  - Group size 8, batch 64, temperature 1.6, clip-higher ε_high 0.28.
  - "Dynamic sampling" drops groups where every rollout succeeded or every rollout failed.
  - [SimpleVLA-RL](https://arxiv.org/html/2509.09674)
- Budget, from the ICLR version: 8× A800 80GB.
  - LIBERO RL takes "approximately 1 or 2 days" with one-trajectory SFT and about 1 day with full SFT.
  - RoboTwin single-task RL takes about 12–24 hours.
  - "Training time increases when the initial success rate is lower".
  - Maximum steps: 512 on LIBERO; 200, 400 or 800 on RoboTwin.
  - [SimpleVLA-RL ICLR 2026](https://proceedings.iclr.cc/paper_files/paper/2026/file/cbfbcb4da14235bd69b134070898ae9d-Paper-Conference.pdf)
- Effect of starting success, RoboTwin 2.0 (Table 6):
  - With 0 demonstrations, SFT gives 0% on all 5 tasks, and RL stays at 0%.
  - With 100-demonstration SFT, the average goes 7.3 → 25.4.
  - With 1,000-demonstration SFT, the average goes 28.2 → 50.4.
  - Pick Dual Bottles goes 1.2 → 4.3 from the 100-demonstration start, but 29.7 → 68.3 from the 1,000-demonstration start.
  - The ICLR version states: "when initial success rates are too low (< 5%), RL improvements remain negligible".
  - [SimpleVLA-RL ICLR 2026](https://proceedings.iclr.cc/paper_files/paper/2026/file/cbfbcb4da14235bd69b134070898ae9d-Paper-Conference.pdf)
- Version difference: the explicit "<5%" threshold sentence and the wall-clock figures appear in the ICLR text. The arXiv v1 extract gave the 0-, 100- and 1,000-demonstration table but no numeric threshold. [SimpleVLA-RL v1](https://arxiv.org/html/2509.09674); [ICLR 2026](https://proceedings.iclr.cc/paper_files/paper/2026/file/cbfbcb4da14235bd69b134070898ae9d-Paper-Conference.pdf)
- "Pushcut": with outcome-only reward, the policy learned to push the can into place rather than grasp and place it, an unpenalised alternative strategy. [SimpleVLA-RL](https://arxiv.org/html/2509.09674)

#### RLinf-VLA (OpenVLA / OpenVLA-OFT; sim plus one real task) — fetched v3 stamped 12 Aug 2026 [2026 revision]
- LIBERO, one GRPO model across 130 tasks: 42.09 → 98.11. LIBERO-Long 11.90 → 93.55. [RLinf-VLA](https://arxiv.org/html/2510.06710)
- ManiSkill (25 tasks), OpenVLA-OFT in-distribution: 28.13 → 97.66 with PPO and 94.14 with GRPO. Out-of-distribution: 18.29 → 77.05 with PPO. [RLinf-VLA](https://arxiv.org/html/2510.06710)
- RoboTwin (6 tasks): 24.48 → 84.63. The paper says the policy converged to high performance even from about 3% initial success (Pot task 3.13%). [RLinf-VLA](https://arxiv.org/html/2510.06710)
- Practical findings:
  - PPO beats GRPO and is more stable.
  - Action-level value estimates beat chunk-level ones.
  - "Partial reset" improves success and sample efficiency.
  - A success-rate filter prevented a training collapse around step 400 for OpenVLA on ManiSkill.
  - [RLinf-VLA](https://arxiv.org/html/2510.06710)
- Budget: 64–256 parallel environments; global batch 640–16,384; efficiency runs on 8, 16 and 32 H100s. Training steps and wall-clock time are not reported. [RLinf-VLA](https://arxiv.org/html/2510.06710)
- Real robot (drawer closing): SFT and RL both scored 8/10; the RL policy was more efficient. [RLinf-VLA](https://arxiv.org/html/2510.06710)
- The framework supports pi-series models, including DSRL on pi0, but the text gives no success numbers for them. [RLinf-VLA](https://arxiv.org/html/2510.06710)

#### VLA-RL (OpenVLA-7B, PPO; LIBERO sim) — v1 24 May 2025
- Average 76.5 → 81.0 (+4.5); Long 53.7 → 59.8. [VLA-RL](https://arxiv.org/html/2505.18719)
- Reward: sparse success plus a learned "robotic process reward model" (a VLM pseudo-labelled from gripper and velocity keyframes). Removing that model drops LIBERO-Spatial from 90.2 to 85.8. [VLA-RL](https://arxiv.org/html/2505.18719)
- About 48 GPU-hours of RL. Learning rate 2e-4 instead of 2e-5 collapsed success to 0.2%. Without critic warm-up, success was 80.0. [VLA-RL](https://arxiv.org/html/2505.18719)

#### RIPT-VLA (QueST, OpenVLA-OFT; LOOP = leave-one-out PPO; sim) — v1 22 May 2025
- QueST LIBERO average: 82.7 → 93.6. OpenVLA-OFT: 96.7 → 97.5. [RIPT-VLA](https://arxiv.org/html/2505.17016)
- With one demonstration: about 4% → 97% "within 15 iterations" (abstract). Cross-goal with 3 demonstrations: 0.7% → 59.7%. [RIPT-VLA](https://arxiv.org/html/2505.17016)
- Binary reward.
  - OpenVLA-OFT: K=8 rollouts per context, 192 rollouts per batch, 4× RTX A5000.
  - QueST: K=16, batch 2,880, 3 GPUs.
  - Total episodes and wall-clock time are not reported.
  - [RIPT-VLA](https://arxiv.org/html/2505.17016)
- Dynamic rollout sampling (discarding contexts where all K rollouts got the same outcome) adds 3.3 points: 90.2 → 93.5. [RIPT-VLA](https://arxiv.org/html/2505.17016)

#### DSRL (diffusion/flow noise-space steering; pi0 in sim and real) — fetched v2, 25 Jun 2025
- Real robot, pi0-DROID on Franka:
  - "Turn on toaster": 5/20 → 18/20 after 80 online episodes (~11,000 steps).
  - "Spoon on plate": 15/20 → 19/20 after 65 episodes (~10,000 steps).
  - [DSRL](https://arxiv.org/html/2506.15799)
- Sim, LIBERO-90 cream-cheese task: about 20% → about 100% after about 10,000 online samples. [DSRL](https://arxiv.org/html/2506.15799)
- Design details:
  - The actor and critic act on a single 32-dimensional noise vector that is repeated across the chunk (the full noise is 50×32 = 1,600 dimensions). The authors call learning over the full 1,600 dimensions "challenging".
  - Noise bound: 1.0 on LIBERO, 2.0 on Aloha, 2.5 on the real robot.
  - Executed actions per chunk: 20 on LIBERO, 50 on Aloha, 10 on the real robot.
  - Critics: 10 in sim, 2 on the real robot. Gradient steps per update: 20 in sim, 30 on the real robot.
  - Discount: 0.999 in sim, 0.99 on the real robot.
  - Sim reward: −1 per step until success.
  - The real-robot critic input includes the 2,048-dimensional VLM feature.
  - Real-robot training ran on an RTX 3070.
  - [DSRL](https://arxiv.org/html/2506.15799)
- Stated limitations: there is "no guarantee all diffusion policies are steerable", and concentrated action distributions may offer few options. [DSRL](https://arxiv.org/html/2506.15799)

#### ConRFT (Octo-small consistency head; real Franka) — v2 14 Apr 2025
- Average over 8 tasks: 39.4 → 96.3%, after 45–90 minutes of online fine-tuning with human interventions. 80–120 policy rollouts were collected in that window. [ConRFT](https://arxiv.org/html/2502.05450)
- Setup:
  - 20–30 demonstrations per task.
  - Reward classifier giving +10 on success and −0.05 per step.
  - Episodes capped at 100 steps at 10 Hz.
  - Human takeover on collision, excessive force, or getting stuck.
  - Cal-QL alone scored 0% on all tasks.
  - [ConRFT](https://arxiv.org/html/2502.05450)

#### PA-RL (policy-agnostic RL; diffusion and OpenVLA; real plus sim) — v1 9 Dec 2024
- OpenVLA on a real robot: 40% → 70% after 40 minutes of online fine-tuning. The critic was pre-trained on 50 zero-shot rollouts; LoRA updates; 8 sampled actions per state. [PA-RL](https://arxiv.org/html/2412.06685)
- Real diffusion policy:
  - Cup task: 55 → 90.
  - Pot task: 80 → 100.
  - 40–110 minutes of training.
  - Performance dipped over the first ~50 episodes before recovering.
  - [PA-RL](https://arxiv.org/html/2412.06685)
- Sim: CALVIN 28 → 61 after 1,000 episodes. [PA-RL](https://arxiv.org/html/2412.06685)

#### π*0.6 / RECAP (Physical Intelligence; real) — blog 17 Nov 2025; arXiv 2511.14759 (fetched v2)
- Reward: −1 per step, −C_fail at failure, 0 at success.
- Value function:
  - Distributional over 201 bins, trained on Monte Carlo returns.
  - Uses a 670M Gemma 3 backbone.
- Advantage conditioning:
  - The advantage indicator threshold is the 30th percentile of value predictions per task.
  - Human corrections are always labelled positive.
- [π*0.6 paper](https://arxiv.org/html/2511.14759)
- Data per iteration:
  - Laundry: 300 autonomous trajectories on 4 robots, ×2 iterations.
  - Box assembly: 600 autonomous plus 360 intervention trials, ×2 iterations.
  - Collar failure-mode fix: 600 per iteration, ×2 iterations.
  - [π*0.6 paper](https://arxiv.org/html/2511.14759)
- Outcomes:
  - Throughput more than doubled on diverse laundry and espresso.
  - Failure rate fell by about 2× or more.
  - Over 90% success on all tasks except diverse laundry.
  - The failure-mode test reached 97% after two iterations.
  - Exact before/after values appear only in charts.
  - [π*0.6 paper](https://arxiv.org/html/2511.14759); [PI blog](https://www.pi.website/blog/pistar06)

#### HIL-SERL (not a VLA: ResNet-10 encoder plus RLPD; real) — v3 20 Mar 2025
- Average across tasks: 49.7% (BC) → 100%. Training took 1–2.5 hours per task, and 6 hours for Timing Belt. [HIL-SERL](https://arxiv.org/html/2410.21845)
- Inputs:
  - 20–30 demonstrations.
  - A reward classifier trained on about 200 positive and 1,000 negative frames, collected in about 5 minutes.
  - Human corrections.
  - [HIL-SERL](https://arxiv.org/html/2410.21845)
- Ablations:
  - RL from scratch: 0%.
  - Demonstrations without online corrections: 49% average.
  - [HIL-SERL](https://arxiv.org/html/2410.21845)

#### World-model RL for VLAs
- **WMPO** (OpenVLA-OFT; v1 Nov 2025): sim (MimicGen) and one real task.
  - MimicGen mean success: 33.6 → 47.1 with P=128 real rollouts and 57.6 with P=1,280. At the same P, GRPO reaches 33.2 / 37.1 and DPO 37.3 / 42.4.
  - Real robot: 53% → 70% using 128 real trajectories.
  - Compute: 32 H100s for world-model and policy training.
  - Reward: a VideoMAE success classifier.
  - [WMPO](https://arxiv.org/html/2511.09515)
- **VLA-RFT** (VLA-Adapter, not pi0; v1 1 Oct 2025): LIBERO sim.
  - The authors say pi0's JAX code "was hard to integrate" with their framework.
  - Average success: 86.6 → 91.1 in 400 RFT steps (batch 16) on 4× A800.
  - Reward: negative L1 + LPIPS distance to expert frames rendered in the world model.
  - [VLA-RFT](https://arxiv.org/html/2510.00406)
- **World-Env** (OpenVLA-OFT, 5 demonstrations per task; v6 27 Apr 2026) [2026 revision].
  - LIBERO average: 74.85 → 79.6, using a VLM success "reflector" (F1 0.896) as reward and termination signal.
  - About 48 hours on 8× H20.
  - Real robot, 10 trials per task: 20→30, 30→50, 30→40, 20→50.
  - [World-Env](https://arxiv.org/html/2509.24948)
- **Ctrl-World** (pi0.5-DROID, real; v3 1 Mar 2026) [2026 revision].
  - The policy was fine-tuned on imagined rollouts: 400 imagined trajectories per task, 25–50 successful ones kept (judged by humans), 2,000 fine-tuning steps on 4 H100s.
  - Average success: 38.7% → 83.4%.
  - The gains target instruction following; the authors do not expect low-level gains on seen instructions.
  - [Ctrl-World](https://arxiv.org/html/2510.10125)

#### 2025–2026 additions directly relevant to steering a frozen pi0/pi0.5
- **AnchorQ** [2026] (v1 16 Oct 2026; frozen pi0.5; sim plus real). Mean of 4 seeds; numbers at 250k / 500k environment steps:
  - 15-task held-out LIBERO-90 split: zero-shot 8.5 → DSRL 37.2 / 48.3, versus AnchorQ 86.0 / 95.5.
  - Hard-10 split (base 1.6): DSRL 7.8 / 25.2, using DSRL with "FRS" replay pre-filling, versus AnchorQ 52.1 / 62.1.
  - 6 RoboTwin tasks, 500k steps (base 47.7): DSRL 47.2, i.e. no gain, versus AnchorQ 70.5.
  - The table column headers are ambiguous, so the 250k/500k assignment is uncertain.
  - [AnchorQ](https://arxiv.org/html/2610.22852)
- **AnchorQ, DSRL failure analysis**:
  - DSRL "collapses to a near-zero noise vector and reproduces the base policy's failure" on LIBERO task 81.
  - On tasks 81, 75 and 73, DSRL and residual RL stay at 0.0, the same as the base policy.
  - Exploring the unstructured noise space "often yields no useful learning signal on hard tasks".
  - [AnchorQ](https://arxiv.org/html/2610.22852)
- **AnchorQ, setup**:
  - REDQ-style ensembles: 10 critic heads, minimum over 2 randomly sampled target heads.
  - 10 updates per decision in sim, 5 on the real robot.
  - Executed steps per decision: 10 on LIBERO, 30 on RoboTwin, 10 on the real robot.
  - Real robot: 100 online episodes per task. AnchorQ beat pi0.5 and DSRL on all three tasks and was the only method that improved towel hanging. Per-task numbers appear only in a figure.
  - [AnchorQ](https://arxiv.org/html/2610.22852)
- **UniSteer** [2026] (v1 11 May 2026, v2 16 Jul 2026; pi0.5; real AgileX Piper arm at 30 Hz).
  - Method: noise-space SAC with human corrective chunks inverted into noise targets, after actor SFT on 30 demonstrations per task.
  - Results, average over 4 tasks: 20% → 90% in 66 minutes (45–100 minutes per task).
  - Baselines: plain DSRL reached 55% and DAgger 60%. HIL-SERL was dropped as "ineffective and unstable".
  - Schedules on 2 tasks: "Only RL" 60% versus SFT-then-RL 95%.
  - Reward: binary terminal.
  - Hardware: 2× RTX 5080.
  - [UniSteer](https://arxiv.org/html/2605.10821v2); [repo](https://github.com/microsoft/UniSteer)
- **LP-DS** [2026] (v1 31 May 2026). Learns a state-conditioned noise shift w = ε + Δ(s), constrained by a Lagrangian trust region E‖Δ‖² ≤ δ (δ = 0.35 typical).
  - It criticises DSRL for replacing the prior: steered noise can drift off the Gaussian support, and DSRL collapses modes.
  - Removing the Lagrangian term makes learning unstable.
  - Real Franka results (a flow decoder trained on teleoperation, not a VLA): pick-place 18/40 → 33/40; mug hanging 11/20 → 17/20.
  - [LP-DS](https://arxiv.org/html/2606.01151v1)
- **QPILOTS** [2026] (v1 11 Jun 2026). Keeps the public pi0.5-LIBERO checkpoint frozen, learns only a critic online (5×10⁵ environment steps, 5 seeds), and applies critic-gradient guidance during flow integration. Tested on six LIBERO-90 tasks with zero-shot base success of 5–50%. It beats the base on all six and "surpasses DSRL on average". [QPILOTS](https://arxiv.org/html/2606.14801v1)
- **DLSRL** [2026] (v1 10 Sep 2026; pi0 on LIBERO, sim only). Adds a second RL interface on intermediate hidden states. It reports faster saturation and shorter episodes, but no budget values. [DLSRL](https://arxiv.org/html/2609.11270)
- **PARTS** [2026] (v2 30 Sep 2026; SFT'd pi0.5 kept frozen; real robot).
  - Method: residual TD3+BC actors on human-chosen "bottleneck" subtasks, each with a local sparse verifier reward. Uses "tens of minutes" of RL per task (cable task ~29 minutes, LEGO ~17 minutes).
  - Franka cable task: 50% → 95%, versus DSRL 65%, RLT 70% and EXPO-FT 20%.
  - YAM full-task: 32% → 61%.
  - [PARTS](https://arxiv.org/html/2609.21788)
- **Real-Time EXPO-FT** [2026] (v1 16 Sep 2026; pi0.5 with LoRA; real robot at 30 Hz).
  - Average: 12.5/30 → 29/30, with at most 10 minutes of online data per task (~5k–18k environment steps).
  - The base was SFT'd to ~30% before RL.
  - Reward: sparse rule-based success detectors. Update-to-data ratio 20.
  - RLPD scored 0/30 on two tasks, and "DSRL pauses between chunks at 30 Hz".
  - [Real-Time EXPO-FT](https://arxiv.org/html/2609.18207)
- **RLT, "RL Token"** [2026] (Physical Intelligence, 19 Mar 2026; π0.6; real robot).
  - Setup: 1–10 hours of teleoperation per task to fine-tune the VLA and the RL token, then 400–1,000 RL episodes (about 15 minutes to 5 hours of robot data).
  - Reward: binary, labelled by a human.
  - Actor design: a small actor edits the VLA's reference chunk and is regularised toward it.
  - Screw insertion: 20% → 65%, stated where the paper discusses critical phases. Full-task success "improves by 40%" on the screwdriver task and 60% on zip tie; the paper does not say whether these are points or relative.
  - Baselines:
    - DSRL matched the success rate but gained less speed; the authors say it "strongly constrains the policy to remain close to the base VLA, providing stable training but comparatively less potential for improvement".
    - Single-step methods (HIL-SERL, PLD) "fail to learn effectively" on a task that "spans hundreds of steps with a sparse reward".
  - [RLT paper](https://www.pi.website/download/rlt.pdf); [RLT page](https://www.pi.website/research/rlt)
- **GR-RL** (ByteDance, Dec 2025; GR-3, about 5B parameters including the critic; real shoe lacing).
  - Shoe-lacing success by stage:
    - BC: 45.7%.
    - Progress-filtered BC: 61.6%.
    - Plus symmetry augmentation: 72.7%.
    - Plus online RL in latent noise space: 83.3%.
  - Online RL design:
    - A noise predictor with a penalty for drifting beyond a threshold.
    - 673 offline rollouts used to fine-tune the critic heads.
    - 50 optimisation steps per 12 new episodes; the evaluated checkpoint is at 500 online steps.
  - The authors report an early success drop when moving from offline to online training, caused by distribution shift.
  - [GR-RL](https://arxiv.org/html/2512.01801v2)
- **Learning from Hindsight (LfH)** [2026] (v1 10 Jul 2026; pi0.5 RLinf SFT checkpoint). On a zero-success task, standard GRPO stays at 0% while VLM hindsight relabelling reaches 60%. On the real robot, after 160 rollouts LfH reaches 56% versus 22% for GRPO. [LfH](https://arxiv.org/html/2607.09042v1)

### Inferences
- Inference: every large gain in simulation used at least about 10⁴ episodes. My order-of-magnitude reading of πRL's LIBERO settings (500 epochs × 64 environments × 8 rollout epochs) is about 2.6×10⁵ episodes, though the paper does not define the units. Simulation results therefore say little about a 60–120-episode budget except where they report early training curves.
- Inference: the pi0/pi0.5 results most comparable to the steering setup are DSRL's real-robot runs (65–80 episodes), UniSteer, PARTS, Real-Time EXPO-FT, AnchorQ's 100-episode real-robot runs, and GR-RL. All are short-horizon or phase-restricted, and most use human data (demonstrations or corrections) or a human or rule-based success label.
- Inference: GR-RL reports 500 online optimisation steps at 50 steps per 12 new episodes. If that ratio held throughout, that is about 120 online episodes, close to a 60–120-episode budget. It started from 72.7% on a real robot, gained about 10.6 points, and also used 673 offline rollouts.
- Inference: the 2026 comparisons consistently rank plain DSRL as stable but low-ceiling. It gains +35 points in UniSteer's real tasks and +15 on PARTS's cable task, gains nothing on RoboTwin, and gains nothing on tasks where the base policy has 0% success (AnchorQ). The fixes that recur are better exploration around the base prior (AnchorQ's anchors), trust regions or drift penalties (LP-DS, GR-RL), human corrections (UniSteer), and editing the reference chunk with BC regularisation (RLT).

### Gaps
- Total episodes and wall-clock time are not reported for πRL, RLinf-VLA, RIPT or WMPO. My episode estimates are inferences.
- I did not find πRL or RLinf numbers for pi0/pi0.5 DSRL in text; they appear only in figures.
- Per-task real-robot numbers for AnchorQ and RECAP appear only in figures.
- I did not research these 2025–2026 methods in depth: ReinFlow, TGRPO, ARFM, PLD, RL-100, SRPO, VLAC, and Self-Improving Embodied Foundation Models.
- The RLinf docs say DSRL trains about 500K parameters. I saw this only in a search snippet of [RLinf DSRL docs](https://rlinf.readthedocs.io/en/latest/rst_source/examples/embodied/dsrl.html).

## Q2. RL or steering results on long-horizon manipulation (1,000+ steps), BEHAVIOR-1K/OmniGibson, and the 2025 BEHAVIOR Challenge

### Takeaway
I found no published online-RL or steering result on BEHAVIOR-1K tasks. The 2025 top teams used pi0.5 with imitation learning. The second-place team explicitly skipped online RL as impractical and used rejection-sampling fine-tuning (about 8,500 rollouts per round, 3 rounds). RLinf ships BEHAVIOR PPO recipes but reports no results, and it flags a known issue where success "may stay at 0" for pi0.

The positive long-horizon results (StructRL on RoboCasa365, which runs 800–2,900 steps; RLT; π*0.6; GR-RL; PARTS) all shorten the effective horizon. They do this with subtask rewards, critical-phase training, or very large budgets.

### Cited Findings
- 2025 BEHAVIOR Challenge, held-out test (provisional leaderboard):
  - Robot Learning Collective: Q-score 0.2599, full-task success 0.124.
  - Comet (NVIDIA): 0.2514 / 0.114.
  - SimpleAI Robot: 0.1591 / 0.108.
  - The North Star (Huawei): 0.1204 / 0.076.
  - All other entries were at or below about 0.09 Q.
  - Q-score gives partial credit for satisfied goal predicates.
  - [BEHAVIOR 2025 leaderboard](https://behavior.stanford.edu/challenge/archive/2025/leaderboard.html)
- First place (Larchenko et al.; v1 7 Dec 2025, v2 21 Dec 2025): a modified pi0.5 with correlated flow-matching noise, mixed-layer attention, stage tracking, multi-sample flow matching, and challenge-specific correction rules. It scored about 26% Q across all 50 tasks. The abstract page mentions no RL. [arXiv 2512.06951](https://arxiv.org/abs/2512.06951)
- Second place (Openpi Comet; v1 10 Dec 2025, fetched v3 5 Jan 2026):
  - They skipped online RL because "its low sample efficiency makes it impractical for the BEHAVIOR challenge". It also "requires a heterogeneous compute setup", with ray-tracing GPUs for simulation and Tensor Core GPUs for training.
  - Rejection-sampling fine-tuning (RFT): 3 rounds of about 8,500 rollouts each, from perturbed initial robot poses, keeping successful ones. About 1,469 trajectories were kept after de-duplication and task balancing.
  - Compute: 8× H200.
  - Evaluating one task takes "from one hour to nearly a full day".
  - v3 adds a post-challenge validation Q of 0.3453.
  - Per-round RFT gains are not reported.
  - [Openpi Comet](https://arxiv.org/html/2512.10071)
- Another team's public "pi05-rft-behavior1k" checkpoint uses RFT to mean rejection-sampling fine-tuning with pose-perturbed rollouts. The released checkpoint itself is SFT on 800 episodes (about 100 hours). [HF model card](https://huggingface.co/Shawn3636/pi05-rft-behavior1k)
- RLinf on BEHAVIOR-1K:
  - Added in "[2025/11]".
  - PPO configs exist for OpenVLA-OFT, pi0 and pi0.5 on 50 tasks with the R1 Pro robot.
  - Each BEHAVIOR process uses "roughly 10 GiB of VRAM". RTX 30/40-series GPUs are recommended, and A100/H100 "can show severe rendering artifacts".
  - The docs give `max_episode_steps` 4096 as an example.
  - Known issue: "env/success_once may stay at 0 for OpenVLA-OFT / π₀".
  - No results are reported.
  - [RLinf BEHAVIOR docs](https://rlinf.readthedocs.io/en/latest/rst_source/examples/embodied/behavior.html)
- RLinf [2026/05]: a "25× end-to-end speedup for the BEHAVIOR simulator", with rollout latency "from 1028.7 ms/step to 41.2 ms/step", through slimming, on-demand observation and hybrid pipeline parallelism. [RLinf README](https://github.com/RLinf/RLinf)
- The 2026 BEHAVIOR Challenge [2026]:
  - 100 tasks, 7 scenes, 20,000 demonstrations (1,950 hours).
  - Baselines are pi0.5 and GR00T N1.7.
  - The submission deadline was 16 Oct 2026, and winners will be announced 4 Nov 2026, so no results exist yet.
  - [BEHAVIOR Challenge](https://behavior.stanford.edu/challenge)
- **StructRL** [2026] (v1 28 Sep 2026; sim). RoboCasa365 tasks run 800–2,900 steps.
  - pi0.5: 39.3 → 45.8%. GR00T-N1.5: 38.6 → 49.1%.
  - Reward: LLM-decomposed, simulator-verifiable subtask rewards, gated by prerequisites, paid once, plus a "pacing" term.
  - Terminal-only reward gives 40.2%; a SimpleVLA-RL baseline gives 41.5%. On the longest bucket (1,400–2,900 steps): 25.1% and 30.6%, versus 37.6% for StructRL.
  - Budget: 100 iterations × 512 rollouts on 256 environments, 32 A100s, about 48 hours (about 1,536 GPU-hours).
  - Failure modes: policies collected intermediate rewards and then idled until timeout. About 52 reward signals per task dropped success to 37.6%.
  - [StructRL](https://arxiv.org/html/2609.36352v1)
- **RLT** [2026]: tasks last 30–120 seconds (about 1,500–6,000 control steps at 50 Hz). RL concentrates on "critical phases" of 5–20 seconds (250–1,000 control steps), with episodes reset to the start of that phase. The full-task evaluation still improved success. [RLT paper](https://www.pi.website/download/rlt.pdf)
- **π*0.6 / RECAP**: long real-robot tasks such as box assembly, evaluated with about 90% success "within 600 s", using 300–960 episodes per iteration over 2 iterations. [π*0.6 paper](https://arxiv.org/html/2511.14759)
- **PARTS** [2026]: 20–120-second tasks. RL runs only on human-identified bottleneck subtasks with local verifier rewards. Sparse full-task rewards "can degrade reliable behaviors" (EXPO-FT on cable). [PARTS](https://arxiv.org/html/2609.21788)
- **SafeVLA**: long-horizon navigation plus manipulation in Safety-CHORES (AI2-THOR), at 15–25M environment steps (see Q3). [SafeVLA v3](https://arxiv.org/html/2503.03480v3)

### Inferences
- Inference: the only BEHAVIOR-specific evidence on RL cost is negative or infrastructural. Comet calls it impractical, RLinf's docs warn of a stuck-at-zero success counter for pi0, and RLinf's speed work shows the simulator was ~1 s/step before optimisation.
- Inference: a ~210–270 ms per control step budget (7–9 minutes per 2,000 steps, including policy calls) is far slower than RLinf's optimised 41 ms/step. System-level changes like theirs (on-demand observations, a slimmed scene) could plausibly buy more episodes than any algorithmic change. I have not verified that their changes transfer to ManiGuard scenes.
- Inference: none of the successful long-horizon RL results trained on a 2,000-step horizon with outcome-only reward at small budgets. Each one shortened the credit-assignment horizon by one of three means:
  - Subtask rewards (StructRL, PARTS).
  - Resetting to a critical phase (RLT).
  - Hundreds of episodes per iteration with a learned value on negative steps-to-go (RECAP).

### Gaps
- I found no BEHAVIOR-1K RL learning curves or success numbers from RLinf or anyone else.
- I found no technical report for third place (SimpleAI Robot).
- A search snippet claimed the 2025 BEHAVIOR tasks average 6.6 minutes and run up to 14 minutes. I could not verify this from a primary source.
- A search snippet also claimed that a 2026 hybrid VLA plus motion-planning method improves BEHAVIOR task progress by 113%. I did not verify it. [arXiv 2606.00985](https://arxiv.org/html/2606.00985v1)

## Q3. Safety-constrained RL and safety layers for VLAs: cost definitions, violation reductions, cost to success, and budgets

### Takeaway
There are two families.
- **Constrained RL training**: SafeVLA (PPO-Lagrangian, 15–25M sim steps), SafeDojo (Lagrangian GRPO inside a 14B world model on 32 A800s), and ShieldVLA (a Hamilton–Jacobi critic gating PPO). These cut cumulative cost by roughly 50–85%, usually with equal or higher task success, but at simulation-scale budgets.
- **Training-free or light runtime layers**: AEGIS (a control-barrier-function QP), SafeLoop (risk prediction plus rollback), and constraints on the steering itself (LP-DS's trust region, GR-RL's drift penalty, RLT's regularisation toward the reference). These reduce violations on frozen pi0/pi0.5 with little or no RL budget.

### Cited Findings
- **SafeVLA** (NeurIPS 2025; fetched v3 6 Nov 2025; SPOC-DINOv2 base; AI2-THOR sim):
  - Cost definitions:
    - State–action predicates (corners, dangerous equipment) cost 1 per violating timestep.
    - Trajectory-level predicates (blind spots, fragile collections, critical points) cost 1 at the end of the violating segment.
  - The cost limit is 20% of the baseline FLaRe's converged cost.
  - [SafeVLA v3](https://arxiv.org/html/2503.03480v3)
- **SafeVLA results** (success rate / cumulative cost):
  - ObjNav: FLaRe 0.822 / 12.356; SafeVLA (ISA) 0.865 / 1.854.
  - PickUp: 0.912 / 7.076 → 0.928 / 0.372.
  - Fetch: 0.605 / 43.364 → 0.637 / 8.084.
  - Headline: cumulative cost down 83.58% and success up 3.85% versus FLaRe.
  - A reward-shaping baseline (FLaRe-RS) cut cost less and cut Fetch success to 0.45.
  - The maximum severity of unsafe behaviour is about 1/35 of FLaRe's.
  - [SafeVLA v3](https://arxiv.org/html/2503.03480v3)
- **SafeVLA budget**:
  - 15M steps for ObjNav and PickUp, 25M for Fetch.
  - 8× H100, with 32 parallel rollouts (8 GPUs × 4 environments).
  - Initial Lagrange multiplier 0.001, multiplier learning rate 0.035.
  - Cost "usually drops below the cost limit within about 1M steps". The multiplier's convergence is "relatively slow".
  - A stricter 10% threshold "may slightly reduce success rate".
  - [SafeVLA v3](https://arxiv.org/html/2503.03480v3)
- SafeVLA version difference: v1 calls the 83.58% figure an "improvement" in safety, while v3 and the NeurIPS listing call it a reduction in cumulative cost. The number is the same. The 1/35 tail-risk figure appears in both v1 and v3. A search snippet mentioned a revision in April 2026, which I did not verify. [SafeVLA v1](https://arxiv.org/html/2503.03480v1); [SafeVLA v3](https://arxiv.org/html/2503.03480v3); [NeurIPS 2025 listing](https://neurips.cc/virtual/2025/poster/116975)
- **SafeDojo** [2026] (fetched v2 21 Oct 2026; 7B OpenVLA-OFT; SafeLIBERO sim plus 5 real Franka tasks):
  - Cost: a head predicting per-step obstacle-contact probability. Trajectory cost is the mean of the top 16 values.
  - Reward: a ResNet success classifier run on imagined frames.
  - Algorithm: Lagrangian GRPO with separately group-normalised reward and cost advantages (budget d = 0.2, step 0.05), no separate cost critic.
  - [SafeDojo](https://arxiv.org/html/2606.20698)
- **SafeDojo budget**:
  - 1,500 offline trajectories per suite, half with collisions.
  - World model: Wan 2.2-based, 14B, fine-tuned for 5,000 steps on 8 A800s.
  - Policy optimisation on 32 A800s.
  - 50 collision-free demonstrations per real task.
  - [SafeDojo](https://arxiv.org/html/2606.20698)
- **SafeDojo results**:
  - Level I safe success: 39.00% → 53.25% (SafeVLA baseline 45.00%).
  - Real robot safe success: 10% → 70%, with 76% task success.
  - Trade-off: removing the adaptive multiplier raised task success from 60% to 68% but lowered safe success from 48% to 46%.
  - An initial η of 0.6 hurt both metrics (36% / 26%).
  - [SafeDojo](https://arxiv.org/html/2606.20698)
- **ShieldVLA** [2026] (v1 2 Sep 2026; sim only; SafeVLA's SPOC VLA on Safety-CHORES, OpenVLA-OFT on Franka-Reach):
  - Method: a model-free Hamilton–Jacobi reachability safety critic gates PPO updates. States judged feasible get the task gradient; infeasible states get a safety gradient.
  - Costs: VLM rubric margins.
  - Versus SafeVLA: success +0.13 on average. Franka-Reach success / cost: 0.34 / 13.4 → 0.45 / 3.50.
  - The headline "57%" cost reduction does not match its own table, which works out to about 48–54%.
  - A Lagrangian penalty using the same critic reached only 0.33 success, versus 0.54 (TurtleBot).
  - The training budget is in an appendix I could not read.
  - [ShieldVLA](https://arxiv.org/html/2609.13231)
- **SafeLoop** [2026] (v1 22 Sep 2026; frozen pi0, pi0.5 and OpenVLA-OFT; LIBERO sim plus real):
  - Method: a Qwen2.5-VL-3B-based hazard and time-to-hazard predictor, plus a PPO-trained decider that rolls back to the lowest-risk saved waypoint.
  - OpenVLA-OFT body-hazard rate: 22.9% → 5.7%, with success 67.7% → 68.2%.
  - pi0.5 body hazards: 8.3% → 3.6%.
  - Real robot: about 78% hazard reduction while keeping baseline success.
  - It does not improve task competence. Irreversible changes cannot be undone.
  - [SafeLoop](https://arxiv.org/html/2609.26313)
- **AEGIS / VLSA** (v1 9 Dec 2025, v2 2 Jul 2026, IROS 2026; training-free CBF-QP layer on pi0.5; SafeLIBERO sim):
  - Collision avoidance with translational actions: 18.7% → 77.9%, with task success 50.9% → 68.1%.
  - Full action space: avoidance 17.1% → 68.9%, task success 57.8% → 67.5%. But Long-suite task success fell from 54.3% to 46.3%.
  - Overhead: 0.356 ms per step on an RTX 4090, at 20 Hz control.
  - Only the end-effector is constrained. "Safety-induced distribution shift" can cause task failure.
  - [AEGIS v2](https://arxiv.org/html/2512.11891v2)
- AEGIS version note: the v2 abstract says "over 50%" better avoidance and "nearly 10%" higher success. Those do not obviously match the Table I differences against pi0.5 (+59 and +17 points), and the comparison set may differ. [AEGIS abstract](https://arxiv.org/abs/2512.11891)
- **Constraints inside small-budget steering and residual methods** (not safety costs as such):
  - LP-DS bounds the expected squared noise shift with a dual-ascent multiplier. [LP-DS](https://arxiv.org/html/2606.01151v1)
  - GR-RL penalises noise beyond a threshold β. [GR-RL](https://arxiv.org/html/2512.01801v2)
  - RLT regularises the actor toward the VLA reference chunk. [RLT](https://www.pi.website/download/rlt.pdf)
  - PARTS bounds residuals to selected coordinates. [PARTS](https://arxiv.org/html/2609.21788)
  - ConRFT relies on human takeover on collision or excessive force. [ConRFT](https://arxiv.org/html/2502.05450)

### Inferences
- Inference: the constrained-RL results with full CMDP machinery (SafeVLA, SafeDojo, ShieldVLA) need 10⁶–10⁷ environment steps or a large world model. Even SafeVLA's cost took about 1M steps to fall below the limit. Lagrangian multipliers are unlikely to settle within 60–120 episodes.
- Inference: at small budgets, the transferable safety mechanisms are these:
  - A learned or rule-based hazard signal used as a separately normalised cost advantage (the SafeDojo style), or as a hard veto or rollback (the SafeLoop style).
  - A geometric filter, as in AEGIS; its tilt analogue would be an orientation constraint on the carried jar.
  - Keeping the steered policy close to the native prior, which bounds how far a steering policy can push into new failure modes.
- Inference: SafeVLA's per-timestep costs versus end-of-segment costs map onto tipping (a state predicate, cost on every violating step) versus lifting the jar while open (a trajectory or segment predicate). SafeVLA notes that credit assignment for the second kind is unsolved.

### Gaps
- I could not read ShieldVLA's and SafeVLA's wall-clock budgets in the fetched pages.
- I found no safety-constrained RL result for a pi0/pi0.5 policy trained online in a physics simulator. SafeLoop and AEGIS wrap pi0.5 but do not train it.
- LIBERO-Safety (arXiv 2606.23686) [2026] appeared only as a title in search. [LIBERO-Safety](https://arxiv.org/pdf/2606.23686)
- A training-free CBF follow-up (2606.09749) [2026] appeared only in an aggregator summary and is not verified.

## Q4. Realistic effect size with 60–120 online episodes from ~25% success, and evidence on minimum base success or successes per batch

### Takeaway
Published small-budget gains on pi-family and other VLA policies (+10 to +70 points from 10–75% starts, within 10–110 minutes or 65–160 episodes) all come from short real tasks, usually with human data. Plain DSRL without human data gains about +15 to +35 points in the 2026 head-to-heads, and nothing when the base succeeds 0% of the time on a task.

The best quantitative threshold is SimpleVLA-RL's: with outcome-only reward, RL gives 0% from a 0% start, gains are negligible below about 5%, and larger from about 28%. A 25% start is above that threshold, but 60–120 episodes provide only about 15–30 successes, and evaluation needs about 60+ episodes per arm to resolve even a +25-point change.

### Cited Findings
- **Small-budget results**, as start → end (budget):
  - DSRL, pi0-DROID, real: 25% → 90% (80 episodes) and 75% → 95% (65 episodes). [DSRL](https://arxiv.org/html/2506.15799)
  - UniSteer, pi0.5, real: 20% → 90% average (66 minutes, with 30-demonstration SFT and human corrections). The DSRL baseline reached 55%. [UniSteer](https://arxiv.org/html/2605.10821v2)
  - PARTS, frozen pi0.5 plus residual, real: 50% → 95% (about 29 minutes) and 32% → 61%. [PARTS](https://arxiv.org/html/2609.21788)
  - Real-Time EXPO-FT, pi0.5, real: 42% → 97% (at most 10 minutes of online data per task). [Real-Time EXPO-FT](https://arxiv.org/html/2609.18207)
  - RLT, π0.6, real: 20% → 65% on a critical phase (400–1,000 episodes). [RLT](https://www.pi.website/download/rlt.pdf)
  - GR-RL, real: 72.7% → 83.3% (500 online steps at 50 steps per 12 episodes, plus 673 offline rollouts). [GR-RL](https://arxiv.org/html/2512.01801v2)
  - PA-RL, OpenVLA, real: 40% → 70% (40 minutes plus 50 zero-shot rollouts). [PA-RL](https://arxiv.org/html/2412.06685)
  - ConRFT, Octo, real: 39.4% → 96.3% (80–120 rollouts with interventions). [ConRFT](https://arxiv.org/html/2502.05450)
  - WMPO, real: 53% → 70% (128 real rollouts). [WMPO](https://arxiv.org/html/2511.09515)
  - LfH, pi0.5, real: GRPO 22% versus LfH 56% after 160 rollouts. [LfH](https://arxiv.org/html/2607.09042v1)
  - Ctrl-World, pi0.5, real: 38.7% → 83.4% using 25–50 kept imagined successes per task. [Ctrl-World](https://arxiv.org/html/2510.10125)
- **Simulation steering at about 2.5–5×10⁵ environment steps**:
  - DSRL on frozen pi0.5: 8.5% → 37.2% / 48.3%; 1.6% → 7.8% / 25.2% (with pre-filling); 47.7% → 47.2%.
  - AnchorQ: 8.5% → 86.0% / 95.5%.
  - [AnchorQ](https://arxiv.org/html/2610.22852)
- **Zero and very low starts**:
  - SimpleVLA-RL: a 0% start stays at 0%. Pick Dual Bottles goes only 1.2% → 4.3%. The ICLR text says "< 5%" gives "negligible" gains. [SimpleVLA-RL ICLR 2026](https://proceedings.iclr.cc/paper_files/paper/2026/file/cbfbcb4da14235bd69b134070898ae9d-Paper-Conference.pdf)
  - AnchorQ: DSRL stays at 0.0 on three tasks where the base is at 0. [AnchorQ](https://arxiv.org/html/2610.22852)
  - LfH: GRPO stays at 0 on a zero-success task. [LfH](https://arxiv.org/html/2607.09042v1)
  - HIL-SERL: RL from scratch scores 0%. [HIL-SERL](https://arxiv.org/html/2410.21845)
- **Very low starts that did work** used massive parallelism or dense signals:
  - RLinf-VLA converged from about 3% on RoboTwin Pot, with 64–256 environments. [RLinf-VLA](https://arxiv.org/html/2510.06710)
  - RIPT went from about 4% to 97% with one demonstration, using K = 8–16 rollouts per context and dynamic sampling. [RIPT-VLA](https://arxiv.org/html/2505.17016)
  - LfH reached 60% from 0% using VLM relabelling. [LfH](https://arxiv.org/html/2607.09042v1)
- **Successes per batch**:
  - Group methods discard groups where every rollout got the same outcome. RIPT gains +3.3 points from this filtering. LfH keeps about 70–80% of groups, versus about 20–40% for GRPO. No paper states a minimum number of successes per batch.
  - [RIPT-VLA](https://arxiv.org/html/2505.17016); [LfH](https://arxiv.org/html/2607.09042v1); [SimpleVLA-RL](https://arxiv.org/html/2509.09674)
- **Early dips**: PA-RL dipped over the first ~50 episodes, GR-RL saw an early drop from offline to online, and πRL saw an early ManiSkill dip from critic warm-up. [PA-RL](https://arxiv.org/html/2412.06685); [GR-RL](https://arxiv.org/html/2512.01801v2); [πRL](https://arxiv.org/html/2510.25889)

### Inferences
Inference, my calculations from binomial statistics; none of these numbers come from a paper:
- **Evaluation power.**
  - Wilson 95% intervals: 3/12 is 8.9–53.2%, and 0/12 is 0–24.2%. The previous 0/12 versus 3/12 comparison cannot separate the policies.
  - To detect 25% → 50% with α = 0.05 and 80% power needs about 58 episodes per arm. For 25% → 40% it needs about 152 per arm. For 25% → 35% it needs about 328 per arm.
- **Expected signal.**
  - At 25%, 60 or 120 episodes yield about 15 or 30 successes in expectation.
  - At 10% they yield only 6 or 12.
  - For group-based updates with group size 8, the chance that a group contains both a success and a failure is 0.90 at p = 0.25, 0.57 at p = 0.10, and 0.34 at p = 0.05.
- **The previous attempt's exploration was probably much worse than native.**
  - If the 24 training episodes came from tasks averaging 25% native success, the probability of seeing 0/24 successes is about 0.001.
  - Seeing 0/24 implies the exploratory policy succeeded at most about 12–14% of the time (95% upper bound).
  - This is consistent with the 2026 critiques: off-prior noise from LP-DS, uninformative noise-space exploration from AnchorQ, and the early offline→online drop in GR-RL.
- **Discounting over the episode.**
  - With about 250 decisions per episode and γ = 0.99 per decision, a terminal reward is discounted to about 0.08 at the episode start (0.99²⁵⁰ ≈ 0.081). With γ = 0.999 it is about 0.78.
  - DSRL's real runs had roughly 14 decisions per episode (about 11,000 steps over 80 episodes, 10 steps per chunk).
- **Realistic expectation.** From about 25% with 60–120 episodes, the published analogues suggest +10 to +30 absolute points is plausible, if three conditions hold:
  - The effective horizon is shortened (critical-phase resets or subtask rewards).
  - Exploration stays near the native prior.
  - The critic is pre-trained on logged native rollouts.

  Without these, the DSRL comparisons and the user's own run suggest no gain or a regression. Confirming any gain needs a pre-registered evaluation of about 60 or more episodes per arm.

### Gaps
- No paper reports a minimum number of successes per batch or update.
- I found no study varying the episode budget at a fixed ~25% start for pi0/pi0.5 steering.
- I found no study of how simulator outcome noise affects small-budget VLA RL.

## Q5. Ingredients that successful methods share, and which transfer to a slow simulator with 3–4 lanes

### Takeaway
Successful methods share six ingredients:
1. A competent prior (roughly ≥20–40% success, often reached by SFT on 20–1,000 demonstrations).
2. A reliable success label (a simulator predicate, a rule-based detector, a classifier, or a human).
3. A short effective horizon (chunk-level decisions, critical phases, subtask rewards).
4. Per-task training.
5. Keeping the policy anchored to the prior (frozen VLM, BC or reference regularisation, trust regions).
6. Either massive parallelism (simulation) or human data (real robots).

For a 3–4-lane simulator, the transferable ingredients are:
- Offline or logged-data critic pre-training.
- Resets to the critical phase.
- Verifiable subtask or progress rewards.
- Per-task steering anchored to the prior.
- Chunk-level critics with ensembles.
- Runtime safety filters.

Parallelism, world-model RL, and million-step constrained RL do not transfer.

### Cited Findings
- **Parallel environments and big compute** (simulation methods):
  - πRL: 64–320 environments on 8 H100s. [πRL](https://arxiv.org/html/2510.25889)
  - RLinf-VLA: 64–256 environments. [RLinf-VLA](https://arxiv.org/html/2510.06710)
  - SimpleVLA-RL: 8 A800s for 1–2 days. [SimpleVLA-RL ICLR 2026](https://proceedings.iclr.cc/paper_files/paper/2026/file/cbfbcb4da14235bd69b134070898ae9d-Paper-Conference.pdf)
  - StructRL: about 1,536 GPU-hours. [StructRL](https://arxiv.org/html/2609.36352v1)
  - WMPO and SafeDojo: 32 GPUs each. [WMPO](https://arxiv.org/html/2511.09515); [SafeDojo](https://arxiv.org/html/2606.20698)
- **Offline data and critic pre-training**:
  - PA-RL pre-trains the critic on 50 zero-shot rollouts. [PA-RL](https://arxiv.org/html/2412.06685)
  - GR-RL uses 673 offline rollouts to fine-tune its critic heads. [GR-RL](https://arxiv.org/html/2512.01801v2)
  - ConRFT uses Cal-QL plus BC on 20–30 demonstrations. [ConRFT](https://arxiv.org/html/2502.05450)
  - RECAP trains its value function on all data, using Monte Carlo returns. [π*0.6](https://arxiv.org/html/2511.14759)
  - AnchorQ's "FRS" pre-fills DSRL's replay buffer, which was needed for DSRL to progress on Hard-10. [AnchorQ](https://arxiv.org/html/2610.22852)
  - DSRL reports that offline data gives about a 2× sample improvement. [DSRL](https://arxiv.org/html/2506.15799)
- **Short effective horizon and chunking**:
  - RLT trains on critical phases and finds single-step methods fail on sparse tasks spanning hundreds of steps. [RLT](https://www.pi.website/download/rlt.pdf)
  - PARTS uses bottleneck subtasks. [PARTS](https://arxiv.org/html/2609.21788)
  - StructRL's subtask rewards beat terminal-only reward on 1,400–2,900-step tasks (37.6% vs 25.1%). [StructRL](https://arxiv.org/html/2609.36352v1)
  - πRL finds larger chunks lower the RL ceiling. [πRL](https://arxiv.org/html/2510.25889)
  - RLinf-VLA finds action-level value estimates beat chunk-level ones. [RLinf-VLA](https://arxiv.org/html/2510.06710)
- **Dense progress signals and their risks**:
  - VLA-RL's process reward model adds 4.4 points on Spatial. [VLA-RL](https://arxiv.org/html/2505.18719)
  - StructRL warns about idling-style reward hacking and finds over-dense rewards hurt. [StructRL](https://arxiv.org/html/2609.36352v1)
  - ConRFT reports classifier false positives (reward hacking). [ConRFT](https://arxiv.org/html/2502.05450)
  - SimpleVLA-RL's "pushcut" is an outcome-reward exploit. [SimpleVLA-RL](https://arxiv.org/html/2509.09674)
- **Per-task training**:
  - All the real-robot small-budget results are per task: DSRL, UniSteer, PARTS, RLT, HIL-SERL, ConRFT. [UniSteer](https://arxiv.org/html/2605.10821v2); [HIL-SERL](https://arxiv.org/html/2410.21845)
  - SimpleVLA-RL's RoboTwin runs are single-task, at 12–24 hours each. [SimpleVLA-RL ICLR 2026](https://proceedings.iclr.cc/paper_files/paper/2026/file/cbfbcb4da14235bd69b134070898ae9d-Paper-Conference.pdf)
- **Reset strategies**:
  - RLinf-VLA's "partial reset" (resetting environments independently) improved success and sample efficiency. [RLinf-VLA](https://arxiv.org/html/2510.06710)
  - Comet perturbs initial robot poses for its rejection-sampling rollouts. [Openpi Comet](https://arxiv.org/html/2512.10071)
  - RLT resets episodes to the start of the critical phase. [RLT](https://www.pi.website/download/rlt.pdf)
  - Ctrl-World resets to random initial arm positions in imagination. [Ctrl-World](https://arxiv.org/html/2510.10125)
- **Anchoring to the prior**:
  - πRL freezes the VLM. [πRL](https://arxiv.org/html/2510.25889)
  - LP-DS uses a trust region. [LP-DS](https://arxiv.org/html/2606.01151v1)
  - GR-RL applies a drift penalty. [GR-RL](https://arxiv.org/html/2512.01801v2)
  - RLT regularises toward the reference and drops the reference at random. [RLT](https://www.pi.website/download/rlt.pdf)
  - ConRFT keeps a BC loss online. [ConRFT](https://arxiv.org/html/2502.05450)
  - AnchorQ samples particles around flow-reversed anchors. [AnchorQ](https://arxiv.org/html/2610.22852)
- **Critic stability**:
  - DSRL uses 10 critics in sim. [DSRL](https://arxiv.org/html/2506.15799)
  - AnchorQ uses REDQ with 10 heads and a minimum over 2. [AnchorQ](https://arxiv.org/html/2610.22852)
  - VLA-RL needed critic warm-up. [VLA-RL](https://arxiv.org/html/2505.18719)
  - πRL's early dip came from an inaccurate warm-up critic. [πRL](https://arxiv.org/html/2510.25889)
- **Rejection sampling as a non-RL alternative**:
  - Comet: 3 rounds of about 8,500 rollouts, keeping 1,469. [Openpi Comet](https://arxiv.org/html/2512.10071)
  - Ctrl-World: 25–50 successes per task gave large pi0.5 gains. [Ctrl-World](https://arxiv.org/html/2510.10125)

### Inferences
- **Transferable** (inference):
  - Pre-train the noise-space or chunk-level critic, with ensembles, on every logged native and previous-attempt rollout before any online steps. Use Monte Carlo or distributional targets rather than high-update-to-data TD on a handful of successes; this is the RECAP, GR-RL and PA-RL pattern.
  - Start episodes from saved simulator states at the critical phase (grasp, lift and carry, where tipping happens), not from the 2,000-step start. This is the RLT-style critical phase, made cheap by simulator state restore.
  - Use simulator-verifiable subtask predicates (lid closed, jar grasped, jar upright, distance to goal) as gated, once-only rewards, following StructRL, with a cost signal for tilt or open-lift. Few signals per task, to avoid over-densification.
  - Train per task, keeping exploration anchored to the base noise distribution (trust region or drift penalty, anchors or particles).
  - Add a runtime tilt or orientation filter or a rollback in the AEGIS/SafeLoop style. These need no RL budget.
- **Not transferable** (inference):
  - The 64–320-environment PPO/GRPO recipes (πRL, SimpleVLA-RL, RLinf).
  - World-model RL (WMPO, SafeDojo, VLA-RFT: 4–32 large GPUs and thousands of trajectories just for the world model).
  - CMDP training at SafeVLA scale (15–25M steps).
  - Full RECAP-style iterations of 300–960 episodes each.
- Inference: rejection-sampling SFT on the roughly 15–30 safe successes per 60–120 episodes is a cheap comparison arm. Ctrl-World's gains came from 25–50 kept successes per task, but those were human-selected imagined trajectories on a different problem, so transfer is uncertain.
- Inference: if the simulator's per-step cost could approach RLinf's optimised BEHAVIOR figure (41 ms/step versus about 210–270 ms implied by 7–9 minutes per 2,000 steps), the episode budget would grow several-fold at the same cost. Whether ManiGuard's OmniGibson stack permits this is unverified.

### Gaps
- I found no ablation isolating each ingredient's contribution at small budgets for pi0.5 steering.
- I found no published result for critical-phase resets in OmniGibson.
- I found no paper on how outcome noise in the simulator affects small-budget VLA RL.
