# SafeCEM task 10: what stage B revealed, and the next improvements

Written 25 October 2026, while stage C was running. Everything in the diagnosis comes from
evidence already saved by stages A and B, plus one read-only CPU check on the rental. No new
episodes were run for it.

## The short version

The clearance dial bites, but the safety check underneath it reads the pusher's position
wrongly. The pilot's start corner (pusher at 40, 40) is almost absent from the training data,
and there the probe misreads the pusher by up to 200 px. Along the wall it is off by 15 to 40
px, about the size of the clearances being dialled. The calibration gap and the exposure peak
in stage B are mostly this perception failure out of distribution, not a property of the
dial itself. Fixing the safety check is the low-hanging fruit with the most leverage.

## Diagnosis

| check | result |
|---|---|
| probe on the real current frame, closed loop, all stage B safe episodes | median 85 px, p90 180 px (against about 5 px on dataset frames) |
| probe at the start frame | reads (191, 137) for a pusher at (40, 40) |
| dataset frames within 40 px of the start | 0.06 percent; the top-left 64 px cell holds 0.2 per mille of frames |
| probe error on env-rendered frames, by region | about 200 px at the start corner, 15 to 40 px along the wall band, 1 to 20 px near the centre |
| hazard-entry states produced by a replan whose chosen plan was feasible under the inflated boxes | 564 of 573 (98 percent); imagined clearance of that plan median 38 px |
| error of the imagined position after the executed block | median 50 px, p95 153 px |
| same, with the probe anchored at the true current position | median 43 px, p95 69 px |

Two more facts matter for interpretation.

- **Rendering.** Every frame, dataset and env alike, draws the standard green target T at one
  fixed pose. The experts always push the block onto that target. Our goal puts the block to
  its right, a configuration the data rarely contains, and the pusher spends most of each
  episode far from the block, which is also rare in expert data.
- **No safe detour exists within the budget.** Going around the right end of the wall means
  going around the block as well, roughly 880 px or 49 steps at the measured 18 px per step.
  Once the gap closes, hovering is the right behaviour. The failure is that it hovers
  unsafely, because the check believes the pusher is 25 to 40 px from where it is.

Anchoring halves the tail but leaves a 43 px median. So the imagined displacement over one
block is also unreliable in this regime. Part of that may be an execution detail: CEM
executes the mean of its elite set, and the constraint never checks that mean, only the
individual candidates.

## What this changes in the stage B story

- The dial is still a sharp route selector, and the closure still lands near the geometric
  value, because the probe's error near the gap is moderate (13 to 25 px).
- "Nominal clearance is not realized clearance" is mainly a perception failure out of
  distribution. The uncertainty-unit dials failed because they were calibrated on dataset
  frames, a different distribution from the closed loop.
- This is the failure mode UNISafe was built for: a latent safety check that is
  overconfident out of distribution. That gives a natural bridge from the SafeCEM chapter to
  the task-9 chapter.
- Stage C remains a valid black-box comparison, because it optimizes realized exposure and
  realized J. But it searches knobs on top of a miscalibrated check, which is not the
  pipeline the paper should rest on.

## Improvements, ranked by leverage per hour

1. **Ground the safety check.** Cheap, and it fixes the root cause.
   - Exact-check control: compute the pusher's future positions from the commanded actions
     (the pusher is position-controlled, and the arena constraint already does this). This is
     the upper bound that separates perception error from planning behaviour.
   - Probe fixes: anchor the probe at the true current position; retrain it on env-rendered
     frames that cover the whole arena, plus far more dataset episodes than the 800 in the
     current 100 chunks; execute the best feasible candidate rather than the unchecked elite
     mean.
   - Move into distribution: start the pusher where the data has coverage, or adopt LeWM's own
     protocol (a dataset start and a goal 24 to 25 actions later) with the wall placed across
     each route. The latter also gives layout randomization for free.
2. **Calibrate the dial in risk units.** This is analysis only, once the check is sound.
   Learn then Test selects the dial values that control a chosen risk with a finite-sample
   guarantee and handles non-monotone risk. Conformal Decision Theory adapts a conservativeness
   parameter online with a long-run risk guarantee. Either replaces the failed uncertainty-unit
   recipe with a guarantee stated in closed loop.
3. **Graceful degradation.** This needs a layout with a feasible alternative route, plus
   guidance past the planner's myopia. "Aim Short to Reach Far" argues that frozen world models
   fail at distant goals because the planner aims at the goal image, and that nearby waypoints
   along a feasible route fix it. "The Objective Is the Bottleneck" reports a similar gain from
   changing only the planning objective. Sampling-MPC work on local minima (repulsive
   potentials, detour-inducing costs) is the classical analogue.
4. **The GECCO angle: quality diversity.** MAP-Elites over the interface, with realized
   clearance as the behaviour descriptor and completion as fitness. The resulting archive is a
   dial indexed by what actually happens, not by nominal pixels, which turns the calibration
   failure into the contribution. Behaviour repertoires selected at deployment are the
   precedent (Cully et al. 2015).

## Proposed next step

Pause stage C. It is resumable from its per-generation records. Implement item 1 (about an
hour of code and tests). Then rerun the gate sweep on two layouts with three checks: the
frozen probe (already measured in B), the fixed probe, and the exact check. That is about 360
episodes, roughly 45 minutes. After that, rerun stage C on the fixed pipeline (about 7.7
hours). The whole sequence fits before the rental deadline of 01:52 UTC if it starts by about
15:30 UTC, and adds about $2.50 to the $0.46 spent so far.

## Literature

- LeWM: Maes et al., arXiv 2603.19312. Its Push-T evaluation places the goal 24 actions ahead
  and allows 50 (per arXiv 2609.30036).
- Aim Short to Reach Far: Your Frozen World Model Can Plan Better Than You Think, arXiv 2609.30036.
- The Objective Is the Bottleneck: Latent World Models Encode What Their Planners Cannot Use,
  arXiv 2608.12959.
- ARC-Bench: Closed-Loop Replanning Masks Broken Action Ranking in Frozen JEPA World Models,
  arXiv 2609.05461.
- The Evaluation Protocol Determines the Result: An Independent Reproduction of LeWorldModel
  on TwoRoom, arXiv 2608.10145.
- DINO-WM, arXiv 2411.04983 (Wall environment, CEM in MPC); stable-worldmodel-v1, arXiv
  2602.08968 (fixed 50-step budget).
- PLDM: Sobal et al., arXiv 2502.14819 (two rooms joined by a narrow door).
- Latent safety filters: Nakamura, Peters and Bajcsy, arXiv 2502.00935 (RSS 2025); the
  uncertainty-aware follow-up (UNISafe) and AnySafe (runtime constraint parameterization).
- Conformal Decision Theory: Lekeufack et al., arXiv 2310.05921.
- Learn then Test: Angelopoulos et al., arXiv 2110.01052.
- Robust CEM: Liu et al., arXiv 2010.07968. iCEM: Pinneri et al., CoRL 2020.
- MPPI local minima: Fuke et al., arXiv 2410.11379; GP-MPPI, arXiv 2307.04019; DRPA-MPPI,
  arXiv 2503.20134.
- MAP-Elites repertoires: Cully et al., arXiv 1407.3501.

## Update, 14:23 UTC: the fix is in and the probe can see again

The user approved the plan. Stage C was paused at generation 0 (receipt
`progress/receipts/10-safecem-C-paused.md`) and item 1 was implemented and tested (receipt
`progress/receipts/10-safecem-probe-v2.md`).

- **Exact check.** Push-T's pusher follows a linear PD controller, so its path is a closed-form
  function of the actions, the position and the velocity. The model matches the simulator to
  0.0 px. The old commanded-target formula was off by about 100 px over a plan: the pusher
  covers only about 40 percent of each commanded offset per step.
- **Probe v2.** Retrained on simulator frames covering the arena plus a wider dataset sample.
  On 4,000 real closed-loop states the median error fell from 36.5 to 8.2 px and the p95 from
  155 to 22.7 px; in the start corner, from 110 to 13 px.
- **Best-candidate execution.** The planner now executes the best checked plan, not the
  unchecked elite mean.

Stage B2 (450 paired episodes on G0 and G80, same seeds as stage B) started at 14:21 UTC; stage
C2 reruns the search on the grounded pipeline afterwards.

## Update, 15:20 UTC: what grounding the check did (stage B2)

Full receipt: `progress/receipts/10-safecem-B2-sweep.md`. In one line: grounding the check
changes how the planner fails, not how often it safely succeeds.

- The exact check makes the dial a guarantee (zero exposure, clearance honoured in all 140
  episodes) and then the planner stalls wherever the safe route bends away from the goal.
- The grounded probe halves the error of the predicted pusher position but completes more by
  cutting through pillars, so safe success stays at about 0.15 with the gap open.
- Executing the single best candidate exploits the world model's errors; the elite mean hedges
  them. That reverses the iCEM intuition in this setting and is worth a sentence in the paper.

Next bottlenecks, both in the planner: imagined self-motion still off by about 19 px per block,
and a myopic goal cost that never finds the detour. Candidate fixes for a later task: waypoint
goals ("Aim Short to Reach Far"), elite-mean execution with feasible-only elites, and a goal
cost that uses the controller model for the pusher's own position.

## Update, 19:30 UTC: what searching the interface did (stage C2)

Full receipt: `progress/receipts/10-safecem-C2-search.md`; paper section "Stage C2" with
Table 4 and Figure 4. In one line: the search finds safer, faster settings than any single
dial on the layout it searched, but neither its edge over random search nor its transfer to a
new layout is established at three replicates.

- Best fresh-seed safe success on G0: NSGA-II 0.43, random search 0.60, grid 0.33, against 0.30
  for the best single dial on the same pipeline. On the held-out G80: 0.27, 0.17 and 0.17
  against 0.30.
- Fresh-seed hypervolume favours random search (9.2 against 6.2); held-out hypervolume favours
  NSGA-II (8.6 against 5.3, 7 of 9 replicate pairings).
- The fronts agree on horizon 3 (the grid lacks it) and a little feasibility tolerance. The
  setting that transfers best starts wide (about 38 px) and shrinks by about 7 px per block.

A lead from task 12 (TwoRoom): under a hard constraint, CEM needed a much smaller elite set
(top 10 of 1000) to keep the rare feasible, goal-reaching candidates; with the default
elite fraction, the elite mean drifted to a far-field minimum. That is the same "hovers above
the wall" failure as the exact check on G0, and C2's elite-fraction gene (5 to 30% of 300)
never reached that regime. It is the cheapest next test on Push-T.
