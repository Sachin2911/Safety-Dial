# LeWM evolution, task 17

26 October 2026. An evolutionary completion advantage was not established.

The complete compact campaign ran 7,800 episodes. All three optimizers used the same
36-coefficient selector around frozen LeWM, with five independent runs per environment.
Training and validation allowances were identical. The selected controllers then faced
twelve fresh cases per environment, two clearances and two new planner seeds.

At the primary Reacher 1.5 cm clearance: evolution 101/120, random 97/120, reinforce 99/120, tuned 20/24.
The paired crossed run/case intervals and every optimizer run are in the
[results](../../../progress/receipts/17-lewm-evolution-results.md). The final denominator
includes every accepted case, unfinished episode and censored attempt. The native and
canonical context uses a separate development panel and is not pooled with final cases.

Actual simulator, checker and predictor consumption differs despite equal enforced
allowances. Validation was not scheduled at common consumed-resource checkpoints, so
these data cannot establish a search-efficiency advantage. Five optimizer repeats and
twelve case blocks give limited precision. Zero observed breaches is not zero risk.
The exact checker retains privileged state/dynamics access; the task-side controller
receives no true target geometry. No transfer or general safety claim is supported.

This campaign's result is separate from task 16's configuration lever and the earlier
ManiGuard studies. Historical evidence and other rentals were left unchanged. All raw
attempts, checkpoints, source freezes and reports are preserved in the existing private
research dataset under `17_lewm17_campaign/57809511/`. The independent guard owns final
preservation and rental self-destruction after the authorized finish request. External
provider absence and posted billing remain separate checks from another device.
