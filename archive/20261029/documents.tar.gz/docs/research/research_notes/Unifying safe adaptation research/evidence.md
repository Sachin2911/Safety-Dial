# Evidence for a shared safe adaptation paper

Repository evidence review, 26 October 2026. This is publication-strategy advice, not a protocol or authorization for new experiments. Task 15 confirmation remains unfinished in the local record; no interim confirmation outcomes informed these recommendations.

## What common claim is supported

### Takeaway

The defensible umbrella is **compact inference-time adaptation around frozen learned components, evaluated for safe task completion**. Evolution is a separately tested way of choosing those adapters. The evidence supports useful mechanisms and informative limits, but not a general evolutionary advantage, a common calibrated risk dial, or autonomous discovery of safety specifications.

### Cited Findings

- SafeCEM modifies the ranking and execution of plans around a frozen LeWM. The new outer searches tune five planner parameters. On TwoRoom, a small exact-check margin improves safe completion and speed on the tested layouts; larger margins cause safe stalling. Reacher shows a similar constraint-induced completion cliff. These are substantive observations about usefulness and over-conservatism, with safety defined by artificial geometric keep-out regions. [TwoRoom sweep](</home/sachin/Desktop/Research/Safety-Dial/progress/receipts/12-tworoom-B-sweep.md>), [Reacher sweep](</home/sachin/Desktop/Research/Safety-Dial/progress/receipts/13-reacher-B-sweep.md>).
- Across the completed outer searches, NSGA-II has no consistent advantage: random search leads on TwoRoom and Cube, Reacher gives little separation, and Push-T changes ranking between fresh seeds and the other layout. These are three optimizer replicates per method, not a definitive ranking across broad task distributions. [Push-T](</home/sachin/Desktop/Research/Safety-Dial/progress/receipts/10-safecem-C2-search.md>), [TwoRoom](</home/sachin/Desktop/Research/Safety-Dial/progress/receipts/12-tworoom-C-search.md>), [Reacher](</home/sachin/Desktop/Research/Safety-Dial/progress/receipts/13-reacher-C-search.md>), [Cube](</home/sachin/Desktop/Research/Safety-Dial/progress/receipts/14-cube-C-search.md>).
- Historical UNISafe adaptation substantially improves completion: evolved 54/64, fixed 55/64, random search 56/64, policy gradient 54/64, baseline 2/64. Evolution has 8/64 violations versus 6/64 baseline; its timeouts are 2/64 versus 56/64. The mechanism was supplied by human diagnosis, and all adaptation methods received additional finger-position information. The work establishes an effective adapter family, not optimizer superiority or safety non-inferiority. [Historical completed comparison](</home/sachin/Desktop/Research/Safety-Dial/archive/20261022/docs/research/reports/UNISafe grasp maintenance and evolutionary adaptation.md>).
- Task 9 confirms the value of grasp sensing beyond timing: sensed delay completes 50/64 versus history-only 31/64, with 8/64 violations each and timeouts 6/64 versus 25/64. Its selected improvement over the earlier random-search setting does not confirm, and no speed/completion tradeoff is supported. Translation scaling's stronger sustained completion is post hoc. [Task 9 result](</home/sachin/Desktop/Research/Safety-Dial/progress/receipts/09-unisafe-results.md>).
- Task 15 provides promising development evidence for phase-gated projection, not confirmed efficacy. In stage B, projection has strict safe completion 9/16, benchmark success 9/16, violations 2/16, unfinished 7/16 and engagement 16/16; native has 5/16, 6/16, 6/16, 10/16 and 16/16 respectively. Selection arms do not beat native. Stage C confirms the prospectively selected sampling arm; stage D separately confirms projection. [Task 15 receipt](</home/sachin/Desktop/Research/Safety-Dial/progress/receipts/15-regrasp-results.md>), [validated stage-B ledger](</home/sachin/Desktop/Research/Safety-Dial/outputs/regrasp15/remote/attempts_stage_b.jsonl>), [protocol](</home/sachin/Desktop/Research/Safety-Dial/progress/15-regrasp-dial-plan.md>).

### Inferences

- A thesis can ask two linked questions: which compact intervention interfaces preserve useful progress under constraints, and when does evolutionary search add value over simpler selection? The existing mix of positive mechanisms and negative optimizer results already addresses this structure.
- A potential cross-system explanation is that successful adaptation depends on a usable proposal, an informative check, and an intervention capable of changing the failure. SafeCEM's learned-check errors, UNISafe's grasp sensing, and Jar's selection-versus-projection comparison probe different parts of that explanation. It remains a synthesis to test, not a single demonstrated causal law.
- The allocated topic asks whether evolution can balance task reward and violations. A negative answer for specific compact interfaces remains relevant. The project cannot claim to eliminate hand-crafted safety semantics: hazards, failure predicates, phase gates and adapter families are explicitly designed. [Allocated topic](</home/sachin/Desktop/Research/Safety-Dial/docs/allocatedTopic.md>).

### Gaps

- No replicated evolutionary advantage is established. No common state-dependent adapter has yet been compared across all three fronts. Task 15 confirmation is not complete.

## Which comparison limits matter for a paper

### Takeaway

The greatest publication risk is overgeneralizing heterogeneous evaluations. The most valuable alignment work is a fair comparison and precise claim boundaries, rather than adding more environments.

### Cited Findings

- **The grid has a different search space.** NSGA-II and random search vary five genes, including horizon 3 and nonzero tolerance. The grid varies clearance, slope and horizons 4/5/6, fixing elite fraction and tolerance. Its deficit cannot be assigned solely to grid search. [Shared decoder and grid](</home/sachin/Desktop/Research/Safety-Dial/experiments/helpers/safecem10_evo.py>), [design](</home/sachin/Desktop/Research/Safety-Dial/configs/safecem10/design.json>).
- **The other layouts were exposed.** G80, T0, R0 and C0 appear in stage-B sweeps before the searches; C0 also appears in Cube side diagnoses. They are held out from optimizer training, not unseen throughout development. Fixed starts and goals are repeated with planner/random seeds; Cube uses one dataset scene. [Task 10 protocol](</home/sachin/Desktop/Research/Safety-Dial/progress/10-safecem-dial-plan.md>), [TwoRoom design](</home/sachin/Desktop/Research/Safety-Dial/configs/tworoom12/design.json>), [Reacher design](</home/sachin/Desktop/Research/Safety-Dial/configs/reacher13/design.json>), [Cube sweep](</home/sachin/Desktop/Research/Safety-Dial/progress/receipts/14-cube-B-sweep.md>).
- **Final-front selection is descriptive.** The analysis reports the maximum safe-success rate among candidates evaluated on the final seeds. This is a best-front statistic, not an unbiased estimate for one controller selected before final evaluation. Front sizes differ. The 3 by 3 win counts reuse the same three optimizer replicates and are not nine independent replications. [Stage-C analysis](</home/sachin/Desktop/Research/Safety-Dial/experiments/scripts/analyze_safecem10.py>).
- **The safety objective differs from episode risk.** World-model search optimizes mean fraction of states in a hazard and completion-time cost. A brief violation can have low exposure while making the whole episode unsafe. Jar and UNISafe also have different physical and task-sequence safety definitions. Pooling their rates or interpreting hypervolume as a risk guarantee is unsupported. [Task 10 protocol](</home/sachin/Desktop/Research/Safety-Dial/progress/10-safecem-dial-plan.md>), [UNISafe outcome contract](</home/sachin/Desktop/Research/Safety-Dial/progress/09-unisafe-dial-plan.md>), [Jar outcome contract](</home/sachin/Desktop/Research/Safety-Dial/progress/15-regrasp-dial-plan.md>).
- **Available information and dynamics knowledge vary materially.** UNISafe's adapter uses finger positions and command history, without object geometry. Task 15 reads jar position and scorer propositions for its closure/lift gate. Grounded Push-T uses true current position, and its exact reference also uses velocity. Reacher rolls a copy of the actual MuJoCo model from true joint positions and velocities for every candidate; this is an oracle dynamics check, not a learned-model-only safety mechanism. Cube uses a fitted command-to-motion model and true current effector state. [UNISafe protocol](</home/sachin/Desktop/Research/Safety-Dial/progress/09-unisafe-dial-plan.md>), [Jar protocol](</home/sachin/Desktop/Research/Safety-Dial/progress/15-regrasp-dial-plan.md>), [Push-T amendment](</home/sachin/Desktop/Research/Safety-Dial/progress/10-safecem-dial-plan.md>), [Reacher check](</home/sachin/Desktop/Research/Safety-Dial/experiments/helpers/reacher13_planner.py>), [Cube check](</home/sachin/Desktop/Research/Safety-Dial/experiments/helpers/cube14_planner.py>).
- **Cube is a reaching study.** Its success is the pinch point within 4 cm of the goal-frame position. Carrying was abandoned after a failed development diagnosis. It should be called reaching in the Cube environment, not successful cube manipulation. [Canonical design](</home/sachin/Desktop/Research/Safety-Dial/configs/cube14/design.json>).
- **Budget equality needs precise wording.** Historical UNISafe uses equal training episodes but different realized controls and selects one final controller across optimizer replicas. New LeWM searches match candidate episode budgets, while early termination, different horizons, final-front sizes and true-model checks create different interaction/query costs. Shared design, probe training and diagnosis are costs, not free method discovery. [UNISafe accounting](</home/sachin/Desktop/Research/Safety-Dial/archive/20261022/docs/research/reports/UNISafe grasp maintenance and evolutionary adaptation.md>), [search runner](</home/sachin/Desktop/Research/Safety-Dial/experiments/scripts/run_safecem10.py>), [Reacher check](</home/sachin/Desktop/Research/Safety-Dial/experiments/helpers/reacher13_planner.py>).

### Inferences

- Horizon and clearance associations in searched candidates motivate ablations; they do not identify causal parameter effects because other genes and selection co-vary.
- Retaining old noisy parent fitness while evaluating offspring on fresh generation seeds is a plausible NSGA-II weakness worth testing with reevaluation. The runner does this, but the current results do not isolate its contribution. [Runner](</home/sachin/Desktop/Research/Safety-Dial/experiments/scripts/run_safecem10.py>).

### Gaps

- The completed studies do not contain an equally informed ordinary-learning comparator for the new five-gene LeWM interfaces. DSRL on Jar and historical UNISafe policy gradient cannot substitute for that comparison.

## What minimal alignment work is justified

### Takeaway

Complete the already frozen Jar comparison, write the honours thesis around the supported mechanisms and their limits, and make any GECCO extension a small preregistered comparison that can succeed scientifically even if random search wins.

### Cited Findings

- The current research controls require a useful replicated lever before an evolutionary claim, then native, tuned fixed, parameter random search and ordinary learning with matched information and interactions. They also reserve ManiGuard held-out tasks. [First-principles plan](</home/sachin/Desktop/Research/Safety-Dial/firstPrinciples.md>).

### Inferences

- **Immediate synthesis, no new simulation:** use one reporting contract across the thesis: safe completion, any-violation episodes, unfinished episodes, engagement, and compute. Keep native task predicates, units and denominators. Mark each study as mechanism evidence, development screen, optimizer comparison or confirmation. Clearly identify designed constraints and privileged information.
- **Jar:** await stages C/D without reading interim outcomes to redesign them. If projection confirms, prioritize one prospective gate/strength ablation and a fresh development replication before any search. An observed benefit from simple fixed projection is already useful; it does not need to become evolutionary to count.
- **UNISafe:** the existing grasp-sensing confirmation may be sufficient for the thesis. If continuing, test sustained completion under continued control prospectively, because that is the remaining signal. Do not reopen optimizer tuning merely to seek an evolutionary win.
- **GECCO:** choose one common optimizer study on at most two interfaces with verified useful variation. Freeze identical parameter support and observations; compare native, a tuned fixed setting, random search, a simple ordinary learner and the evolutionary method. Match a declared simulator-step budget, account for query costs and shared preparation, and evaluate every optimizer replicate under the same selection rule. Reserve new scene distributions as well as fresh planner seeds. A carefully isolated reevaluation or noise-aware selection method could be a new hypothesis, but must beat the same-budget baseline rather than be justified by the earlier null result alone.
- Avoid a new dial claim unless the operating points reliably change realized safety and task cost in a useful range. Threshold-induced inactivity and nonmonotone response are findings about dial limitations, not calibrated user control of risk.

### Gaps

- The evidence does not set a defensible new sample size or spending cap. Those require measured variance, runtime and a prospective effect target, plus a separate authorization. The thesis can proceed while that decision remains open.
