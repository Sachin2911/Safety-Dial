# Evolutionary contribution and GECCO positioning

Research notes checked 26 October 2026. These are publication-strategy recommendations, not experiment authorization. The three questions below separate venue requirements, prior art, and proposed work. Source dates are publication dates where available; official venue pages were accessed on the date above.

## Can evolutionary adapters remain the shared framing and fit GECCO?

### Takeaway

Yes, as a research question about the usefulness and limits of evolutionary search over compact execution interfaces. The current evidence does not support a title or abstract asserting that evolution is responsible for the improvements across all three fronts. An honours thesis can contain the broad investigation; a GECCO submission needs one focused evolutionary-computation contribution, with the other studies serving distinct supporting roles.

### Cited Findings

- GECCO's verified 2026 call asks for original work in genetic and evolutionary computation and lists significance, soundness, novelty, clarity, relevance and replicability among its review criteria. Full papers are at most eight pages excluding references; the four-page poster route is for less mature work and appears in the Companion proceedings. This is 2026 guidance, not a verified 2027 rule. [Official 2026 call](https://gecco-2026.sigevo.org/Call%2Bfor%2BPapers).
- The 2026 EMO scope explicitly includes comparison with non-EMO approaches, uncertainty handling, expensive objectives, and application studies yielding broader insights. Therefore a careful finding that evolution does not beat random search can fit the stated subject area; acceptance still depends on the significance and completeness of the study. [Official EMO scope](https://gecco-2026.sigevo.org/Track?itemId=54).
- The 2026 EML scope covers reinforcement learning, transfer, domain adaptation and application-focused work. It strongly encourages comparison with corresponding non-evolutionary methods. [Official EML scope](https://gecco-2026.sigevo.org/Track?itemId=53).
- The 2026 BBSR scope includes algorithm benchmarking, statistical analysis, benchmark tools and rigorous replication. Its special requirements for reproducibility studies include explaining the reasons for new findings and making artifacts publicly available. That could matter for a later submission because the project currently preserves much evidence privately; no publication is authorized here. [Official BBSR scope](https://gecco-2026.sigevo.org/Track).
- The official page under the 2027 domain still describes GECCO 2026 in Costa Rica and gives January 19 and 26, 2026 as abstract and paper deadlines. It is demonstrably stale as 2027 scheduling evidence. [2027-domain CFP, accessed 26 October 2026](https://gecco-2027.sigevo.org/Call%2Bfor%2BPapers).

### Inferences

- A credible honours title is **Compact execution adapters for safer task completion with frozen robot models**, with evolutionary optimization as a principal research question. An explicitly evolutionary alternative is **Evaluating evolutionary adaptation for safe task completion with frozen robot models**. Both leave room for null optimizer findings.
- A narrower GECCO working title is **Budgeted evolutionary search for safe adaptation of frozen robot models**. The title describes what is evaluated; the abstract must state where it helps, ties, or fails.
- The shared object is a compact interface around a frozen model, not necessarily a neural adapter. LeWM contributes planner settings, UNISafe contributes feedback-dependent execution logic, and ManiGuard contributes phase-gated execution modification. Avoid implying that all three are VLAs or foundation models.
- The thesis can answer three successive questions: does the interface offer useful authority, does adaptation improve task completion under explicit safety constraints, and does evolutionary search improve on simpler ways to configure that interface? The paper should select one of these as its principal contribution.
- If the core remains comparative evolutionary search, EMO is the natural fit when set quality and tradeoffs are central, and EML when adapting frozen learned systems is central. BBSR fits a sufficiently general and reproducible evaluation contribution. Neuroevolution is not the obvious fit for evolving five non-neural planner parameters.
- Keep the allocated topic's intent while narrowing its wording: Pareto or constrained optimization can reduce dependence on a scalar safety-penalty weight, but it does not eliminate manually specified safety predicates, costs, constraints or preferences.

### Gaps

- No reliable 2027 submission deadline was verified. The report should not transform the stale 2026 dates into presumed 2027 dates.
- Venue fit is an informed recommendation, not an acceptance prediction or confirmation from the track chairs.
- The current study's ability to supply a publication artifact that satisfies the eventual chosen track needs a later check of licensing, data redistribution and anonymization. Do not change current private preservation policy merely to satisfy an assumed future requirement.

## Which ideas are established prior art and where could novelty remain?

### Takeaway

Pareto search, constrained evolutionary optimization, safety-informed evolution, behavior repertoires and resampling under uncertainty are established ideas. The possible contribution lies in a carefully defined adaptation problem, an effective compact mechanism, and evidence about how interface authority, observation quality and evaluation noise affect the value of evolutionary search around frozen models.

### Cited Findings

- NSGA-II already combines elitist multiobjective selection, non-dominated sorting, diversity preservation and a constrained-dominance extension. Using it to return a safety-performance set is not itself a new algorithm. Deb, Pratap, Agarwal and Meyarivan, April 2002. [Original paper](https://web.njit.edu/~horacio/Math451H/download/2002-6-2-DEB-NSGA-II.pdf).
- Safety-informed evolutionary mutation has already been studied with deep RL, using encountered unsafe states to bias exploration toward safer actions while retaining return. This is related prior art, but it modifies policies in an evolutionary/RL loop rather than establishing this project's frozen-backbone, compact-interface formulation. Marchesini and Amato, GECCO Companion 2022. [Author-hosted paper](https://emarche.github.io/assets/pdf/GECCO2022_safemut.pdf).
- A separate action-editing policy is also established: SEditor learns to transform the utility policy's proposed action while preserving useful behavior through its training objective. It is relevant wrapper prior art, but it does not establish the same frozen-backbone and evolutionary-configuration setting as this project. Yu, Xu and Zhang, NeurIPS 2022 camera-ready revision dated 10 October 2022. [Safety Editor primary paper](https://arxiv.org/abs/2201.12427).
- A precomputed map of high-performing behaviors used for rapid robot adaptation predates this work. Cully et al. demonstrated repertoire-based recovery from damage for a legged robot and a robotic arm. Submitted 2014, Nature version 2015. [Original paper record](https://arxiv.org/abs/1407.3501).
- Uncertain Quality-Diversity treats fitness and behavioral descriptors as distributions and proposes comparisons based on sampling budgets and corrected metrics, alongside sampling-based methods. It reports the limitations of ordinary MAP-Elites in uncertain settings. Flageat and Cully, submitted February 2023, revised March 2023. [Original paper](https://arxiv.org/abs/2302.00463).
- Extract-QD unifies uncertain-QD approaches and introduces Extract-ME; the authors also study augmenting policy-gradient-assisted MAP-Elites under a fixed evaluation cost. Consequently, adding archive resampling to a safety repertoire cannot be presented as a new generic idea. Flageat et al., February 2025. [Full primary text](https://arxiv.org/html/2502.06585v1).

### Inferences

- Do not claim novelty as merely "evolution for safety", "a safety-performance Pareto front", "a repertoire selected at deployment", "search instead of gradient descent", or "reevaluate candidates because rollouts are noisy".
- A potentially useful contribution is to distinguish **interface efficacy** from **optimizer efficacy** in frozen robot systems. A hand-built projection beating native supports the former. NSGA-II beating a weak grid that excludes the useful horizon does not establish the latter.
- A second possible contribution is an operational diagnostic: determine whether the candidate interface can actually change the hazardous action while preserving useful behavior before spending an optimizer budget. ManiGuard's offline candidate-rescue observations and the exact-versus-learned checks in SafeCEM are candidate evidence. This remains a proposed synthesis, not a proven general predictor.
- A third possibility is a controlled account of selection noise: explain when elitist search concentrates on lucky candidates and when repeated evaluation changes that behavior. Existing receipts suggest this hypothesis, but observational associations alone do not establish it. It needs an intervention on evaluation allocation or a carefully controlled comparison.
- "Safety dial" should be reserved for an empirically reliable range of operating points. A monotonically increasing nominal margin is not enough if realized risk is non-monotone, completion is flat, or one setting dominates all others. The repertoire itself does not supply a statistical risk guarantee.
- The novel part, if achieved, would be the combination of a specified compact interface and reproducible findings across frozen-model systems, including where authority or evaluation quality limits optimization. A broad framework diagram by itself is not sufficient novelty.

### Gaps

- This focused review is not exhaustive enough to support a "first" claim for frozen-model safety adaptation or its evolutionary optimization.
- No claimed new algorithm should be named until its distinction from NSGA-II, uncertain QD, constrained optimization and existing safety filters has been checked in the intended formulation.
- Claims of risk control need their own finite-sample assumptions and validation; the existing improvement screens alone do not establish a deployment safety guarantee.

## Which GECCO route is feasible without chasing a positive result?

### Takeaway

The preferred near-term route is a controlled empirical study of when compact-interface evolution earns its interaction budget. It can retain an evolutionary focus even if random search wins. A new state-dependent adapter method or a calibrated repertoire are conditional extensions that should not be pursued just to manufacture a more evolutionary story.

### Cited Findings

- Comparative studies against non-EMO approaches and studies of uncertainty and evaluation cost lie within the verified EMO scope. [Official EMO scope](https://gecco-2026.sigevo.org/Track?itemId=54).
- Uncertain-QD work makes evaluation allocation and corrected performance central objects of comparison. It is a relevant methodological baseline, not evidence that a particular resampling scheme will fix this project's NSGA-II results. [Flageat and Cully, 2023](https://arxiv.org/abs/2302.00463).
- EML explicitly encourages non-evolutionary comparators, supporting the repository's existing requirement for tuned fixed, random and ordinary-learning controls. [Official EML scope](https://gecco-2026.sigevo.org/Track?itemId=53).

### Inferences

1. **Preferred: a budgeted empirical contribution.** Ask: "Under matched interaction budgets, when does evolutionary search over compact execution interfaces improve held-out safe completion or the safety-performance set relative to tuned fixed settings, parameter random search and ordinary learning?" Fix one defensible interface per included system, give optimizers the same observations and parameter domain, and separate selection from final evaluation. Treat the existing studies as development evidence. A fresh comparison should include useful parameter values for every comparator, account for all evaluations, report multiple optimizer seeds, and test transfer on a genuinely reserved panel. Do not count the nine cross-pairings of three runs as nine independent replications. This is a plausible paper only if it yields reusable insight, not merely three leaderboard tables.

   The cheapest explanatory addition is a controlled evaluation-allocation study in one or two of the faster world-model tasks: at the same total simulator budget, compare broad exploration with more repeat evaluations, using the same allocation policy for evolutionary and random search where possible. Include plain and uncertainty-aware variants so a gain is not automatically attributed to evolutionary variation. If common initialization, unchanged search space and matched final evaluation still favor random search, that is the answer. The current results should not be erased by the new comparison.

2. **Conditional: one compact, phase-dependent adapter method.** Ask whether a small state-dependent rule offers gains beyond the best static parameter, then compare optimizers on that exact rule. The common formulation could choose when and how strongly to modify a proposal, with domain-specific measurements and actions. A static-setting control, phase/gating ablation and ordinary-learning comparator are essential. Only expand expressiveness if the failure analysis requires it; increasing parameter count simply to make grid search unattractive weakens the work. This becomes the preferred method-paper route only if the same principled design demonstrates useful behavior across at least two systems and the evolutionary component has a distinct, tested role.

3. **Conditional, larger extension: an empirically calibrated repertoire.** Optimize a set of compact adapters, then let a requested operating preference choose among independently evaluated members. Compare NSGA-II or an uncertainty-aware repertoire method with equal-budget random archives and scalar/static tuning. Report realized safety and completion with uncertainty and account for archive validation cost. This is appropriate only where multiple non-dominated operating points persist out of sample. It is currently the riskiest scope expansion because UNISafe did not establish the proposed dial and several world-model results collapse to speed differences or zero-exposure saturation. Prior repertoire and uncertain-QD methods are mandatory baselines, not novelty claims.

- **Recommended division of labor between thesis and paper:** the thesis can carry all three fronts as a coherent investigation of frozen-model adaptation, with positive mechanisms, nulls and engineering lessons. The GECCO paper should use the smallest subset that answers its exact evolutionary question convincingly. Including all three is beneficial only if the evaluation is genuinely aligned; it is not a requirement.
- **Proposed minimum sequence:** finish the existing ManiGuard confirmation without changing its selection rule; freeze a synthesis of claims; decide whether the shared contribution is mechanism or optimizer behavior; run only the missing decisive comparison. Reopening DSRL or inventing an additional task is not an automatic alignment requirement.

### Gaps

- No new cost or sample-size estimate is justified from this literature check alone. It requires measured runtime, desired precision and a prospective protocol using the current project controls.
- A full-paper claim of cross-system generality remains premature if most positive cases rely on simulator-only state or if each domain receives a materially different information advantage. These need explicit disclosure and matched within-system comparators.
- The attainable thesis scope should be reconciled with the supervisor's actual deadline. The older repository timeline is context, not a newly verified submission schedule.
