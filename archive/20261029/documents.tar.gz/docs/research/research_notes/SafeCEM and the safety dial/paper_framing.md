# Scientific framing and two paper strategy

## What did the SafeCEM experiment establish about evolution and a dial?

### Takeaway

The defensible role is an opening mechanism study: a frozen learned world model can support population-based trajectory search with an interpretable clearance setting. It does not establish that an evolutionary algorithm learned a persistent safety adapter, that the dial is a calibrated probability of safety, or that evolution beats other optimizers.

### Cited Findings

- LeWM is a learned latent predictive model, distinct from the planner wrapped around it. Its authors present end-to-end JEPA training, physical probing and planning; the official repository supplies released Push-T weights and delegates planning infrastructure to `stable-worldmodel`. Cite Maes et al. for the model, rather than attributing the underlying world model to this project. [LeWM paper](https://arxiv.org/abs/2603.19312), [official code](https://github.com/lucas-maes/le-wm).
- CEM repeatedly samples a population and updates its sampling distribution from the samples. This is a population-based black-box optimization mechanism. Rubinstein's own description makes the sample/update distinction explicit. It is accurate to connect this to distribution-based evolutionary search, but the unambiguous label in the manuscript is cross-entropy trajectory optimization. [Rubinstein's description](https://or.stanford.edu/seminars/rubinstein_112404.html).
- The local SafeCEM implementation changes candidate ranking: feasible trajectories rank by goal cost and precede infeasible trajectories, which rank by violation magnitude. Its docstring explicitly credits MPC-RCE. The authors of MPC-RCE describe robust cross-entropy optimization of a control sequence under model uncertainty and constraints, so feasibility-prioritized CEM is prior art, not a new algorithmic contribution here. [SafeCEM implementation](/home/sachin/Desktop/Research/Safety-Dial/archive/legacy/experiments/helpers/safeCEM.py:38), [Liu et al.](https://arxiv.org/abs/2010.07968).
- The local dial `d` inflates a supplied hazard box in pixels. It changes the admissible predicted trajectories. The measured violation is against the true box rather than the enlarged one. The safety rule is supplied by the experimenter; it is not discovered by the world model or evolutionary search. [Dial definition](/home/sachin/Desktop/Research/Safety-Dial/archive/legacy/notes/safeCEM.md:184), [implementation](/home/sachin/Desktop/Research/Safety-Dial/archive/legacy/experiments/helpers/safeCEM.py:118).
- The corrected archived note reports no observed true-box violations in nine episodes across d = 0, 20 and 40, but explicitly says this does not demonstrate its proposed trade-off hypothesis: safety is flat at zero and block error is nonmonotone. The same note retracts the earlier interpretation that penalty weighting inherently caused escape; initial geometry confounded that conclusion. [Corrected evidence](/home/sachin/Desktop/Research/Safety-Dial/archive/legacy/notes/safeCEM.md:76), [correction and dial qualification](/home/sachin/Desktop/Research/Safety-Dial/archive/legacy/notes/safeCEM.md:100).
- The d = 60 failure and separate action-space arena repair show why physical engagement and model validity matter alongside hazard measurements. The original high-dial runs avoided the hazard by leaving the arena and never moving the block. The repair restored block movement. [Failure and repair](/home/sachin/Desktop/Research/Safety-Dial/archive/legacy/notes/safeCEM.md:122).

### Inferences

- Three propositions must remain separate: an interface changes behavior; a learned or evolved adapter selects useful behavior; a particular optimizer finds better adapters. The SafeCEM study addresses the first and demonstrates the use of online population search. It does not answer the last two.
- A fixed clearance dial can function correctly as a constraint-setting interface without yielding a statistically resolved safety-performance frontier. Increasing a margin reduces a predicted feasible set, but does not mathematically imply monotonically safer closed-loop behavior when prediction, search and execution are imperfect.
- Even when every selected candidate satisfies a learned constraint, physical safety does not follow without additional validity assumptions. Avoid reproducing the archived note's stronger phrase that constraint ranking makes execution clean every time. The data support observed outcomes, not a guarantee.
- The paper's story can connect *where adaptation acts*: first candidate ranking around a frozen predictive model, then behavioral parameters around a frozen policy. Describe this as a shared design principle. They are not the same controller and have different safety signals.
- The supplied hazard geometry and clearance rule also mean this is not evidence of eliminating all hand-designed safety definitions. The useful distinction is replacing a reward-penalty trade-off with explicit constraints, while retaining externally specified safety semantics.

### Gaps

- The results agent is auditing the raw rows, planning budgets, checkpoint provenance, later corrections and figures. This framing note should not be used as an independent verification of those quantitative details.
- Nine repeated runs over three seeds and multiple dial values do not support broad layout generalization, a guarantee of zero risk, or an optimizer ranking. A claim about a useful calibrated dial would need a separately specified operating range, outcome curve and uncertainty analysis.

## How should the honours and GECCO manuscripts differ?

### Takeaway

Use a broad honours investigation of controllable safety around frozen models and policies, with SafeCEM as an early mechanistic case and UNISafe as the adaptation case. Build the GECCO paper around one specific, replicated evolutionary question once its evidence exists; the older demonstrations can motivate it without being counted as proof of that question.

### Cited Findings

- The allocated topic is Safe AI via Evolutionary Algorithms, asking whether black-box methods can balance reward and violations. The concept note separately asks whether evolutionary adaptation improves a pretrained policy under a learned safety filter without increased physical violations. These support an honours narrative connecting planning, intervention and adaptation, provided each experiment's claims stay bounded. [Allocated brief](/home/sachin/Desktop/Research/Safety-Dial/docs/allocatedTopic.md:13), [concept note](/home/sachin/Desktop/Research/Safety-Dial/docs/researchConceptNote/concept-note.tex:18).
- The current plan orders variance, a useful control interface, stable evaluation and optimizer advantage. It requires native execution, a tuned fixed controller, parameter random search and ordinary learning with the same available information and interaction accounting before claiming an evolutionary advantage. [Current stages](/home/sachin/Desktop/Research/Safety-Dial/firstPrinciples.md:38), [comparison controls](/home/sachin/Desktop/Research/Safety-Dial/firstPrinciples.md:101).
- GECCO's official 2027 homepage includes evolutionary machine learning, neuroevolution, evolutionary numerical optimization, real-world applications, benchmarking and reproducibility. The retrieved 2026 call evaluates significance, technical soundness, novelty, clarity, relevance and replicability. These are useful precedents for framing; 2026 page limits and dates should not be asserted as confirmed 2027 requirements. [GECCO 2027](https://gecco-2027.sigevo.org/HomePage), [2026 call](https://gecco-2026.sigevo.org/Call%2Bfor%2BPapers).
- The local venue note explicitly marks the 2027 submission dates as unconfirmed and retains stale references to an earlier LeWM plan. Its authority on current experimental direction is therefore limited. [Venue note](/home/sachin/Desktop/Research/Safety-Dial/docs/gecco2027.md:6), [stale direction reference](/home/sachin/Desktop/Research/Safety-Dial/docs/gecco2027.md:76).

### Inferences

- A suitable honours question is: **How can compact control interfaces around frozen learned models and policies change the balance between task progress and safety, and what additional benefit does evolutionary adaptation provide?** This lets the answer to the second clause be negative or unresolved without erasing the empirical contribution of the first.
- Suggested honours sequence: (1) define safety, completion, engagement and budget; (2) introduce frozen systems and population search; (3) present corrected SafeCEM as a controlled planning demonstration, including arena failure and repair; (4) present completed UNISafe adaptation and its fixed/random/ordinary-learning comparisons; (5) report the current dial investigation only to the extent executed; (6) use ManiGuard as the more difficult frozen-policy test, including failures and engineering limits; (7) discuss what makes an intervention useful and what evidence would distinguish optimizers. Scale the ManiGuard detail to the manuscript limit; every historical study need not become a full chapter.
- The opening SafeCEM case can be titled **Constraint-guided planning around a frozen world model**. Its logical transition to UNISafe is: planning changes which actions are proposed, while a filter changes which proposed actions are executed; a task policy may then need adaptation to make progress under intervention.
- A candidate GECCO question is: **Under matched interaction budgets, can evolution find compact controllers around a frozen policy that improve safe completion over tuned fixed settings, parameter random search and ordinary learning?** A variant for the fresh dial work is whether a state-dependent evolved controller improves the measured safety-completion frontier over the best fixed operating points, under identical safety definitions. Both are prospective questions, not descriptions of results already achieved.
- GECCO need not require a positive optimizer superiority result in principle: a rigorous, novel account of when and why evolution helps or fails could also be a contribution. The current project should not relabel a simple successful adapter or standard SafeCEM as that contribution. Method controls and mechanism analysis remain central.
- For GECCO, keep SafeCEM to concise motivation or an appendix unless new evidence establishes the same method across both systems. Combining heterogeneous demonstrations as if they were two replications would weaken attribution. A broad honours manuscript and a focused conference manuscript can share an evidence base while serving different questions.
- An honest provisional honours title is **Safety dials and evolutionary adaptation for frozen learned controllers**. A GECCO title should name the actual final method and question only after results are known. Avoid a title that presupposes evolutionary improvement.

### Gaps

- The 2027 call endpoint was not retrievable during this check. The homepage confirms the event's field, location and dates, but not submission requirements. No 2027 deadline is newly verified here.
- The honours programme's exact submission length and assessment rubric have not been supplied in these sources. The proposed structure is a scientific framing recommendation, not a claim about university format requirements.

## What is the smallest defensible next step for reuse?

### Takeaway

The first step is a manuscript evidence package built from preserved artifacts. New simulations are only needed if the desired claim exceeds the historical evidence; revisiting the study does not itself authorize restarting archived runs.

### Cited Findings

- The archive guidance requires retaining original results unchanged and states that archived plans do not activate experiments. The current plan also requires fresh protocols and output paths for new experiments. [Archive rules](/home/sachin/Desktop/Research/Safety-Dial/archive/legacy/AGENTS.md:1), [current controls](/home/sachin/Desktop/Research/Safety-Dial/firstPrinciples.md:115).
- The SafeCEM note lists committed result JSON, replay states, figures and animations, and records that the original sweep used probe-based arena checking while current default code uses action-space checking. That distinction must survive any figure reuse or reproduction description. [Artifacts and provenance](/home/sachin/Desktop/Research/Safety-Dial/archive/legacy/notes/safeCEM.md:41).

### Inferences

- Reanalysis package: recover the historical configuration and artifact hashes; regenerate summary numbers from saved rows; distinguish per-step exposure from per-episode failure; pair hazard outcomes with block progress and arena exits; choose a representative trajectory figure by a stated rule; write one concise preliminary-experiment subsection with the corrected claim. This can establish a useful opening case without buying further compute.
- Keep the original d = 60 failure and repaired d = 60 result separate. Do not splice the repaired point into an otherwise differently constrained sweep and describe it as a single controlled frontier.
- If the user later wants a stronger dial result, propose and freeze a *new* small experiment with paired starts and goals, varied independent hazard layouts, one common arena guard, adequate seeds and an operating range where the margin changes attainable progress. Compare fixed margins with the proposed adaptive controller under the same objective, information and search budgets. This is future work, not an extension silently licensed by the old protocol.
- If the desired claim is evolutionary adapters rather than online planning, the persistent genotype and its observations/actions must be specified. Evaluate the resulting adapter on reserved cases without further fitting. Compare against a tuned fixed rule and parameter random search before attributing success to evolution; ordinary learning is also required under the current controls.
- Avoid adding a separate large LeWM research branch merely to strengthen the honours introduction. The preserved positive behavior and revealing failure already give a coherent mechanism-and-limitation example. Allocate new work to the active question that could distinguish optimizers.

### Gaps

- Artifact availability, completeness and saved-state semantics are being audited separately. If a saved representation is only sufficient for pose visualization, figure captions must not imply it is a validated physics replay.
