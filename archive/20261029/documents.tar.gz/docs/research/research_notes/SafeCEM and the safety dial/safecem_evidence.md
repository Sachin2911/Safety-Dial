# Archived SafeCEM and LeWM evidence

## What worked in the Push-T pilot

### Takeaway

The positive result the user remembers is the 20 September 2026 Push-T pilot: a
constraint-priority CEM planner using the frozen released LeWM avoided the supplied
pusher hazard while still moving the block close to its goal. The dial was a real,
interpretable clearance control, but the completed sample did not establish a
monotone safety-performance curve, reliable generalization, or an evolved adapter.

### Cited Findings

- All arms used the released `pusht/lewm` cost model, the same CEM planner, and a
  learned pusher-position probe. The runner loads the model in evaluation mode;
  the experiment changes candidate ranking, not LeWM weights. The probe has
  recorded train/test counts of 80,000/20,000 real latent observations, test RMSE
  3.034 px and radial p95 error 7.534 px. Its learning is distinct from CEM's
  action search. [Runner](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/experiments/scripts/safe_dial_pusht.py:130>),
  [recorded configuration and results](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/safeDial/results/results.json>).
- CEM optimizes sequences of actions. Defaults in the archived helper are 300
  candidate sequences, 30 iterations, 30 elites, five predicted blocks, five
  actions per block, and receding horizon one block. Both ranking arms use these
  defaults. This implies 9,000 candidate sequence scores per full solve, not
  9,000 simulator interactions; it is a configuration-derived count, not a
  retained all-in query ledger. [Planner construction](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/experiments/helpers/safeCEM.py:440>).
- The dial `d` expands the supplied hazard rectangle by `d` pixels when testing
  predicted pusher positions. Feasible candidates rank by goal cost; all
  infeasible candidates rank after feasible ones, using graded violation cost.
  If no feasible candidate exists, CEM still ranks the infeasible population.
  Thus this is a planning preference over predicted constraints, not a runtime
  safety guarantee. [Constraint calculation](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/experiments/helpers/safeCEM.py:118>),
  [ranking code](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/experiments/helpers/safeCEM.py:213>).
- The safety metric checks whether the **pusher centre** in each saved simulator
  state lies inside the true rectangle. It is not whole-object overlap or a
  continuous-time collision check. The endpoint task metric is Euclidean
  **block-centre error**, not full block-pose success. [Safety metric](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/experiments/helpers/linProbeHelpers.py:282>),
  [task metrics](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/experiments/helpers/hazardSweep.py:94>).
- The geometry was one fixed start/goal pair and one 100 by 100 px hazard,
  calibrated against the seed-0 unconstrained route. The block starts at
  (300,310), goal (360,310); the pusher starts at (40,40). The quick sweep uses
  three CEM seeds (0,1,2), penalty weights 0,0.1,1,10, and dials 0,20,40,60.
  This is a selected demonstration geometry, not a held-out geometry sample.
  [Configuration](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/safeDial/results/results.json>),
  [calibration and sweep](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/experiments/scripts/safe_dial_pusht.py:187>).

The following values were independently reconstructed on 25 October 2026 from all
30 saved main-sweep state arrays and checked against the JSON: hazard counts,
per-episode fractions, out-of-arena counts and final block errors all agree. Mean
and standard deviation of per-episode violation fractions agree with the saved
summaries. No simulation or model evaluation was run.
[JSON rows](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/safeDial/results/results.json>),
[saved states](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/safeDial/results/results_states.npz>).

| Setting, original probe-arena variant | Mean violating-state fraction, mean ± population SD | Final block-centre error, mean ± population SD (px) | Episodes with any hazard entry | Recorded terminal-success flags | Hazard states / saved states |
|---|---:|---:|---:|---:|---:|
| Penalty λ=0 | 0.1875 ± 0.0969 | 11.21 ± 0.58 | 3/3 | 2/3 | 22/131 |
| Penalty λ=0.1 | 0.0729 ± 0.0309 | 7.76 ± 2.14 | 3/3 | 2/3 | 8/116 |
| Penalty λ=1 | 0.0200 ± 0.0283 | 4.89 ± 1.71 | 1/3 | 2/3 | 3/121 |
| Penalty λ=10 | 0.01075 ± 0.01521 | 7.94 ± 2.40 | 1/3 | 3/3 | 1/109 |
| SafeCEM d=0 px | 0 | 9.05 ± 1.06 | 0/3 | 2/3 | 0/116 |
| SafeCEM d=20 px | 0 | 11.86 ± 1.95 | 0/3 | 3/3 | 0/101 |
| SafeCEM d=40 px | 0 | 6.66 ± 2.01 | 0/3 | 2/3 | 0/125 |
| SafeCEM d=60 px, failed arena variant | 0 | 60.00 ± 0.00 | 0/3 | 0/3 | 0/150 |

- Each row represents three episodes. The original report's shorthand of 50
  steps means a maximum: saved episodes contain 31 to 50 states. A mean of
  episode-level fractions is different from the pooled count fraction. The
  final column is an accounting denominator, not a count of independent trials.
  The standard deviations are descriptive dispersion across three seeds, not
  standard errors or confidence intervals. [Saved states](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/safeDial/results/results_states.npz>),
  [aggregation code](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/experiments/helpers/safeCEM.py:564>).
- The usable d=0,20,40 settings have zero recorded hazard entries across nine
  episodes and 342 states, **but seven of nine recorded terminal-success flags**.
  All nine moved the block: final displacement from its initial centre ranges
  from 48.87 to 70.28 px. This supports avoidance with engagement and useful
  task progress, not nine of nine successful completions. The three settings
  share the same seeds and geometry, so pooling them into a general reliability
  estimate would be misleading. [Per-episode rows](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/safeDial/results/results.json>),
  [saved states](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/safeDial/results/results_states.npz>).
- `success` is directly copied from `world.terminateds[0]`. Fields named
  `max_coverage` and `final_coverage` copy `world.rewards` first, and the saved
  values are negative. They must not be reported as physical coverage percentages.
  The historical metric names do not validate their semantics. The terminal
  flags above are reported with that qualification, not independently recertified
  benchmark successes. [Recorder](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/experiments/helpers/hazardSweep.py:37>),
  [metric code](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/experiments/helpers/hazardSweep.py:94>),
  [saved values](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/safeDial/results/results.json>).

### Inferences

- This is a suitable honours preliminary experiment: changing a small explicit
  constraint around a frozen learned planner changes its real behaviour without
  retraining the world model. It gives a concrete precursor to inference-time
  adapters and illustrates population search influenced by safety constraints.
- It does not isolate an evolutionary-optimizer advantage. Both comparison arms
  use CEM; the changed factor is the ranking rule and clearance. There is no
  outer-loop evolution of an adapter, and no matched parameter-random-search or
  ordinary-learning comparison. Those claims belong to a later experiment.
- The literal clearance knob works. The evidence does not make its values
  calibrated risk levels, prove monotone completion, or establish a full Pareto
  frontier. Zero observed events on three seeds is weak evidence of a low
  population event rate, especially on one chosen geometry.

### Gaps

- The pilot JSON does not retain a complete simulator/query/time ledger, exact
  upstream model revision or all planner parameters. The archived helper supplies
  defaults, but these do not replace a contemporaneous frozen-source manifest.
  The main sweep contains 1,221 saved states in 30 episodes; the paired arena
  follow-up contains 295 in six episodes. These are retained-state counts, not
  an all-in cost reconstruction: baseline calibration, probe learning, previous
  failed sweeps and other work are outside those counts.
- The executed upstream CEM solver was unavailable at the expected local checkout,
  so this review did not independently certify its final action-selection rule.
  Candidate-level feasibility diagnostics should not be promoted to a guarantee
  about the returned sequence.
- The probe's reported real-latent accuracy is not an imagined-trajectory guarantee.
  The archived notes report a much larger 35.5 px radial p95 at prediction depth
  five; this review did not independently recompute that notebook result.
  [Probe notes](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/notes/safeCEM.md:226>).

## Which corrections and later studies qualify the story

### Takeaway

The positive Push-T result survives, but two old interpretations do not: a penalty
weight did not inherently make the corrected task collapse, and zero hazard entries
at the largest original dial did not mean safe useful behaviour. Later LeWM studies
did not turn this small demonstration into validated general-purpose safe planning.

### Cited Findings

- The earliest penalty-collapse observation was confounded by placing the start
  inside the inflated hazard. With corrected geometry, increasing λ monotonically
  reduced mean hazard exposure, and both penalty arms had zero out-of-arena states.
  The λ=0 and λ=1 penalty-noarena rows equal their arena-constrained counterparts.
  Avoid the claim that penalties generally fail or every positive λ abandons the
  task. [Explicit historical correction](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/notes/safeCEM.md:100>).
- All original sweep settings used the **probe-based arena constraint**. At d=60,
  the pusher left the arena on 143/150 logged states (95.33%), the block moved
  zero pixels, and final block error remained 60 px in all three seeds. The
  planner nevertheless labelled about 80.6% of final-iteration candidates
  feasible. [Recorded configuration](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/safeDial/results/results.json>),
  [failure explanation](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/notes/safeCEM.md:122>).
- A paired follow-up tested the original and a corrected **action-space arena
  constraint** at d=60 on the same three seeds. The corrected variant uses
  current pusher position and decoded candidate commands to bound commanded
  positions. It produced zero out-of-arena and zero hazard states in 145 logged
  states; block errors were 9.43,15.82,24.76 px (mean 16.67), and block
  displacement 66.83,67.81,84.03 px. Every paired follow-up array was checked
  against its JSON metrics in this review. This is a real recovery of engagement,
  not a measured calibrated risk curve. [Paired results](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/safeDial/results/arena_fix.json>),
  [paired states](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/safeDial/results/arena_fix_states.npz>),
  [commanded-position calculation](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/experiments/helpers/safeCEM.py:82>).
- Across d=0,20,40, hazard exposure is flat at zero and block error is
  nonmonotone. The recorded feasible-candidate fraction falls from 0.974 to 0.964
  to 0.796, demonstrating that the knob changes the internal constraint. The
  archived notes explicitly state that the trade-off hypothesis was not
  demonstrated. Do not connect original d=0 and repaired d=60 as if they were
  an otherwise identical controlled sweep: arena implementation also changed.
  [Correction and dial limit](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/notes/safeCEM.md:112>),
  [variant provenance](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/notes/safeCEM.md:62>).
- The later Push-T v4 model-repair study failed its repair/retention gate on
  27 September; acquisition, transfer and conditional closed-loop SafeCEM stages
  were not launched. This is a different study and must not be presented as a
  successful extended dial validation. [Final v4 status](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/mainPlan/results/continuation-v4/README.md:1>).
- Walker LeWM S4 improved the saved dial-wide ranking summary after adaptation,
  but boundary-focused acquisition did not consistently beat random acquisition
  on the main test, and ordinary prediction retention regressed. These were
  open-loop prediction checks, not a closed-loop SafeCEM dial demonstration.
  [Walker results and limitations](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/mainPlan/reports/through-s4-20260927/report.md:375>).
- The subsequent Walker evolutionary study did have substantial completed
  evidence: 20 paired search seeds, 320 fresh final episodes, and reduced
  high-pressure failure from 29.56% to 22.36% with 99.04% progress retention.
  Its starting frozen controller failed at 16.88%, so the result was partial
  mitigation of optimization-induced harm, not improvement over the starting
  controller. This is scientifically useful but a separate narrative from the
  successful Push-T clearance demonstration. [Final evolutionary-study index](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/evoPlan/results/README.md:3>).
- Hopper/Walker Phase 0 used recovery search to distinguish benchmark termination
  from physical irreversibility. It was not the SafeCEM-LeWM dial. The apparent
  Hopper irrecoverable set disappeared under relaxed recovery definitions.
  [Archive distinctions](</home/sachin/Desktop/Research/Safety-Dial/archive/README.md:24>),
  [animation caveats](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/animations/README.md:51>).

### Inferences

- The strongest bridge to UNISafe is the coupled requirement of progress and
  safety, including awareness of where a learned safety estimate is valid. The
  d=60 failure makes that bridge concrete. Do not claim this pilot validates
  UNISafe's particular mechanism or that UNISafe fixes this exact failure.
- A coherent honours account can include the successful small mechanism and its
  failure boundary, then move to the more demanding adapter problem. Treating
  every historical LeWM stage as positive support would weaken that account.

### Gaps

- The paired arena-fix JSON does not preserve the terminal-success field, so no
  completion-rate claim for that follow-up should be inferred from its endpoint
  errors or its one shorter trajectory.
- No completed fresh-geometry/full-grid action-space SafeCEM replication was
  identified in the archived study index. The gate-geometry proposal in the old
  notes is a proposal, not an executed result or current launch instruction.

## What can be reused in the honours paper

### Takeaway

The saved evidence is sufficient for a carefully labelled exploratory opening
study now. A stronger dial or optimizer claim requires fresh, separately authorized
evaluation, not stronger language around the existing nine usable trajectories.

### Cited Findings

- The original report and source are available, but some headings overstate
  reliability (for example, "Safe CEM reaches zero; no weight does"). Use the
  corrected notes and raw rows to rewrite the section rather than copying its
  abstract or conclusion verbatim. [Report source](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/safeDial/latex/main.tex:325>),
  [corrected interpretation](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/notes/safeCEM.md:97>).
- Useful existing visuals are [trajectories.png](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/safeDial/latex/figures/trajectories.png>)
  and [arena_fix.png](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/safeDial/latex/figures/arena_fix.png>),
  both visually inspected in this review. The trajectory figure explicitly labels
  the d=60 breakdown and widened axes. Its caption needs seed/metric/variant
  provenance; a new figure from the saved states could present the original and
  repaired variants more cleanly without rerunning experiments.
- The existing [dial_response.png](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/docs/safeDial/latex/figures/dial_response.png>)
  was also visually inspected. It plots the failed original d=60 endpoint, labels
  the axis as "Task cost of conservatism", and overlays clearance d and weight λ
  on one numerical x-axis despite their different meanings. Do not reuse it as
  evidence of a calibrated trade-off. The similarly named animation has different
  provenance: its d=60 point uses the repaired variant. [Animation provenance](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/animations/README.md:32>).
- Ready-to-view examples are [dial sweep](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/animations/dial_sweep.mp4>),
  [penalty versus SafeCEM](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/animations/penalty_vs_safe_cem.mp4>),
  and [arena-failure and repair](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/animations/dial60_arena_escape.mp4>).
  The animation README states that these replay committed simulator states and
  distinguishes single-seed illustrations from three-seed summaries.
  [Animation source record](</home/sachin/Desktop/Research/Safety-Dial/archive/legacy/animations/README.md:9>).

### Inferences

- Reuse now: the frozen-model setup; literal pixel-clearance definition;
  correctly labelled endpoint/safety/engagement table; original-variant failure
  and paired arena repair; selected trajectory figures; the lesson that
  constraint-driven population planning can change behaviour around a fixed
  learned model.
- For the honours manuscript, a defensible claim is: "In an exploratory Push-T
  study, constraint-priority CEM around a frozen LeWM avoided the supplied hazard
  in all nine runs at three usable clearance settings while retaining substantial
  block motion. The largest original setting exposed an arena-validity failure,
  which a paired action-space constraint repair removed." The next paragraph
  should give the seven recorded terminal-success flags and distinguish them
  from the nine hazard-free trajectories.
- Fresh evaluation would be needed for: a monotone risk/completion dial;
  new-geometry generalization; a whole-pose safe-completion result; uncertainty
  over multiple geometries and optimization seeds; a consistently fixed repaired
  implementation across the full grid; or superiority of an evolutionary adapter
  over tuned fixed, random-search and ordinary-learning controls. These are
  requirements for stronger claims, not instructions to run archived jobs.

### Gaps

- This evidence review does not establish conference novelty or publication
  eligibility. It does establish exactly which archived measurements can support
  the proposed preliminary-study narrative.
