# LeWM safe progress: task 16 interpretation

26 October 2026. Evidence: [completed campaign](../../../progress/receipts/16-lewm-results.md),
[frozen final comparison](../../../progress/receipts/16-final-ab-v1.json) and
[full audit](../../../progress/receipts/16-final-audit.json).

Task 16 establishes a useful configuration lever in frozen LeWM planning. At the
hardest requested clearance on familiar layouts, safe completion rose from 3/36 to
34/36 in TwoRoom and from 0/36 to 33/36 in Reacher when canonical SafeCEM was replaced
with a tuned fixed configuration. The stronger fixed controller also performed well
on twenty fresh cases per environment: 238/240 TwoRoom and 218/240 Reacher, pooling
two margins. Neither fixed nor adaptive breached the requested clearance in those
960 combined evaluation episodes. Zero observed breaches is not a safety guarantee.

The ten-parameter feedback adapter did not establish a substantial advantage over
that comparator. It scored 240/240 in TwoRoom and 212/240 in Reacher. The main gap was
Reacher at 1.5 cm: 92/120 adaptive versus 99/120 fixed, a difference of -5.83 percentage
points with a pointwise 95% case-block interval of [-19.17, 7.50]. The small TwoRoom
gain and uncertain Reacher result are conditional on the selected controllers and
planner-seed panel. They do not establish equivalence or general failure of adaptation.

This was a completed development campaign rather than an abandoned engineering
screen. It repaired image-layout and recorder-reset errors, compared six mechanisms,
tested revised feedback and its fixed-base ablation, and completed both larger
evaluations. All 2,380 attempts are retained. The final adapter used nonbase modes in
197/348 TwoRoom and 347/348 Reacher episodes, so feedback was active in the final test.

The mechanism evidence narrows the story. Shorter imagination with more candidates
under the same predictor-work ceiling, and candidate retention with correlated
sampling, improved difficult-margin TwoRoom planning. Doubling canonical search alone
did not. These are combined interventions, not isolated causal estimates of horizon
or retention. The geometric reference has privileged goal information and remains a
diagnostic. The main planner uses visual task information with a privileged safety
checker; it is not a wholly image-based safety system.

For the honours thesis, the defensible contribution is a disciplined account of when
safe planning loses useful progress and how a compact configuration restores it,
including an honest test of whether runtime feedback adds value. This strengthens the
shared framing across LeWM, UNISafe and ManiGuard without requiring each front to show
the same mechanism or a positive adaptive effect. Their outcomes must remain separate,
since their tasks, monitors and information contracts differ.

For an evolutionary paper, task 16 supplies a stronger comparator and a warning
against crediting evolution for discovering an effective fixed horizon. No evolutionary
search or ordinary-learning comparison ran here. Any future optimizer claim needs
matched information and total interaction budgets, repeated independent searches,
and new evaluation cases. It must count counterfactual safety-check work as well as
executed actions. This campaign used 61,388 environment actions, 1.240 billion checker
physics integrations and 375.9 million learned predictor steps. The small rental bill
does not erase that computational distinction.

The remaining scientific question is whether feedback can identify and repair the
strict-clearance Reacher failures more reliably than the selected fixed controller.
The current study does not answer that positively, and it authorizes no additional run.
