# Paper spine and SafeCEM next steps

25 October 2026. Brainstorm after the SafeCEM re-audit; nothing here is authorized or frozen.

## The spine in one sentence

A frozen learned model or policy can be given a small, inspectable interface, and
search over that interface (population planning in SafeCEM, parameter evolution in
UNISafe, a controller in ManiGuard) changes safe task completion; when the search is
multi-objective, the set it returns is the safety dial.

That last clause is the "dial for free" idea, stated so it can be tested: a
single-objective search returns one setting, a multi-objective search returns a front
(safe-and-slow to fast-and-risky), and an operator choosing a point on that front is
the dial. The front is only "free" if the search needed to find the settings anyway.

## What each testbed contributes, honestly

| Testbed | Frozen thing | Interface searched | What is established | What is not |
| --- | --- | --- | --- | --- |
| SafeCEM, Push-T | LeWM world model | action sequences (CEM) under a clearance constraint d | explicit constraint ranking avoided the hazard 9/9 at d = 0, 20, 40 px; d = 60 exposed the probe validity failure and the action-space repair | no trade-off curve (exposure flat at zero, one layout), no evolution, no comparators on the dial |
| UNISafe, block plucking | pi0-style policy plus learned filter | 3 adapter parameters (delay, closing count, aperture) | completion 2/64 to 54/64; evolution tied fixed, random search and policy gradient | no optimizer advantage, no risk reduction (8/64 vs 6/64 violations) |
| ManiGuard Jar | pi0.5 VLA | retry, execution feedback, DSRL noise, execution knobs (tasks 3 to 8) | measured base rate and noise floor; retry and bounded feedback null | no lever yet; task 7 and 8 outcomes pending |

Rules that keep the spine honest: never pool safety rates across testbeds; each keeps
its own safety definition; "evolution" is only claimed where an outer evolutionary loop
actually ran (UNISafe, and anything new). CEM is population-based sampling with a
distribution update, which is fair to call population search, not evolution.

## Why a grid can beat "evolution gives you the dial"

With one or two interface parameters, a grid (task 9 is a 3 by 3 grid) produces the
same front as a multi-objective evolutionary algorithm at the same cost. Evolution
earns its place only when the interface has three or more parameters, or includes a
state-dependent rule, or episodes are expensive enough that a grid cannot cover it.
So any "dial for free" experiment must (1) use an interface bigger than a grid can
cover, and (2) compare front quality per episode budget (hypervolume, plus the front
itself) against grid and parameter random search, with at least three optimizer seeds.

## SafeCEM low-hanging fruit, cheapest first

Local workstation only: the venv has torch 2.13 with CUDA on the RTX 4070 laptop GPU
and `stable_worldmodel`. The `pusht/lewm` checkpoint and the expert HDF5
(`data/processed/pusht_expert_train.h5`) are no longer on disk, and the probe cache is
gone, so setup is a re-download plus probe retraining (an hour or two). Old timing:
about one second per CEM solve on a quiet machine, ten solves per 50-step episode, so
one to two minutes per episode. Any of these needs a new frozen protocol (task 10) with
fresh paths; the archived runner is copied, not run in place.

1. **Gate geometry, so the dial bites.** Two hazard boxes with a gap of width w on the
   planner's route; sweep d across w/2 with the action-space arena check throughout,
   ten seeds, full d grid. Report hazard entries, block error, steps to success and
   completion within 50 steps. Expected: exposure stays at zero while task cost rises
   once the gate closes. This turns the flat sweep into a measured trade-off curve and
   removes the single-layout objection. About 100 to 200 episodes, a few hours.
2. **Layout randomization.** Five to ten random gate positions and widths, same seeds
   per layout, reported per layout. Folds into item 1 at two to three times the cost.
3. **Clearance in uncertainty units.** Set d from the probe's error quantiles at
   prediction depth five (p50, p90, p95) instead of raw pixels, then report nominal
   versus realized avoidance. Gives the dial a probabilistic reading at no new cost
   beyond item 1.
4. **Multi-objective evolution of the constraint interface.** Genotype of three to five
   parameters: clearance, a time-varying clearance slope, planning horizon or action
   block, elite fraction. Objectives: exposure (minimize) and steps to success or block
   error (minimize). NSGA-II or a simple Pareto evolution strategy, versus grid and
   parameter random search at the same episode budget, three optimizer seeds, final
   front re-evaluated on unused seeds and layouts. Roughly 1,000 episodes, one to two
   days of local compute. This is the experiment that makes SafeCEM part of the
   evolutionary story and the same shape as task 9's conditional stage.
5. **Optional: a literal evolutionary planner.** Replace the CEM sampler with CMA-ES or
   a (mu, lambda) evolution strategy over action sequences, same constraint-priority
   ranking and candidate budget. Makes "evolution in planning" literal; the likely
   result is parity, which is still a clean statement.

Items 1 and 3 can share one protocol. Item 4 requires item 1's geometry, otherwise
there is nothing to trade.

## How this feeds the two papers

- Honours: SafeCEM (items 1 and 3 if done, else the audited pilot) opens the story,
  UNISafe plus task 9 supplies the measured adapter and its grid front, ManiGuard is
  the hard case with whatever tasks 7 and 8 return.
- GECCO: the central question becomes "does multi-objective evolution find a better
  safety-performance front per budget than grid and random search over compact
  interfaces around frozen models", tested on SafeCEM (item 4) and UNISafe (task 9's
  conditional stage). ManiGuard joins only if a lever appears. Two testbeds with the
  same method and matched budgets is a stronger GECCO shape than one testbed with
  unmatched demonstrations.
