# Evolution and learned steering of frozen VLAs

## What direct evolutionary VLA results are relevant?

### Takeaway

Direct evolutionary VLA precedents exist, so an evolutionary wrapper alone is not a sufficient novelty claim. The useful distinction is what search controls, what supplies its fitness, and whether the base action model remains frozen.

### Cited Findings

- **VLA-Pilot**, arXiv:2511.14178v1, 18 November 2025, performs inference-time evolutionary search over action proposals. GPT-4o produces scoring code from language, images and DINO/SAM-grounded keypoints. It starts with 32 proposals and performs ten evolutionary rounds, selecting elites and applying truncated noising/denoising. It reports mean manipulation success increasing from 0.31 to 0.62 for DiVLA and 0.30 to 0.60 for RDT-1B across six tasks, with 20 trials per method and task scenario. Those are manipulation-success results, not ManiGuard temporal-safety results. Its learned VLA weights remain frozen; the evolutionary population is regenerated during execution, rather than producing a compact learned controller. [Paper, methods and Tables I to III](https://arxiv.org/html/2511.14178v1)
- The VLA-Pilot project page reports approximately 2 to 4 times base inference latency and identifies keypoint grounding and MLLM latency as limitations. Its code link is still labelled “Coming soon” when checked on 24 October 2026. Thus a direct faithful reproduction is not currently an inexpensive code integration. [Author project page](https://rip4kobe.github.io/vla-pilot/)
- **Online-ES**, arXiv:2609.38855v1, 30 September 2026, perturbs generated action trajectories, executes them and uses outcome-weighted regression to update the action expert. Vision, depth and language modules remain frozen, but the action expert does not. The baseline is GR00T N1.5 augmented with depth features. The paper uses eight H100 GPUs for simulation and one for its real robot. LIBERO suite-average success changes from 0.948 to 0.972; a real bowl-grasp result changes from 32/100 to 54/100 after 150 adaptation steps. Its real baseline was first trained using 300 demonstrations. This is an actual evolutionary adaptation precedent but falls outside the current entirely frozen-policy premise and lean hardware assumption. [Paper, Algorithm 1 and Section V](https://arxiv.org/html/2609.38855v1)
- **Evolving Cache Schedules**, arXiv:2607.20293v1, 22 July 2026, evolves a complete cache-refresh schedule over transformer blocks and denoising timesteps. It targets inference efficiency while maintaining rollout performance, reporting up to 8.05 times action-generation speedup. This establishes evolutionary optimization around a frozen diffusion policy, but its objective is different from improving safe requested completion. [Paper](https://arxiv.org/html/2607.20293v1), [official implementation](https://github.com/pillom/EVO)

### Inferences

- VLA-Pilot's useful lesson is to search a behaviorally meaningful space with an informative evaluator. Transplanting its optimizer without its grounding and reward machinery would omit the part that makes candidate ranking useful.
- An MLLM's assessment of a candidate joint trajectory is not a demonstrated predictor of whether a lid closes before lift or whether contact tips the jar. Building this verifier would become a separate research project.
- Online-ES is useful related work but cannot be presented as a drop-in frozen-pi0.5 baseline. Cache scheduling is an alternative project about efficiency, not a shortcut to the present safety objective.

### Gaps

- I did not establish a reliable equal-inference-budget evolutionary ablation for VLA-Pilot from the accessible text. Its results therefore do not establish that its evolutionary component alone explains all gains over its baselines.
- None of these verified studies establishes temporal-specification-safe Jar completion, or justifies a global “first evolutionary frozen VLA” claim.

## What learned frozen-policy interfaces already work?

### Takeaway

DSRL provides the strongest mature baseline for a learned noise controller. Flow Reversal Steering provides a particularly relevant new way to make noise coordinates meaningful, with explicit experiments on frozen pi0.5 and an absolute-joint-control embodiment.

### Cited Findings

- **DSRL**, arXiv:2506.15799v1, 18 June 2025, learns an observation-conditioned noise policy at each policy query, treating the frozen decoder as an action transformation. Its pi0 experiments use SAC with learned visual actor and critic encoders, sparse success-based rewards, and a noise vector repeated across the chunk. The pi0 toaster experiment trains for 80 episodes, about 11,000 reported steps, and improves from 5/20 to 18/20 evaluation successes. Spoon placement trains for 65 episodes, about 10,000 steps, and changes from 15/20 to 19/20. A separate small diffusion-policy cube experiment changes from 2/10 to 9/10 after approximately 40 online episodes. These are different experiments and must not be combined into one pi0 sample-efficiency claim. The original pi0 actor outputs 32 noise coordinates repeated across the chunk, rather than the archived four-dimensional random basis. [Paper, Sections 5.4, 5.5 and Appendix C.5](https://arxiv.org/html/2506.15799v1)
- The official DSRL pi0 repository provides a JAX implementation for LIBERO, Aloha and real Franka use, and identifies the publication as CoRL 2025. This is a more mature implementation starting point than the current FRS or VLA-Pilot project pages. Its code is not already integrated with ManiGuard. [Official DSRL repository](https://github.com/nakamotoo/dsrl_pi0)
- **Flow Reversal Steering (FRS)**, arXiv:2606.13675v1, 11 June 2026, maps coarse reference actions backward through a frozen flow model and then denoises them. It explicitly uses pi0.5. The paper's DROID interface converts Cartesian commands to seven absolute joint targets plus a gripper target through IK. With exact integration the reference would be reconstructed; useful refinement is empirical with finite integration, typically ten steps each way. On 11 of 42 LIBERO tasks with native success at most 2%, zero-shot FRS improves success by at least ten percentage points. Its small noise policies can be trained by behavior cloning, called DSBC, or SAC. Real-world DSBC uses ten successful human-steered trajectories per task and reports an average 60-percentage-point gain across six selected tasks. Its one-minute training claim excludes acquiring those trajectories and running the frozen VLA. [Paper, Sections 4 to 5 and Appendix D.1](https://arxiv.org/html/2606.13675v1)
- FRS has three distinct uses: direct human/VLM steering, distillation into a small noise policy, and bootstrapping DSRL. These preserve the base policy weights. The project page still labels code “Coming soon.” Coarse guidance chooses motion directions; it does not supply a temporal-safety guarantee. [Author FRS project page](https://flow-reversal-steering.github.io/)
- **Probe, Learn, Distill (PLD)**, arXiv:2511.00091v1, 30 October 2025, first trains residual RL specialists around a frozen VLA, then collects hybrid trajectories and distills them into the generalist with supervised fine-tuning. Its final headline performance therefore includes changing the generalist. The initial residual specialist is relevant as a controller baseline; the final distilled model answers a different question. [Paper](https://arxiv.org/html/2511.00091v1), [author project page](https://wenlixiao.com/self-improve-VLA-PLD)

### Inferences

- The literature supports learning which actions to elicit in each observation. A single global scalar cannot test the whole capability of an observation-conditioned interface. Requiring every future learned controller to be preceded by a successful global scalar is too strong: context-dependent corrections can cancel when averaged under one fixed setting.
- DSRL is an essential ordinary-learning comparison if the project returns to latent steering. Replacing SAC with an EA is a testable comparison, but is not intrinsically a contribution. The EA must earn its place through physical sample efficiency, held-out performance, robustness of selection, or another measured property.
- FRS is promising because it replaces an arbitrary noise direction with the inverse image of a proposed movement. This is a different representation hypothesis from the archived controller, whose bounded arm-supported random basis had no direct gripper coordinate.
- FRS uses the same frozen velocity field in both directions, reversing integration order and sign for the inverse pass. There is no new learned denoiser or safety verifier. The paper compares FRS against directly executing the same coarse VLM references and reports better aggregate performance for FRS, but this does not establish the same benefit on Jar. Its empirical finite-step refinement must not be called a mathematically guaranteed projection. [FRS Sections 4.1 and 5.2](https://arxiv.org/html/2606.13675v1)
- FRS also reduces one conceptual mismatch: the published DROID interface already addresses absolute joint targets. Porting still requires the exact ManiGuard checkpoint transforms, masks, normalization, padding and joint conventions. LIBERO Cartesian delta actions must not be pasted into Jar's absolute targets.
- Online FRS needs both reversal and denoising, roughly two velocity-field integration passes instead of one, plus any reference generator. This is an operation-count inference, not a measured twofold wall-time estimate. Distilling a noise policy could remove reversal and a VLM from deployment, but adds data collection and training costs.
- A direct bounded residual policy is a credible fallback with clear control authority. Its main danger is destroying coordinated motion, and the task is already contact-sensitive. Residual RL is a serious comparator, not a weak baseline to add at the end.

### Gaps

- These papers measure completion, not Jar closure-before-carry plus no violation. No claimed success improvement transfers automatically to safe requested completion.
- The pi0.5-specific DSRL evidence here comes through FRS's experiments. The older original DSRL paper tests pi0, not pi0.5.
- There is no verified local cost for a faithful DSRL or FRS port. “Steps” in these papers must be reconciled with simulator controls, chunk decisions and gradient updates before budgeting.
- FRS's gains on selected difficult tasks and human-guided real trajectories are not evidence that an autonomous compact controller will produce equally good reference actions in Jar.

## Which direction should Safety-Dial test next?

### Takeaway

My strategic recommendation is to learn a **compact observation-conditioned correction policy on one validated interface**, rather than making a global scalar the prerequisite for all learning. For an immediate lean engineering purchase, bounded residual feedback has the clearest actuator authority and easiest audit. DSRL is the most mature latent alternative. FRS is a worthwhile bounded offline challenger that could justify a more ambitious action-informed latent representation, but missing code and unvalidated finite-step refinement prevent ranking it unequivocally above direct residual feedback for the next physical run.

### Cited Findings

- The current project requires a useful intervention, stable evaluation and matched optimizer comparisons, while retaining frozen base policies, both success definitions and untouched reserved tasks. [Current plan](../../../../firstPrinciples.md), [research controls](../../../../AGENTS.md)
- The archived pilot did not isolate a failure of all noise steering: its small bounded random-basis controller, sparse fitness and tiny checking panels produced no requested completion. [Historical audit](../../../../archive/20261022/reports/Recent%20ManiGuard%20progress%20audit.md)
- The recent retry experiment is a null result for its fixed detector and retreat. It does not measure the capacity of the learned interfaces above. [Task 3 results](../../../../progress/receipts/03-results.md)

### Inferences

The following is a proposal, not a new frozen protocol or authority to launch compute.

1. **Run an interface test before a search.** Use a prospectively selected collection of development-only observations around approach, closure and regrasp. Preserve complete images, robot state, prompts and native action proposals. At identical requests compare native samples, the old type of random-direction perturbation, and action-informed reference motions mapped through FRS. Include defer-to-native, small Cartesian directions converted through robot kinematics, and explicit gripper alternatives. Evaluate whether the executed prefix reliably changes in the intended direction, whether the gripper is controllable, and what extra model computation is required. This asks whether the search representation expresses the repair, not whether an optimizer can discover it.

2. **Make the first physical diagnostic interpretable.** If the offline FRS challenger qualifies, compare native, direct reference corrections and FRS-refined versions of the same corrections on new development seeds. Include simple smoothing of the same reference if the supposed advantage could be smoothing. Fix integration count prospectively. A fixed observable trigger can initially be used solely to test a mechanism; alternatively a short recorded human-guided diagnostic can test an upper bound on useful authority. Human/VLM guidance is extra information and must be separately labelled and charged. Keep full safety and completion scoring. Require useful physical behavior on several development tasks, rather than declaring victory from changed decoder outputs. A modest first pilot can reject obvious failures; it cannot resolve a ten-point effect precisely. If FRS does not qualify, carry the direct residual interface forward instead.

3. **Then learn one compact controller on that interface.** A small observation-conditioned selector or gate decides when to defer and which correction to request. Start with the smallest representation justified by the interface test. Do not evolve an arbitrary large network merely because evolution supports it. If visual features are used, expose the same frozen features to random-search and ordinary-learning comparators. A finite repertoire of meaningful corrections can make the search question more interpretable than hundreds of unconstrained policy weights.

4. **Frame the EC question around search geometry and cost.** A plausible claim to test is: action-informed coordinates let evolutionary search discover controllers that improve temporal-specification-safe completion more efficiently than random coordinates or independently sampled candidates, under the same physical interaction ceiling. Separate the representation comparison from the optimizer comparison. Compare native, a tuned fixed policy, random search and a competent DSRL-style learner on the same controller interface and initialization information. Use independent optimizer runs and final reserved tasks. If the EA loses to SAC or random search, retain the useful representation result and report the optimizer result honestly.

5. **Stop early for the right reason.** Stop the FRS route if its correct implementation cannot express useful arm/gripper alternatives within a predeclared reference bound, if it offers no advantage over executing the same reference directly, or if the required inference/data cost cannot fit a credible comparison. If useful behavior exists but the initial rate intervals are wide, call the experiment inconclusive rather than declaring no effect. If a large learned controller is required before any benefit appears, reconsider whether the project remains compact enough for its budget.

This direction does not eliminate validation. It changes what gets validated: a literature-backed, context-dependent interface capable of expressing a repair, followed by the evolutionary learning question. Task 4's identity, recording, accounting and contemporary control work remains valuable infrastructure, but the twelve-arm screen need not be treated as the inevitable next scientific experiment. The ordering between direct residual feedback and FRS should follow demonstrated control authority and integration cost, not the novelty of the paper title.

### Gaps

- The useful bound, controller features, final genotype size, minimum effect and total interaction ceiling still need to be chosen from the interface and throughput measurements. They should not be fabricated from paper headlines.
- I cannot promise that action-informed latent steering works on Jar or is globally novel. Novelty would rest on the demonstrated safety result, representation evidence and fair EC comparison, not on naming this combination.
